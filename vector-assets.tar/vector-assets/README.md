# vector-assets

Icon With Text
---
![Icon With Text](/bcbstx.svg)

Icon Only
---
![Icon Only](/bcbs_icon.svg)
