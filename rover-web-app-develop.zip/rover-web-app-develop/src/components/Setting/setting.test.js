import React from 'react';
import { configure, shallow } from 'enzyme/build';
import Adapter from 'enzyme-adapter-react-16/build';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import ThemeReducer, {
  CHANGE_THEME_TO_DARK,
  CHANGE_THEME_TO_LIGHT, changeThemeToLight, changeThemeToDark
} from '../../store/Theme';
import { Setting } from './setting';

// for enzyme to work
configure({ adapter: new Adapter() });

let component = null;

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();

const baseProps = {
  setThemeLight: jest.fn(),
  setThemeDark: jest.fn()
};

describe('Setting component', () => {
  beforeEach(() => {
    component = shallow(<Setting {...baseProps} />);
  });

  describe('Changes call the setTheme functions correctly', () => {
    it('Should call setThemeLight when press light theme button press ', () => {
      const click = component.find('#lightThemeButton');
      click.simulate('click');
      expect(baseProps.setThemeLight).toHaveBeenCalled();
    });

    it('Should call setThemeDark when press light theme button press ', () => {
      const click = component.find('#darkThemeButton');
      click.simulate('click');
      expect(baseProps.setThemeDark).toHaveBeenCalled();
    });
  });
});

describe('Redux Store for Theme', () => {
  beforeEach(() => {
    store = mockStore();
  });
  describe('Theme Store Actions', () => {
    it('should create an action to set light theme', () => {
      const expectedAction = {
        type: CHANGE_THEME_TO_LIGHT
      };
      expect(changeThemeToLight()).toEqual(expectedAction);
    });

    it('should create an action to set dark theme', () => {
      const expectedAction = {
        type: CHANGE_THEME_TO_DARK
      };
      expect(changeThemeToDark()).toEqual(expectedAction);
    });
  });

  describe('Theme Reducer', () => {
    it('should return the initial state', () => {
      const initialState = {
        className: ''
      };
      expect(ThemeReducer(initialState, {})).toEqual({
        className: ''
      });
    });

    it('should handle CHANGE_THEME_TO_LIGHT', () => {
      expect(ThemeReducer({}, { type: CHANGE_THEME_TO_LIGHT }))
        .toEqual({
          className: 'theme-light'
        });
    });
    it('should handle CHANGE_THEME_TO_DARK', () => {
      expect(ThemeReducer({}, { type: CHANGE_THEME_TO_DARK }))
        .toEqual({
          className: 'theme-dark'
        });
    });
  });
});
