import React from 'react';
import PropTypes from 'prop-types';
import { Button } from 'react-bootstrap';
import { connect } from 'react-redux';
import { changeThemeToDark, changeThemeToLight } from '../../store';

export const Setting = (props) => {
  const { setThemeLight, setThemeDark } = props;

  return (
    <div>
      <Button variant='light' id='lightThemeButton' onClick={setThemeLight}>Light Theme</Button>
      <Button variant='dark' id='darkThemeButton' onClick={setThemeDark}>Dark Theme</Button>
    </div>
  );
};

export const mapDispatchToProps = dispatch => ({
  setThemeLight: () => dispatch(changeThemeToLight()),
  setThemeDark: () => dispatch(changeThemeToDark())
});

Setting.propTypes = {
  setThemeLight: PropTypes.func,
  setThemeDark: PropTypes.func
};

export default connect(null, mapDispatchToProps)(Setting);
