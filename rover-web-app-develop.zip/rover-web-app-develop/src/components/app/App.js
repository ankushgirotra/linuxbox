import React, { Component } from "react";
import "./App.css";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { withRouter } from "react-router";
import moment from 'moment';
import {
  setUserInfoThunk,
  setConfigsThunk,
  setPortfoliosThunk,
  setLocationsThunk,
  setProductsThunk,
  setApplicationsThunk,
  setSkillsThunk,
  setRolesThunk,
  setTitlesThunk,
  setDegreesThunk,
  setResourceTypesThunk,
  refreshThunk,
  userInformationThunk
} from "./../../store";
import Router from "./Route/Routes";
import "bootstrap/dist/css/bootstrap.css";
import "../../scss/app.scss";
import ScrollToTop from "./ScrollToTop";

import cookie from "react-cookies";
import {
  switchToRRC,
  switchToSOG,
  switchToSUITE,
  switchToSkillsCentral,
  switchToPCDM,
  switchToTimesheet,
  switchToVendorPortal,
  switchToTD360,
} from "../../store/Apps";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      loaded: false,
    };
    this.isIE = !!document.documentMode;
    this.isEdge = !this.isIE && !!window.StyleMedia;
  }

  componentDidMount = async () => {
    const {
      setUserInfo,
      setAppToRRC,
      setAppToSOG,
      setAppToSkillsCentral,
      setAppToSUITE,
      location,
      setPortfolios,
      setProducts,
      setApplications,
      setLocations,
      setSkills,
      setRoles,
      setTitles,
      setDegrees,
      setResourceTypes,
      setAppToPCDM,
      setAppToTimesheet,
      setAppToVendorPortal,
      setAppToTD360,
      refreshThunk,
      setEmployeeId
    } = this.props;
    if (this.isEdge || this.isIE) {
      this.showalert();
    } else {
      await this.props.setConfigs(); // responsible for setting configs in cookie
      // need the following cookies before making any axios calls
      const userNameL = localStorage.getItem("username")
      if (!cookie.load("ROVER_WEB_API")) {
        window.location.reload(); 
      }
      if(window.performance){
        console.log("code here")
        if(performance.navigation.type===1){
          await setEmployeeId(userNameL);
        }
      }
      const accessToken = window.localStorage.getItem("token");
      const token = window.sessionStorage.getItem("token")
      const username = window.sessionStorage.getItem("username")
      try {
        if (accessToken && token) {
          await setUserInfo();
        }
        if (accessToken && token && username) {
          await setEmployeeId(username);
        }
      } catch (error) {
        console.error(error);
        window.localStorage.clear();
      }
      
      this.setState({ loading: false });
      setTimeout(() => this.setState({ loaded: true }), 500);

      if (location.pathname.includes("/rrc")) {
        setAppToRRC();
      } else if (location.pathname.includes("/sog")) {
        setAppToSOG();
      } else if (location.pathname.includes("/skillscentral")) {
        setAppToSkillsCentral();
      } else if (location.pathname.includes("/pcdm")) {
        setAppToPCDM();
      } else if (location.pathname.includes("/timesheet")) {
        setAppToTimesheet();
      } else if (location.pathname.includes("/vendorportal")) {
        setAppToVendorPortal();
      } else if (location.pathname.includes("/td360")){
        setAppToTD360();
      }else {
        setAppToSUITE();
      }
      try {
        if (accessToken) {
          await setPortfolios();
          await setProducts();
          await setApplications();
          await setLocations();
          await setSkills();
          await setRoles();
          await setTitles();
          await setDegrees();
          await setResourceTypes();
          const expires_in = localStorage.getItem("expires_in");
          let expiry_ms = (expires_in - 120) * 1000
          setInterval(() => refreshThunk(), expiry_ms);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };

  componentDidUpdate(prevProps, prevState, snapshot) {
    const {
      location,
      setAppToSUITE,
      setAppToRRC,
      setAppToSOG,
      setAppToSkillsCentral,
      setAppToPCDM,
      setAppToTimesheet,
      setAppToVendorPortal,
      setAppToTD360,
    } = this.props;
    if (prevProps.location !== location) {
      if (location.pathname.includes("/rrc")) {
        setAppToRRC();
      } else if (location.pathname.includes("/sog")) {
        setAppToSOG();
      } else if (location.pathname.includes("/skillscentral")) {
        setAppToSkillsCentral();
      } else if (location.pathname.includes("/pcdm")) {
        setAppToPCDM();
      } else if (location.pathname.includes("/timesheet")) {
        setAppToTimesheet();
      } else if (location.pathname.includes("/vendorportal")) {
        setAppToVendorPortal();
      } else if (location.pathname.includes("/td360")){
        setAppToTD360();
      }else {
        setAppToSUITE();
      }
    }
  }

  showalert = () => {
    alert('Please use Chrome to log in to Rover. \nPress "OK" to redirect to FYIBlue.');
    window.location.href = "https://myfyi.sharepoint.com/sites/intranet";
  };

  render() {
    const { loaded, loading } = this.state;
    return (
      <div>
        {!(this.isEdge || this.isIE) && !loading ? (
          <ScrollToTop>
            <div>
              {!loaded && (
                <div className={`load${loading ? "" : " loaded"}`}>
                  <div className="load__icon-wrap">
                    <svg className="load__icon">
                      <path fill="#4ce1b6" d="M12,4V2A10,10 0 0,0 2,12H4A8,8 0 0,1 12,4Z" />
                    </svg>
                  </div>
                </div>
              )}
              <div>
                <Router />
              </div>
            </div>
          </ScrollToTop>
        ) : (
            <div />
          )}
      </div>
    );
  }
}

export const mapStateToProps = (state) => ({
  portfolios: state.RequestResourceReducer.portfolios,
  products: state.RequestResourceReducer.products,
  applications: state.RequestResourceReducer.applications,
  locations: state.FieldsReducer.locations,
  roles: state.FieldsReducer.roles,
  skills: state.FieldsReducer.skills,
  titles: state.FieldsReducer.titles,
  degrees: state.FieldsReducer.degrees,
  resourceTypes: state.FieldsReducer.resourceTypes,
  invalidInfo: state.AuthReducer.errorAuth,
  isAuthenticated: state.AuthReducer.isAuthenticated,
  user: state.AuthReducer.user,
});

export const mapDispatchToProps = (dispatch) => ({
  setPortfolios: () => dispatch(setPortfoliosThunk()),
  setProducts: () => dispatch(setProductsThunk()),
  setApplications: () => dispatch(setApplicationsThunk()),
  setLocations: () => dispatch(setLocationsThunk()),
  setSkills: () => dispatch(setSkillsThunk()),
  setRoles: () => dispatch(setRolesThunk()),
  setTitles: () => dispatch(setTitlesThunk()),
  setDegrees: () => dispatch(setDegreesThunk()),
  setResourceTypes: () => dispatch(setResourceTypesThunk()),
  setUserInfo: () => dispatch(setUserInfoThunk()),
  setConfigs: () => dispatch(setConfigsThunk()),
  setAppToRRC: () => dispatch(switchToRRC()),
  setAppToSOG: () => dispatch(switchToSOG()),
  setAppToSkillsCentral: () => dispatch(switchToSkillsCentral()),
  setAppToSUITE: () => dispatch(switchToSUITE()),
  setAppToPCDM: () => dispatch(switchToPCDM()),
  setAppToTimesheet: () => dispatch(switchToTimesheet()),
  setAppToVendorPortal: () => dispatch(switchToVendorPortal()),
  setAppToTD360: () => dispatch(switchToTD360()),
  refreshThunk: () => dispatch(refreshThunk()),
  setEmployeeId: (username) => dispatch(userInformationThunk(username))
});

App.propTypes = {
  setProducts: PropTypes.func,
  setPortfolios: PropTypes.func,
  setApplications: PropTypes.func,
  setResourceTypes: PropTypes.func,
  setRoles: PropTypes.func,
  setLocations: PropTypes.func,
  setSkills: PropTypes.func,
  setTitles: PropTypes.func,
  setDegrees: PropTypes.func,
  setUserInfo: PropTypes.func,
  location: PropTypes.object,
  setAppToRRC: PropTypes.func,
  setAppToSOG: PropTypes.func,
  setAppToSkillsCentral: PropTypes.func,
  setAppToSUITE: PropTypes.func,
  setAppToTimesheet: PropTypes.func,
  setAppToVendorPortal: PropTypes.func,
  setAppToTD360: PropTypes.func,
  setConfigs: PropTypes.func,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));
