import React, { useEffect, useState} from 'react';
import moment from 'moment'
import {
    DEFAULT_MSG_MODAL_CONFIG,
    MessageModal,
} from "../apps/pcdm/src/components/MessageModal/messageModal"
import { ACTIONS } from "../apps/pcdm/src/constants/action.constants";


export default function IdleTimeOutHandler(props){
    const[showModal,setShowModal]=useState(false)
    const[isLogout,setLogout]=useState(false)
    let timer=undefined;
    let autoLogOutTimer = undefined;
    const events= ['click','load','keydown', 'scroll']
    const [messageModalConfig, setMessageModelConfig] = useState({ ...DEFAULT_MSG_MODAL_CONFIG })

    const eventHandler =(eventType)=>{
        if(!isLogout){
            localStorage.setItem('lastInteractionTime',moment() )
            if(timer){
                // props.onActive();
                startTimer();
            }
            if(autoLogOutTimer){
                startAutoLogoutTimer();
            }
        }
    };
    
    useEffect(()=>{
        addEvents();
        return (()=>{
            removeEvents();
            clearTimeout(timer);
            clearTimeout(autoLogOutTimer);
        })
    })
    
    const startTimer=()=>{
        if(timer){
            clearTimeout(timer)
        }
        timer=setTimeout(()=>{
            let lastInteractionTime=localStorage.getItem('lastInteractionTime')
            const diff = moment.duration(moment().diff(moment(lastInteractionTime)));
            let timeOutInterval=props.timeOutInterval?props.timeOutInterval:3600000;
            if(isLogout){
                clearTimeout(timer)
            }else{
                if(diff._milliseconds<timeOutInterval){
                    startTimer();
                    // props.onActive();
                }else{
                    // props.onIdle();
                    // setShowModal(true)
                    setMessageModelConfig({
                        ...messageModalConfig,
                        message: 'Your session is Timed Out. You want to stay?',
                        variant: ACTIONS.YES_NO,
                        visible: true,
                        title: 'You Have Been Idle!!',
                        onClose: handleClose,
                        dialogClassName: 'save-changes-model'
                    })
                }
            }
            
        },props.timeOutInterval?props.timeOutInterval:300000)
    }
    const startAutoLogoutTimer=()=>{
        if(autoLogOutTimer){
            clearTimeout(autoLogOutTimer)
        }
        autoLogOutTimer=setTimeout(()=>{
            let lastInteractionTime=localStorage.getItem('lastInteractionTime')
            const diff = moment.duration(moment().diff(moment(lastInteractionTime)));
            let timeOutInterval=props.timeOutInterval?props.timeOutInterval:36000000;
            if(isLogout){
                clearTimeout(autoLogOutTimer)
            }else{
                if(diff._milliseconds<timeOutInterval){
                    startAutoLogoutTimer();
                    // props.onActive();
                }else{
                    handleLogout()
                }
            }
            
        },props.timeOutInterval?props.timeOutInterval:36000000) //10hours
    }
    
    const addEvents=()=>{
        
        events.forEach(eventName=>{
            window.addEventListener(eventName,eventHandler)
        })
        
        startTimer();
        startAutoLogoutTimer();
    }
    
    const removeEvents=()=>{
        events.forEach(eventName=>{
            window.removeEventListener(eventName,eventHandler)
        })
    };
    
    const handleClose = (action, data)=>{
        if (action === ACTIONS.YES) {
            handleContinueSession()
            setMessageModelConfig({
                visible: false,
            })
        } else if(action === ACTIONS.NO){
            handleLogout()
            setMessageModelConfig({
                visible: false,
            })
        }

    }
    const handleContinueSession = ()=>{
        setShowModal(false)
        setLogout(false)
        
    }
    const handleLogout = ()=>{
        removeEvents();
        clearTimeout(timer);
        clearTimeout(autoLogOutTimer)
        setLogout(true)
        // props.onLogout();
        setShowModal(false)
        window.localStorage.removeItem("token")
        window.localStorage.removeItem("emplyoee_id")
        window.location.reload()
        
    }
    
    return(
        <div>
        
            {/* <MessageModal {...messageModalConfig} /> */}
        
        </div>
        )
        
    }