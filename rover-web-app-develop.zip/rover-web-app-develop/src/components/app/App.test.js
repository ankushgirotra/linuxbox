import React from 'react';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import Enzyme, { shallow } from 'enzyme/build';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import App from './App';

import mockAxios from 'axios';
import { setConfigsThunk } from '../../store';

// for enzyme to work with react 16 and up
Enzyme.configure({ adapter: new EnzymeAdapter() });

// This is to set up mock store for redux
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
const store = mockStore();

const baseProps = {
  loading: true,
  loaded: false,
  setUserInfoThunk: jest.fn(),
  setConfigsThunk: jest.fn(),
  setPortfoliosThunk: jest.fn(),
  setLocationsThunk: jest.fn(),
  setProductsThunk: jest.fn(),
  setApplicationsThunk: jest.fn(),
  setSkillsThunk: jest.fn(),
  setRolesThunk: jest.fn(),
  setTitlesThunk: jest.fn(),
  setDegreesThunk: jest.fn(),
  setResourceTypesThunk: jest.fn()
};

let component = null;

describe('App component', () => {
  beforeEach(() => {
    component = shallow(<App {...baseProps} store={store} />);
  });

  describe('Snapshot tests (display)', () => {
    it('Display App Component', async () => {
      const componentToSnapshot = shallow(
        <App {...baseProps} />
      ).debug();
      expect(componentToSnapshot).toMatchSnapshot();
    });
  });

  describe('Redux Store for App Component', () => {
    beforeEach(() => {
      console.error = jest.fn();
    });
    describe('Middleware', () => {
      it('setConfigsThunk performs Axios GET request to "/configs" endpoint', async () => {
        mockAxios.get.mockImplementationOnce(() => Promise.resolve());
        await store.dispatch(setConfigsThunk());
        expect(mockAxios.get).toHaveBeenCalledWith('/configs');
      });
    });
  });
});
