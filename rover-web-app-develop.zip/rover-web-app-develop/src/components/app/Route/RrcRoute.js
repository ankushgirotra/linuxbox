import React from "react";
import { Route, Switch } from "react-router-dom";
import ResourceForm from "../../apps/rrc/src/component/addResourceForm/addResourceFormRRC";
import ViewResources from "../../apps/rrc/src/component/ViewResources/viewResourcesRRC";
import RequestDrafts from "../../apps/rrc/src/component/requestDrafts/requestDraftsRRC";
import AdminUpload from "../../apps/rrc/src/component/adminUpload/adminUploadRRC";
import RequestTemplates from "../../apps/rrc/src/component/requestTemplates/requestTemplatesRRC";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import DashboardRRC from "../../apps/rrc/src/component/dashboard/dashboardRRC";
import RequestIndexPage from "../../apps/rrc/src/views/index";
import RequestFormIndex from "../../apps/rrc/src/views/RequestForm/requestFormIndex";
import requestDetailsHome from "../../apps/rrc/src/views/RequestDetailsHome/requestDetailsHome";

import { properties } from "../../../properties";
import PropTypes from "prop-types";
import Admin from './../../apps/rrc/src/views/Admin/admin';

const getUploadRoute = (props) => {
  if (props.user && properties.authorizedUploaders.includes(props.user.id)) {
    return <Route exact path="/rrc/admin/upload" component={AdminUpload} />;
  }
};
export const RrcRoutes = (props) => (
  <Switch>
    <Route exact path="/rrc" component={RequestIndexPage} />
    <Route exact path="/rrc/create-request" component={RequestFormIndex} />
    <Route exact path="/rrc/request-details" component={requestDetailsHome} />
    {/* <Route exact path="/rrc/admin" component={Admin} /> */}
    <Route exact path="/rrc/admin/external-blockers" component={Admin} />
    <Route exact path="/rrc/admin/email-notification" component={Admin} />
    {/* <Route exact path="/rrc/resourceform" component={ResourceForm} />
    <Route exact path="/rrc/viewresources" component={ViewResources} />
    <Route exact path="/rrc/requestdrafts" component={RequestDrafts} />
    <Route exact path="/rrc/requesttemplates" component={RequestTemplates} />
    {getUploadRoute(props)} */}
    <Route component={NotFoundPage} />
  </Switch>
);

RrcRoutes.propTypes = {
  user: PropTypes.object,
};
