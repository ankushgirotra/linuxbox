import React, { Component } from "react";
import PropTypes from "prop-types";
import { Route, Switch, Redirect, withRouter, Prompt } from "react-router-dom";
import { connect } from "react-redux";
import Login from "../../login/login";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import Dashboard from "../../dashboard/dashboard";
import Layout from "../../layout";
import MainWrapper from "../MainWrapper";
import Setting from "../../Setting/setting";
import { SogRoutes } from "./SogRoute";
import { RrcRoutes } from "./RrcRoute";
import SkillsCentralRoutes from "./SkillsCentralRoute";
import PcdmRoutes from "./PcdmRoute";
import { AdminPageRoute } from "./AdminPageRoute";
import { PCDM_ROUTES } from "./constants/pcdmRoutes.constants";
import { SUITE_ROUTES } from "./constants/suiteRoutes.constants";
import { TIMESHEET_ROUTES } from "./constants/timesheetRoutes.constants";
import { VendorPortalRoutes } from "./VendorPortalRoute";
import  { TD360Routes } from "./TD360Route";
import TimesheetRoutes  from "./TimesheetRoute";
import IdleTimeOutHandler from "../IdleTimeOutHandler";

export class Routes extends Component {
  constructor(props) {
    super(props);
    this.state = {
      accessToken: localStorage.getItem("token"),
    };
  }
  allowRoute = (location) => {
    // if (["/rrc", "/setting/theme"].includes(location.pathname)) {
    //   alert("The rest of Rover is still under construction!");
    //   return false;
    // }
    return true;
  };
  render() {
    let containerClassName;
    if (this.props && this.props.location && this.props.location.pathname) {
      if (this.props.location.pathname.includes("/skillscentral/home")) {
        containerClassName = "rover-container sog"
      } else if (this.props.location.pathname.includes("skillscentral/manage/")) {
        containerClassName = "rover-container sog"
      } else if (this.props.location.pathname.includes("/rrc")) {
        containerClassName = "rover-container request"
      } else if (this.props.location.pathname.includes("/pcdm")) {
        containerClassName = "rover-container sog"
      } else if (this.props.location.pathname.includes("/vendorportal")) {
        containerClassName = "rover-container sog"
      } else if(this.props.location.pathname.includes("/td360")){
        containerClassName = "rover-container sog"
      } else if (this.props.isLoggedInUserRM) {
        containerClassName = "rover-container sog"
      } else {
        containerClassName = "rover-container";
      }
    }
    
      
    return (
      <MainWrapper>
        <div>
          {!this.props.isAuthenticated ? (
            <main>
              <Redirect to="/login" />
              <Route exact path="/login" component={Login} />
            </main>
          ) : (
            <main>
               <IdleTimeOutHandler />
              <Layout />
              <div className={containerClassName}>
                {/*className="container__wrap" */}
                <Switch>
                  <Redirect from="/login" to={PCDM_ROUTES.ROUTE} />
                  <Route exact path="/"
                    render = {(props) => <Redirect to={SUITE_ROUTES.ROUTE} /> }
                  />
                  <Route 
                    path="/dashboard"
                    render={(props) => <Dashboard {...props} />}
                  />
                  <Route 
                    path="/vendorportal"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <VendorPortalRoutes {...props} user={this.props.user} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  />
                  <Route 
                    path="/td360"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <TD360Routes {...props} user={this.props.user} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  />
                  <Route
                    path="/rrc"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <RrcRoutes {...props} user={this.props.user} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  />
                  <Route
                    path="/skillscentral"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <SkillsCentralRoutes {...props} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  />
                  <Route
                    path="/sog"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <SogRoutes {...props} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  />
                  <Route path={PCDM_ROUTES.ROUTE} component={PcdmRoutes} />

                  <Route
                    exact
                    path="/skillscentral/admin"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <Setting {...props} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  />
                  {/* <Route
                    exact
                    path="/setting/theme"
                    render={(props) =>
                      this.allowRoute(props.location) ? (
                        <Setting {...props} />
                      ) : (
                        <Redirect to={PCDM_ROUTES.ROUTE} />
                      )
                    }
                  /> */}
                  <Route path={TIMESHEET_ROUTES.ROUTE} component={TimesheetRoutes} />
                  <Route path="/admin-page" component={AdminPageRoute} />
                  <Route component={NotFoundPage} />
                </Switch>
              </div>
            </main>
          )}
        </div>
        <Prompt when={true} message={(location) => this.allowRoute(location)} />
      </MainWrapper>
    );
  }
}

export const mapStateToProps = (state) => ({
  user: state.AuthReducer.user,
  isAuthenticated: state.AuthReducer.isAuthenticated,
  isLoggedInUserRM: state.suiteCommonReducer.isLoggedInUserRM,
});

Routes.propTypes = {
  user: PropTypes.object,
  isAuthenticated: PropTypes.bool,
};

export default withRouter(connect(mapStateToProps)(Routes));
