import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import VendorPortal from "../../apps/vendorPortal/views/index";
import VendorRequestDetails from "../../apps/vendorPortal/views/VendorRequestDetails/vendorRequestHome";
import { VENDORPORTAL_ROUTES } from "./constants/vendorRoutes.constants";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import { properties } from "../../../properties";
import PropTypes from "prop-types";

export const VendorPortalRoutes = (props) => (
  <Switch>
    <Redirect exact from={VENDORPORTAL_ROUTES.ROUTE} to={VENDORPORTAL_ROUTES.getHomeRoute()} />
    <Route path={VENDORPORTAL_ROUTES.getHomeRoute()} component={VendorPortal} />
    <Route path={VENDORPORTAL_ROUTES.getVendorRequestRoute()} component={VendorRequestDetails} />
    <Route component={NotFoundPage} />
  </Switch>
);

VendorPortalRoutes.propTypes = {
  user: PropTypes.object,
};
