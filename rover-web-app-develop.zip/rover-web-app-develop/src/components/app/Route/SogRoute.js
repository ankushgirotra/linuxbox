import React from "react";
import { Route, Switch } from "react-router-dom";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import SOGHome from "../../apps/sog/views/index";
import SOGSubmissionForm from "../../apps/sog/views/SOGSubmissionForm/submissionForm";

export const SogRoutes = () => (
  <Switch>
    <Route exact path="/sog" component={SOGHome} />
    <Route exact path="/sog/submission-form" component={SOGSubmissionForm} />
    <Route component={NotFoundPage} />
  </Switch>
);
