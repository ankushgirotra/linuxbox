import React from 'react';
import {
  Route, Switch
} from 'react-router-dom';
import NotFoundPage from '../../notFoundPage/notFoundPage';
import Admin from '../../apps/skillsCentral/src/views/Admin/admin';


export const AdminPageRoute = () => (
  <Switch>
    <Route path='/admin-page' component={Admin} />
    <Route component={NotFoundPage} />
  </Switch>
);
