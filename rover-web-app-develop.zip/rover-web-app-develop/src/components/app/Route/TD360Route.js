import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import TD360Home from "../../apps/TD360/views/index";
import { TD360_ROUTES } from "./constants/td360Routes.constants";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import PropTypes from "prop-types";
import ProductContact from "../../apps/TD360/views/ProductConfig/productConfig";
import Edit from "../../apps/TD360/views/ProductConfig/edit";


export const TD360Routes = (props) => (
  <Switch>
    <Redirect exact from={TD360_ROUTES.ROUTE} to={TD360_ROUTES.getHomeRoute()} />
    <Route path={TD360_ROUTES.getHomeRoute()} component={TD360Home} />
    <Route path={TD360_ROUTES.getEditRoute()} component={Edit} />

    <Route path={TD360_ROUTES.getProdutConfigRoute()} component={ProductContact} />
    <Route component={NotFoundPage} />

  </Switch>
);

TD360Routes.propTypes = {
  user: PropTypes.object,
};
