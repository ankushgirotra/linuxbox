import React from "react";
import { connect } from "react-redux";
import { Route, Switch, Redirect } from "react-router-dom";
import { SC_ROUTES } from "./constants/scRoutes.constants";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import SkillCentralHome from "../../apps/skillsCentral/src/views/home";
import Admin from "../../apps/skillsCentral/src/views/Admin/admin";
import RMReportsLanding from "../../apps/skillsCentral/src/views/Admin/SCReports/RMReportsLanding";
// import SCHome from "../../apps/skillsCentral/src/views/skillCentralHome";
// import SkillCentralHome from "../../apps/skillsCentral/src/views/index";
// import { getAccess } from "../../../services/auth.services";

const isLoggedInUserAdminOrResManager = (location, iiqRole) => {
  let allowedRoutes = [
    SC_ROUTES.getAdvanceSearchHomeRoute(),
    SC_ROUTES.getAdvanceSearchResultRoute(),
    SC_ROUTES.getAdvanceSearchProfileRoute(),
    SC_ROUTES.getRMReportsRoute(),
  ];
  let isAdminorRM = iiqRole.RESOURCE_MANAGER || iiqRole.SC.ADMIN
  if (allowedRoutes.includes(location.pathname) && isAdminorRM) {
    return true;
  };
  return false;
};

const SCAdminRouteValidation = (location, accessParams, userParams, iiqRole) => {

  let scAdminRoutes = [
    SC_ROUTES.getAdminRoute(),
    SC_ROUTES.getSkillsConfigurationRoute(),
    SC_ROUTES.getAttritionOptionsRoute(),
    SC_ROUTES.getDeptHeadsRoute(),
    SC_ROUTES.getManageVendorsRoute(),
    SC_ROUTES.getManageRolesRoute(),
    SC_ROUTES.getAutomationJobsControlRoute(),
    SC_ROUTES.getManageOneRateRoute(),
    SC_ROUTES.getManageEmailNotificationRoute(),
    SC_ROUTES.getAdminReportsRoute(),
  ];

  // Before CPRM-3214
  // if ( scAdminRoutes.includes(location.pathname) &&  getAccess(accessParams, userParams).SC_ADMIN)

  // After CPRM-3214
  if (scAdminRoutes.includes(location.pathname) && iiqRole.SC.ADMIN) { 
    return true;
  }
  return false;
};

export const SkillsCentralRoutes = ({ accessParams, userParams, iiqRole }) => (
  <Switch>
    <Redirect exact from={SC_ROUTES.ROUTE} to={SC_ROUTES.getHomeRoute()} />
    <Route path={SC_ROUTES.getHomeRoute()} component={SkillCentralHome} />
    <Route path={SC_ROUTES.getAdminRoute()}
      render={(props) =>
        SCAdminRouteValidation(props.location, accessParams, userParams, iiqRole) ? (
          <Admin {...props} />
        ) : (
            <Redirect to={SC_ROUTES.ROUTE} />
          )
      } />
    <Route
      path={SC_ROUTES.getAdvanceSearchHomeRoute()}
      render={(props) =>
        isLoggedInUserAdminOrResManager(props.location, iiqRole) ? <SkillCentralHome {...props} /> :
          <Redirect to={SC_ROUTES.getHomeRoute()} />}
    />
    <Route path={SC_ROUTES.getRMReportsRoute()} component={RMReportsLanding}  />  
    <Route component={NotFoundPage} />
  </Switch>
);

export const mapStateToProps = (state) => ({
  accessParams: state.ProductsReducer.productsByOwner.data,
  userParams: state.AuthReducer.user,
  iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
});

export default connect(mapStateToProps)(SkillsCentralRoutes);
