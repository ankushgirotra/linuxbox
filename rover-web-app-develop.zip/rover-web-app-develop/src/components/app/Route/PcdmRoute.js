import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import ProductSelection from "../../apps/pcdm/src/views/productSelection/productSelection";
import PCDMContainer from "../../apps/pcdm/src/views/PCDMContainer";
import ProductLine from "../../apps/pcdm/src/views/ProductLine/productLine";
import PCDMAdmin from "../../apps/pcdm/src/views/Admin/admin";
import { PCDM_ROUTES } from "./constants/pcdmRoutes.constants";
import { getAccess } from "../../../services/auth.services";
import { connect } from "react-redux";
import PCDMReports from "../../apps/pcdm/src/views/Admin/Reports/PCDMReports";
import PCDMReportView from "../../apps/pcdm/src/views/Common/capacityConstraintContainer/pcdmReports";

const PCDMAdminRouteValidation = (location, accessParams, userParams,iiqRole) => {
  let pcdmAdminRoutes = [
    PCDM_ROUTES.getMangeProdutRoute(),
    PCDM_ROUTES.getMangeProdutLineRoute(),
    PCDM_ROUTES.getMangeTeamRolesRoute(),
    PCDM_ROUTES.getGenerateReportsRoute(),
    PCDM_ROUTES.getConfigurationsRoute(),
  ];
  // removed cprm-3124
  // if (
  //   pcdmAdminRoutes.includes(location.pathname) &&
  //   getAccess(accessParams, userParams).PCDM_ADMIN
  // ) 
    
  // added cprm-3124
  if (pcdmAdminRoutes.includes(location.pathname) && iiqRole.PCDM.ADMIN) 
  {
    return true;
  }
  return false;
};

export const PcdmRoutes = ({ accessParams, userParams,iiqRole }) => (
  <Switch>
    <Redirect exact from={PCDM_ROUTES.ROUTE} to={PCDM_ROUTES.getHomeRoute()} />
    <Route path={PCDM_ROUTES.getHomeRoute()} component={ProductSelection} />
    <Route
      path={PCDM_ROUTES.getAdminRoute()}
      render={(props) =>
        PCDMAdminRouteValidation(props.location, accessParams, userParams,iiqRole) ? (
          <PCDMAdmin {...props} />
        ) : (
          <Redirect to={PCDM_ROUTES.ROUTE} />
        )
      }
    />
    <Route
      path={PCDM_ROUTES.getGeneratePCDMReportsRoute()}
      component={PCDMReportView}
    />
    <Route path={PCDM_ROUTES.getProdutRoute()} component={PCDMContainer} />
    <Route path={PCDM_ROUTES.getProdutLineRoute()} component={ProductLine} />
    <Route component={NotFoundPage} />
  </Switch>
);
export const mapStateToProps = (state) => ({
  accessParams: state.ProductsReducer.productsByOwner.data,
  userParams: state.AuthReducer.user,
  iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
});

export default connect(mapStateToProps)(PcdmRoutes);
