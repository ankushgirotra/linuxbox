export const REQUEST_ROUTES = {
    ROUTE: "/rrc",
    CHILDREN: {
        ADMIN: {
          ROUTE: "/admin",
          CHILDREN: {
            EXTERNAL_BLOCKERS: "/external-blockers",
            EMAIL_NOTIFICATION: "/email-notification"
            
          },
        },
        HOME: "/home",
        ROUTE: "/create-request",
        ROUTE1: "/request-details",
      },

      getAdminRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ADMIN.ROUTE}`;
      },
      getExternalBlockersRoute: function () {
        return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.EXTERNAL_BLOCKERS}`;
      },
      getEmailNotificationRoute: function () {
        return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.EMAIL_NOTIFICATION}`;
      },
};
