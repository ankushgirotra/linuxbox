export const VENDORPORTAL_ROUTES = {
    ROUTE: "/vendorportal",
    CHILDREN: {
        HOME: "/home",
        ROUTE: "/requestDetails",
    },
    getHomeRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.HOME}`;
    },
    getVendorRequestRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE}`;
    },
};
