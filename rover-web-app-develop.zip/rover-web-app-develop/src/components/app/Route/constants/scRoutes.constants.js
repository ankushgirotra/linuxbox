export const SC_ROUTES = {
  ROUTE: "/skillscentral",
  CHILDREN: {
    ADMIN: {
      ROUTE: "/admin",
      CHILDREN: {
        SKILLS_CONFIGURATION: "/skills-configuration",
        ATTRITION_OPTIONS: "/attrition-options",
        DEPT_HEADS: "/departments",
        MANAGE_VENDORS: "/manage-vendors",
        MANAGE_ROLES: "/manage-roles",
        AUTOMATION_JOBS_CONTROL: "/automation-jobs-control",
        MANAGE_ONE_RATE: "/manage-one-rate",
        MANAGE_EMAIL_NOTIFICATION: "/manage-email-notifications",
        REPORTS: "/reports",
      },
    },
    RESOURCE_MANAGER: {
      ROUTE: "/manage",
      CHILDREN: {
        ADVANCE_SEARCH: {
          ROUTE: "/advance-search",
          CHILDREN: {
            SEARCH_RESULTS: "/searchResults",
            DISPLAY_PROFILE: "/displayProfile"
          }
        },
        REPORTS: "/reports",
      },
    },
    HOME: "/home"
  },
  /* Common for all SC users */
  getHomeRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.HOME}`;
  },
  /* Applicable for SC Admin */
  getAdminRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.ADMIN.ROUTE}`;
  },
  getSkillsConfigurationRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.SKILLS_CONFIGURATION}`;
  },
  getAttritionOptionsRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.ATTRITION_OPTIONS}`;
  },
  getDeptHeadsRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.DEPT_HEADS}`;
  },
  getManageVendorsRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_VENDORS}`;
  },
  getManageRolesRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_ROLES}`;
  },
  getAutomationJobsControlRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.AUTOMATION_JOBS_CONTROL}`;
  },
  getManageOneRateRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_ONE_RATE}`;
  },
  getManageEmailNotificationRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_EMAIL_NOTIFICATION}`;
  },
  getAdminReportsRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.REPORTS}`;
  },
  /* Applicable for SC RM & SC Admin */
  getRMRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.RESOURCE_MANAGER.ROUTE}`;
  },
  getAdvanceSearchHomeRoute: function () {
    return `${this.getRMRoute()}${this.CHILDREN.RESOURCE_MANAGER.CHILDREN.ADVANCE_SEARCH.ROUTE}`;
  },
  getAdvanceSearchResultRoute: function () {
    return `${this.getAdvanceSearchHomeRoute()}${this.CHILDREN.RESOURCE_MANAGER.CHILDREN.ADVANCE_SEARCH.CHILDREN.SEARCH_RESULTS}`;
  },
  getAdvanceSearchProfileRoute: function () {
    return `${this.getAdvanceSearchHomeRoute()}${this.CHILDREN.RESOURCE_MANAGER.CHILDREN.ADVANCE_SEARCH.CHILDREN.DISPLAY_PROFILE}`;
  },
  getRMReportsRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.RESOURCE_MANAGER.CHILDREN.REPORTS}`;
  },
};
