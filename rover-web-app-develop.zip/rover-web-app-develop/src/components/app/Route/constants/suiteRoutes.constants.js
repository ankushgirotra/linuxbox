export const SUITE_ROUTES = {
    ROUTE: "/dashboard",
    CHILDREN: {
        // ROUTE: "/general",
        // ROUTE1: "/financial",
        // ROUTE2: "/workforce",
        // ROUTE3: "/skills",
        // ROUTE4: "/requests",
        // ROUTE5: "/vendorSLA",
        ROUTE: "general",
        ROUTE1: "financial",
        ROUTE2: "workforce",
        ROUTE3: "skills",
        ROUTE4: "requests",
        ROUTE5: "vendorSLA",
      },
      getHomeRoute: function () {
        return `${this.ROUTE}`;
      },
      getGeneralDashboardRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE}`;
      },
      getFinancialDashboardRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE1}`;
      },
      getWorkforceDashboardRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE2}`;
      },
      getSkillsDashboardRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE3}`;
      },
      getRequestsDashboardRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE4}`;
      },
      getVendorDashboardRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.ROUTE5}`;
      },
};
