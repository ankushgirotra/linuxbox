export const TIMESHEET_ROUTES = {
  ROUTE: "/timesheet",
  CHILDREN: {
    IC_VIEW: {
      ROUTE: "/ic",
      CHILDREN: {
        WEEKLY_VIEW: "/weekly-view",
        MONTHLY_VIEW: "/monthly-view",
      },
    },
    RM_VIEW: {
      ROUTE: "/rm",
      CHILDREN: {
        WEEKLY_VIEW: "/weekly-view",
        MONTHLY_VIEW: "/monthly-view",
      },
    },
    ADMIN_VIEW: {
      ROUTE: "/admin",
      CHILDREN: {
        CORE_CODES: "/core-codes",
        MANAGE_HOLIDAYS: "/manage-holidays"
      },
    },
    CALENDAR_VIEW: "/calendar-view",
  },
  getHomeRoute: function () {
    return `${this.ROUTE}`;
  },
  getTimesheetAdminRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.ADMIN_VIEW.ROUTE}`;
  },
  getTimesheetAdminCoreCodesRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.ADMIN_VIEW.ROUTE}${
      this.CHILDREN.ADMIN_VIEW.CHILDREN.CORE_CODES
      }`;
  },
  getTimesheetAdminManageHolidaysRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.ADMIN_VIEW.ROUTE}${
      this.CHILDREN.ADMIN_VIEW.CHILDREN.MANAGE_HOLIDAYS
      }`;
  },
  getWeeklyViewRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.IC_VIEW.ROUTE}${
      this.CHILDREN.IC_VIEW.CHILDREN.WEEKLY_VIEW
      }`;
  },
  getMonthlyViewRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.IC_VIEW.ROUTE}${
      this.CHILDREN.IC_VIEW.CHILDREN.MONTHLY_VIEW
      }`;
  },
  getRmWeeklyViewRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.RM_VIEW.ROUTE}${
      this.CHILDREN.RM_VIEW.CHILDREN.WEEKLY_VIEW
      }`;
  },
  getRmMonthlyViewRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.RM_VIEW.ROUTE}${
      this.CHILDREN.RM_VIEW.CHILDREN.MONTHLY_VIEW
      }`;
  },
  getRmCalendarViewRoute: function () {
    return `${this.getHomeRoute()}${this.CHILDREN.CALENDAR_VIEW}`;
  }
};
