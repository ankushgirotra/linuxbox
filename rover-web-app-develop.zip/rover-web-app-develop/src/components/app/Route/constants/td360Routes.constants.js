export const TD360_ROUTES = {
    ROUTE: "/td360",
    CHILDREN: {
        HOME: "/home",
        EDIT: "/editProduct",
        PRD: (product_Id) => `/${product_Id ? product_Id : `:productId`}`,
    },
    getHomeRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.HOME}`;
    },
    getProdutConfigRoute: function (productId) {
        return `${this.ROUTE}${this.CHILDREN.PRD(productId)}`;
    },
    getEditRoute: function () {
        return `${this.ROUTE}${this.CHILDREN.EDIT}`;
    },

};
