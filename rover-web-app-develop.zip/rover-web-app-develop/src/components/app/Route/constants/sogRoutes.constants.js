export const SOG_ROUTES = {
  ROUTE: "/sog",
  CHILDREN: {
    ROUTE: "/submission-form",
  },
};
