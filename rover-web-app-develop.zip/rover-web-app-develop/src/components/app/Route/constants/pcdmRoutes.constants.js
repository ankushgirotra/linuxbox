export const PCDM_ROUTES = {
  ROUTE: "/pcdm",
  CHILDREN: {
    ADMIN: {
      ROUTE: "/admin",
      CHILDREN: {
        MANAGE_PRD: "/manage-products",
        MANAGE_PRD_LINE: "/manage-product-lines",
        MANAGE_TEAM_ROLE: "/manage-team-roles",
        GENERATE_REPORT: "/generate-reports",
        GENERATE_PCDM_REPORT: "/generate-pcdm-reports",
        CONFIGURATIONS: "/configurations",
      },
    },
    NON_ADMIN: {
      CHILDREN: {
        GENERATE_PCDM_REPORT: "/generate-pcdm-reports",
      },
    },
    HOME: "/home",
    PRD: (productCode) => `/product/${productCode ? productCode : `:productCode`}`,
    PRD_LINE: (productLine) => `/product-line/${productLine ? productLine : `:productLine`}`,
  },
  getHomeRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.HOME}`;
  },
  getProdutRoute: function (productCode) {
    return `${this.ROUTE}${this.CHILDREN.PRD(productCode)}`;
  },
  getProdutLineRoute: function (productLine) {
    return `${this.ROUTE}${this.CHILDREN.PRD_LINE(productLine)}`;
  },
  getAdminRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.ADMIN.ROUTE}`;
  },
  getMangeProdutRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_PRD}`;
  },
  getMangeProdutLineRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_PRD_LINE}`;
  },
  getMangeTeamRolesRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.MANAGE_TEAM_ROLE}`;
  },
  getGenerateReportsRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.GENERATE_REPORT}`;
  },
  getConfigurationsRoute: function () {
    return `${this.getAdminRoute()}${this.CHILDREN.ADMIN.CHILDREN.CONFIGURATIONS}`;
  },
  getGeneratePCDMReportsRoute: function () {
    return `${this.ROUTE}${this.CHILDREN.NON_ADMIN.CHILDREN.GENERATE_PCDM_REPORT}`;
  },
};
