import React, {useEffect} from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import NotFoundPage from "../../notFoundPage/notFoundPage";
import { TIMESHEET_ROUTES } from "./constants/timesheetRoutes.constants";
import { connect } from "react-redux";
import TimesheetHome from "../../apps/timesheet/views/home";
import { getAccess } from "../../../services/auth.services";
import TimesheetAdmin from "../../apps/timesheet/views/AdminView/admin";
import {setProductsByOwnerThunk} from '../../apps/pcdm/src/store/products.reducer';

export const TimesheetAdminRouteValidation = (location, accessParams, userParams) => {
  let TimesheetAdminRoutes = [
    TIMESHEET_ROUTES.getTimesheetAdminRoute(),
    TIMESHEET_ROUTES.getTimesheetAdminCoreCodesRoute(),
    TIMESHEET_ROUTES.getTimesheetAdminManageHolidaysRoute(),
  ];
  if (
    TimesheetAdminRoutes.includes(location.pathname) &&
    getAccess(accessParams, userParams).TIMESHEET_ADMIN
  ) {
    return true;
  }
  return false;
};

const TimesheetRoutes = ({ accessParams, userParams, loggedInUser, setProductsByOwner }) => {
  useEffect(()=>{
    let lanId = loggedInUser && loggedInUser.isAuthenticated ? getLANID(loggedInUser) : "";
    setProductsByOwner(lanId);
  },[loggedInUser])
  const getLANID = (user) => {
    const {
      user: { id },
    } = user;
    if (
      id.toUpperCase().includes("CH") ||
      id.toUpperCase().includes("CN") ||
      id.toUpperCase().includes("MS")
    ) {
      return id.toUpperCase();
    }
    return id.replace(/[A-Z]/gi, "");
  };
  return (
  <Switch>
    <Route
      path={TIMESHEET_ROUTES.getTimesheetAdminRoute()}
      render={(props) =>
        TimesheetAdminRouteValidation(props.location, accessParams, userParams) ? (
          <TimesheetAdmin />
        ) : (
          <Redirect to={TIMESHEET_ROUTES.ROUTE} />
        )
      }
    />
    <Route path={TIMESHEET_ROUTES.ROUTE} component={TimesheetHome} />
    <Route component={NotFoundPage} />
  </Switch>
)};
export const mapStateToProps = (state) => ({
  accessParams: state.ProductsReducer.productsByOwner.data,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});
export const mapDispatchToProps = (dispatch) => ({
  setProductsByOwner: (id) => dispatch(setProductsByOwnerThunk(id)),
})
export default connect(mapStateToProps, mapDispatchToProps)(TimesheetRoutes);
