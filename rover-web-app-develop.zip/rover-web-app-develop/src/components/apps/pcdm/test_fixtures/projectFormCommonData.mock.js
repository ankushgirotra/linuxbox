import { DATA_STATUS } from "../src/constants/service.constant";
import projectEstimates from "../src/views/projectEstimates/projectEstimates";
import { projectsEstimatesData } from "./projectsEstimatesData.mock";
import { DEFAULT_MSG_MODAL_CONFIG } from "../src/components/MessageModal/messageModal";
import {
  FORM_CONTROL_DEFAULT,
  STORY_PTS_MIN,
  STORY_PTS_MAX,
  MONTH_DATE_YEAR_FORMAT,
} from "../src/constants/form.constants";
import { getFormattedDate } from "../src/services/form.service";

export const projectFormCommons = {
  projectDefaults: {
    projectName: "",
    projectType: "",
    investmentPortfolio: "",
    deliveryPortfolio: "",
    financialStatus: "",
    icode: "",
    pcode: "",
    listOfComments: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  usedPCodes: [],
  pCodeOptions: [],
  estimateTypeOptions: [
    { id: 1, desc: "Intake" },
    { id: 2, desc: "Execution" },
  ],
  projectTypeOptions: [
    { id: 1, desc: "Transform" },
    { id: 2, desc: "Core Enablement (Grow)" },
    { id: 3, desc: "Planned Sustain" },
  ],
  estimationTimingOptions: [
    { id: 1, desc: "During Intake (ROM)" },
    { id: 2, desc: "During PPP" },
  ],
  fundingOptions: [
    { id: 1, desc: "Funded" },
    { id: 2, desc: "Unfunded" },
  ],
  investmentPortfolioOptions: [
    { id: 1, desc: "TD&S" },
    { id: 2, desc: "Retail" },
    { id: 3, desc: "Provider" },
  ],
  deliveryPortfolioOptions: [
    { id: 1, desc: "ADC" },
    { id: 2, desc: "Mandates" },
    { id: 3, desc: "Provider" },
  ],
  saveProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  saveProjectCommentStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
  editProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  completeProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  projects: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
  baseLineBudget: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: {},
  },
};

export const defaultProjectFormState = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    error: false,
    errorMessage: "",
    errorDetail: "",
    isEdited: false,
    estimateType: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    iCode: {
      ...FORM_CONTROL_DEFAULT,
    },
    pCode: {
      ...FORM_CONTROL_DEFAULT,
    },
    projectName: {
      ...FORM_CONTROL_DEFAULT,
    },
    projectType: {
      ...FORM_CONTROL_DEFAULT,
    },
    investmentPortfolio: {
      ...FORM_CONTROL_DEFAULT,
    },
    deliveryPortfolio: {
      ...FORM_CONTROL_DEFAULT,
    },
    points: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      min: STORY_PTS_MIN,
      max: STORY_PTS_MAX,
    },
    plannedStart: {
      ...FORM_CONTROL_DEFAULT,
      min: getFormattedDate("01/01/2019", "DATE", MONTH_DATE_YEAR_FORMAT),
      max: null,
      required: true,
    },
    plannedEnd: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      min: null,
      max: null,
      disabled: true,
    },
    funding: {
      ...FORM_CONTROL_DEFAULT,
    },
    baseLineBudget: {
      ...FORM_CONTROL_DEFAULT,
      value: 0.0,
    },
  },
};

export const editedProjectFormState = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    error: false,
    errorMessage: "",
    errorDetail: "",
    isEdited: false,
    estimateType: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      value: projectsEstimatesData.data.projectEstimatesList[0].estimateType,
    },
    iCode: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].icode,
    },
    pCode: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].pcode,
    },
    projectName: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].projectName,
    },
    projectType: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].projectType,
    },
    investmentPortfolio: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].investmentPortfolio,
    },
    deliveryPortfolio: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].deliveryPortfolio,
    },
    points: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      min: STORY_PTS_MIN,
      max: STORY_PTS_MAX,
      value: projectsEstimatesData.data.projectEstimatesList[0].storyPoints,
    },
    plannedStart: {
      ...FORM_CONTROL_DEFAULT,
      min: getFormattedDate("01/01/2019", "DATE", MONTH_DATE_YEAR_FORMAT),
      max: null,
      required: true,
      value: projectsEstimatesData.data.projectEstimatesList[0].plannedStart,
    },
    plannedEnd: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      min: null,
      max: null,
      disabled: false,
      value: projectsEstimatesData.data.projectEstimatesList[0].plannedEnd,
    },
    funding: {
      ...FORM_CONTROL_DEFAULT,
      value: projectsEstimatesData.data.projectEstimatesList[0].funding,
    },
    baseLineBudget: {
      ...FORM_CONTROL_DEFAULT,
      disabled: false,
      error: false,
      errorMsg: "",
      max: "",
      min: "",
      readOnly: false,
      required: false,
      value: projectsEstimatesData.data.projectEstimatesList[0].baselineBudget,
    },
  },
};
