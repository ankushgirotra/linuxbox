// this is teamCaluclation for  only one team with teamId 53 of PRD00000204
export const teamCalculation = {
	teamId: 53,
	costPerPoint: 285.3846,
	costPerSprint: 22260,
	hoursPerPoint: 3.1897435,
	hoursPerSprint: 248.8,
	rolesCalculation: [
		{
			sprintCost: 2400,
			sprintHours: 32,
			teamRoleId: 71,
		},
		{
			sprintCost: 9600,
			sprintHours: 80,
			teamRoleId: 67,
		},
		{
			sprintCost: 4800,
			sprintHours: 64,
			teamRoleId: 69,
		},
		{
			sprintCost: 4800,
			sprintHours: 64,
			teamRoleId: 70,
		},
		{
			sprintCost: 660,
			sprintHours: 8.8,
			teamRoleId: 72,
		},
	],
};
