import React from "react";
import { withRouter } from "react-router";
import "./dataGrid.scss";
import {
  useTable,
  useFilters,
  useGlobalFilter,
  useAsyncDebounce,
  useSortBy,
  useExpanded,
} from "react-table";
import matchSorter from "match-sorter";

/*Default column filter*/
const DefaultColumnFilter = ({ column: { filterValue, preFilteredRows, setFilter } }) => {
  const count = preFilteredRows.length;
  return (
    <input
      value={filterValue || ""}
      onChange={(e) => {
        setFilter(e.target.value || undefined);
      }}
      placeholder={`Search ${count} records...`}
    ></input>
  );
};

/*For dropdown filter*/
export function SelectColumnFilter({ column: { filterValue, setFilter, preFilteredRows, id } }) {
  const options = React.useMemo(() => {
    const options = new Set();
    preFilteredRows.forEach((row) => {
      options.add(row.values[id]);
    });
    return [...options.values()];
  }, [id, preFilteredRows]);
  return (
    <select
      value={filterValue}
      onChange={(e) => {
        setFilter(e.target.value || undefined);
      }}
    >
      <option value="">All</option>
      {options.map((option, index) => (
        <option key={index} value={option}>
          {option}
        </option>
      ))}
    </select>
  );
}
function fuzzyTextFilterFn(rows, id, filterValue) {
  return matchSorter(rows, filterValue, { keys: [(row) => row.values[id]] });
}

/*Remove the filter if string is empty */
fuzzyTextFilterFn.autoRemove = (val) => !val;

function DataGrid(props) {
  const {
    data,
    columns,
    onRowClick,
    onCellClick,
    isRowClickable,
    getCellClassName,
    appendToCell,
    noRowText,
    getRowClassName,
    getRowId,
    toolTip,
    renderRowSubComponent,
    isTimesheet,
    hideObjectTitle = false,
    showUpdatedDataGrid = false,
    className,
  } = props;

  const getTimesheetTableStyle = () => {
    if (isTimesheet) {
      return {
        zIndex: `${isTimesheet === "Sub Component" ? 1 : 99}`,
        position: "relative",
      };
    } else {
      return {};
    }
  };

  const filterTypes = React.useMemo(() => ({
    fuzzyText: fuzzyTextFilterFn,
    text: (rows, id, filterValue) => {
      return rows.filter((row) => {
        const rowValue = row.values[id];
        return rowValue !== undefined
          ? String(rowValue).toLowerCase().startsWith(String(filterValue).toLowerCase())
          : true;
      });
    },
  }));
  const defaultColumn = React.useMemo(() => ({ Filter: DefaultColumnFilter }), []);
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    state,
    visibleColumns,
    preGlobalFilteredRows,
    setGlobalFilter,
    state: { expanded },
    
  } = useTable(
    { columns, data, defaultColumn, filterTypes, autoResetFilters: false },
    useFilters,
    useSortBy,
    useExpanded
  );

  let nf = new Intl.NumberFormat();

  const getClassName = () => {
    let pathname = props.location.pathname ? props.location.pathname : "";
    if (pathname.includes("skillscentral/home") || pathname.includes("skillscentral/manage/advance-search") || pathname.includes("rrc/request-details"))
      return "sc-data-grid";
    else if (showUpdatedDataGrid)
      return "pcdm-updated_data-grid";
    else
      return "pcdm-data-grid";
  };

  return (
    <div className={className?className:getClassName()}>
      <table {...getTableProps()} className="table-striped table-hover" >
        <thead  style={getTimesheetTableStyle()}>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps()}>
                  <span
                    {...column.getSortByToggleProps()}
                    title={`${column.canSort ? `Click to Sort` : ``}`}
                  >
                    {column.isSorted
                      ? column.isSortedDesc
                        ? [column.render("Header"), <div className="pcdm-sort-down"></div>]
                        : [<div className="pcdm-sort-up"></div>, column.render("Header")]
                      : column.render("Header")}
                  </span>
                  {typeof toolTip === "function" ? toolTip(column.id) : null}
                  {column.canFilter ? (
                    <div className="pcdm-filter-input">{column.render("Filter")}</div>
                  ) : null}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {rows.length ? (
            rows.map((row, i) => {
              prepareRow(row);
              let clickableClassName = isRowClickable
                ? isRowClickable(row)
                  ? "row-onclick"
                  : ""
                : "";
              let rowClassName = getRowClassName ? getRowClassName(row) : "";
              let rowId = getRowId ? getRowId(row) : "";
              return (
                <React.Fragment
                  // className={`${clickableClassName} ${rowClassName}`}
                  // {...row.getRowProps({
                  //   onClick: () => (onRowClick ? onRowClick(row) : null),
                  // })}
                >
                 
                  <tr className={`${clickableClassName} ${rowClassName}`} id={rowId} 
                    {...row.getRowProps({
                      onClick: () => (onRowClick ? onRowClick(row) : null),
                    })}>
                    {row.cells.map((cell) => {
                      let cellClassName = getCellClassName ? getCellClassName(cell) : "";
                      return (
                        <td
                          className={`${cellClassName}`}
                          style={{color:typeof cell.value==='string'?'block':typeof cell.value==='number'&& cell.value>= 50 ?'#00cb85':'#ff4d4d'}}
                          title={typeof cell.value === "object" && hideObjectTitle ? "" : typeof cell.value === "number" ? nf.format(cell.value) : cell.value}
                          {...cell.getCellProps({
                            onClick: () => (onCellClick ? onCellClick(row, cell) : null),
                          })}
                        >
                          {cell.render("Cell")}
                          {appendToCell ? appendToCell(row, cell) : null}
                          
                        </td>
                      );
                    })}
                  </tr>
                  {row.isExpanded ? (
                    <tr>
                      <td colSpan={visibleColumns.length}>{renderRowSubComponent({ row })}</td>
                    </tr>
                  ) : null}
                </React.Fragment>
              );
            })
          ) : (
            <tr>
              <td className="empty-row" colSpan={columns.length}>
                {data.length === 0 ? noRowText : `No rows found`}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
export default withRouter(DataGrid)