import React from "react";
import "./navigationExtended.scss";

export function RoverNavigationExtended({ onTabChange, activeKey, className = "", navList }) {
  const getNavItem = () => {
    return navList.map((nav, index) => {
      const isActive = activeKey === nav.navKey ? "rover-nav__item--active" : "";
      const decideContent = typeof nav.header === "function" ? nav.header() : nav.header;
      return (
        <li key={index} className={`rover-nav__item ${isActive}`}>
          <a className="rover-nav__menu" onClick={() => onTabChange(nav.navKey)}>
            {decideContent}
          </a>
          {nav.floater ? (typeof nav.floater === "function" ? nav.floater() : nav.floater) : null}
        </li>
      );
    });
  };
  const getNavPanes = () => {
    return navList.map((nav, index) => {
      const isActive = activeKey === nav.navKey ? "rover-nav-content__pane--active" : "";
      const decideContent = typeof nav.content === "function" ? nav.content() : nav.content;
      return (
        <div key={index} className={`rover-nav-content__pane ${isActive}`}>
          {decideContent}
        </div>
      );
    });
  };
  return (
    <div className={`rover-nav-container ${className}`}>
      <ul className={`rover-nav`}>{getNavItem()}</ul>
      <div className={`rover-nav-content`}>{getNavPanes()}</div>
    </div>
  );
}
