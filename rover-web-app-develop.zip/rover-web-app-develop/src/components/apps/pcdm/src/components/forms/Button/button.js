import React from "react";
import { Spinner } from "react-bootstrap";
import "./button.scss";
export const BUTTON_VARIANTS = {
  PRIMARY: "custom-button--primary",
  SUCCESS: "custom-button--success",
  ERROR: "custom-button--error",
  WARNING: "custom-button--warning",
  LIGHT: "custom-button--light",
  BLUE_GOLD: "custom-button--blue-gold",
  LINK: "custom-button--link",
  ICON: "custom-button--icon",
};
export default function CustomButton({
  onClick,
  title,
  className,
  children,
  fluid,
  type = "button",
  loading = false,
  disable = false,
  borderless = false,
  size = "sm",
  variant = BUTTON_VARIANTS.LINK,
}) {
  const makeClassName = () => {
    let cn = "custom-button cursor-pointer";
    if (fluid) {
      cn = `${cn} custom-button--fluid`;
    }
    if (variant) {
      cn = `${cn} ${variant}`;
    }
    if (className) {
      cn = `${cn} ${className}`;
    }
    if (borderless) {
      cn = `${cn} custom-button--border-less`;
    } else {
      cn = `${cn} custom-button--border`;
    }
    if (size === "md") {
      cn = `${cn} custom-button-big`;
    }
    if(disable) {
      cn = `${cn} custom-button-disable`;
    }
    return cn;
  };
  const makeContent = () => {
    if (loading) {
      return (
        <Spinner
          size={"sm"}
          animation="border"
          className="custom-button-spinner"
        />
      );
    } else if (children) {
      return children;
    }
  };
  return (
    <div
      disabled={disable}
      onClick={loading || disable ? null : onClick}
      title={title}
      className={makeClassName()}
    >
      {makeContent()}
    </div>
  );
}
