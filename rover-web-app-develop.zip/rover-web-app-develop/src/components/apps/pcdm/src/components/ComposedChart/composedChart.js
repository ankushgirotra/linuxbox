import React from "react";
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Brush,
  Label,
  Cell,
  LabelList,
} from "recharts";
import {
  DEFAULT_HEIGHT,
  DEFAULT_WIDTH,
  CARTESIAN_GRID_COLOR,
  DEFAULT_LINE_STROKE_COLOR,
  DEFAULT_BAR_FILL_COLOR,
} from "../../constants/chart.constants";
import "./composedChart.scss";
import { Spinner } from "react-bootstrap";
import { DATA_STATUS } from "../../constants/service.constant";

const showLine = (props) => {
  const style = {
    backgroundColor: props.color,
  };
  return <div className="lengend-mini legend-mini-line" style={{ ...style }}></div>;
};
const showRect = (props) => {
  const style = {
    backgroundColor: props.dataKey === "extraCapacity" ? "#00000000" : props.color,
    border: props.dataKey === "extraCapacity" ? `1px solid ${props.color}` : "none",
  };
  return <div className="lengend-mini legend-mini-rectangle" style={{ ...style }}></div>;
};
const CustomLegend = (props) => {
  const { payload } = props;
  return (
    <ul className="legend-list-container">
      {payload.map((entry, index) => (
        <li className={`item-${index}`} key={index}>
          {entry.type === "line" ? showLine(entry) : showRect(entry)}
          {entry.value}
        </li>
      ))}
    </ul>
  );
};
const PrepareToolTip = ({ active, payload, label, customToolTip }) => {
  if (active) {
    return (
      <div className="custom-tooltip-container">
        <div className="list-head">
          <h5 className="pcdm-head center">{label}</h5>
        </div>
        <div className="custom-tooltip-content">
          {payload
            ? customToolTip && typeof customToolTip === "function"
              ? customToolTip(payload)
              : payload.map((el, index) => (
                  <div className="custom-tooltip" key={index}>
                    <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()}</span> -
                    <span>{el.value}</span>
                  </div>
                ))
            : null}
        </div>
      </div>
    );
  } else {
    return null;
  }
};
export default function PCDMComposedChart(props) {
  const {
    points,
    xAxisKey,
    barConfig,
    lineConfig,
    chartLoading,
    width,
    height,
    brushConfig,
    chartType,
    customLegend,
    xAxisFormatter,
    xAxisTick,
    yAxisFormatter,
    legendVerticalAlign = "top",
    customToolTip,
    customLabel,
  } = props;
  const getBar = (bar, index, isStacked = false) => {
    return (
      <Bar
        key={index + bar.key}
        name={bar.name || bar.key}
        dataKey={bar.key}
        barSize={bar.size || 20}
        fill={bar.fill || DEFAULT_BAR_FILL_COLOR}
        shape={typeof bar.customShape !== "undefined" ? bar.customShape : null}
        {...(isStacked ? { stackId: bar.stackId || "a", stackOffset: "sign" } : {})}
      >
        {bar.showLabel ? (
          <LabelList
            dataKey={bar.key}
            position={"center"}
            content={customLabel ? (e) => customLabel(e, bar) : null}
          />
        ) : null}
      </Bar>
    );
  };
  const mountBarCharts = () => {
    return (barConfig && barConfig.length
      ? barConfig.map((bar, index) => {
          return bar.stack && bar.stack.length
            ? bar.stack.map((item, index) => getBar(item, index, true))
            : getBar(bar, index);
        })
      : barConfig.stack.map((item, index) => getBar(item, index, true))
    ).flat();
  };
  const mountLineChart = () => {
    return lineConfig && lineConfig.length
      ? lineConfig.map((line) => (
          <Line
            type="monotone"
            name={line.name || line.dataKey}
            dataKey={line.dataKey}
            stroke={line.stroke || DEFAULT_LINE_STROKE_COLOR}
            strokeWidth={line.strokeWidth || 1}
          />
        ))
      : null;
  };
  const mountBrush = () => {
    return brushConfig && brushConfig.dataKey ? (
      <Brush
        dataKey={xAxisKey}
        startIndex={brushConfig.startIndex}
        endIndex={brushConfig.endIndex}
        height={brushConfig.height || 18}
        stroke="#162955"
        fill="#fff"
        onChange={(e) => (brushConfig.onChange ? brushConfig.onChange(e) : null)}
      >
        <title>Click and drag the edges of the scroll bar to expand/contract view</title>
      </Brush>
    ) : null;
  };
  return (
    <div className="pcdm-chart-container">
      {chartLoading === DATA_STATUS.LOADING ? (
        <div className="spinner-container">
          <Spinner size="md" animation="border" variant="secondary" />
        </div>
      ) : points.length ? (
        <ResponsiveContainer>
          <ComposedChart
            width={width || DEFAULT_WIDTH}
            height={height || DEFAULT_HEIGHT}
            data={points}
            margin={{
              top: 20,
              right: 20,
              bottom: 20,
              left: 20,
            }}
          >
            <XAxis
              dataKey={xAxisKey}
              {...(xAxisTick ? { tick: xAxisTick } : null)}
              tickFormatter={xAxisFormatter ? xAxisFormatter : null}
            />
            <YAxis
              padding={{ top: 20 }}
              allowDataOverflow={true}
              tickFormatter={yAxisFormatter ? yAxisFormatter : null}
            />
            <Tooltip content={<PrepareToolTip customToolTip={customToolTip} />} />
            <Legend
              verticalAlign={legendVerticalAlign}
              content={customLegend ? customLegend() : <CustomLegend />}
            />
            {mountBrush()}
            {mountBarCharts()}
            {mountLineChart()}
          </ComposedChart>
        </ResponsiveContainer>
      ) : (
        <div className="empty-data-container"> No data to show</div>
      )}
    </div>
  );
}
