import React from "react";
import PropTypes from "prop-types";
import ErrorMsg from "../errorMsg/errorMsg";

import "./textArea.scss";
export default function TextArea({
  label,
  formObj,
  onChange,
  isRequired,
  placeholder = "",
  onBlur,
  resize = false,
  rows,
  cols,
  name,
  className = "",
}) {
  // console.log(formObj);
  return (
    <div className={`${className} custom-textarea`}>
      <label name={name} className={`text-cap ${isRequired ? `required ` : ``}`}>
        {label}
      </label>
      <textarea
        style={resize ? {} : { resize: "none" }}
        onChange={onChange}
        onBlur={onBlur ? onBlur : null}
        className={"pcdm-input"}
        name={name}
        rows={rows}
        cols={cols}
        placeholder={placeholder}
        required={isRequired ? true : false}
        value={formObj.value}
        readOnly={formObj.readOnly || false}
      ></textarea>
      {formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null}
    </div>
  );
}

TextArea.propTypes = {
  label: PropTypes.string,
  formObj: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    error: PropTypes.bool,
    errorMsg: PropTypes.string,
  }),
  name: PropTypes.string,
  onChange: PropTypes.func,
  onBlur: PropTypes.func,
  isRequired: PropTypes.bool,
  placeholder: PropTypes.string,
  rows: PropTypes.number,
  cols: PropTypes.number,
  resize: PropTypes.bool,
};
