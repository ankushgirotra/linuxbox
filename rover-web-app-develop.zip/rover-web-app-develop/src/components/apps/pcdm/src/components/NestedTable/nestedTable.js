import React from "react";
import PropTypes from "prop-types";
import "./nestedTable.scss";
import { check } from "../../services/validation";
import { Spinner } from "react-bootstrap";
import { OverlayLoader } from "../DataHandler/dataHandler";

function NestedTable({ className = "", finalArray, columnPaths, headerConfig, colWidths }) {
  const getColHeadersArr = () => {
    let colGroupArr = (
      <colgroup>
        {colWidths.map((colWidth, index) => (
          <col key={index} style={{ width: `${colWidth}px` }} />
        ))}
      </colgroup>
    );
    let colHeaderGroupArr = [];
    headerConfig.forEach((colHeaders, rowIndex) => {
      const { colGroup, colHeaderGroup } = getColHeaders(colHeaders, rowIndex);
      colHeaderGroupArr.push(<tr key={rowIndex}>{colHeaderGroup}</tr>);
    });
    return { colGroupArr, colHeaderGroupArr };
  };
  const getColHeaders = (colHeaders, rowIndex) => {
    let colGroup = [];
    let colHeaderGroup = [];
    colHeaders.forEach((colHeader, colIndex) => {
      const { rowSpan, colSpan, scope, content, id = "" } = colHeader;
      let thProps = {
        key: `${rowIndex}-${colIndex}`,
        colSpan: colSpan || 1,
        rowSpan: rowSpan || 1,
        scope: scope || "row",
      };
      if (typeof content === "function") {
        colHeaderGroup.push(content({ thProps: thProps }));
      } else {
        colHeaderGroup.push(
          <th id={id} {...thProps}>
            {content}
          </th>
        );
      }
    });
    return { colGroup, colHeaderGroup };
  };
  const getTh = (cellProps, row, col, rowIndex, colIndex) => {
    const { rowSpan, colSpan, scope, content } = cellProps;
    let thProps = {
      key: `${rowIndex}-${colIndex}`,
      colSpan: colSpan || 1,
      rowSpan: rowSpan || 1,
      scope: scope || "row",
      class: row && row.original && row.original.completed ? 'completed-project' : ''
    };
    if (typeof col.content === "function") {
      return col.content(cellProps, row, col, thProps);
    } else {
      return <th {...thProps}>{content}</th>;
    }
  };
  const getTd = (cellProps, row, col, rowIndex, colIndex) => {
    const { rowSpan, colSpan, scope, value } = cellProps;
    let tdProps = {
      key: `${rowIndex}-${colIndex}`,
      colSpan: colSpan || 1,
      rowSpan: rowSpan || 1,
      scope: scope || "row",
      class: row && row.original && row.original.completed ? 'completed-project' : ''
    };
    if (typeof col.content === "function") {
      return col.content(cellProps, row, col, tdProps);
    } else {
      return <td {...tdProps}>{value}</td>;
    }
  };
  const getRow = () => {
    return finalArray.map((row, rowIndex) =>
      (<tr key={rowIndex}>
        {columnPaths.map((col, colIndex) => {
          const { flag, value } = check({
            path: col.accessor,
            original: row,
            defaultReturnValue: null,
          });
          let cellProps = {
            rowSpan: col.rowSpan || 1,
            colSpan: col.colSpan || 1,
            scope: col.scope || "row",
            content: value,
            class: row && row.original && row.original.completed ? 'completed-project' : ''
          };
          if (col.type === "th") {
            if (flag) {
              return getTh(cellProps, row, col, rowIndex, colIndex);
            }
          } else {
            return getTd(cellProps, row, col, rowIndex, colIndex);
          }
          return null;
        })}
      </tr>
      )
    );
  };

  const { colGroupArr, colHeaderGroupArr } = getColHeadersArr();
  return (
    <div className={className}>
      <table className="nested-table">
        {colGroupArr}
        <thead>{colHeaderGroupArr}</thead>
        <tbody>   {finalArray.length ? (getRow()) : <tr> <td class="empty-row" colSpan="3"> No Rows Found </td> </tr>}    </tbody>
      </table>
    </div>
  );
}

NestedTable.propTypes = {
  selected: PropTypes.string,
  navOptions: PropTypes.array,
  onClick: PropTypes.func,
};

export default NestedTable;
