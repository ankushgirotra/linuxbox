import SidebarLink from "../../../../../layout/sidebar/SidebarLink";
import SidebarCategory from "../../../../../layout/sidebar/SidebarCategory";
import React from "react";
import PropTypes from "prop-types";
import { Grid, Home, Settings, LogOut } from "react-feather";

export const SidebarPCDM = (props) => {
  const { hideSidebar, logout } = props; 

  return (
    <div className="sidebar__content">
      <ul className="sidebar__block">
        <SidebarLink
          title="Dashboard"
          icon={() => <Home size="20" strokeWidth={1} />}
          route="/pcdm"
          onClick={hideSidebar}
        />
      </ul>
      {/* Do condition render for following tag */}
      <ul className="sidebar__block">
        <SidebarCategory title="Apps" icon={() => <Grid size="20" strokeWidth={1} />}>
          <SidebarLink title="Rover Suite" route="/" onClick={hideSidebar} />
          <SidebarLink title="Rover RRC" route="/rrc" onClick={hideSidebar} />
          <SidebarLink title="Rover SOG" route="/sog" onClick={hideSidebar} />
          <SidebarLink title="Rover Skills Central" route="/skillscentral" onClick={hideSidebar} />
          <SidebarLink title="Rover PCDM" route="/pcdm" onClick={hideSidebar} />
        </SidebarCategory>
      </ul>
      <ul className="sidebar__block">
        <SidebarLink
          title="Theme"
          icon={() => <Settings size="20" strokeWidth={1} />}
          route="/setting/theme"
          onClick={hideSidebar}
        />
      </ul>
      <ul className="sidebar__block">
        <SidebarLink
          title="Log Out"
          icon={() => <LogOut size="20" strokeWidth={1}></LogOut>}
          onClick={logout}
        />
      </ul>
    </div>
  );
};

SidebarPCDM.propTypes = {
  logout: PropTypes.func.isRequired,
  hideSidebar: PropTypes.func.isRequired,
};
