import React from "react";
import { Modal, Button } from "react-bootstrap";
import { ACTIONS } from "../../constants/action.constants";
import CustomButton, { BUTTON_VARIANTS } from "../forms/Button/button";
import CustomCheckBox, {
  CustomCheck,
} from "../../../../../shared/CustomCheckBox/customCheckBox";
import Checkbox from "../forms/Checkbox/checkbox";
import "./messageModal.scss";

function MessageModal(props) {
  const {
    visible,
    onClose,
    title,
    variant,
    message,
    customContent,
    customFooter = null,
    size = null,
    dialogClassName = "",
    loading = false,
    checkboxLabel = null,
    checkboxSelected = null,
    checkboxOnChange = null,
  } = props;
  const getFooter = () => {
    if (variant === ACTIONS.YES_NO) {
      return [
        <CustomButton
          key={1}
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.YES, "")}
        >
          Yes
        </CustomButton>,
        <CustomButton
          key={2}
          variant={BUTTON_VARIANTS.LIGHT}
          size="md"
          onClick={() => onClose(ACTIONS.NO, "")}
        >
          No
        </CustomButton>,
      ];
    } else if (variant === ACTIONS.SUCCESS) {
      return (
        <CustomButton
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.SUCCESS, "")}
        >
          Close
        </CustomButton>
      );
    } else if (variant === ACTIONS.ERROR || variant === ACTIONS.OK) {
      return (
        <CustomButton
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.OK, "")}
        >
          Ok
        </CustomButton>
      );
    } else if (variant === ACTIONS.EXPORT_CANCEL) {
      return [
        <CustomButton
          key={1}
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.EXPORT, checkboxSelected, "")}
          loading={loading ? loading : false}
        >
          Export
        </CustomButton>,
        <CustomButton
          key={2}
          variant={BUTTON_VARIANTS.LIGHT}
          size="md"
          onClick={() => onClose(ACTIONS.CANCEL, checkboxSelected, "")}
        >
          Cancel
        </CustomButton>,
      ];
    } else if (variant === ACTIONS.SEND_NOTIFICATION) {
      return [
        <CustomButton
          key={1}
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.YES, "")}
        >
          Send Notification
        </CustomButton>,
        <CustomButton
          key={2}
          variant={BUTTON_VARIANTS.LIGHT}
          size="md"
          onClick={() => onClose(ACTIONS.CANCEL, "")}
        >
          Cancel
        </CustomButton>,
      ];
    } else if (variant === ACTIONS.EDIT_NOTIFICATION) {
      return [
        <CustomButton
          key={1}
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.YES, "")}
        >
          Edit Notification
        </CustomButton>,
        <CustomButton
          key={2}
          variant={BUTTON_VARIANTS.LIGHT}
          size="md"
          onClick={() => onClose(ACTIONS.CANCEL, "")}
        >
          Cancel
        </CustomButton>,
      ];
    } else if (variant === ACTIONS.SAVE_CLEAR) {
      return [
        <CustomButton
          key={1}
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => onClose(ACTIONS.SAVE, "")}
        >
          Save
        </CustomButton>,
        <CustomButton
          key={2}
          variant={BUTTON_VARIANTS.LIGHT}
          size="md"
          onClick={() => onClose(ACTIONS.CLEAR, "")}
        >
          Clear
        </CustomButton>,
      ];
    }
  };
  const CHECK = {
    SELECTED: "SELECTED",
    NOT_SELECTED: "NOT_SELECTED",
    PARTIALLY_SELECTED: "PARTIALLY_SELECTED",
  };
  const getCheckBoxState = () => {
    return checkboxSelected ? CHECK.SELECTED : CHECK.NOT_SELECTED;
  };
  const getCheckbox = () => {
    return (
      <div className = "rolledOff_checkbox">
        {/* <Checkbox
          label= {checkboxLabel}
          checked={checkboxSelected}
          onChange={()=>checkboxOnChange()}
        /> */}
        <CustomCheckBox
          list={[{ key: 1, value: checkboxLabel }]}
          key={"key"}
          value={"value"}
          onCheckboxClick={() => checkboxOnChange()}
          isSelected={getCheckBoxState}
        />
      </div>
    );
  };
  return (
    <Modal
      show={visible}
      onHide={() => onClose(ACTIONS.CLOSE, "")}
      size={size}
      animation={true}
      bsPrefix="message-overlay"
      dialogClassName={dialogClassName}
    >
      <Modal.Header closeButton className="msg-modal-header">
        <Modal.Title>{title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {customContent ? customContent() : message}
        {checkboxLabel ? getCheckbox() : null}
      </Modal.Body>
      <Modal.Footer>
        {typeof customFooter === "function" ? (
          customFooter()
        ) : (
          <div className="pcdm-btn-wrapper pcdm-btn-wrapper--inline">
            {getFooter()}
          </div>
        )}
      </Modal.Footer>
    </Modal>
  );
}

const DEFAULT_MSG_MODAL_CONFIG = {
  visible: false,
  onClose: null,
  variant: ACTIONS.YES_NO,
  message: "",
  title: "",
  size: "sm",
  customContent: null,
  dialogClassName: "",
};
export { DEFAULT_MSG_MODAL_CONFIG, MessageModal };
