import React, { useMemo } from "react";
import "./selectDropdown.scss";
import Select from "react-select";
import PropTypes from "prop-types";
import ErrorMsg from "../errorMsg/errorMsg";
import ToolTip from "../../ToolTip/ToolTip";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import { TOOL_TIP_TITLE } from "../../../constants/action.constants";
import DisableView from "../../../../../../shared/common/DisableView/disableView";

function CustomSelect({
  label,
  formObj,
  onChange,
  onInputChange = null,
  isRequired,
  config,
  name,
  formatOptionLabel = null,
  placeholder = "Select an option",
  containerClassName = "",
  classNamePrefix = "pcdm-input",
  isMulti = false,
  hasToolTip = false,
  toolTipTitle = TOOL_TIP_TITLE.DEFAULT_TITLE,
  toolTipMessage = TOOL_TIP_MESSAGE.NO_TOOL_TIP,
  disable = false,
  disabledErrorMessage = "",
  isOptionsMultiList = false,
  formatGroupLabel = null,
  isLoading=false,
  isClearable= false,
  errorTooltip = false,
  info,
  infoStyle,
  redTooltip = false,
  getToolTipMessage = null,
}) {
  const getToolTip = () => {
    return hasToolTip ? redTooltip ? (
      <ToolTip toolTipMessage={getToolTipMessage()} toolTipTitle={""}
          content={() => (
            <span className="custom-tool-tip-alert-icon">
              <i className="fas fa-exclamation-circle" title="Click to get info"></i>
            </span>
          )}
          >
          </ToolTip>
    ): (
      <ToolTip toolTipMessage={toolTipMessage} toolTipTitle={toolTipTitle} ></ToolTip>
    ) : null;
  };
  const options = useMemo(() => {
    return config && config.options.length
      ? config.options.map((opt) => {
        return {
          label: config.value ? opt[config.value] : opt,
          value: config.id ? opt[config.id] : opt,
        };
      })
      : [];
  }, [config.options]);


/*  const manageOptions = useMemo(() => {
    return isOptionsMultiList ? config.options.map((opt) => {
      return opt.options ? opt.options.map((prdt) => {
        console.log(prdt)
        return {
          label: prdt[config.value],
          value: prdt[config.id],
        }
      }) : []
    }) : []
  }, [config.options]); */

  const getValue = (val) => {
    let value = null;
    if (isOptionsMultiList) {
      let allOptions = config.options.map((grp) => grp.options).flat();
      value = allOptions.filter((opt) => opt.value === val)[0];
    }
    else {
      value = options.length ? options.filter((opt) => opt.value === val)[0] : {};
    };
    value = value != undefined ? value : null; // returning null instead of undefined
    return value;
  };
  return (
    <div className={`rover-custom-select ${containerClassName}`}>
      {label ? (
        <label className={isRequired ? "required text-cap" : "text-cap"}>{label}</label>
      ) : null}
      {info  ? (
        <span style={infoStyle()}>{info}</span>
      ) : null}
      {getToolTip()}
      <Select
        label={label}
        formatGroupLabel = {formatGroupLabel}
        name={name}
        styles={(base) => ({ ...base, zIndex: 999 })}
        isMulti={isMulti}
        classNamePrefix={classNamePrefix}
        options={isOptionsMultiList ? config.options : options}
        isDisabled={formObj.readOnly || formObj.disabled || false}
        isClearable={isClearable || false}
        menuContainerStyle={{ zIndex: 999 }}
        placeholder={placeholder}
        onChange={(e) => {
          if (e == null && isClearable) {
            e = { label: "", value: "" }
          }
          if (isMulti) {
            onChange({ value: e, name: name });
          } else if (e.value === formObj.value) {
          } else {
            onChange({ ...e, name: name });
          }
        }}
        onInputChange={onInputChange === null ? ()=>{}:(value) => onInputChange(value)}
        formatOptionLabel={formatOptionLabel}
        value={isMulti ? formObj.value : getValue(formObj.value)}
        isLoading={isLoading}
      />
      {errorTooltip ? 
        <div className="card"><span className="tooltipText">{toolTipMessage}</span></div>
      : formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null
      }
      {disable && disabledErrorMessage ? (
        <DisableView className="custom-select-disable">
          <>
            {getToolTip()}
            {disabledErrorMessage}
          </>
        </DisableView>
      ) : null}
    </div>
  );
}
CustomSelect.propTypes = {
  name: PropTypes.string,
  label: PropTypes.string,
  formObj: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.array]),
    error: PropTypes.bool,
    errorMsg: PropTypes.string,
  }),
  onChange: PropTypes.func,
  isRequired: PropTypes.bool,
  config: PropTypes.shape({
    options: PropTypes.array,
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  }),
  customValue: PropTypes.func,
  onInputChange: PropTypes.func,
  isLoading: PropTypes.bool,
};
export default CustomSelect;
