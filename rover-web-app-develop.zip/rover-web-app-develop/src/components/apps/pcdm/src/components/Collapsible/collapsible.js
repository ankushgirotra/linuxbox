import React, {useState} from "react";
import "./collapsible.scss";

export default function Collapsible({ children }) {
  const [collapse, setCollapse] = useState(true);
  return (
    <div>
      <div id="module" >
        <div
          className={collapse ? `collapse` : `collapsed`}
          aria-expanded="false"
        >
          {children}
        </div>
        <a
          role="button"
          className="collapse-link"
          aria-expanded="false"
          onClick={() => setCollapse(!collapse)}
        >
          {collapse ? '+ Show more': '- Show less'}
        </a>
      </div>
    </div>
  );
}
