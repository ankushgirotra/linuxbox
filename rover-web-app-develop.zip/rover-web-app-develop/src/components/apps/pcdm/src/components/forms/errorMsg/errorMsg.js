import React, { useState } from "react";
import "./errorMsg.scss";

export default function ErrorMsg(props) {
  const [showErrorDetail, setshowErrorDetail] = useState(false);
  const { message, errorDetail } = props;
  return (
    <div className="error-message-container">
      <div className="error-message">
        {message}
        {errorDetail ? (
          <div onClick={() => setshowErrorDetail(!showErrorDetail)}>
            {showErrorDetail ? "show less" : "show more"}
          </div>
        ) : null}
      </div>
    </div>
  );
}
