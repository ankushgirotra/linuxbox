import React, { Component } from "react";
import "./pcdm-modal.scss";
import PropTypes from "prop-types";
import { ACTIONS } from "../../constants/action.constants";

const DEFAULT_WIDTH = 500;

class PCDMmodal extends Component {
  decideContent = () => {
    const { config, closeModal } = this.props;
    if (config.variant === ACTIONS.CUSTOM) {
      return this.props[config.customPropId];
    } else if (config.variant === ACTIONS.SUCCESS) {
      return (
        <div>
          <p className="modal-message">{config.message}</p>
          <div className="pcdm-btn-wrapper pcdm-btn-wrapper--inline">
            <button
              className={`pcdm-btn pcdm-btn--${config.variant.toLowerCase()}`}
              onClick={() => closeModal("", "")}
            >
              Done
            </button>
          </div>
        </div>
      );
    }
  };
  decideHeaderContent = () => {
    const { customHeader, config } = this.props;
    if (customHeader) {
      return customHeader();
    } else {
      return (
        <h4 className={`text-${config.variant.toLowerCase()}`}>
          {config.title}
        </h4>
      );
    }
  };
  getTitleClass = () => {
    const { config } = this.props;
    if (config.variant === ACTIONS.SUCCESS) {
      return "pcdm-modal__header--success";
    } else if (config.variant === ACTIONS.ERROR) {
      return "pcdm-modal__header--error";
    } else return "";
  };
  render() {
    const { visible, closeModal, config } = this.props;
    const width = config.size
      ? config.size === "xs"
        ? 300
        : config.size === "sm"
        ? 400
        : config.size === "md"
        ? 600
        : config.size === "lg"
        ? 800
        : DEFAULT_WIDTH
      : DEFAULT_WIDTH;
    return visible ? (
      <div className="overlay">
        <div
          className="pcdm-modal"
          id="pcdm-modal"
          style={{ width: `${width}px` }}
        >
          <div
            className={`pcdm-modal-close text-${config.variant.toLowerCase()}`}
            onClick={closeModal}
          >
            <i className="far fa-window-close"></i>
          </div>
          <div className={`pcdm-modal__header ${this.getTitleClass()}`}>
            {this.decideHeaderContent()}
          </div>
          <div className="pcdm-modal__content">{this.decideContent()}</div>
          <div className="pcdm-modal-footer"></div>
        </div>
      </div>
    ) : null;
  }
}
PCDMmodal.propTypes = {
  visible: PropTypes.bool,
  config: PropTypes.shape({
    customPropId: PropTypes.string,
    variant: PropTypes.oneOf([
      ACTIONS.CUSTOM,
      ACTIONS.SUCCESS,
      ACTIONS.ERROR,
      ACTIONS.WARNING,
      ACTIONS.CONFIRM,
      ACTIONS.INFO,
    ]),
    title: PropTypes.string,
    message: PropTypes.string,
  }),
  customHeader: PropTypes.func,
  closeModal: PropTypes.func,
};
const DEFAULT_MODAL_STATE = {
  variant: "",
  customPropId: "",
  title: "",
  size: "sm",
};
export { PCDMmodal, DEFAULT_MODAL_STATE };
