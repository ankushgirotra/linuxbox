import React from "react";
import { Modal, Button } from "react-bootstrap";
import { ACTIONS } from "../../constants/action.constants";
import CustomButton, { BUTTON_VARIANTS } from "../forms/Button/button";
import { connect } from "react-redux";
import { discardDisplayCommonError } from "../../store/common.reducer";
import "./messageModal.scss";

export function ErrorMessageModal(props){
  const onClose = () => {
      props.discardNotification()
  }
  return (
    <Modal
      show={props.errorNotification.data }
      onHide={() => onClose()}
      size={"md"}
      animation={true}
      bsPrefix="message-overlay"
      dialogClassName={"error-message-prompt-modal"}
    >
      <Modal.Header closeButton className="msg-modal-header">
        {/* <Modal.Title>
        {customContent ? customContent() : message}
        
        </Modal.Title> */}
      </Modal.Header>
      <Modal.Body > 
        "Some error occured. Please try again."
     </Modal.Body>
      <Modal.Footer>
          <div className="pcdm-btn-wrapper pcdm-btn-wrapper--inline">
            <CustomButton
          variant={BUTTON_VARIANTS.WARNING}
          size="md"
          onClick={() => onClose()}
        >
          Ok
        </CustomButton>
          </div>
      </Modal.Footer>
    </Modal>
  );
}

export default ErrorMessageModal;