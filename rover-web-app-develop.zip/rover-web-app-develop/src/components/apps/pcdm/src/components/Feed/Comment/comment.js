import React from "react";
import "./comment.scss";
import moment from "moment";
import userDefault from "../../../../../../../shared/img/logo/user-default.jpg";
export default function Comment({ comment, name, time, content }) {
  return (
    <div>
      <div className="chat-container">
        <img src={userDefault} alt="avatar" />
        <h5 className="pcdm-head inline">{comment[name.key]}</h5>
        <span
          className="log-time inline"
          title={moment(comment[time.key]).format("MMM Do, YYYY hh:mm A")}
        >
          {` - ${moment(comment[time.key]).fromNow()}`}
        </span>
        <p className="chat-content">{comment[content.key]}</p>
      </div>
    </div>
  );
}
