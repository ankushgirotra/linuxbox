import React from "react";
import "./switch.scss";
import ErrorMsg from "../errorMsg/errorMsg";
import ToolTip from "../../ToolTip/ToolTip";
import DisableView from "../../../../../../shared/common/DisableView/disableView";

export default function Switch({
  label,
  on,
  off,
  config,
  onChange,
  formObj,
  isRequired,
  className = "",
  hasToolTip,
  toolTipMessage,
  toolTipTitle,
  toolTipPlacement,
  disable,
  disabledErrorMessage,
}) {
  const getToolTip = () => {
    return hasToolTip ? (
      <ToolTip
        toolTipMessage={toolTipMessage}
        toolTipTitle={toolTipTitle}
        placement={toolTipPlacement}
      ></ToolTip>
    ) : null;
  };
  /**
   * config.options[0] => on state
   * config.options[1] => off state
   */
  const disableStyle = {
    background: "grey",
    cursor: "not-allowed",
  };
  const onValue = config.options[0][config.id];
  const offValue = config.options[1][config.id];
  return (
    <div className={`custom-slider ${className}`}>
      {label ? (
        <label className={isRequired ? "required text-cap" : "text-cap"}>{label}</label>
      ) : null}
      {getToolTip()}
      <ul className="slider-content">
        <li className={`slider-label ${formObj.value === onValue ? "slider-label--active" : ""}`}>
          {config.options[0][config.value]}
        </li>
        <li>
          <div
            className="rover-switch"
            onClick={() =>
              !disable ? onChange(formObj.value === onValue ? offValue : onValue) : null
            }
          >
            <input type="checkbox" checked={formObj.value !== onValue} />
            <span className="slider round" style={disable ? disableStyle : null}></span>
          </div>
        </li>
        {offValue ? (
          <li
            className={`slider-label ${formObj.value === offValue ? "slider-label--active" : ""}`}
          >
            {config.options[1][config.value]}
          </li>
        ) : null}
      </ul>
      {disable && disabledErrorMessage ? (
        <DisableView className="slider-locked-error">
          <>
            {getToolTip()}
            {disabledErrorMessage}
          </>
        </DisableView>
      ) : null}
      {formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null}
    </div>
  );
}

