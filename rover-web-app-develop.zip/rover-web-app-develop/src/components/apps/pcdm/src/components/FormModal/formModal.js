import React from "react";
import "./formModal.scss";
import PropTypes from "prop-types";
import { X } from "react-feather";
import { Modal } from "react-bootstrap";
import "./formModal.scss";
import { OverlayLoader } from "../DataHandler/dataHandler";

function FormModal({ visible, header, content, footer, closeModal, className, isLoading, isSCForm }) {
  const decideBodyContent = () => {
    if (typeof content === "function") {
      return content();
    } else {
      return content;
    }
  };
  const decideHeaderContent = () => {
    if (typeof header === "function") {
      return header();
    } else {
      return <h4>{header}</h4>;
    }
  };
  const decideFooterContent = () => {
    if (typeof footer === "function") {
      return (
        <Modal.Footer bsPrefix="custom-modal__footer custom-modal__footer-top-border">
          {footer()}
        </Modal.Footer>
      );
    } else if (footer === null || footer === undefined) {
      return null;
    } else {
      return (
        <Modal.Footer bsPrefix="custom-modal__footer custom-modal__footer-top-border">
          {footer}
        </Modal.Footer>
      );
    }
  };
  return (
    <Modal
      show={visible}
      onHide={closeModal}
      backdrop="static"
      dialogClassName={`custom-modal ${className || ""}`}
    >
      <div style={{position: 'relative'}}>
      <OverlayLoader loading={isLoading}/>
      <Modal.Header bsPrefix="custom-modal__header">
        <div className="custom-modal__header--close-icon" onClick={closeModal}>
          {isSCForm ? <X size={20} strokeWidth={3} /> : <i className="far fa-window-close"></i>}
        </div>
        {decideHeaderContent()}
      </Modal.Header>
      <Modal.Body bsPrefix="custom-modal__body">{decideBodyContent()}</Modal.Body>
      {decideFooterContent()}
      </div>
    </Modal>
  );
}

FormModal.propTypes = {
  visible: PropTypes.bool,
  isLoading: PropTypes.bool,
  header: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
  content: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
  footer: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
  closeModal: PropTypes.func,
  className: PropTypes.string,
};
FormModal.defaultProps = {
  visible: true,
  header: "Modal Title",
  content: "Modal content",
  footer: "Modal Footer",
  closeModal: null,
  className: "",
};
export { FormModal };
