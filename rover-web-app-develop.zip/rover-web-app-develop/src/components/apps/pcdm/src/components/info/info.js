import React from "react";
import { Table } from "react-bootstrap";
import "./info.scss";
import CustomButton, { BUTTON_VARIANTS } from "../forms/Button/button";
import { resetForecast } from "../../store/forecast.reducer";
import { connect } from "react-redux";
import { resetTeam } from "../../store/teams.reducer";
import { resetProject } from "../../store/projects.reducer";
import { resetSummary } from "../../store/summary.reducer";
import { productLineSummaryReset } from "../../store/productLine.reducer";
import { PCDM_ROUTES } from "../../../../../app/Route/constants/pcdmRoutes.constants";
import Collapsible from "../Collapsible/collapsible";

export function info(props) {
  const onExitIconClick = () => {
    if (props.forecastTableHistory.length && props.checkForecastChanges) {
      props.checkForecastChanges();
    } else {
      props.resetTeamStore();
      props.resetProjectStore();
      props.resetSummaryStore();
      props.resetForecastStore();
      props.resetProductLineStore();
      props.history.push(PCDM_ROUTES.ROUTE);
    }
  };
  const checkTitleContent = (property) => {   
    return typeof(property) === "string" ? property : property.props.children[0];
  }

  return (
    <Table borderless={true}>
      <tbody>
        {Object.keys(props.info).map((property, i) => {
          let valueLength = props.info[property] ? props.info[property].length : 0;
          return (
            <tr key={i}>
              <td className="info-key">{property}:</td>
              <td className="info-value" title={props.isTeams || property === "Product Manaager" ? checkTitleContent(props.info[property])
                : props.info[property]}>
                {valueLength > 200 ? (
                  <Collapsible> {props.info[property]}</Collapsible>
                ) : (
                  props.info[property]
                )}
                {(property === "Product" &&
                  props.history &&
                  props.history.location.pathname.includes("pcdm")) ||
                (props.history && props.history.location.pathname.includes("product-line")) ? (
                  <CustomButton
                    onClick={onExitIconClick}
                    title={"Switch Product"}
                    className="switch-product-link"
                    borderless={true}
                    size="sm"
                    variant={BUTTON_VARIANTS.ICON}
                  >
                    <span className="lnr lnr-exit"></span>
                  </CustomButton>
                ) : null}
              </td>
            </tr>
          );
        })}
        {props.isTeams ?
                <tr key="scrumNew">
                <td className="info-key">{props.scrumNewLabel}:</td>
                <td className="info-value" title={props.scrumNewValue}>{props.scrumNewValue} </td> 
                </tr> 
              :null }
      </tbody>
    </Table>
  );
}

export const mapStateToProps = (state) => ({
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
});
export const mapDispatchToProps = (dispatch) => ({
  resetTeamStore: () => dispatch(resetTeam()),
  resetProjectStore: () => dispatch(resetProject()),
  resetSummaryStore: () => dispatch(resetSummary()),
  resetForecastStore: () => dispatch(resetForecast()),
  resetProductLineStore: () => dispatch(productLineSummaryReset()),
});

export default connect(mapStateToProps, mapDispatchToProps)(info);
