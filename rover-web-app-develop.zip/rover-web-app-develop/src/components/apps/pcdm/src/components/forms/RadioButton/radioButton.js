import React from "react";
import "./radioButton.scss";
import { AlertCircle } from "react-feather";

export default function RadioButton(props) {
  const { groupName, value, checked, id, hasTooltip=false } = props;
  return (
    <>
      <label className="radio-container">
        {value}
        <input
          type="radio"
          name={groupName}
          checked={checked}
          onClick={props.onClick ? () => props.onClick(id) : null}
          onChange={() => props.onChange(id)}
        />
        {hasTooltip ? <span className="teams-info-enddate-tooltip">
          <AlertCircle size={17} strokeWidth={3} /> </span> : null}
        <span className="checkmark"></span>
      </label>
    </>
  );
}
