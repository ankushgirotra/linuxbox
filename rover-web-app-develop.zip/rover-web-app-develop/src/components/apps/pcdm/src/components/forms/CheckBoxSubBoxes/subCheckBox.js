import React, { useState, useEffect } from "react";
// import { OverlayLoader } from "../../../../pcdm/src/components/DataHandler/dataHandler";
import CustomCheckBox, { CustomCheck } from "../../../../../../shared/CustomCheckBox/customCheckBox";
import './subCheckBox.scss';

export const CHECK = {
    SELECTED: "SELECTED",
    NOT_SELECTED: "NOT_SELECTED",
    PARTIALLY_SELECTED: "PARTIALLY_SELECTED",
};

export default function RMFilterSection({
    title,
    list,
    key,
    value,
    valuesSelected,
    selectedFilters,
    updateFilters,
    noDataMessage = "No data",
    className = "",
    checkAllSelected,
    selectOrDeselectAll,
    setSelectedFilter,
    componentName = "",
}) {
    const checkSelected = (payload, filters = []) => {
        let tempValues = [...selectedFilters];
        let checkExist = CHECK.NOT_SELECTED;
        tempValues.forEach((el) => {
            if (el.id === payload.value) {
                if (el.children.length === 0) {
                    checkExist = CHECK.NOT_SELECTED
                } else if (el.children.length < list[payload.value][value].length) {
                    checkExist = CHECK.PARTIALLY_SELECTED
                } else {
                    checkExist = CHECK.SELECTED
                }
            }
        })
        return checkExist;
    };
    const checkChildSelected = (payload, parent) => {
        let tempValues = [...selectedFilters];
        let checkExist = tempValues.findIndex((el) =>  el.id === parent);
        if(checkExist !== -1) {
           return tempValues[checkExist].children.includes(payload) ? CHECK.SELECTED : CHECK.NOT_SELECTED
        }
        return CHECK.NOT_SELECTED;
    };
    const [open, setOpen] = useState(false);
    const openCheckBox = (value, e) => {
        e.stopPropagation()
        if (value) {
            document.getElementById(`dropdown-${componentName}`).classList.add("on");
        } else {
            document.getElementById(`dropdown-${componentName}`).classList.remove("on");
        }
        setOpen(value);
    };

    const displayListItems = (element) => {
        if (document.getElementById(`${componentName}-${element}`).style.display && document.getElementById(`${componentName}-${element}`).style.display !== 'none') {
            document.getElementById(`${componentName}-${element}`).style.display = 'none';
            document.getElementById(`${componentName}-${element}-minus`).style.display = 'none';
            document.getElementById(`${componentName}-${element}-plus`).style.display = 'block';
        } else {
            document.getElementById(`${componentName}-${element}`).style.display = 'list-item';
            document.getElementById(`${componentName}-${element}-plus`).style.display = 'none';
            document.getElementById(`${componentName}-${element}-minus`).style.display = 'block';
        }
    }
    const intermediateClick = (element) => {
        let selected = [...selectedFilters];
        const exists = selected.findIndex((el) => el.id === element.value);
        if (exists !== -1) {
            if (selected[exists].children.length > 0 && selected[exists].children.length < list[element.value][value].length) {
                selected[exists].children = list[element.value][value];
                setSelectedFilter(selected);
            } else {
                let newSelected = selected.filter((el) => el.id !== element.value);
                setSelectedFilter(newSelected);
            }
        } else {
            let obj = { id: element.value, children: list[element.value][value] };
            selected.push(obj);
            setSelectedFilter(selected);
        }
    }
    useEffect(()=>{
        valuesSelected !== 0 ? document.getElementById(`dropdown-placeholder-${componentName}`).innerHTML = `${valuesSelected} Selected` : document.getElementById(`dropdown-placeholder-${componentName}`).innerHTML = `Select`
    },[valuesSelected])
    return (
        <div
            id={`dropdown-${componentName}`}
            onClick={(e) => openCheckBox(!open, e)}
            className="dropdown-checkbox"
            data-control="checkbox-dropdown"
        >
            <label id={`dropdown-placeholder-${componentName}`} className="dropdown-label">
                Select
            </label>
            <div
                onClick={(e) => e.stopPropagation()}
                id={`dropdown-list-${componentName}`}
                className="dropdown-list"
            >
                <div className='dropdown-option'>
                    <CustomCheckBox
                        list={[{ key: 1, value: "Select All" }]}
                        key={"key"}
                        value={"value"}
                        onCheckboxClick={(filter) => selectOrDeselectAll(title)}
                        isSelected={(el) => checkAllSelected()}
                    />
                </div>
                {Object.keys(list).length ? (
                    Object.keys(list).map((el, index) => {
                        return (
                            <ul>
                                <li className='dropdown-option'>
                                    <div onClick={()=>displayListItems(el)} id={`${componentName}-${el}-plus`}><i className='fa fa-plus'></i></div>
                                    <div  onClick={()=>displayListItems(el)} id={`${componentName}-${el}-minus`} style={{display:'none'}}><i className='fa fa-minus'></i></div>
                                    <CustomCheckBox
                                        list={[{ id: list[el][key], value: el }]}
                                        key={'id'}
                                        value={'value'}
                                        onCheckboxClick={(filter) => intermediateClick(filter)}
                                        isSelected={checkSelected}
                                    />
                                </li>
                                <li id={`${componentName}-${el}`} className='dropdown-subOption'>
                                    <CustomCheckBox
                                        list={list[el][value] ? list[el][value] : []}
                                        key={key}
                                        value={value}
                                        onCheckboxClick={(filter) => updateFilters(filter, el)}
                                        isSelected={(element) => checkChildSelected(element, el)}
                                    />
                                </li>
                            </ul>
                        )
                    })) : null}
            </div>
        </div>
    );
}
