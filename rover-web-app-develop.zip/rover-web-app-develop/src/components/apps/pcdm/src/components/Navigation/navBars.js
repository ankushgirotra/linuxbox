import React from "react";
import PropTypes from "prop-types";
import "./navBars.scss";

function NavBarCapsule({
  selected,
  navOptions,
  onClick,
  customContainerClassName,
}) {
  const isNavSelected = (id) => {
    return selected === id;
  };
  return (
    <div className={`navbar-capsule-conatiner ${customContainerClassName}`}>
      <ul>
        {navOptions.map((item, index) => (
          <li
            key={index}
            onClick={() => onClick(item.key)}
            className={`navbar-capsule-head ${
              isNavSelected(item.key) ? "navbar-capsule-head-active" : ""
            }`}
          >
            <a>{item.value}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

NavBarCapsule.propTypes = {
  selected: PropTypes.string,
  navOptions: PropTypes.array,
  onClick: PropTypes.func,
};

export default NavBarCapsule;
