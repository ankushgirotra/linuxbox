import React from "react";
import { OverlayTrigger, Popover } from "react-bootstrap";
import "./toolTip.scss";

export default function ToolTip(props) {
  const { toolTipMessage, toolTipTitle, toolTipPlacement = "auto", content ,margin = "auto" } = props;
  const makeTooltipContent = () => {
    if (typeof toolTipMessage === "function") {
      return toolTipMessage();
    } else if (Array.isArray(toolTipMessage)) {
      return toolTipMessage.map((data, index) => <p key={index}>{data}</p>);
    } else {
      return toolTipMessage;
    }
  };
  const toolTipData = (
    <Popover className="custom-popover" style={{marginLeft : margin}} >
      <Popover.Title className="custom-popover-header">{toolTipTitle}</Popover.Title>
      <Popover.Content className="custom-popover-content">{makeTooltipContent()}</Popover.Content>
    </Popover>
  );
  return (
    <OverlayTrigger trigger="click" rootClose placement={toolTipPlacement} overlay={toolTipData}>
      {content ? (
        content()
      ) : (
        <span className="custom-tool-tip">
          <i className="far fa-question-circle" title="Click to get info"></i>
        </span>
      )}
    </OverlayTrigger>
  );
}
