import React from "react";
import PropTypes from "prop-types";

import "./table.scss";

function RowColHeaderTable({
  columns = [],
  rows = [],
  className = "",
  customRowColHead,
  defaultValue = "",
  customCell,
  colWidths = [],
  isStriped=true
}) {
  const getWidths = () => {
    if (colWidths.length) {
      return (
        <colgroup>
          {colWidths.map((colWidth, index) => (
            <col key={index} style={{ width: `${colWidth}` }} />
          ))}
        </colgroup>
      );
    } else {
      return (
        <colgroup>
          {columns.map((colWidth, index) => (
            <col key={index} style={{ width: `${80}px` }} />
          ))}
        </colgroup>
      );
    }
  };
  return (
    <div className={isStriped ? `row-col-head-container table-striped ${className}` : `row-col-head-container ${className} `}>
      <table>
      {getWidths()}
        <thead>
          <tr>
            <th>{customRowColHead ? customRowColHead : ""}</th>
            {columns.map((column, i) => (
              <th key={i}>{column.head}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, indexI) => (
            <tr key={indexI}>
              <th>{row.head}</th>
              {columns.map((col, indexJ) => (
                <td key={indexJ}>
                  {typeof customCell === "function"
                    ? customCell(row, col)
                    : row[col.accessor] || row[col.accessor] === 0
                    ? row[col.accessor]
                    : defaultValue}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export function HorizontalScroll({ children }) {
  return (
    <div className="outer">
      <div className="pcdm-scroll-horizontal inner">{children}</div>
    </div>
  );
}
RowColHeaderTable.propTypes = {
  columns: PropTypes.arrayOf(
    PropTypes.shape({ head: PropTypes.string, accessor: PropTypes.string })
  ),
  Rows: PropTypes.array,
};
export default RowColHeaderTable;
