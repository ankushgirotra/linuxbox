import React from "react";
import { HotTable, HotColumn } from "@handsontable/react";
import Handsontable from "handsontable";
import "./spreadsheet.scss";
import "handsontable/dist/handsontable.full.css";
import { Component } from "react";
import { connect } from "react-redux";

class Spreadsheet extends Component {
  constructor(props) {
    super(props);
    this.state = { sideBarState: true };
    this.hotTableRef = React.createRef();
  }
  refreshDimensions = () => {
    setTimeout(() => {
      console.log("refreshing", this.hotTableRef);
      this.hotTableRef.current.hotInstance.refreshDimensions();
      this.setState({ sideBarState: this.props.sidebar.collapse });
    }, 2000);
  };
  componentDidMount() {
    this.props.onRef(this);
    const { updateSettings } = this.props;
    if (updateSettings) {
      this.hotTableRef.current.hotInstance.updateSettings(updateSettings(this.hotTableRef));
    }
  }
  
  callSetDataAtCell = (row, col, value, source) => {
    this.hotTableRef.current.hotInstance.setDateAtCell(row, col, value, source);
  };
  getRowData = (row) => {
    return this.hotTableRef.current.hotInstance.getSourceDataAtRow(row);
  };
  componentWillUnmount() {
    this.props.onRef(this);
  }
  render() {
    const {
      className = "",
      columns,
      data = Handsontable.helper.createSpreadsheetData(14, 14),
      colWidths = 100,
      fixedRowsTop = 0,
      fixedColumnsLeft = 0,
      colHeaders = false,
      rowHeaders = false,
      wholeTableReadonly = false,
      nestedHeaders = [],
      mergeCells = [],
      customRender = null,
      allAlignment = "htCenter",
      sidebar,
      onCellSelect,
      onCellChange,
      onAfterCellChange,
    } = this.props;
    if (this.state.sideBarState !== sidebar.collapse) {
      this.refreshDimensions();
    }
    return [
      <div className={`${className} rover-spreadsheet-container`}>
        <HotTable
          ref={this.hotTableRef}
          className={allAlignment}
          colWidths={colWidths} // Column widths in array or number
          columns={columns} // Column accessor specifier for nested object
          data={JSON.parse(JSON.stringify(data))} // Datasource
          colHeaders={colHeaders} // Show column headers <boolean>
          rowHeaders={rowHeaders} // show row headers <boolean>
          licenseKey={"non-commercial-and-evaluation"}
          fixedRowsTop={fixedRowsTop} // no of rows fixed top <number>
          fixedColumnsLeft={fixedColumnsLeft} // no of rows fixed left <number>
          nestedHeaders={[...nestedHeaders]} // nested headers config
          mergeCells={mergeCells} // merged cell specifications
          renderer={customRender} // custom render for each cell <function>
          copyable={false} // disable copy of data
          disableVisualSelection={true} // disable visual selection
          renderAllRows={false} // render all rows <boolean>
          readOnly={wholeTableReadonly} // making all cells read only
          readOnlyCellClassName={"spreadsheet-table-readonly-cell"}
          placeholderCellClassName={"spreadsheet-table-placeholder"}
          afterSelectionEnd={onCellSelect}
          beforeChange={(changes, source) => onCellChange(changes, source, this.hotTableRef)}
        />
      </div>,
    ];
  }
}

export const mapStateToProps = (state) => ({ sidebar: state.SidebarReducer });
export default connect(mapStateToProps)(Spreadsheet);
