import React from "react";
import "./list.scss";
import RadioButton from "../forms/RadioButton/radioButton";
import Checkbox from "../forms/Checkbox/checkbox";
import ListOptions from "../../../../skillsCentral/src/component/list/List";
import CustomCheckBox from "../../../../../shared/CustomCheckBox/customCheckBox";
import { AlertCircle } from "react-feather";

export default function List({
  list,
  title,
  selected,
  onClick,
  onChange,
  multiSelect = false,
  emptyTxt = "No list found",
  className = "",
  id,
  value,
  groupName,
  showSelectAll = false,
  onSelectAllClick,
  hasToolTip = false,
  checkToolTip = null,
  isRolledOffTeams = false,
  getMore = null,
  hideRadioButton = false,
  showCheckbox = false,
}) {
  const checkSelect = (currentId, on) => {
    if (multiSelect) {
      return selected && selected.filter((selecteditem) => selecteditem[id] === currentId).length;
    } else {
      return selected && selected[id] === currentId;
    }
  };

  const checkSelected = (selectedItem) => {
    let checkExist = selected.findIndex((el) => el[id] === selectedItem[id]);
    return checkExist >= 0 ? "SELECTED" : "NOT_SELECTED";
  };

  const showListOptions = (item, displayKey) => {
    return (
      <div className="list-option">
        <span className="list-label" title={item[displayKey]}>
          {item[displayKey]}
        </span>
        {hasToolTip ? checkToolTipContent(item) ? <span className="teams-list-enddate-tooltip">
          <AlertCircle
            size="15"
            color="#d50000"
            strokeWidth={2.5}
          /> </span> : null :
          null}
      </div>
    )
  };

  const checkToolTipContent = (row) => {
    return checkToolTip(row);
  };

  const getClassName = () => {
    if (hideRadioButton) {
      if (showCheckbox) {
        return "list-checkbox";
      } else {
        return "list-options sc-scroll-vertical";
      };
    } else {
      return "list-select pcdm-scroll-vertical";
    };
  };

  return (
    <div className={`list-select-container ${className}`}>
      {typeof title === "string" ? (
        <div className="list-head">
          <h5 className="pcdm-head center">{title}</h5>
          {showSelectAll ? <h5 className="pcdm-head">
            <Checkbox
              label={"Select All"}
              onChange={onSelectAllClick}
            />
          </h5> : null}
        </div>
      ) : (
          title()
        )}
      <div className={getClassName()}>
        {list.length ?
          (hideRadioButton ?
            (showCheckbox ?
              <CustomCheckBox
                list={list}
                key={id}
                value={value}
                onCheckboxClick={(el) => onChange(el)}
                isSelected={(el) => checkSelected(el)}
                containerClassName = {"list-checkbox_container sc-scroll-vertical"}
                showSelectAll = {showSelectAll}
                onSelectAllClick={onSelectAllClick}
                isSelectAllChecked = {(list.length === selected.length) ? true : false}
              /> : (
                <ListOptions
                  listArray={list}
                  displayKey={value}
                  onClick={onChange}
                  isActive={(item) => checkSelect(item[id], "listOption") ? true : false}
                  content={(item, displayKey) => showListOptions(item, displayKey)}
                />
              )
            ) : (
              <ul>
                {list.map((item, i) => (
                  <li key={i} className={checkSelect(item[id], "list") ? "li-active" : ""}>
                    <RadioButton
                      groupName={multiSelect ? `${item[value]}-${item[id]}` : groupName}
                      value={item[value]}
                      id={item[id]}
                      onClick={multiSelect ? (id) => onClick(item) : null}
                      checked={checkSelect(item[id], "radio") ? true : false}
                      onChange={(id) => onChange(item)}
                      hasTooltip={hasToolTip ? checkToolTipContent(item) : false}
                    />
                  </li>
                ))}
              </ul>
            )
          ) : typeof emptyTxt === "string" ? (
            <div className="list-empty">
              <p>{emptyTxt}</p>
            </div>
          ) : (
              emptyTxt()
            )}
        {isRolledOffTeams ?
          <div id="rolledOff_teams">
            <a role="button"
              className="collapse-link"
              aria-expanded="false"
              onClick={() => {getMore()}} >Show more rolled off Teams</a>
          </div>
          : null}
      </div>
    </div>
  );
}
