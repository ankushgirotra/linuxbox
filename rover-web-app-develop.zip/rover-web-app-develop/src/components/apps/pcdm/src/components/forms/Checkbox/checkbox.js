import React from "react";
import "./checkbox.scss";

export default function Checkbox(props) {
  const { label, checked, className = "", isDisabled = false } = props;
  return (
    <div className={`custom-checkbox-container inline ${className}`}>
      <label className="custom-checkbox inline">
        <span className="checkbox-label">{label}</span>
        <input type="checkbox" checked={checked} onChange={() => props.onChange()} disabled={isDisabled} />
        <span className={`tickmark ${isDisabled ? "disabled_checkbox" : ""}`}></span>
      </label>
    </div>
  );
}
