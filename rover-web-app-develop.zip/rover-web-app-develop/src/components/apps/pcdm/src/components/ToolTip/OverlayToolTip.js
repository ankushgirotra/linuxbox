import React from "react";
import PropTypes from "prop-types";
import { Overlay, Popover } from "react-bootstrap";
import "./toolTip.scss";

export default function OverlayToolTip(props) {
  const {
    toolTipTitle,
    toolTipMessage,
    showTooltip,
    toolTipIconRef,
    toolTipMessageTarget,
    onClick,
    onHide,
    toolTipPlacement = "auto",
  } = props;

  const toolTipData = (
    <Popover className="custom-popover" style={{ marginLeft: "15px" }}>
      <Popover.Title className="custom-popover-header">
        {toolTipTitle}
      </Popover.Title>
      <Popover.Content className="custom-popover-content">
        {typeof toolTipMessage === "function" ? toolTipMessage() : toolTipMessage}
      </Popover.Content>
    </Popover>
  );
  return (
    <div style={{ display: "inline-block" }}>
      <span className="custom-overlay-tooltip" onClick={onClick} ref={toolTipIconRef} >
        <i className="fa fa-question-circle" title="Click to get info"></i>
      </span>
      <Overlay
        show={showTooltip}
        // container={toolTipIconRef.current}
        target={toolTipMessageTarget}
        placement={toolTipPlacement}
        containerPadding={-450}
        rootClose
        onHide={onHide}
      >
        {toolTipData}
      </Overlay>
    </div>
  );
}

OverlayToolTip.propTypes = {
  toolTipTitle: PropTypes.string,
  toolTipMessage: PropTypes.oneOfType([PropTypes.string, PropTypes.func ,PropTypes.object]),
  onClick: PropTypes.func,
  onHide: PropTypes.func,
  showTooltip: PropTypes.bool,
  toolTipIconRef: PropTypes.object,
  toolTipMessageTarget: PropTypes.object,
};
