import React from "react";
import "./dataHandler.scss";
import { Spinner } from "react-bootstrap";

export default function DataHandler({
  loader: { show, state } = { show: false, state: false },
  showData,
  children,
  emptyDataMessage = "",
}) {
  return state ? (
    show ? (
      <div className="spinner-container">
        <div className="spinner-div">
          <Spinner size="md" animation="border" variant="secondary" />
        </div>
      </div>
    ) : null
  ) : showData ? (
    children
  ) : (
    <div className="empty-data-container">
      {" "}
      {emptyDataMessage ? emptyDataMessage : "No data to show"}
    </div>
  );
}

export function OverlayLoader({
  loading,
  className = "",
  noData,
  noDataMessage = "No data found",
}) {
  return loading ? (
    <div className={`overlay-container ${className}`}>
      <div className="overlay-loader">
        <div className="overlay-spinner-container">
          <div className="overlay-spinner-div">
            <Spinner size="md" animation="border" variant="secondary" />
          </div>
        </div>
      </div>
    </div>
  ) : noData ? (
    <div className={`overlay-container ${className}`}>
      <div className="overlay-no-data">
        <div className="overlay-no-data-container">
          <div className="overlay-no-data-div">
            <h5>{noDataMessage}</h5>
          </div>
        </div>
      </div>
    </div>
  ) : null;
}
