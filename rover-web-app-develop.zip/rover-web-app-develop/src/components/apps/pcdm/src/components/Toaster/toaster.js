import React from "react";
import "./toaster.scss";
import { ACTIONS } from "../../constants/action.constants";
import { discardNotification } from "../../store/common.reducer";
import { connect } from "react-redux";
import { ToastContainer, toast, Slide } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Toaster({ autoClose = 2000, notifications, hideNotification }) {
  if (notifications.length) {
    notifications
      .filter((noti) => noti.expired === false)
      .forEach((notification, index) => {
        if (notification.variant === ACTIONS.SUCCESS) {
          toast.success(notification.content, {
            position: toast.POSITION.TOP_RIGHT,
            toastId: notification.id,
            onClose: hideNotification(notification),
          });
        } else if(notification.variant === ACTIONS.ERROR) {
          toast.error(notification.content, {
            position: toast.POSITION.TOP_RIGHT,
            toastId: notification.id,
            onClose: hideNotification(notification),
          });
        } else {
          toast.info(notification.content, {
            position: toast.POSITION.TOP_RIGHT,
            toastId: notification.id,
            onClose: hideNotification(notification),
          });
        }
      });
  }
  return <ToastContainer autoClose={autoClose}/>;
}
export const mapStateToProps = (state) => ({
  notifications: state.CommonPCDMReducer.notifications,
});
export const mapDispatchToProps = (dispatch) => ({
  hideNotification: (notification) =>
    dispatch(discardNotification(notification)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Toaster);
