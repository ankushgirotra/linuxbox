import React from "react";
import Divider from "@material-ui/core/Divider";
import "./list.scss";

export default function List({
  listArray,
  id,
  displayKey,
  onClick,
  className = "",
  selected,
}) {
  const showListOptions = (item, displayKey) => {
    return (
      <>
        <div className="list-option">
          <p className="list-label" title={item[displayKey]}>
            {item[displayKey]}
            {item.completed ? <i className="fas fa-check-circle"></i> : null}
          </p>
          {item.projectEstimateId != "pc" && item.projectEstimateId != "pf" ? (
            <p className="list-label2" title={item[displayKey]}>
              {item.pcode}
            </p>
          ) : null}
        </div>
      </>
    );
  };
  const isActive = (item) => {
    if (item.projectEstimateId == selected.teamId) {
      return true;
    } else {
      return false;
    }
  };
  return (
    <div className={`sc-scroll-vertical ${className}`}>
      <ul className="skillcentral-list ">
        <Divider />
        {listArray.map((item, index) => {
          let activeClassName = isActive(item)
            ? "forecast-list--item__active"
            : "";
          let completedClassName = item.completed ? "forecast-list--item__completed" : ""; 
          return (
            <>
              <li
                key={item.projectEstimateId}
                className={`forecast-list--item ${activeClassName} ${completedClassName}`}
                onClick={() => onClick(item)}
              >
                {showListOptions(item, displayKey, index)}
                {/* <ChevronRight className="list-direction" size={18} strokeWidth={3} /> */}
              </li>
              <Divider />
            </>
          );
        })}
      </ul>
    </div>
  );
}
