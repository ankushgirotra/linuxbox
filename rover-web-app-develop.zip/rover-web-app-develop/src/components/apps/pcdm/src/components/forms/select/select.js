import React from "react";
import PropTypes from "prop-types";
import ErrorMsg from "../errorMsg/errorMsg";
import ToolTip from "../../ToolTip/ToolTip";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import { TOOL_TIP_TITLE } from "../../../constants/action.constants";

function SelectDropdown(props) {
  const {
    label,
    formObj,
    onChange,
    isRequired,
    config,
    name,
    info,
    infoStyle,
    customValue,
    placeholder = "Select an option",
    hasToolTip = false,
    toolTipTitle = TOOL_TIP_TITLE.DEFAULT_TITLE,
    toolTipMessage = TOOL_TIP_MESSAGE.NO_TOOL_TIP,
  } = props;
  /* Set to empty value if selected value is not in the list*/
  if (
    !config.options.filter((opt) => (config.id ? opt[config.id] : opt) == formObj.value).length &&
    formObj.value !== ""
  ) {
    // console.log(config, formObj.value);
    onChange({ target: { name: name, value: "" } });
  }
  return (
    <div>
      {label ? (
        <label className={isRequired ? "required text-cap" : "text-cap"}>
          {label}
        </label>
      ) : null}
      {hasToolTip ? (
        <ToolTip toolTipMessage={toolTipMessage} toolTipTitle={toolTipTitle}></ToolTip>
      ) : null}
      {info  ? (
        <span style={infoStyle()}>{info}</span>
      ) : null}
      <select
        name={name}
        className={"pcdm-input pcdm-input--select"}
        value={formObj.value || ""}
        required={isRequired || false}
        onChange={onChange}
        disabled={formObj.readOnly || formObj.disabled || false}
      >
        <option value={""} disabled={true} defaultValue={""}>
          {placeholder}
        </option>
        {config.options.map((opt, i) => (
          <option key={i} value={config.id ? opt[config.id] : opt}>
            {customValue ? customValue(opt) : config.value ? opt[config.value] : opt}
          </option>
        ))}
      </select>
      {formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null}
    </div>
  );
}

SelectDropdown.propTypes = {
  name: PropTypes.string,
  label: PropTypes.string,
  formObj: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    error: PropTypes.bool,
    errorMsg: PropTypes.string,
  }),
  onChange: PropTypes.func,
  isRequired: PropTypes.bool,
  config: PropTypes.shape({
    options: PropTypes.array,
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  }),
  customValue: PropTypes.func,
};
export default SelectDropdown;
