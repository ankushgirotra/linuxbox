import React, { Component } from "react";
import PropTypes from "prop-types";
import ErrorMsg from "../errorMsg/errorMsg";
import { checkValueBetweenRange } from "../../../services/form.service";
import { ERR_CODES } from "../../../constants/message.contants";
import ToolTip from "../../ToolTip/ToolTip";
import "./textField.scss";

class TextField extends Component {
  onNumberChange = (event) => {
    return {
      ...this.validateNumberInput(event),
    };
  };
  validateNumberInput = (event) => {
    const { allowDecimal, min, max ,highEndRangeName,highEndRangeMin ,hasRange } = this.props;
    let number;
    if (allowDecimal) {
      number = event.target.value.replace(/[^0-9.]/g, "");
    } else {
      number = event.target.value.replace(/[^0-9]/g, "");
    }
    let isHighEndValueChange = hasRange && event.target.name === highEndRangeName ? true : false;
    let minValue = isHighEndValueChange ? Number(highEndRangeMin)+1 : min;
    let { error, errorCode } = checkValueBetweenRange(number, minValue, max);
    if (error) {
      return {
        name: event.target.name,
        value: number,
        error: true,
        errorMessage:
          errorCode === ERR_CODES.LESS_THAN
            ? isHighEndValueChange ? `Value must be greater than ${highEndRangeMin}` :
             `Minimum value allowed is ${min}`              
            : errorCode === ERR_CODES.GREATER_THAN
              ? `Maximum value allowed is ${max}`
              : "",
      };
    } else {
      return {
        name: event.target.name,
        value: number,
        error: false,
        errorMessage: "",
      };
    }
  };
  render() {
    const {
      label,
      formObj,
      onChange,
      type,
      isRequired,
      placeholder,
      onBlur,
      min,
      max,
      name,
      toolTipMessage,
      toolTipTitle,
      hasToolTip,
      onFocus,
      autoFoucs,
      className,
      hasRange = false,
      isRangeNow = false,
      rangeLinkText,
      highEndRangeName,
      rangeFormObj,
      highEndRangeMin,
      onRangeLinkChange,
      onRangeValueChange,
      id,
    } = this.props;
    return (
      <div>
        <label className={isRequired ? "required text-cap" : "text-cap"}> {label} </label>
        {hasToolTip ? (
          <ToolTip toolTipMessage={toolTipMessage} toolTipTitle={toolTipTitle}></ToolTip>
        ) : null}
        {hasRange && rangeLinkText ? (
          <span> &nbsp;
            (<span className="rover-link" onClick={() => onRangeLinkChange()}>
              {rangeLinkText}
            </span>)
          </span>
        ) : null}
        {type === "number" ? (!hasRange || !isRangeNow ? (
          <input
            name={name}
            onFocus={onFocus || null}
            autoFocus={autoFoucs || false}
            className={className ? `${className} ${formObj.readOnly ? `${className}--readonly` : ""}` : `pcdm-input ${formObj.readOnly ? "pcdm-input--readonly" : ""}`}
            type={"text"}
            placeholder={placeholder || ""}
            value={formObj.value}
            onChange={(e) => onChange(this.onNumberChange(e))}
            onBlur={(e) => (onBlur ? onBlur(this.onNumberChange(e)) : null)}
            required={isRequired || false}
            min={String(min) || ""}
            max={String(max) || ""}
            readOnly={formObj.readOnly || false}
          />)
          : (<div className="pcdm-form__form-group-field form-group-field--inline input-textfield-range-hyphen">
            <input
              name={name}
              onFocus={onFocus || null}
              autoFocus={autoFoucs || false}
              className={className ? `${className} ${formObj.readOnly ? `${className}--readonly` : ""}` : `pcdm-input ${formObj.readOnly ? "pcdm-input--readonly" : ""}`}
              type={"text"}
              placeholder={placeholder || ""}
              value={formObj.value}
              onChange={(e) => onChange(this.onNumberChange(e))}
              onBlur={(e) => (onBlur ? onBlur(this.onNumberChange(e)) : null)}
              required={isRequired || false}
              min={String(min) || ""}
              max={String(max) || ""}
              readOnly={formObj.readOnly || false}
            />
            <span> </span>
            <input
              name={highEndRangeName}
              onFocus={onFocus || null}
              autoFocus={autoFoucs || false}
              className={className ? `${className} ${formObj.readOnly ? `${className}--readonly` : ""}` :
                `pcdm-input ${formObj.readOnly ? "pcdm-input--readonly" : ""}`}
              type={"text"}
              placeholder={placeholder || ""}
              value={rangeFormObj.value}
              onChange={(e) => onRangeValueChange(this.onNumberChange(e))}
              onBlur={(e) => (onBlur ? onBlur(this.onNumberChange(e)) : null)}
              required={isRequired || false}
              min={String(highEndRangeMin) || ""}
              max={String(max) || ""}
              readOnly={formObj.readOnly || false}
            />
          </div>)
        ) : (
            <input
              name={name}
              className={className ? `${className} ${formObj.readOnly ? `${className}--readonly` : ""}` : `pcdm-input ${formObj.readOnly ? "pcdm-input--readonly" : ""}`}
              type={type || "text"}
              placeholder={placeholder || ""}
              value={formObj.value}
              onChange={onChange}
              onBlur={onBlur || null}
              required={isRequired || false}
              min={String(min) || ""}
              max={String(max) || ""}
              readOnly={formObj.readOnly || false}
              id = {id || null}
              disabled = {formObj.disabled ? formObj.disabled : null}
            />
          )}

        {hasRange && isRangeNow ? (
          <div className="input-textfield-error-message">
            <span> {formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null} </span>
            <span> {rangeFormObj && rangeFormObj.error ?
              <ErrorMsg message={rangeFormObj.errorMsg} /> : null} </span>
          </div>) : (formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null)}

      </div>
    );
  }
}

TextField.propTypes = {
  label: PropTypes.string,
  formObj: PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    error: PropTypes.bool,
    errorMsg: PropTypes.string,
  }),
  name: PropTypes.string,
  onChange: PropTypes.func,
  onBlur: PropTypes.func,
  type: PropTypes.string.isRequired,
  isRequired: PropTypes.bool,
  autoFocus: PropTypes.bool,
  placeholder: PropTypes.string,
  /*
  hasRange: PropTypes.bool,
  isRangeNow: PropTypes.bool,
  rangeLinkText: PropTypes.string,
  pointToRangeText: PropTypes.string,
  highEndRangeName: PropTypes.string,
  rangeFormObj: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  highEndRangeMin: PropTypes.string,
  onRangeLinkChange: PropTypes.func,
  onRangeValueChange: PropTypes.func, */
};

export default TextField;
