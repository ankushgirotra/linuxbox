import React, { useState, forwardRef } from "react";
import DatePicker from "react-datepicker";
import ErrorMsg from "../forms/errorMsg/errorMsg";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";
import "./datepicker.scss";
import ToolTip from "../ToolTip/ToolTip";
// import ICONcalender from "../../../../../../shared/img/icon-img/ICONcalender.png"
// import abc from "../../../../../../shared/img/icon-img/ICONcalender.png"
import LastPublishIcon from "../../../../../../shared/img/icon-img/LastPublishIcon.png";

export default function Datepicker(props) {
  const {
    label,
    formObj,
    onChange,
    name,
    isRequired,
    dateFormat,
    dateView,
    portalId,
    className,
    containerClassName = "",
    clearable,
    showMonthYearPicker = false,
    placeholderText = "Select date",
    hasToolTip = false,
    bold = false,
    calendarClassName,
    toolTipTitle = "",
    toolTipMessage = "",
    toolTipPlacement = "",
    showTimeSelect,
    showTimeSelectOnly,
    timeIntervals,
    timeCaption,
    timeFormat,
    popperPlacement = "right",
    isRequestDatePicker,
    customInput=false,
    showFormat=false,
    min,
    max,
    openToDate
  } = props;
  const rootProps = portalId
    ? {
        portalId: "root-potal-pcdm",
      }
    : null;
  
  const CustomCalenderInput = forwardRef(({value, onClick, onChange},ref)=>(
  <label className="picker-with-calenderIcon" ref={ref} >
    <input
              name={name}
              // onFocus={onFocus || null}
              // autoFocus={autoFoucs || false}
              className={className ? `${className} ${formObj.readOnly ? `${className}--readonly` : ""}` : `pcdm-input ${formObj.readOnly ? "pcdm-input--readonly" : ""}`}
              type={"text"}
              placeholder={placeholderText || ""}
              value={value}
              // onChange={(e) => onChange(this.onNumberChange(e))}
              // onBlur={(e) => (onBlur ? onBlur(this.onNumberChange(e)) : null)}
              required={isRequired || false}
              readOnly={formObj.readOnly || false}
              id="icon"
              onClick={onClick}
              onChange={onChange}
            />
    {/* <span onClick={onClick} >
    <img
    className="publishViewers-icon"
    src={LastPublishIcon}
  />
    </span> */}
  </label>
))
  return (
    <div className={`${containerClassName}`}>
      <span>
        {isRequestDatePicker ?
          <label className={"required text-cap"}>{label}</label> : 
          <label className={isRequired ? "required text-cap" : "text-cap"} style={bold?{fontWeight:500}:{}}>
            {label}
          </label>}
        
        {hasToolTip ? (
          <ToolTip
            toolTipTitle={toolTipTitle}
            toolTipMessage={toolTipMessage}
            content={() => (
              <span className="custom-tool-tip-alert-icon">
                <i className="fas fa-exclamation-circle" title="Click to get info"></i>
              </span>
            )}
            toolTipPlacement={toolTipPlacement}
          />
        ) : null}
      </span>
      <DatePicker
        selected={formObj.value}
        onChange={(date) => onChange(name, date)}
        disabled={formObj.disabled || false}
        className={className ? className : "pcdm-input"}
        calendarClassName={calendarClassName ? calendarClassName : "pcdm-calendar-container"}
        minDate={min || null}
        maxDate={max || null}
        required={isRequired}
        {...((showTimeSelect && showTimeSelectOnly) || showFormat ? { dateFormat: dateFormat } : {})}
        popperPlacement={popperPlacement}
        placeholderText={placeholderText}
        isClearable={clearable || false}
        {...rootProps}
        showMonthYearPicker={showMonthYearPicker}
        showTimeSelect={showTimeSelect || false}
        showTimeSelectOnly={showTimeSelectOnly || false}
        timeIntervals={timeIntervals || 15}
        timeCaption={timeCaption || "Time"}
        openToDate={openToDate || null}
        // dateFormat={dateView?dateView:"MM/DD/YYYY"}
        // customInput = {customInput? <CustomCalenderInput /> : null }
        id = { customInput ? "icon" : null }
      />
      
      <ErrorMsg message={formObj.errorMsg ? formObj.errorMsg : ""} />
    </div>
  );
}
