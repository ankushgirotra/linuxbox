import React, { Component } from "react";
import PropTypes from "prop-types";
import ErrorMsg from "../errorMsg/errorMsg";
import "./datePicker.scss";

class PCDMDatePicker extends Component {
	render() {
		const { label, formObj, onChange, name, isRequired } = this.props;
		return (
			<div>
				<label className={isRequired? 'required' : ''}>{label}</label>
				<input
					name={name}
					className="pcdm-input"
					value={formObj.value}
					type="month"
					required={isRequired}
					min={formObj.min}
					max={formObj.max}
					disabled={formObj.disabled || false}
					onChange={(event) => onChange(event.target.name, event.target.value)}
				/>
				{formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null}
			</div>
		);
	}
}

PCDMDatePicker.propTypes = {
	label: PropTypes.string,
	formObj: PropTypes.shape({
		value: PropTypes.string,
		error: PropTypes.bool,
		errorMsg: PropTypes.string,
		max: PropTypes.string,
		min: PropTypes.string,
		disabled: PropTypes.bool,
	}),
	onChange: PropTypes.func,
	onBlur: PropTypes.func,
	isRequired: PropTypes.bool,
};

export default PCDMDatePicker;
