import React, { useState } from "react";
import DatePicker from "react-datepicker";
import { getFormattedDate } from "../../services/form.service";
import "react-datepicker/dist/react-datepicker.css";
import "../Datepicker/datepicker.scss";
import "./dateRangePicker.scss";

export default function DateRangePicker(props) {
  const {
    startRangeDate,
    endRangeDate,
    onStartDateChange,
    onEndDateChange,
    className,
    showCalendarIcon = true,
    isClearable = false,
    usePortal = false,
    popperPlacement = "right",
  } = props;

  const rootProps = usePortal
    ? {
        portalId: "root-potal-pcdm",
      }
    : null;

  const [isOpen, setIsOpen] = useState(false);

  // --> on click of clear button
  const onChange = (date) => {
    if (date === null) {
      onStartDateChange(null);
      onEndDateChange(null);
    } else if (!startRangeDate && !endRangeDate) {
      onStartDateChange(date);
    } else if (startRangeDate && !endRangeDate) {
      onEndDateChange(date);
      setIsOpen(false);
    } else if (startRangeDate && endRangeDate) {
      onStartDateChange(date);
      onEndDateChange(null);
    }
  };

  const CustomInput = ({ val, onClick, onChange }) => {
    if (!startRangeDate && !endRangeDate) {
      return (
        <input
          type="text"
          onClick={onClick}
          id={showCalendarIcon ? "icon" : null}
          placeholder={"Select the Range"}
        />
      );
    } else {
      return (
        <input
          type="text"
          onClick={onClick}
          onChange={onChange}
          id={showCalendarIcon ? "calendar-range_icon" : null}
          value={`${
            startRangeDate ? getFormattedDate(startRangeDate) : "MM/DD/YYYY"
          }  -  ${
            endRangeDate ? getFormattedDate(endRangeDate) : "MM/DD/YYYY"
          }`}
        />
      );
    }
  };

  return (
    <div>
      <DatePicker
        selectsRange={true}
        open={isOpen}
        onInputClick={() => setIsOpen(true)}
        onClickOutside={() => setIsOpen(false)}
        selected={startRangeDate}
        startDate={startRangeDate}
        endDate={endRangeDate}
        minDate={startRangeDate && !endRangeDate ? startRangeDate : null}
        onChange={(date) => onChange(date)}
        popperPlacement={popperPlacement}
        showMonthDropdown
        useShortMonthInDropdown
        isClearable={isClearable}
        customInput={<CustomInput />}
        className={className ? className : "pcdm-input"}
        calendarClassName={"pcdm-calendar-container pcdm-date_range-container"}
        {...rootProps}
      />
    </div>
  );
}
