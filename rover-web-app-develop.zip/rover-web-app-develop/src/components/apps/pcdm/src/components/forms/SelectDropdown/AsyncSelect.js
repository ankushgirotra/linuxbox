import React, { useMemo } from 'react';
import AsyncSelect from 'react-select/async'
import "./selectDropdown.scss";
import PropTypes from "prop-types";
import ErrorMsg from "../errorMsg/errorMsg";
import ToolTip from "../../ToolTip/ToolTip";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import { TOOL_TIP_TITLE } from "../../../constants/action.constants";
import DisableView from "../../../../../../shared/common/DisableView/disableView";

function AsyncCustomSelect({
    menuPlacement,
    label,
    formObj,
    onChange,
    isRequired,
    config,
    name,
    formatOptionLabel = null,
    placeholder = "Select an option",
    containerClassName = "",
    classNamePrefix = "pcdm-input",
    isMulti = false,
    hasToolTip = false,
    toolTipTitle = TOOL_TIP_TITLE.DEFAULT_TITLE,
    toolTipMessage = TOOL_TIP_MESSAGE.NO_TOOL_TIP,
    disable = false,
    disabledErrorMessage = "",
    isOptionsMultiList = false,
    formatGroupLabel = null,
    showDefaultValues = false,
    doubleIds = false,
    employeeName = null,
    errorTooltip = false,
    redTooltip = false,
  getToolTipMessage = null,
  customLabel=false
}) {

    const getToolTip = () => {
        return hasToolTip ? redTooltip ? (
            <ToolTip toolTipMessage={getToolTipMessage()} toolTipTitle={""}
                content={() => (
                  <span className="custom-tool-tip-alert-icon">
                    <i className="fas fa-exclamation-circle" title="Click to get info"></i>
                  </span>
                )}
                >
                </ToolTip>
          ): (
            <ToolTip toolTipMessage={toolTipMessage} toolTipTitle={toolTipTitle} ></ToolTip>
          ) : null;
        };
        // customLabel? opt[config.value]+"      -     "+opt[config.id] : 
    const displayOptions = useMemo(() => {
        return config.options && config.options.length
            ? config.options.map((opt) => {
                return {
                    label: config.value ? opt[config.value] : opt,
                    value: config.id ? opt[config.id] : opt,
                    value2: config.id2 ? opt[config.id2] : opt,
                };
            })
            : [];
    }, [config.options]);

    const filterOptions = (inputValue) => {
        let dropdownOptions = displayOptions.filter(i => i.label ? i.label.toLowerCase().includes(inputValue.toLowerCase()) : null )
        return dropdownOptions.slice(0, 500)
    }

    const loadOptions = (inputValue, callback) => {
        setTimeout(() => callback(filterOptions(inputValue)), 300)
    }
    const getValue = (val) => {
        let value = null;
        if (isOptionsMultiList) {
            let allOptions = config.options.map((grp) => grp.options).flat();
            value = allOptions.filter((opt) => opt.value === val)[0];
        }
        if (doubleIds ) {
            value = displayOptions.length ? displayOptions.filter((opt) => opt.value === val || opt.value2 === val)[0] : {};
        } else {
            value = displayOptions.length ? displayOptions.filter((opt) => opt.value === val)[0] : {};
        };
        value = value != undefined ? value : null; // returning null instead of undefined
        if(value == null && employeeName){
          value = {
            label : employeeName,
            value : val,
          }
        }
        return value;
    };
    const initialOptions = displayOptions.slice(0, 1000)
    return (
        <div className={`rover-custom-select ${containerClassName}`} >
            {label ? (
                <label className={isRequired ? "required text-cap" : "text-cap"}>{label}</label>
            ) : null}
            {getToolTip()}
            <AsyncSelect
                label={label}
                formatGroupLabel={formatGroupLabel}
                name={name}
                isMulti={isMulti}
                styles={(base) => ({ ...base, zIndex: 999 })}
                classNamePrefix={classNamePrefix}
                isDisabled={formObj.readOnly || formObj.disabled || false}
                menuContainerStyle={{ zIndex: 99999 }}
                menuPlacement={menuPlacement}
                cacheOptions
                defaultOptions={showDefaultValues ? initialOptions : null}
                // options={initialOptions}
                formatOptionLabel={formatOptionLabel}
                loadOptions={loadOptions}
                placeholder={placeholder}
                formatOptionLabel={formatOptionLabel}
                onChange={(newValue) => {
                    onChange(newValue)
                }}
                value={isMulti ? formObj.value : getValue(formObj.value)}
            />
            {errorTooltip ? 
        <div className="card"><span className="tooltipText">{toolTipMessage}</span></div>
      : formObj.error ? <ErrorMsg message={formObj.errorMsg} /> : null
      }
            {disable && disabledErrorMessage ? (
                <DisableView className="custom-select-disable">
                    <>
                        {getToolTip()}
                        {disabledErrorMessage}
                    </>
                </DisableView>
            ) : null}
        </div>
    )

}
AsyncCustomSelect.propTypes = {
    name: PropTypes.string,
    label: PropTypes.string,
    formObj: PropTypes.shape({
        value: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.array]),
        error: PropTypes.bool,
        errorMsg: PropTypes.string,
    }),
    onChange: PropTypes.func,
    isRequired: PropTypes.bool,
    config: PropTypes.shape({
      options: PropTypes.array,
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    }),
    customValue: PropTypes.func,
};
export default AsyncCustomSelect;