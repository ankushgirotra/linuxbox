import roverPcdmURL from "../../../../../apis/pcdm_api";
import { DATA_STATUS } from "../constants/service.constant";
import { GET_ROLE_URL, saveRoleURL, updateRoleURL, getAllocationDetailsURL } from "./endpoints";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";
// ACTION TYPES
export const SET_ROLE_OPTIONS = "SET_ROLE_OPTIONS";

export const SAVE_ROLE_RESET = "SAVE_ROLE_RESET";
export const SAVE_ROLE_LOADING = "SAVE_ROLE_LOADING";
export const SAVE_ROLE_SUCCESS = "SAVE_ROLE_SUCCESS";
export const SAVE_ROLE_ERROR = "SAVE_ROLE_ERROR";

export const EDIT_ROLE_RESET = "EDIT_ROLE_RESET";
export const EDIT_ROLE_LOADING = "EDIT_ROLE_LOADING";
export const EDIT_ROLE_SUCCESS = "EDIT_ROLE_SUCCESS";
export const EDIT_ROLE_ERROR = "EDIT_ROLE_ERROR";

export const DELETE_ROLE_RESET = "DELETE_ROLE_RESET";
export const DELETE_ROLE_LOADING = "DELETE_ROLE_LOADING";
export const DELETE_ROLE_SUCCESS = "DELETE_ROLE_SUCCESS";
export const DELETE_ROLE_ERROR = "DELETE_ROLE_ERROR";

export const GET_ALLOCATION_DETAILS_LOADING = "GET_ALLOCATION_DETAILS_LOADING";
export const GET_ALLOCATION_DETAILS_SUCCESS = "GET_ALLOCATION_DETAILS_SUCCESS";
export const GET_ALLOCATION_DETAILS_ERROR = "GET_ALLOCATION_DETAILS_ERROR";

// ACTION CREATORS
export const setRoleOptions = (roles) => ({
  type: SET_ROLE_OPTIONS,
  roles,
});

export const saveRoleReset = () => ({
  type: SAVE_ROLE_RESET,
});
export const saveRoleLoading = () => ({
  type: SAVE_ROLE_LOADING,
});
export const saveRoleSuccess = (saveRole) => ({
  type: SAVE_ROLE_SUCCESS,
  saveRole,
});
export const saveRoleError = (error) => ({
  type: SAVE_ROLE_ERROR,
  error,
});

export const editRoleReset = () => ({
  type: EDIT_ROLE_RESET,
});
export const editRoleLoading = () => ({
  type: EDIT_ROLE_LOADING,
});
export const editRoleSuccess = (editRole) => ({
  type: EDIT_ROLE_SUCCESS,
  editRole,
});
export const editRoleError = (error) => ({
  type: EDIT_ROLE_ERROR,
  error,
});

export const deleteRoleReset = () => ({
  type: DELETE_ROLE_RESET,
});
export const deleteRoleLoading = () => ({
  type: DELETE_ROLE_LOADING,
});
export const deleteRoleSuccess = (deleteRole) => ({
  type: DELETE_ROLE_SUCCESS,
  deleteRole,
});
export const deleteRoleError = (error) => ({
  type: DELETE_ROLE_ERROR,
  error,
});

export const getAllocationDetailsLoading = () => ({
  type: GET_ALLOCATION_DETAILS_LOADING,
});
export const getAllocationDetailsSuccess = (allocDetails) => ({
  type: GET_ALLOCATION_DETAILS_SUCCESS,
  allocDetails,
});
export const getAllocationDetailsError = (error) => ({
  type: GET_ALLOCATION_DETAILS_ERROR,
  error,
});

// THUNK CREATORS
export const setRoleOptionsThunk = () => async (dispatch) => {
  try {
    const { data } = await roverPcdmURL.get(GET_ROLE_URL);
    dispatch(setRoleOptions(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const saveRoleThunk = (payload, productCode, teamId, callback) => async (dispatch) => {
  try {
    dispatch(saveRoleLoading());
    const { data } = await roverPcdmURL.post(saveRoleURL(productCode, teamId), payload);
    if (callback) {
      callback(SAVE_ROLE_SUCCESS, data);
    }
    dispatch(saveRoleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_ROLE_ERROR, error);
    }
    dispatch(saveRoleError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const editRoleThunk = (payload, productCode, teamId, teamRoleId, callback) => async (
  dispatch
) => {
  try {
    dispatch(editRoleLoading());
    const { data } = await roverPcdmURL.put(
      updateRoleURL(productCode, teamId, teamRoleId),
      payload
    );
    if (callback) {
      callback(EDIT_ROLE_SUCCESS, data);
    }
    dispatch(editRoleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_ROLE_ERROR, error);
    }
    dispatch(editRoleError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const deleteRoleThunk = (payload, productCode, teamId, teamRoleId, callback) => async (
  dispatch
) => {
  try {
    dispatch(deleteRoleLoading());
    const { data } = await roverPcdmURL.put(
      updateRoleURL(productCode, teamId, teamRoleId),
      payload
    );
    if (callback) {
      callback(DELETE_ROLE_SUCCESS, data);
    }
    dispatch(deleteRoleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_ROLE_ERROR, error);
    }
    dispatch(deleteRoleError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getAllocationDetailsThunk = (lanId, callback) => async (dispatch) => {
  try {
    dispatch(getAllocationDetailsLoading());
    const { data } = await roverPcdmURL.get(getAllocationDetailsURL(lanId));
    if (callback) {
      callback(GET_ALLOCATION_DETAILS_SUCCESS, data);
    }
    dispatch(getAllocationDetailsSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_ALLOCATION_DETAILS_ERROR, error);
    }
    dispatch(getAllocationDetailsError(error));
  }
};

// INITIAL STATE
export const roleInitialState = {
  roles: [],
  saveRoleStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editRoleStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteRoleStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  allocationDetails: {
    status: DATA_STATUS.INITIAL,
    data: [],
    response: {},
  },
};

// REDUCERS
const RolesReducer = (state = roleInitialState, action) => {
  switch (action.type) {
    case SET_ROLE_OPTIONS:
      return { ...state, roles: [...action.roles] };
    case SAVE_ROLE_RESET:
      return {
        ...state,
        saveRoleStatus: { ...roleInitialState.saveRoleStatus },
      };
    case SAVE_ROLE_LOADING:
      return {
        ...state,
        saveRoleStatus: {
          ...state.saveRoleStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_ROLE_SUCCESS:
      return {
        ...state,
        saveRoleStatus: {
          ...state.saveRoleStatus,
          response: action.saveRole,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_ROLE_ERROR:
      return {
        ...state,
        saveRoleStatus: {
          ...state.saveRoleStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_ROLE_RESET:
      return {
        ...state,
        editRoleStatus: { ...roleInitialState.editRoleStatus },
      };
    case EDIT_ROLE_LOADING:
      return {
        ...state,
        editRoleStatus: {
          ...state.editRoleStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_ROLE_SUCCESS:
      return {
        ...state,
        editRoleStatus: {
          ...state.editRoleStatus,
          response: action.editRole,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_ROLE_ERROR:
      return {
        ...state,
        editRoleStatus: {
          ...state.editRoleStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_ROLE_RESET:
      return {
        ...state,
        deleteRoleStatus: { ...roleInitialState.deleteRoleStatus },
      };
    case DELETE_ROLE_LOADING:
      return {
        ...state,
        deleteRoleStatus: {
          ...state.deleteRoleStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_ROLE_SUCCESS:
      return {
        ...state,
        deleteRoleStatus: {
          ...state.deleteRoleStatus,
          response: action.deleteRole,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_ROLE_ERROR:
      return {
        ...state,
        deleteRoleStatus: {
          ...state.deleteRoleStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_ALLOCATION_DETAILS_LOADING:
      return {
        ...state,
        allocationDetails: {
          ...state.allocationDetails,
          status: DATA_STATUS.LOADING,
          data: [],
        },
      };
    case GET_ALLOCATION_DETAILS_SUCCESS:
      return {
        ...state,
        allocationDetails: {
          ...state.allocationDetails,
          data: typeof action.allocDetails !== "string" ? [...action.allocDetails] : [],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ALLOCATION_DETAILS_ERROR:
      return {
        ...state,
        allocationDetails: {
          ...state.allocationDetails,
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default RolesReducer;
