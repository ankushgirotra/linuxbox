import roverPcdmURL from "../../../../../apis/pcdm_api";
import {
  updateCalculationsURL,
  refreshCalculationsURL,
  getTeamRolesURL,
  getTeamSprintVelocityURL,
  getScrumMasterURL,
  refreshMonthlyURL,
  projectsBudgetRefreshURL,
} from "./endpoints";
import { DATA_STATUS } from "../constants/service.constant";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";
// ACTION TYPES
export const REFRESH_PRODUCT = "REFRESH_PRODUCT";
export const REFRESH_PRODUCT_LOADING = "REFRESH_PRODUCT_LOADING";
export const REFRESH_PRODUCT_ERROR = "REFRESH_PRODUCT_ERROR";

export const SET_MONTHDATA = "SET_MONTHDATA";
export const SET_MONTHDATA_LOADING = "SET_MONTHDATA_LOADING";
export const SET_MONTHDATA_ERROR = "SET_MONTHDATA_ERROR";

export const REFRESH_PRODUCT_MONTHLY = "REFRESH_PRODUCT_MONTHLY";
export const REFRESH_PRODUCT_MONTHLY_LOADING =
  "REFRESH_PRODUCT_MONTHLY_LOADING";
export const REFRESH_PRODUCT_MONTHLY_ERROR = "REFRESH_PRODUCT_MONTHLY_ERROR";

export const PROJECTS_BUDGET_REFRESH = "PROJECTS_BUDGET_REFRESH";
export const PROJECTS_BUDGET_REFRESH_LOADING =
  "PROJECTS_BUDGET_REFRESH_LOADING";
export const PROJECTS_BUDGET_REFRESH_ERROR = "PROJECTS_BUDGET_REFRESH_ERROR";

export const GET_TEAMSROLES_LOADING = "GET_TEAMSROLES_LOADING";
export const GET_TEAMSROLES_SUCCESS = "GET_TEAMSROLES_SUCCESS";
export const GET_TEAMSROLES_ERROR = "GET_TEAMSROLES_ERROR";

export const GET_TEAMSSPRINTVELOCITY_LOADING =
  "GET_TEAMSSPRINTVELOCITY_LOADING";
export const GET_TEAMSSPRINTVELOCITY_SUCCESS =
  "GET_TEAMSSPRINTVELOCITY_SUCCESS";
export const GET_TEAMSSPRINTVELOCITY_ERROR = "GET_TEAMSSPRINTVELOCITY_ERROR";

export const GET_SCRUMMASTER_NAMES = "GET_SCRUMMASTER_NAMES";
export const GET_SCRUMMASTER_NAMES_LOADING = "GET_SCRUMMASTER_NAMES_LOADING";
export const GET_SCRUMMASTER_NAMES_ERROR = "GET_SCRUMMASTER_NAMES_ERROR";

// ACTION CREATORS
export const refreshProduct = (data) => ({
  type: REFRESH_PRODUCT,
  data,
});
export const refreshProductLoading = () => ({
  type: REFRESH_PRODUCT_LOADING,
});
export const refreshProductError = (error) => ({
  type: REFRESH_PRODUCT_ERROR,
  error,
});

export const refreshProductMonthly = (data) => ({
  type: REFRESH_PRODUCT_MONTHLY,
  data,
});
export const refreshProductMonthlyLoading = () => ({
  type: REFRESH_PRODUCT_MONTHLY_LOADING,
});
export const refreshProductMonthlyError = (error) => ({
  type: REFRESH_PRODUCT_MONTHLY_ERROR,
  error,
});

export const projectsBudget = (data) => ({
  type: PROJECTS_BUDGET_REFRESH,
  data,
});
export const projectsBudgetLoading = () => ({
  type: PROJECTS_BUDGET_REFRESH_LOADING,
});
export const projectsBudgetError = (error) => ({
  type: PROJECTS_BUDGET_REFRESH_ERROR,
  error,
});

export const setMonthData = (data) => ({
  type: SET_MONTHDATA,
  data,
});
export const setMonthDataLoading = () => ({
  type: SET_MONTHDATA_LOADING,
});
export const setMonthDataError = (error) => ({
  type: SET_MONTHDATA_ERROR,
  error,
});
export const getTeamsRolesLoading = () => ({
  type: GET_TEAMSROLES_LOADING,
});
export const getTeamsRolesSuccess = (roles) => ({
  type: GET_TEAMSROLES_SUCCESS,
  roles,
});
export const getTeamsRolesError = (error) => ({
  type: GET_TEAMSROLES_ERROR,
  error,
});

export const getTeamsSprintVelocityLoading = () => ({
  type: GET_TEAMSSPRINTVELOCITY_LOADING,
});
export const getTeamsSprintVelocitySuccess = (sprintVelocity) => ({
  type: GET_TEAMSSPRINTVELOCITY_SUCCESS,
  sprintVelocity,
});
export const getTeamsSprintVelocityError = (error) => ({
  type: GET_TEAMSSPRINTVELOCITY_ERROR,
  error,
});

export const getScrumMasterLoading = () => ({
  type: GET_SCRUMMASTER_NAMES_LOADING,
});
export const getScrumMasterSuccess = (names) => ({
  type: GET_SCRUMMASTER_NAMES,
  names,
});
export const getScrumMasterError = (error) => ({
  type: GET_SCRUMMASTER_NAMES_ERROR,
  error,
});

// THUNK CREATORS
export const refreshProductThunk = (productCode, callback) => async (
  dispatch
) => {
  try {
    dispatch(refreshProductLoading());
    const { data } = await roverPcdmURL.get(
      refreshCalculationsURL(productCode)
    );
    if (callback) {
      callback(REFRESH_PRODUCT, data);
    }
    dispatch(refreshProduct(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(REFRESH_PRODUCT_ERROR, error);
    }
    dispatch(refreshProductError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const refreshProductMonthlyThunk = (productCode, callback) => async (
  dispatch
) => {
  try {
    dispatch(refreshProductMonthlyLoading());
    const { data } = await roverPcdmURL.get(refreshMonthlyURL(productCode));
    if (callback) {
      callback(REFRESH_PRODUCT_MONTHLY, data);
    }
    dispatch(refreshProductMonthly(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(REFRESH_PRODUCT_MONTHLY_ERROR, error);
    }
    dispatch(refreshProductMonthlyError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const projectsBudgetRefreshThunk = (
  projectestimateId,
  type,
  callback
) => async (dispatch) => {
  try {
    dispatch(projectsBudgetLoading());
    const { data } = await roverPcdmURL.get(
      projectsBudgetRefreshURL(projectestimateId, type)
    );
    if (callback) {
      callback(PROJECTS_BUDGET_REFRESH, data);
    }
    dispatch(projectsBudget(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(PROJECTS_BUDGET_REFRESH_ERROR, error);
    }
    dispatch(projectsBudgetError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const setMonthDataCalculationsThunk = (teamId, callback) => async (
  dispatch
) => {
  try {
    dispatch(setMonthDataLoading());
    const { data } = await roverPcdmURL.post(updateCalculationsURL(teamId));
    if (callback) {
      callback(SET_MONTHDATA, data);
    }
    dispatch(setMonthData(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SET_MONTHDATA_ERROR, error);
    }
    dispatch(setMonthDataError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getTeamsRolesThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getTeamsRolesLoading());
    const { data } = await roverPcdmURL.get(getTeamRolesURL(productCode));
    dispatch(getTeamsRolesSuccess(data));
  } catch (error) {
    dispatch(getTeamsRolesError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getTeamsSprintVelocityThunk = (productCode) => async (
  dispatch
) => {
  try {
    dispatch(getTeamsSprintVelocityLoading());
    const { data } = await roverPcdmURL.get(
      getTeamSprintVelocityURL(productCode)
    );
    dispatch(getTeamsSprintVelocitySuccess(data));
  } catch (error) {
    dispatch(getTeamsSprintVelocityError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getScrumMasterThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getScrumMasterLoading());
    const { data } = await roverPcdmURL.get(getScrumMasterURL(productCode));
    dispatch(getScrumMasterSuccess(data));
  } catch (error) {
    dispatch(getScrumMasterError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

// INITIAL STATE
const initialState = {
  RefreshProductStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  RefreshProductMonthlyStatus: {
    data: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  RefreshProjectsBudgetStatus: {
    data: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  updateCalculationsStatus: {
    data: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  teamsRoles: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
  teamsSprintVelocity: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
  scrumMasterData: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
};

// REDUCERS
const TeamCalculationsReducer = (state = initialState, action) => {
  switch (action.type) {
    case REFRESH_PRODUCT:
      return {
        ...state,
        RefreshProductStatus: {
          ...state.RefreshProductStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case REFRESH_PRODUCT_LOADING:
      return {
        ...state,
        RefreshProductStatus: {
          ...state.RefreshProductStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case REFRESH_PRODUCT_ERROR:
      return {
        ...state,
        RefreshProductStatus: {
          ...initialState.RefreshProductStatus,
          status: DATA_STATUS.ERROR,
        },
      };
    case REFRESH_PRODUCT_MONTHLY:
      return {
        ...state,
        RefreshProductMonthlyStatus: {
          ...state.RefreshProductMonthlyStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case REFRESH_PRODUCT_MONTHLY_LOADING:
      return {
        ...state,
        RefreshProductMonthlyStatus: {
          ...state.RefreshProductMonthlyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case REFRESH_PRODUCT_MONTHLY_ERROR:
      return {
        ...state,
        RefreshProductMonthlyStatus: {
          ...initialState.RefreshProductMonthlyStatus,
          status: DATA_STATUS.ERROR,
        },
      };
    case PROJECTS_BUDGET_REFRESH:
      return {
        ...state,
        RefreshProjectsBudgetStatus: {
          ...state.RefreshProjectsBudgetStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case PROJECTS_BUDGET_REFRESH_LOADING:
      return {
        ...state,
        RefreshProjectsBudgetStatus: {
          ...state.RefreshProjectsBudgetStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case PROJECTS_BUDGET_REFRESH_ERROR:
      return {
        ...state,
        RefreshProjectsBudgetStatus: {
          ...initialState.RefreshProjectsBudgetStatus,
          status: DATA_STATUS.ERROR,
        },
      };
    case SET_MONTHDATA:
      return {
        ...state,
        updateCalculationsStatus: {
          ...state.updateCalculationsStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SET_MONTHDATA_LOADING:
      return {
        ...state,
        updateCalculationsStatus: {
          ...state.updateCalculationsStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SET_MONTHDATA_ERROR:
      return {
        ...state,
        updateCalculationsStatus: {
          ...initialState.updateCalculationsStatus,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_TEAMSROLES_LOADING:
      return {
        ...state,
        teamsRoles: { ...state.teamsRoles, status: DATA_STATUS.LOADING },
      };
    case GET_TEAMSROLES_SUCCESS:
      return {
        ...state,
        teamsRoles: {
          ...state.teamsRoles,
          data: action.roles,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_TEAMSROLES_ERROR:
      return {
        ...state,
        teamsRoles: {
          ...state.teamsRoles,
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_TEAMSSPRINTVELOCITY_LOADING:
      return {
        ...state,
        teamsSprintVelocity: {
          ...state.teamsSprintVelocity,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_TEAMSSPRINTVELOCITY_SUCCESS:
      return {
        ...state,
        teamsSprintVelocity: {
          ...state.teamsSprintVelocity,
          data: action.sprintVelocity,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_TEAMSSPRINTVELOCITY_ERROR:
      return {
        ...state,
        teamsSprintVelocity: {
          ...state.teamsSprintVelocity,
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_SCRUMMASTER_NAMES_LOADING:
      return {
        ...state,
        scrumMasterData: {
          ...state.scrumMasterData,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_SCRUMMASTER_NAMES:
      return {
        ...state,
        scrumMasterData: {
          ...state.scrumMasterData,
          data: action.names,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_SCRUMMASTER_NAMES_ERROR:
      return {
        ...state,
        scrumMasterData: {
          ...state.scrumMasterData,
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default TeamCalculationsReducer;
