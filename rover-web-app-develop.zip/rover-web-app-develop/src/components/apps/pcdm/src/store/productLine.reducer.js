import roverPcdmURL from "../../../../../apis/pcdm_api";
import { 
  getProductLineSummaryURL, 
  saveProductLineURL, 
  getProductLineSummaryConstraintsURL, 
  addProductLinesURL 
} from "./endpoints";
import { DATA_STATUS } from "../constants/service.constant";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";

// ACTION TYPES
export const PRODUCT_LINE_SUMMARY_RESET = "PRODUCT_LINE_SUMMARY_RESET";

export const GET_PRODUCT_LINE_SUMMARY = "GET_PRODUCT_LINE_SUMMARY";
export const GET_PRODUCT_LINE_SUMMARY_LOADING = "GET_PRODUCT_LINE_SUMMARY_LOADING";
export const GET_PRODUCT_LINE_SUMMARY_ERROR = "GET_PRODUCT_LINE_SUMMARY_ERROR";

export const SAVE_PRODUCT_LINE_RESET = "SAVE_PRODUCT_LINE_RESET";
export const SAVE_PRODUCT_LINE_LOADING = "SAVE_PRODUCT_LINE_LOADING";
export const SAVE_PRODUCT_LINE_SUCCESS = "SAVE_PRODUCT_LINE_SUCCESS";
export const SAVE_PRODUCT_LINE_ERROR = "SAVE_PRODUCT_LINE_ERROR";

export const ADD_PRODUCT_LINES = "ADD_PRODUCT_LINES";
export const ADD_PRODUCT_LINES_LOADING = "ADD_PRODUCT_LINES_LOADING";
export const ADD_PRODUCT_LINES_ERROR = "ADD_PRODUCT_LINES_ERROR";

export const GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS = "GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS";
export const GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_LOADING = "GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_LOADING";
export const GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_ERROR = "GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_ERROR";

// ACTION CREATORS
export const productLineSummaryReset = () => ({
  type: PRODUCT_LINE_SUMMARY_RESET,
});

export const getProductLineSummary = (productLineSummary) => ({
  type: GET_PRODUCT_LINE_SUMMARY,
  productLineSummary,
});
export const getProductLineSummaryLoading = () => ({
  type: GET_PRODUCT_LINE_SUMMARY_LOADING,
});
export const getProductLineSummaryError = (error) => ({
  type: GET_PRODUCT_LINE_SUMMARY_ERROR,
  error,
});

export const saveProductLineReset = () => ({
  type: SAVE_PRODUCT_LINE_RESET,
});
export const saveProductLineLoading = () => ({
  type: SAVE_PRODUCT_LINE_LOADING,
});
export const saveProductLineSuccess = (saveProductLine) => ({
  type: SAVE_PRODUCT_LINE_SUCCESS,
  saveProductLine,
});
export const saveProductLineError = (error) => ({
  type: SAVE_PRODUCT_LINE_ERROR,
  error,
});

export const addProductLines = (productLines) => ({
  type: ADD_PRODUCT_LINES,
  productLines,
});
export const addProductLinesLoading = () => ({
  type: ADD_PRODUCT_LINES_LOADING,
});
export const addProductLinesError = (error) => ({
  type: ADD_PRODUCT_LINES_ERROR,
  error,
});

export const getProductLineSummaryConstraints = (productLineSummaryConstraints) => ({
  type: GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS,
  productLineSummaryConstraints,
});
export const getProductLineSummaryConstraintsLoading = () => ({
  type: GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_LOADING,
});
export const getProductLineSummaryConstraintsError = (error) => ({
  type: GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_ERROR,
  error,
});

// THUNK CREATORS
export const getProductLineSummaryThunk = (productLine, pCodes) => async (dispatch) => {
  try {
    dispatch(getProductLineSummaryLoading());
    const { data } = await roverPcdmURL.get(getProductLineSummaryURL(productLine, pCodes));
    dispatch(getProductLineSummary(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(getProductLineSummaryError(error));
  }
};

export const getProductLineSummaryConstraintsThunk = (productLineId) => async (dispatch) => {
  try {
    dispatch(getProductLineSummaryConstraintsLoading());
    const { data } = await roverPcdmURL.get(getProductLineSummaryConstraintsURL(productLineId));
    dispatch(getProductLineSummaryConstraints(data));
  } catch (error) {
    console.error(error);
    dispatch(getProductLineSummaryConstraintsError(error));
  }
};

export const addProductLineThunk = (payload, callback) => async (dispatch) => {
  console.log(payload)
  try {
    dispatch(addProductLinesLoading());
    const { data } = await roverPcdmURL.post(addProductLinesURL(), payload);
    if (callback) {
      callback(ADD_PRODUCT_LINES, data);
    }
    dispatch(addProductLines(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_PRODUCT_LINES_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(addProductLinesError(error));
  }
};

export const saveProductLineThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveProductLineLoading());
    const { data } = await roverPcdmURL.put(saveProductLineURL(), payload);
    if (callback) {
      callback(SAVE_PRODUCT_LINE_SUCCESS, data);
    }
    dispatch(saveProductLineSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_PRODUCT_LINE_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(saveProductLineError(error));
  }
};

// INITIAL STATE
const initialState = {
  productLineSummary: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  saveProductLineStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  addProductLineStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  productLineSummaryConstraints : { data: [], status: DATA_STATUS.INITIAL, response: {} }
};

// REDUCERS
const ProductLinesReducer = (state = initialState, action) => {
  switch (action.type) {
    case PRODUCT_LINE_SUMMARY_RESET:
      return {
        ...state,
        ...initialState,
      };
    case GET_PRODUCT_LINE_SUMMARY:
      return {
        ...state,
        productLineSummary: {
          data: action.productLineSummary,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_PRODUCT_LINE_SUMMARY_LOADING:
      return {
        ...state,
        productLineSummary: {
          ...state.productLineSummary,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_PRODUCT_LINE_SUMMARY_ERROR:
      return {
        ...state,
        productLineSummary: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      }
      case GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS:
        return {
          ...state,
          productLineSummaryConstraints: {
            data: action.productLineSummaryConstraints,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_LOADING:
        return {
          ...state,
          productLineSummaryConstraints: {
            ...state.productLineSummaryConstraints,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_PRODUCT_LINE_SUMMARY_CONSTRAINTS_ERROR:
        return {
          ...state,
          productLineSummaryConstraints: { data: [], status: DATA_STATUS.ERROR, response: action.error },
        }  
    case SAVE_PRODUCT_LINE_RESET:
        return {
          ...state,
          saveProductLineStatus: { ...initialState.saveProductLineStatus },
        };
    case SAVE_PRODUCT_LINE_LOADING:
        return {
          ...state,
          saveProductLineStatus: {
            ...state.saveProductLineStatus,
            status: DATA_STATUS.LOADING,
          },
        };
    case SAVE_PRODUCT_LINE_SUCCESS:
        return {
          ...state,
          saveProductLineStatus: {
            response: action.saveProductLine,
            ...state.saveProductLineStatus,
            status: DATA_STATUS.SUCCESS,
          },
        };
    case SAVE_PRODUCT_LINE_ERROR:
        return {
          ...state,
          saveProductLineStatus: {
            ...state.saveProductLineStatus,
            response: action.error,
            status: DATA_STATUS.ERROR,
          },
        };
        case ADD_PRODUCT_LINES_LOADING:
          return {
            ...state,
            addProductLineStatus: {
              ...state.addProductLineStatus,
              status: DATA_STATUS.LOADING,
            },
          };
      case ADD_PRODUCT_LINES:
          return {
            ...state,
            addProductLineStatus: {
              response: action.productLines,
              ...state.addProductLineStatus,
              status: DATA_STATUS.SUCCESS,
            },
          };
      case ADD_PRODUCT_LINES_ERROR:
          return {
            ...state,
            addProductLineStatus: {
              ...state.addProductLineStatus,
              response: action.error,
              status: DATA_STATUS.ERROR,
            },
          };
    default:
      return state;
  }
};

export default ProductLinesReducer;
