import cookie from "react-cookies";

const DOMAIN = cookie.load('ROVER_PCD_API');

// PRODUCT APIS
export const getProductsURL = (lanId) => {
  return `/pcd/products?lanId=${lanId}`;
};
export const getDelegatesByProductURL = (prdCode) => {
  return `/pcd/products/${prdCode}/delegates`;
};
export const getProductLinesURL = () => {
  return `/pcd/products/productLines`;
};
export const addProductLinesURL = () => {
  return `/pcd/products/addProductLines`;
};
export const saveProductLineURL = () => {
  return `/pcd/products/productLines `;
};
export const getProductLineSummaryConstraintsURL = (productLineId) => {
  return `/pcd/products/${productLineId}/productLinesSummaryConstraint`;
} 
export const getProductLineSummaryURL = (productLine, pCodes = []) => {
  let url = `/pcd/products/${productLine}/productLinesSummary`;
  if (pCodes.length) {
    pCodes.forEach((pCode, index) => {
      if (index === 0) url += `?`;
      if (index > 0) url += `&`;
      url += `productCode=${pCode}`;
    });
  }

  return url;
};
export const addProductURL = () => {
  return `pcd/products/addProduct`;
}
export const saveProductURL = () => {
  return `/pcd/products/addDelegate`;
};
export const getPcdmAccessURL = (productCode, lanId) => {
  return `/pcd/products/${productCode}/${lanId}/delegateAccess`;
};

//ADMIN APIS
export const uploadActualsURL = (month, year) => {
  return `${DOMAIN}/pcd/products/importActualData/${month}/${year}`;
};

export const sendEmailURL = () => {
  return `/pcd/products/sendEmail`;
};

export const getPublishDueDateURL = () => {
  return `/pcd/products/publishDays`;
};

export const modifyPublishDueDateURL = (date) => {
  return `/pcd/products/modifyDays/${date}`;
};

export const addHolidayDetailsURL = () => {
  return `/rover/Holidays`;
};

export const deleteHolidayDetailsURL = (holidayId) => {
  return `rover/deleteHolidays/${holidayId}`
}
export const getHolidayDetailsURL = () => {
  return '/rover/getHolidays';
};

export const editHolidayDetailsURL = (id) => {
  return `/rover/Holidays/${id}`;
}

export const getEmployeesDetailsURL = () => {
  return `/pcd/products/employees`;
}

export const getProjectCodesUsedURL = () => {
  return `/pcd/products/projectCodesUsed`;
} 

export const getPCDMEmailNotificationStatusURL = (nameOfAutomation = "MasterSwitchPCDM") => {
  return `/pcd/products/getStatusAutomationEmail?automationName=${nameOfAutomation}`;
}

export const updatePCDMEmailNotificationStatusURL = (status, nameOfAutomation = "MasterSwitchPCDM") => {
  return `/pcd/products/automateSendEmail?automationName=${nameOfAutomation}&isEmailSend=${status}`;
} 


//TEAM ROLES APIS
export const getManageTeamRolesURL = () => {
  return `/pcd/products/roles`;
};
export const modifyTeamRoleRateURL = () => {
  return `/pcd/products/modifyRate`;
};

//TEAM COMPOSITION APIS
export const GET_METHODOLOGY_URL = `/pcd/products/teams/methodology`;
export const GET_ROLE_URL = `/pcd/products/roles`; //`/pcd/products/teams/roles`;
export const getTeamURL = (productCode) => {
  return `/pcd/products/${productCode}/teams`;
};
export const getRolledOffTeamURL = (productCode,data) => {
  return `/pcd/products/${productCode}/rolledOffTeams${data}`;
};
export const getProductCalcURL = (productCode) => {
  return `/pcd/products/${productCode}/getProductCalculation`;
};
export const getScrumMasterURL = () => {
  return `/pcd/products/scrumMaster`;
}
export const saveTeamURL = (productCode) => {
  return `/pcd/products/${productCode}/teams`;
};
export const copyTeamURL = (productCode) => {
  return `/pcd/products/${productCode}/team-copy`;
};
export const updateTeamURL = (productCode, teamId) => {
  return `/pcd/products/${productCode}/teams/${teamId}`;
};
export const saveRoleURL = (productCode, teamId) => {
  return `/pcd/products/${productCode}/teams/${teamId}/teamRoles`;
};
export const updateRoleURL = (productCode, teamId, teamRoleId) => {
  return `/pcd/products/${productCode}/teams/${teamId}/teamRoles/${teamRoleId}`;
};
export const updateCalculationsURL = (teamId) => {
  return `/pcd/products/teams/monthSprintVelocity/${teamId}`;
}
export const refreshCalculationsURL = (productCode) => {
  return `/pcd/products/refresh/${productCode}`
}
export const refreshMonthlyURL = (productCode) => {
  return `/pcd/products/refresh/monthly/${productCode}`
}
export const projectsBudgetRefreshURL = (projectestimateId, type) => {
  return `/pcd/products/projectBudget/${projectestimateId}/${type}`
}
export const getTeamRolesURL = (productCode) => {
  return `/pcd/products/${productCode}/teamsRoles`;
};
export const getTeamSprintVelocityURL = (productCode) => {
  return `/pcd/products/${productCode}/teams/sprintVelocity`;
};
export const getAllocationDetailsURL = (lanID) => {
  return `/pcd/products/allocation/${lanID}`;
};

//PROJECT ESTIMATES
export const getProjectURL = (productCode) => {
  return `/pcd/products/${productCode}/projects`;
};
export const getCompletedProjectsURL = (productCode) => {
  return `pcd/products/${productCode}/completeProjects`
}
export const saveProjectURL = (productCode) => {
  return `/pcd/products/${productCode}/projects`;
};
export const updateProjectURL = (productCode, projectId) => {
  return `/pcd/products/${productCode}/projects/${projectId}`;
};
export const saveProjectCommentURL = (productCode, projectId) => {
  return `pcd/products/${productCode}/projects/${projectId}/comments`;
};
export const getPortfoliosURL = () => {
  return `/pcd/products/portfolios`;
};
export const getPCodesURL = () => {
  return `/pcd/products/projectCodes`;
};
export const getUsedPCodesURL = () => {
  return `/pcd/products/used-pcodes`;
};
export const getProjectDefaultsURL = (pCode) => {
  return `/pcd/products/projectCodes/${pCode}`;
};

// Summary
export const getMockSummaryURL = () => {
  return `pcd/summary/products/1`;
};
export const getSummaryURL = (productCode) => {
  return `pcd/products/${productCode}/summary`;
};
export const getResourceForecastURL = (productCode) => {
  return `pcd/products/${productCode}/resourceForecast`;
};
export const publishReportURL = (productCode) => {
  return `pcd/products/${productCode}/publishSummaryReport`;
};
export const getBaseLineBudgetURL = (productCode, start, end, storyPoints) => {
  return `pcd/products/${productCode}/getBaseLineBudget?plannedStart=${start}&plannedEnd=${end}&storyPoints=${storyPoints}`;
};
export const getPublishAnswersURL = (productCode) => {
  return `pcd/products/${productCode}/answers`;
}

//Forecast
export const getForecastURL = (productCode) => {
  return `pcd/products/${productCode}/getForecastData`;
};
export const getForecastAggregateURL = (productCode,completed) => {
  return `pcd/products/${productCode}/getAggregateForecastData?projectCompletionFlag=${completed}`;
};
export const getForecastsCapacityURL = (productCode) => {
  return `pcd/products/${productCode}/getForecastsChartTeamCapacity`;
};
export const getForecastDollarURL = (productCode, projectEstimateId, forecastPoints, month) => {
  return `pcd/products/${productCode}/getForecastDollarsAndVariance?projectEstimateId=${projectEstimateId}&forecastPoints=${forecastPoints}&month=${month}`;
};
export const updateForecastChangesURL = (productCode) => {
  return `pcd/products/${productCode}/saveOrUpdateForecastPoints`;
};
export const getForecastDueDatesURL = () =>{
  return `pcd/products/forcastpublishdates`
}
export const getCompletedForecastIndivudualURL = (productCode) => {
  return `pcd/products/${productCode}/getCompletedForecastData`
}
//RMFollow
export const getFollowURL = (productCode, employeeId) => {
  return `/pcd/products/follower/${productCode}/${employeeId}`
};

export const getProductFollowURL = (productCode) => {
  return `/pcd/products/${productCode}/followers`
}