import ProductsReducer from "./products.reducer";
import TeamsReducer from "./teams.reducer";
import RolesReducer from "./roles.reducer";
import ProjectsReducer from './projects.reducer';
import SummaryReducer from './summary.reducer';
import CommonPCDMReducer from './common.reducer';
import ForecastsReducer from './forecast.reducer';
import ProductLinesReducer from './productLine.reducer';
import PCDMAdminReducer from './admin.reducer';
import RMFollowReducer from './RMFollow.reducer';
import TeamCalculationsReducer from './teamCalculations.reducer';

const PCDMreducer = {
  CommonPCDMReducer,
  ProductsReducer,
  TeamsReducer,
  RolesReducer,
  ProjectsReducer,
  SummaryReducer,
  ForecastsReducer,
  ProductLinesReducer,
  PCDMAdminReducer,
  RMFollowReducer,
  TeamCalculationsReducer,
};

export { PCDMreducer };
