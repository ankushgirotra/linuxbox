import { PCDM_TABS } from "../constants/common.constants";

// ACTION TYPES
export const CHANGE_TAB = "CHANGE_TAB";
export const ADD_NOTIFICATION = "ADD_NOTIFICATION";
export const DISCARD_NOTIFICATION = "DISCARD_NOTIFICATION";

export const COMMON_ERROR_PROMPT = "COMMON_ERROR_PROMPT";
export const DISCARD_COMMON_ERROR_PROMPT = "DISCARD_COMMON_ERROR_PROMPT";
// ACTION CREATORS
export const changeTab = (tab) => ({
  type: CHANGE_TAB,
  tab,
});
export const addNotification = (notification) => ({
  type: ADD_NOTIFICATION,
  notification,
});
export const discardNotification = (notification) => ({
  type: DISCARD_NOTIFICATION,
  notification,
});

export const displayCommonError = (notification) => ({
  type: COMMON_ERROR_PROMPT,
  notification
})

export const discardDisplayCommonError = () => ({
  type: DISCARD_COMMON_ERROR_PROMPT,
})

// INITIAL STATE
const initialState = {
  selectedTab: PCDM_TABS.TEAM_COMPOSITION,
  notifications: [],
  errorNotification : { data: null, response:{} }
};

// REDUCERS
const CommonPCDMReducer = (state = initialState, action) => {
  switch (action.type) {
    case CHANGE_TAB:
      return {
        ...state,
        selectedTab: action.tab,
      };
    case ADD_NOTIFICATION:
      let tempAdd = state.notifications.slice();
      let arrLength = tempAdd.length;
      let startIndex = arrLength ? arrLength - 1 : arrLength;
      tempAdd.splice(startIndex, 0, {
        ...action.notification,
        id: arrLength,
        expired: false,
      });
      return {
        ...state,
        notifications: [...tempAdd],
      };
    case DISCARD_NOTIFICATION:
      let tempDiscard = state.notifications.map((item, index) => {
        if (item.id === action.notification.id) {
          return { ...item, expired: true };
        } else {
          return item;
        }
      });
      return {
        ...state,
        notifications: [...tempDiscard],
      };
     case COMMON_ERROR_PROMPT:
      return {
        ...state,
        errorNotification: {
          data: action.notification, 
        },
      }; 
      case DISCARD_COMMON_ERROR_PROMPT:
      return {
        ...state,
        errorNotification: {
          data: null, 
        },
      }; 
    default:
      return state;
  }
};

export default CommonPCDMReducer;
