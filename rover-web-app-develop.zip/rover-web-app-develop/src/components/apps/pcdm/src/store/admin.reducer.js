import roverPcdmURL from "../../../../../apis/pcdm_api";
import {
  getManageTeamRolesURL,
  modifyTeamRoleRateURL,
  getPcdmAccessURL,
  uploadActualsURL,
  getPublishDueDateURL,
  getProjectCodesUsedURL,
  modifyPublishDueDateURL,
  addHolidayDetailsURL,
  getHolidayDetailsURL,
  editHolidayDetailsURL,
  getEmployeesDetailsURL,
  deleteHolidayDetailsURL,
  sendEmailURL,
  getPCDMEmailNotificationStatusURL,
  updatePCDMEmailNotificationStatusURL,
} from "./endpoints";
import { DATA_STATUS } from "../constants/service.constant";
import axios, { post } from "axios";
import { GET_DELEGATES_BY_PRD_LOADING } from "./products.reducer";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";

// ACTION TYPES
export const GET_ADMIN_TEAM_ROLES_RESET = "GET_ADMIN_TEAM_ROLES_RESET";
export const GET_ADMIN_TEAM_ROLES = "GET_ADMIN_TEAM_ROLES";
export const GET_ADMIN_TEAM_ROLES_LOADING = "GET_ADMIN_TEAM_ROLES_LOADING";
export const GET_ADMIN_TEAM_ROLES_ERROR = "GET_ADMIN_TEAM_ROLES_ERROR";

export const MODIFY_TEAM_ROLE_RATE_LOADING = "MODIFY_TEAM_ROLE_RATE_LOADING";
export const MODIFY_TEAM_ROLE_RATE_SUCCESS = "MODIFY_TEAM_ROLE_RATE_SUCCESS";
export const MODIFY_TEAM_ROLE_RATE_ERROR = "MODIFY_TEAM_ROLE_RATE_ERROR";

export const GET_PCDM_ACCESS = "GET_PCDM_ACCESS";
export const GET_PCDM_ACCESS_LOADING = "GET_PCDM_ACCESS_LOADING";
export const GET_PCDM_ACCESS_ERROR = "GET_PCDM_ACCESS_ERROR";

export const UPLOAD_ACTUALS_LOADING = "UPLOAD_ACTUALS_LOADING";
export const UPLOAD_ACTUALS_SUCCESS = "UPLOAD_ACTUALS_SUCCESS";
export const UPLOAD_ACTUALS_ERROR = "UPLOAD_ACTUALS_ERROR";

export const SEND_EMAIL_LOADING = "SEND_EMAIL_LOADING";
export const SEND_EMAIL_SUCCESS = "SEND_EMAIL_SUCCESS";
export const SEND_EMAIL_ERROR = "SEND_EMAIL_ERROR";

export const GET_PUBLISH_DUE_DATE_LOADING = "GET_PUBLISH_DUE_DATE_LOADING";
export const GET_PUBLISH_DUE_DATE_SUCCESS = "GET_PUBLISH_DUE_DATE_SUCCESS";
export const GET_PUBLISH_DUE_DATE_ERROR = "GET_PUBLISH_DUE_DATE_ERROR";

export const GET_USED_PROJECTCODES_LOADING = "GET_USED_PROJECTCODES_LOADING";
export const GET_USED_PROJECTCODES_SUCCESS = "GET_USED_PROJECTCODES_SUCCESS";
export const GET_USED_PROJECTCODES_ERROR = "GET_USED_PROJECTCODES_ERROR";

export const MODIFY_PUBLISH_DUE_DATE_LOADING = "MODIFY_PUBLISH_DUE_DATE_LOADING";
export const MODIFY_PUBLISH_DUE_DATE_SUCCESS = "MODIFY_PUBLISH_DUE_DATE_SUCCESS";
export const MODIFY_PUBLISH_DUE_DATE_ERROR = "MODIFY_PUBLISH_DUE_DATE_ERROR";

export const ADD_HOLIDAY_LOADING = "ADD_HOLIDAY_LOADING";
export const ADD_HOLIDAY_SUCCESS = "ADD_HOLIDAY_SUCCESS";
export const ADD_HOLIDAY_ERROR = "ADD_HOLIDAY_ERROR";

export const DELETE_HOLIDAY_LOADING = "DELETE_HOLIDAY_LOADING";
export const DELETE_HOLIDAY_SUCCESS = "DELETE_HOLIDAY_SUCCESS";
export const DELETE_HOLIDAY_ERROR = "DELETE_HOLIDAY_ERROR";

export const GET_HOLIDAY_DETAILS_LOADING = "GET_HOLIDAY_DETAILS_LOADING";
export const GET_HOLIDAY_DETAILS_SUCCESS = "GET_HOLIDAY_DETAILS_SUCCESS";
export const GET_HOLIDAY_DETAILS_ERROR = "GET_HOLIDAY_DETAILS_ERROR";

export const EDIT_HOLIDAY_LOADING = "EDIT_HOLIDAY_LOADING";
export const EDIT_HOLIDAY_SUCCESS = "EDIT_HOLIDAY_SUCCESS";
export const EDIT_HOLIDAY_ERROR = "EDIT_HOLIDAY_ERROR";

export const GET_EMPLOYEE_DETAILS_LOADING = "GET_EMPLOYEE_DETAILS_LOADING";
export const GET_EMPLOYEE_DETAILS_SUCCESS = "GET_EMPLOYEE_DETAILS_SUCCESS";
export const GET_EMPLOYEE_DETAILS_ERROR = "GET_EMPLOYEE_DETAILS_ERROR";

export const GET_EMAIL_NOTIFICATION_STATUS_LOADING = "GET_EMAIL_NOTIFICATION_STATUS_LOADING";
export const GET_EMAIL_NOTIFICATION_STATUS_SUCCESS = "GET_EMAIL_NOTIFICATION_STATUS_SUCCESS";
export const GET_EMAIL_NOTIFICATION_STATUS_ERROR = "GET_EMAIL_NOTIFICATION_STATUS_ERROR";

export const UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING = "UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING";
export const UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS = "UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS";
export const UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR = "UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR";

// ACTION CREATORS
export const manageAdminTeamRolesReset = () => ({
  type: GET_ADMIN_TEAM_ROLES_RESET,
});
export const getManageAdminTeamRoles = (teamRoles) => ({
  type: GET_ADMIN_TEAM_ROLES,
  teamRoles,
});
export const getManageAdminTeamRolesLoading = () => ({
  type: GET_ADMIN_TEAM_ROLES_LOADING,
});
export const getManageAdminTeamRolesError = (error) => ({
  type: GET_ADMIN_TEAM_ROLES_ERROR,
  error,
});

export const modifyTeamRoleRateLoading = () => ({
  type: MODIFY_TEAM_ROLE_RATE_LOADING,
});
export const modifyTeamRoleRateSuccess = (saveProduct) => ({
  type: MODIFY_TEAM_ROLE_RATE_SUCCESS,
  saveProduct,
});
export const modifyTeamRoleRateError = (error) => ({
  type: MODIFY_TEAM_ROLE_RATE_ERROR,
  error,
});

export const sendEmailLoading = () => ({
  type: SEND_EMAIL_LOADING,
});
export const sendEmailSuccess = (data) => ({
  type: SEND_EMAIL_SUCCESS,
  data,
});
export const sendEmailError = (error) => ({
  type: SEND_EMAIL_ERROR,
  error,
});

export const getPcdmAccess = (pcdmAccess) => ({
  type: GET_PCDM_ACCESS,
  pcdmAccess,
});
export const getPcdmAccessLoading = () => ({
  type: GET_PCDM_ACCESS_LOADING,
});
export const getPcdmAccessError = (error) => ({
  type: GET_PCDM_ACCESS_ERROR,
  error,
});

export const uploadActulasLoading = () => ({
  type: UPLOAD_ACTUALS_LOADING,
});
export const uploadActulasSuccess = (uploadActualsResponse) => ({
  type: UPLOAD_ACTUALS_SUCCESS,
  uploadActualsResponse,
});
export const uploadActulasError = (error) => ({
  type: UPLOAD_ACTUALS_ERROR,
  error,
});

export const getPublishDueDateLoading = () => ({
  type: GET_PUBLISH_DUE_DATE_LOADING,
});
export const getPublishDueDateSuccess = (getPublishDueDate) => ({
  type: GET_PUBLISH_DUE_DATE_SUCCESS,
  getPublishDueDate,
});
export const getPublishDueDateError = (error) => ({
  type: GET_PUBLISH_DUE_DATE_ERROR,
  error,
});

export const getUsedProjectCodesLoading = () => ({
  type: GET_USED_PROJECTCODES_LOADING,
});
export const getUsedProjectCodesSuccess = (UsedProjectCodes) => ({
  type: GET_USED_PROJECTCODES_SUCCESS,
  UsedProjectCodes,
});
export const getUsedProjectCodesError = (error) => ({
  type: GET_USED_PROJECTCODES_ERROR,
  error,
});

export const modifyPublishDueDateLoading = () => ({
  type: MODIFY_PUBLISH_DUE_DATE_LOADING,
});
export const modifyPublishDueDateSuccess = (modifyPublishDueDate) => ({
  type: MODIFY_PUBLISH_DUE_DATE_SUCCESS,
  modifyPublishDueDate,
});
export const modifyPublishDueDateError = (error) => ({
  type: MODIFY_PUBLISH_DUE_DATE_ERROR,
  error,
});

export const addHolidayLoading = () => ({
  type: ADD_HOLIDAY_LOADING,
});
export const addHolidaySuccess = (addHoliday) => ({
  type: ADD_HOLIDAY_SUCCESS,
  addHoliday,
});
export const addHolidayError = (error) => ({
  type: ADD_HOLIDAY_ERROR,
  error,
});

//#region Delet holiday 
export const deleteHolidayLoading = () => ({
  type: DELETE_HOLIDAY_LOADING,
});
export const deleteHolidaySuccess = (deleteData) => ({
  type: DELETE_HOLIDAY_SUCCESS,
  deleteData,
});
export const deleteHolidayError = (error) => ({
  type: DELETE_HOLIDAY_ERROR,
  error,
});
//#endregion

export const getHolidayDetailsLoading = () => ({
  type: GET_HOLIDAY_DETAILS_LOADING,
});
export const getHolidayDetailsSuccess = (getHolidayDetails) => ({
  type: GET_HOLIDAY_DETAILS_SUCCESS,
  getHolidayDetails,
});
export const getHolidayDetailsError = (error) => ({
  type: GET_HOLIDAY_DETAILS_ERROR,
  error,
});

export const editHolidayLoading = () => ({
  type: ADD_HOLIDAY_LOADING,
});
export const editHolidaySuccess = (editHoliday) => ({
  type: ADD_HOLIDAY_SUCCESS,
  editHoliday,
});
export const editHolidayError = (error) => ({
  type: ADD_HOLIDAY_ERROR,
  error,
});

export const getEmployeeDetails = (employeeDetails) => ({
  type: GET_EMPLOYEE_DETAILS_SUCCESS,
  employeeDetails,
});
export const getEmployeeDetailsLoading = () => ({
  type: GET_EMPLOYEE_DETAILS_LOADING,
});
export const getEmployeeDetailsError = (error) => ({
  type: GET_EMPLOYEE_DETAILS_ERROR,
  error,
});

export const getEmailNotificationStatusSuccess = (status) => ({
  type: GET_EMAIL_NOTIFICATION_STATUS_SUCCESS,
  status,
});

export const updateEmailNotificationStatusLoading = () => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING,
});
export const updateEmailNotificationStatusSuccess = (updateStatus) => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS,
  updateStatus,
});
export const updateEmailNotificationStatusError = (error) => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR,
  error,
});

// THUNK CREATORS
export const getManageAdminTeamRolesThunk = () => async (dispatch) => {
  try {
    dispatch(getManageAdminTeamRolesLoading());
    const { data } = await roverPcdmURL.get(getManageTeamRolesURL());
    dispatch(getManageAdminTeamRoles(data));
  } catch (error) {
    console.error(error);
    dispatch(getManageAdminTeamRolesError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const modifyTeamRoleRateThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(modifyTeamRoleRateLoading());
    const { data } = await roverPcdmURL.put(modifyTeamRoleRateURL(), payload);
    if (callback) {
      callback(MODIFY_TEAM_ROLE_RATE_SUCCESS, data);
    }
    dispatch(modifyTeamRoleRateSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(MODIFY_TEAM_ROLE_RATE_ERROR, error);
    }
    dispatch(modifyTeamRoleRateError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const sendEmailThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(sendEmailLoading());
    const { data } = await roverPcdmURL.post(sendEmailURL(), payload);
    if (callback) {
      callback(SEND_EMAIL_SUCCESS, data);
    }
    dispatch(sendEmailSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SEND_EMAIL_ERROR, error);
    }
    dispatch(sendEmailError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const uploadActulasThunk = (month, year, formData, callback) => async (dispatch) => {
  const token = localStorage.getItem('token');
  dispatch(uploadActulasLoading());
  post(uploadActualsURL(month, year), formData, {
    headers: { "content-type": "multipart/form-data" ,
            "Authorization":`Bearer ${token}`
    },
  })
    .then((response) => {
      if (callback) {
        callback(UPLOAD_ACTUALS_SUCCESS, response);
      }
      dispatch(uploadActulasSuccess(response));
    })
    .catch((error) => {
      console.error(error);
      if (callback) {
        callback(UPLOAD_ACTUALS_ERROR, error);
      }
      dispatch(uploadActulasError(error));
      if(checkErrorType(error)) {
        dispatch(displayCommonError(error))
      }
    });
};

export const getPublishDueDateThunk = () => async (dispatch) => {
  try {
    dispatch(getPublishDueDateLoading());
    const { data } = await roverPcdmURL.get(getPublishDueDateURL());
    dispatch(getPublishDueDateSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getPublishDueDateError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getUsedProjectCodesThunk = () => async (dispatch) => {
  try {
    dispatch(getUsedProjectCodesLoading());
    const { data } = await roverPcdmURL.get(getProjectCodesUsedURL());
    dispatch(getUsedProjectCodesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getUsedProjectCodesError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const modifyPublishDueDateThunk = (date, callback) => async (dispatch) => {
  try {
    dispatch(modifyPublishDueDateLoading());
    const { data } = await roverPcdmURL.put(modifyPublishDueDateURL(date));
    if (callback) {
      callback(MODIFY_PUBLISH_DUE_DATE_SUCCESS, data);
    }
    dispatch(modifyPublishDueDateSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(MODIFY_PUBLISH_DUE_DATE_ERROR, error);
    }
    dispatch(modifyPublishDueDateError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const addHolidayThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addHolidayLoading());
    const { data } = await roverPcdmURL.post(addHolidayDetailsURL(), payload);
    if (callback) {
      callback(ADD_HOLIDAY_SUCCESS, data);
    }
    dispatch(addHolidaySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_HOLIDAY_ERROR, error);
    }
    dispatch(addHolidayError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const deleteHolidayThunk = (holidayId, callback) => async (dispatch) => {
  try {
    dispatch(deleteHolidayLoading());
    const { data } = await roverPcdmURL.put(deleteHolidayDetailsURL(holidayId));
    if (callback) {
      callback(DELETE_HOLIDAY_SUCCESS, data);
    }
    dispatch(deleteHolidaySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_HOLIDAY_ERROR, error);
    }
    dispatch(deleteHolidayError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getHolidayDetailsThunk = (callback) => async (dispatch) => {
  try {
    dispatch(addHolidayLoading());
    const { data } = await roverPcdmURL.get(getHolidayDetailsURL());
    if (callback) {
      callback(GET_HOLIDAY_DETAILS_SUCCESS, data);
    }
    dispatch(getHolidayDetailsSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_HOLIDAY_DETAILS_ERROR, error);
    }
    dispatch(getHolidayDetailsError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const editHolidayThunk = (id, payload, callback) => async (dispatch) => {
  try {
    dispatch(editHolidayLoading());
    const { data } = await roverPcdmURL.put(editHolidayDetailsURL(id), payload);
    if (callback) {
      callback(EDIT_HOLIDAY_SUCCESS, data);
    }
    dispatch(editHolidaySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_HOLIDAY_ERROR, error);
    }
    dispatch(editHolidayError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getEmployeeDetailsThunk = () => async (dispatch) => {
  try {
    dispatch(getEmployeeDetailsLoading());
    const { data } = await roverPcdmURL.get(getEmployeesDetailsURL());
    dispatch(getEmployeeDetails(data));
  } catch (error) {
    console.error(error);
    dispatch(getEmployeeDetailsError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getEmailNotificationStatusThunk = () => async (dispatch) => {
  try {
    const { data } = await roverPcdmURL.get(getPCDMEmailNotificationStatusURL());
    dispatch(getEmailNotificationStatusSuccess(data));
  } catch (error) {
    console.error(error);
  }
};

export const updateEmailNotificationStatusThunk = (status, callback) => async (dispatch) => {
  try {
    dispatch(updateEmailNotificationStatusLoading());
    const { data } = await roverPcdmURL.put(updatePCDMEmailNotificationStatusURL(status));
    if (callback) {
      callback(UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS, status);
    }
    dispatch(updateEmailNotificationStatusSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR, error);
    }
    dispatch(updateEmailNotificationStatusError(error));
  }
};

// INITIAL STATE
export const initialState = {
  teamRoles: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  modifyTeamRoleRateStatus: { status: DATA_STATUS.INITIAL, response: {} },
  actualsUploadStatus: { status: DATA_STATUS.INITIAL, response: {} },
  getPublishDueDate: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  projectCodesUsed : { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  modifyPublishDueDate: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  pcdmAccess: {
    data: { productCode: "", delegateLanId: "", writeAccess: false },
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  addHoliday: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  getHolidayDetails: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editHoliday: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  employeeDetails: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deleteData: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  sendEmailStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  emailNotificationStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  updateEmailNotificationStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
export const PCDMAdminReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_ADMIN_TEAM_ROLES_RESET:
      return {
        ...state,
        ...initialState,
      };
    case GET_ADMIN_TEAM_ROLES:
      return {
        ...state,
        teamRoles: {
          data: action.teamRoles, //typeof action.teamRoles === "string" ? [] : [...action.teamRoles],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ADMIN_TEAM_ROLES_LOADING:
      return {
        ...state,
        teamRoles: {
          ...state.teamRoles,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ADMIN_TEAM_ROLES_ERROR:
      return {
        ...state,
        teamRoles: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_PCDM_ACCESS:
      return {
        ...state,
        pcdmAccess: {
          ...state.pcdmAccess,
          data: action.pcdmAccess,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_PCDM_ACCESS_LOADING:
      return {
        ...state,
        pcdmAccess: {
          ...state.pcdmAccess,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_PCDM_ACCESS_ERROR:
      return {
        ...state,
        pcdmAccess: { ...initialState.pcdmAccess, response: action.error },
      };
    case MODIFY_TEAM_ROLE_RATE_SUCCESS:
      return {
        ...state,
        modifyTeamRoleRateStatus: {
          ...state.modifyTeamRoleRateStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case MODIFY_TEAM_ROLE_RATE_LOADING:
      return {
        ...state,
        modifyTeamRoleRateStatus: {
          ...state.modifyTeamRoleRateStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case MODIFY_TEAM_ROLE_RATE_ERROR:
      return {
        ...state,
        modifyTeamRoleRateStatus: {
          ...state.modifyTeamRoleRateStatus,
          status: DATA_STATUS.ERROR,
        },
      };
    case UPLOAD_ACTUALS_SUCCESS:
      return {
        ...state,
        actualsUploadStatus: {
          ...state.actualsUploadStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPLOAD_ACTUALS_LOADING:
      return {
        ...state,
        actualsUploadStatus: {
          ...state.actualsUploadStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPLOAD_ACTUALS_ERROR:
      return {
        ...state,
        actualsUploadStatus: {
          ...state.actualsUploadStatus,
          status: DATA_STATUS.ERROR,
        },
      };
    // publish_due_date
    case GET_PUBLISH_DUE_DATE_SUCCESS:
      return {
        ...state,
        getPublishDueDate: {
          data: action.getPublishDueDate,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_PUBLISH_DUE_DATE_LOADING:
      return {
        ...state,
        getPublishDueDate: {
          ...state.getPublishDueDate,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_PUBLISH_DUE_DATE_ERROR:
      return {
        ...state,
        getPublishDueDate: { data: {}, status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_USED_PROJECTCODES_SUCCESS:
      return {
        ...state,
        projectCodesUsed: {
          data: action.UsedProjectCodes,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_USED_PROJECTCODES_LOADING:
      return {
        ...state,
        projectCodesUsed: {
          ...state.projectCodesUsed,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_USED_PROJECTCODES_ERROR:
      return {
        ...state,
        projectCodesUsed: { data: {}, status: DATA_STATUS.ERROR, response: action.error },
      };
    case MODIFY_PUBLISH_DUE_DATE_SUCCESS:
      return {
        ...state,
        modifyPublishDueDate: {
          data: action.modifyPublishDueDate,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case MODIFY_PUBLISH_DUE_DATE_LOADING:
      return {
        ...state,
        modifyPublishDueDate: {
          ...state.modifyPublishDueDate,
          status: DATA_STATUS.LOADING,
        },
      };
    case MODIFY_PUBLISH_DUE_DATE_ERROR:
      return {
        ...state,
        modifyPublishDueDate: {
          ...state.modifyPublishDueDate,
          status: DATA_STATUS.ERROR,
          response: action.error
        },
      };
    case ADD_HOLIDAY_SUCCESS:
      return {
        ...state,
        addHoliday: {
          data: action.addHoliday,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_HOLIDAY_LOADING:
      return {
        ...state,
        addHoliday: {
          ...state.addHoliday,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_HOLIDAY_ERROR:
      return {
        ...state,
        addHoliday: {
          ...state.addHoliday,
          status: DATA_STATUS.ERROR,
          response: action.error
        },
      };
    case DELETE_HOLIDAY_SUCCESS:
      return {
        ...state,
        deleteData: {
          data: action.deleteData,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_HOLIDAY_LOADING:
      return {
        ...state,
        deleteData: {
          ...state.deleteData,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_HOLIDAY_ERROR:
      return {
        ...state,
        deleteData: {
          ...state.deleteData,
          status: DATA_STATUS.ERROR,
          response: action.error
        },
      };
    case GET_HOLIDAY_DETAILS_LOADING:
      return {
        ...state,
        getHolidayDetails: {
          ...state.getHolidayDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_HOLIDAY_DETAILS_SUCCESS:
      return {
        ...state,
        getHolidayDetails: {
          data: action.getHolidayDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_HOLIDAY_DETAILS_ERROR:
      return {
        ...state,
        getHolidayDetails: {
          ...state.getHolidayDetails,
          status: DATA_STATUS.ERROR,
          response: action.error
        },
      };
    case EDIT_HOLIDAY_SUCCESS:
      return {
        ...state,
        editHoliday: {
          data: action.editHoliday,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_HOLIDAY_LOADING:
      return {
        ...state,
        editHoliday: {
          ...state.editHoliday,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_HOLIDAY_ERROR:
      return {
        ...state,
        editHoliday: {
          ...state.editHoliday,
          status: DATA_STATUS.ERROR,
          response: action.error
        },
      };
    case GET_EMPLOYEE_DETAILS_SUCCESS:
      return {
        ...state,
        employeeDetails: {
          ...state.employeeDetails,
          data: action.employeeDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_EMPLOYEE_DETAILS_LOADING:
      return {
        ...state,
        employeeDetails: {
          ...state.employeeDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_EMPLOYEE_DETAILS_ERROR:
      return {
        ...state,
        employeeDetails: { ...initialState.employeeDetails, response: action.error },
      };
    case SEND_EMAIL_SUCCESS:
      return {
        ...state,
        sendEmailStatus: {
          data: action.data, //typeof action.teamRoles === "string" ? [] : [...action.teamRoles],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SEND_EMAIL_LOADING:
      return {
        ...state,
        sendEmailStatus: {
          ...state.sendEmailStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SEND_EMAIL_ERROR:
      return {
        ...state,
        sendEmailStatus: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_EMAIL_NOTIFICATION_STATUS_SUCCESS:
      return {
        ...state,
        emailNotificationStatus: {
          ...state.emailNotificationStatus,
          data: action.status,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default PCDMAdminReducer;
