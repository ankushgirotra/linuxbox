import roverPcdmURL from "../../../../../apis/pcdm_api";
import {
  getProductsURL,
  getProductLinesURL,
  saveProductURL,
  addProductURL,
  getDelegatesByProductURL,
  getForecastDueDatesURL
} from "./endpoints";
import { DATA_STATUS } from "../constants/service.constant";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";
// ACTION TYPES
export const SET_PRODUCTS_BY_OWNER = "SET_PRODUCTS_BY_OWNER";
export const SET_PRODUCTS_BY_OWNER_LOADING = "SET_PRODUCTS_BY_OWNER_LOADING";
export const SET_PRODUCTS_BY_OWNER_ERROR = "SET_PRODUCTS_BY_OWNER_ERROR";

export const GET_DELEGATES_BY_PRD = "GET_DELEGATES_BY_PRD";
export const GET_DELEGATES_BY_PRD_LOADING = "GET_DELEGATES_BY_PRD_LOADING";
export const GET_DELEGATES_BY_PRD_ERROR = "GET_DELEGATES_BY_PRD_ERROR";

export const SET_PRODUCT_LINES = "SET_PRODUCT_LINES";
export const SET_PRODUCT_LINES_LOADING = "SET_PRODUCT_LINES_LOADING";
export const SET_PRODUCT_LINES_ERROR = "SET_PRODUCT_LINES_ERROR";

export const SAVE_PRODUCT_RESET = "SAVE_PRODUCT_RESET";
export const SAVE_PRODUCT_LOADING = "SAVE_PRODUCT_LOADING";
export const SAVE_PRODUCT_SUCCESS = "SAVE_PRODUCT_SUCCESS";
export const SAVE_PRODUCT_ERROR = "SAVE_PRODUCT_ERROR";

export const ADD_PRODUCT_RESET = "ADD_PRODUCT_RESET";
export const ADD_PRODUCT_LOADING = "ADD_PRODUCT_LOADING";
export const ADD_PRODUCT_SUCCESS = "ADD_PRODUCT_SUCCESS";
export const ADD_PRODUCT_ERROR = "ADD_PRODUCT_ERROR";

export const GET_FORECAST_DUE_DATES = 'GET_FORECAST_DUE_DATES'
export const GET_FORECAST_DUE_DATES_LOADING = 'GET_FORECAST_DUE_DATES_LOADING'
export const GET_FORECAST_DUE_DATES_ERROR = 'GET_FORECAST_DUE_DATES__ERROR'


// ACTION CREATORS
export const setProductsByOwner = (products) => ({
  type: SET_PRODUCTS_BY_OWNER,
  products,
});
export const setProductsByOwnerLoading = () => ({
  type: SET_PRODUCTS_BY_OWNER_LOADING,
});
export const setProductsByOwnerError = (error) => ({
  type: SET_PRODUCTS_BY_OWNER_ERROR,
  error,
});

export const getDelegatesByProduct = (delegates) => ({
  type: GET_DELEGATES_BY_PRD,
  delegates,
});
export const getDelegatesByProductLoading = () => ({
  type: GET_DELEGATES_BY_PRD_LOADING,
});
export const getDelegatesByProductError = (error) => ({
  type: GET_DELEGATES_BY_PRD_ERROR,
  error,
});

export const setProductLines = (productLines) => ({
  type: SET_PRODUCT_LINES,
  productLines,
});
export const setProductLinesLoading = () => ({
  type: SET_PRODUCT_LINES_LOADING,
});
export const setProductLinesError = (error) => ({
  type: SET_PRODUCT_LINES_ERROR,
  error,
});

export const saveProductReset = () => ({
  type: SAVE_PRODUCT_RESET,
});
export const saveProductLoading = () => ({
  type: SAVE_PRODUCT_LOADING,
});
export const saveProductSuccess = (saveProduct) => ({
  type: SAVE_PRODUCT_SUCCESS,
  saveProduct,
});
export const saveProductError = (error) => ({
  type: SAVE_PRODUCT_ERROR,
  error,
});

export const addProductReset = () => ({
  type: ADD_PRODUCT_RESET,
});
export const addProductLoading = () => ({
  type: ADD_PRODUCT_LOADING,
});
export const addProductSuccess = (addProduct) => ({
  type: ADD_PRODUCT_SUCCESS,
  addProduct,
});
export const addProductError = (error) => ({
  type: ADD_PRODUCT_ERROR,
  error,
});

export const getForecastDueDatesLoading = () => ({
  type: GET_FORECAST_DUE_DATES_LOADING,
});
export const getForecastDueDates = (dueDates) => ({
  type: GET_FORECAST_DUE_DATES,
  dueDates,
});
export const getForecastDueDatesError = (error) => ({
  type: GET_FORECAST_DUE_DATES_ERROR,
  error,
});

// THUNK CREATORS
export const getDelegatesByProductThunk = (prdCode) => async (dispatch) => {
  try {
    dispatch(getDelegatesByProductLoading());
    const { data } = await roverPcdmURL.get(getDelegatesByProductURL(prdCode));
    dispatch(getDelegatesByProduct(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(getDelegatesByProductError(error));
  }
};
export const setProductsByOwnerThunk = (lanID) => async (dispatch) => {
  try {
    dispatch(setProductsByOwnerLoading());
    const { data } = await roverPcdmURL.get(getProductsURL(lanID));
    dispatch(setProductsByOwner(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(setProductsByOwnerError(error));
  }
};
export const setProductLinesThunk = () => async (dispatch) => {
  try {
    dispatch(setProductLinesLoading());
    const { data } = await roverPcdmURL.get(getProductLinesURL());
    dispatch(setProductLines(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(setProductLinesError(error));
  }
};

export const saveProductThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveProductLoading());
    const { data } = await roverPcdmURL.put(saveProductURL(), payload);
    if (callback) {
      callback(SAVE_PRODUCT_SUCCESS, data);
    }
    dispatch(saveProductSuccess(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    if (callback) {
      callback(SAVE_PRODUCT_ERROR, error);
    }
    dispatch(saveProductError(error));
  }
};

export const addProductThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addProductLoading());
    const { data } = await roverPcdmURL.post(addProductURL(), payload);
    if (callback) {
      callback(ADD_PRODUCT_SUCCESS, data);
    }
    dispatch(addProductSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_PRODUCT_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(addProductError(error));
  }
};

export const getForecastDueDatesThunk = () => async (dispatch) => {
  try {
    dispatch(getForecastDueDatesLoading());
    const { data } = await roverPcdmURL.get(getForecastDueDatesURL());
    dispatch(getForecastDueDates(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(getForecastDueDatesError(error));
  }
};

// INITIAL STATE
const initialState = {
  productsByOwner: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  productLines: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  delegatesByProduct: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  saveProductStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  addProductStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  forecastDueDates: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  }
};

// REDUCERS
const ProductsReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_PRODUCTS_BY_OWNER:
      return {
        ...state,
        productsByOwner: {
          data: action.products,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SET_PRODUCTS_BY_OWNER_LOADING:
      return {
        ...state,
        productsByOwner: {
          ...state.productsByOwner,
          status: DATA_STATUS.LOADING,
        },
      };
    case SET_PRODUCTS_BY_OWNER_ERROR:
      return {
        ...state,
        productsByOwner: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_DELEGATES_BY_PRD:
      return {
        ...state,
        delegatesByProduct: {
          data: action.delegates,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DELEGATES_BY_PRD_LOADING:
      return {
        ...state,
        delegatesByProduct: {
          ...state.delegatesByProduct,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DELEGATES_BY_PRD_ERROR:
      return {
        ...state,
        delegatesByProduct: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case SET_PRODUCT_LINES:
      return {
        ...state,
        productLines: {
          data: action.productLines,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SET_PRODUCT_LINES_LOADING:
      return {
        ...state,
        productLines: {
          ...state.productLines,
          status: DATA_STATUS.LOADING,
        },
      };
    case SET_PRODUCT_LINES_ERROR:
      return {
        ...state,
        productLines: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case SAVE_PRODUCT_RESET:
      return {
        ...state,
        saveProductStatus: { ...initialState.saveProductStatus },
      };
    case SAVE_PRODUCT_LOADING:
      return {
        ...state,
        saveProductStatus: {
          ...state.saveProductStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_PRODUCT_SUCCESS:
      return {
        ...state,
        saveProductStatus: {
          ...state.saveProductStatus,
          response: action.saveProduct,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_PRODUCT_ERROR:
      return {
        ...state,
        saveProductStatus: {
          ...state.saveProductStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    // Add Product Reducers
    case ADD_PRODUCT_RESET:
      return {
        ...state,
        addProductStatus: { ...initialState.addProductStatus },
      };
    case ADD_PRODUCT_LOADING:
      return {
        ...state,
        addProductStatus: {
          ...state.addProductStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_PRODUCT_SUCCESS:
      return {
        ...state,
        addProductStatus: {
          ...state.addProductStatus,
          response: action.addProduct,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_PRODUCT_ERROR:
      return {
        ...state,
        addProductStatus: {
          ...state.addProductStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
      case GET_FORECAST_DUE_DATES:
        return {
          ...state,
          forecastDueDates: {
            data: action.dueDates,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_FORECAST_DUE_DATES_LOADING:
        return {
          ...state,
          forecastDueDates: {
            ...state.forecastDueDates,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_FORECAST_DUE_DATES_ERROR:
        return {
          ...state,
          forecastDueDates: { data: [], status: DATA_STATUS.ERROR, response: action.error },
        };
    default:
      return state;
  }
};

export default ProductsReducer;
