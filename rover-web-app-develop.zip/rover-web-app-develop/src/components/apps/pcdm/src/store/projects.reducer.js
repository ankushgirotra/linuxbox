import roverPcdmURL from "../../../../../apis/pcdm_api";
import { DATA_STATUS } from "../constants/service.constant";
import {
  getProjectURL,
  saveProjectURL,
  updateProjectURL,
  getPortfoliosURL,
  getPCodesURL,
  getProjectDefaultsURL,
  getUsedPCodesURL,
  saveProjectCommentURL,
  getBaseLineBudgetURL,
  getCompletedProjectsURL,
} from "./endpoints";
import { moveArrayEl } from "../services/validation";
import { checkErrorType } from "../templates/forecast.template";
import { displayCommonError } from "./common.reducer";

// ACTION TYPES
export const SET_PORTFOLIO_OPTIONS = "GET_PORTFOLIO_OPTIONS";
export const SET_PCODE_OPTIONS = "GET_PCODE_OPTIONS";
export const GET_USED_PCODES = "GET_USED_PCODES";

export const GET_PROJECT_DEFAULTS_LOADING = "GET_PROJECT_DEFAULTS_LOADING";
export const GET_PROJECT_DEFAULTS_SUCCESS = "GET_PROJECT_DEFAULTS_SUCCESS";
export const GET_PROJECT_DEFAULTS_ERROR = "GET_PROJECT_DEFAULTS_ERROR";

export const SAVE_PROJECT_LOADING = "SAVE_PROJECT_LOADING";
export const SAVE_PROJECT_SUCCESS = "SAVE_PROJECT_SUCCESS";
export const SAVE_PROJECT_ERROR = "SAVE_PROJECT_ERROR";

export const EDIT_PROJECT_LOADING = "EDIT_PROJECT_LOADING";
export const EDIT_PROJECT_SUCCESS = "EDIT_PROJECT_SUCCESS";
export const EDIT_PROJECT_ERROR = "EDIT_PROJECT_ERROR";

export const SAVE_PROJECT_COMMENT_LOADING = "SAVE_PROJECT_COMMENT_LOADING";
export const SAVE_PROJECT_COMMENT_SUCCESS = "SAVE_PROJECT_COMMENT_SUCCESS";
export const SAVE_PROJECT_COMMENT_ERROR = "SAVE_PROJECT_COMMENT_ERROR";

export const COMPLETE_PROJECT_LOADING = "COMPLETE_PROJECT_LOADING";
export const COMPLETE_PROJECT_SUCCESS = "COMPLETE_PROJECT_SUCCESS";
export const COMPLETE_PROJECT_ERROR = "COMPLETE_PROJECT_ERROR";

export const DELETE_PROJECT_LOADING = "DELETE_PROJECT_LOADING";
export const DELETE_PROJECT_SUCCESS = "DELETE_PROJECT_SUCCESS";
export const DELETE_PROJECT_ERROR = "DELETE_PROJECT_ERROR";

export const GET_PROJECTS_LOADING = "GET_PROJECTS_LOADING";
export const GET_PROJECTS_SUCCESS = "GET_PROJECTS_SUCCESS";
export const GET_PROJECTS_ERROR = "GET_PROJECTS_ERROR";

export const GET_COMPLETED_PROJECTS_LOADING = "GET_COMPLETED_PROJECTS_LOADING";
export const GET_COMPLETED_PROJECTS_SUCCESS = "GET_COMPLETED_PROJECTS_SUCCESS";
export const GET_COMPLETED_PROJECTS_ERROR = "GET_COMPLETED_PROJECTS_ERROR";

export const GET_BASELINE_BUDGET_LOADING = "GET_BASELINE_BUDGET_LOADING";
export const GET_BASELINE_BUDGET_SUCCESS = "GET_BASELINE_BUDGET_SUCCESS";
export const GET_BASELINE_BUDGET_ERROR = "GET_BASELINE_BUDGET_ERROR";

export const RESET_PROJECT_STATE = "RESET_PROJECT_STATE";

// ACTION CREATORS

export const resetProject = () => ({ type: RESET_PROJECT_STATE });

export const setPortfolioOptions = (portfolioOptions) => ({
  type: SET_PORTFOLIO_OPTIONS,
  portfolioOptions,
});

export const setPCodeOptions = (pCodeOptions) => ({
  type: SET_PCODE_OPTIONS,
  pCodeOptions,
});
export const setUsedPCodes = (pCodes) => ({
  type: GET_USED_PCODES,
  pCodes,
});

export const getProjectDefaultsLoading = () => ({
  type: GET_PROJECT_DEFAULTS_LOADING,
});
export const getProjectDefaultsSuccess = (projectDefaults) => ({
  type: GET_PROJECT_DEFAULTS_SUCCESS,
  projectDefaults,
});
export const getProjectDefaultsError = (error) => ({
  type: GET_PROJECT_DEFAULTS_ERROR,
  error,
});

export const saveProjectLoading = () => ({
  type: SAVE_PROJECT_LOADING,
});
export const saveProjectSuccess = (saveProject) => ({
  type: SAVE_PROJECT_SUCCESS,
  saveProject,
});
export const saveProjectError = (error) => ({
  type: SAVE_PROJECT_ERROR,
  error,
});

export const editProjectLoading = () => ({
  type: EDIT_PROJECT_LOADING,
});
export const editProjectSuccess = (editProject) => ({
  type: EDIT_PROJECT_SUCCESS,
  editProject,
});
export const editProjectError = (error) => ({
  type: EDIT_PROJECT_ERROR,
  error,
});

export const saveProjectCommentLoading = () => ({
  type: SAVE_PROJECT_COMMENT_LOADING,
});
export const saveProjectCommentSuccess = (saveProjectComment) => ({
  type: SAVE_PROJECT_COMMENT_SUCCESS,
  saveProjectComment,
});
export const saveProjectCommentError = (error) => ({
  type: SAVE_PROJECT_COMMENT_ERROR,
  error,
});

export const deleteProjectLoading = () => ({
  type: DELETE_PROJECT_LOADING,
});
export const deleteProjectSuccess = (deleteProject) => ({
  type: DELETE_PROJECT_SUCCESS,
  deleteProject,
});
export const deleteProjectError = (error) => ({
  type: DELETE_PROJECT_ERROR,
  error,
});

export const completeProjectLoading = () => ({
  type: COMPLETE_PROJECT_LOADING,
});
export const completeProjectSuccess = (completeProject) => ({
  type: COMPLETE_PROJECT_SUCCESS,
  completeProject,
});
export const completeProjectError = (error) => ({
  type: COMPLETE_PROJECT_ERROR,
  error,
});

export const getProjectsLoading = () => ({
  type: GET_PROJECTS_LOADING,
});
export const getProjectsSuccess = (projects) => ({
  type: GET_PROJECTS_SUCCESS,
  projects,
});
export const getProjectsError = (error) => ({
  type: GET_PROJECTS_ERROR,
  error,
});

export const getCompletedProjectsLoading = () => ({
  type: GET_COMPLETED_PROJECTS_LOADING,
});
export const getCompletedProjectsSuccess = (completedProjects) => ({
  type: GET_COMPLETED_PROJECTS_SUCCESS,
  completedProjects,
});
export const getCompletedProjectsError = (error) => ({
  type: GET_COMPLETED_PROJECTS_ERROR,
  error,
});

export const getBaseLineBudgetLoading = () => ({
  type: GET_BASELINE_BUDGET_LOADING,
});
export const getBaseLineBudgetSuccess = (baseLineBudget) => ({
  type: GET_BASELINE_BUDGET_SUCCESS,
  baseLineBudget,
});
export const getBaseLineBudgetError = (error) => ({
  type: GET_BASELINE_BUDGET_ERROR,
  error,
});

// THUNK CREATORS

export const saveProjectThunk = (payload, productCode, callback) => async (dispatch) => {
  try {
    dispatch(saveProjectLoading());
    const { data } = await roverPcdmURL.post(saveProjectURL(productCode), payload);
    if (callback) {
      callback(SAVE_PROJECT_SUCCESS, data);
    }
    dispatch(saveProjectSuccess(data));
  } catch (error) {
    if (callback) {
      callback(SAVE_PROJECT_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(saveProjectError(error));
    console.error(error);
  }
};
export const editProjectThunk = (payload, productCode, ProjectId, callback) => async (dispatch) => {
  try {
    dispatch(editProjectLoading());
    const { data } = await roverPcdmURL.put(updateProjectURL(productCode, ProjectId), payload);
    if (callback) {
      callback(EDIT_PROJECT_SUCCESS, data);
    }
    dispatch(editProjectSuccess(data));
  } catch (error) {
    if (callback) {
      callback(EDIT_PROJECT_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(editProjectError(error));
    console.error(error);
  }
};

export const saveProjectCommentThunk = (payload, productCode, projectId, callback) => async (
  dispatch
) => {
  try {
    dispatch(saveProjectCommentLoading());
    const { data } = await roverPcdmURL.post(
      saveProjectCommentURL(productCode, projectId),
      payload
    );
    if (callback) {
      callback(SAVE_PROJECT_COMMENT_SUCCESS, data);
    }
    dispatch(saveProjectCommentSuccess(data));
  } catch (error) {
    if (callback) {
      callback(SAVE_PROJECT_COMMENT_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(saveProjectCommentError(error));
    console.error(error);
  }
};

export const completeProjectThunk = (payload, productCode, ProjectId, callback) => async (
  dispatch
) => {
  try {
    dispatch(completeProjectLoading());
    const { data } = await roverPcdmURL.put(updateProjectURL(productCode, ProjectId), payload);
    if (callback) {
      callback(COMPLETE_PROJECT_SUCCESS, data);
    }
    dispatch(completeProjectSuccess());
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(COMPLETE_PROJECT_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(completeProjectError());
  }
};
export const deleteProjectThunk = (payload, productCode, ProjectId, callback) => async (
  dispatch
) => {
  try {
    dispatch(deleteProjectLoading());
    const { data } = await roverPcdmURL.put(updateProjectURL(productCode, ProjectId), payload);
    if (callback) {
      callback(DELETE_PROJECT_SUCCESS, data);
    }
    dispatch(deleteProjectSuccess(data));
  } catch (error) {
    if (callback) {
      callback(DELETE_PROJECT_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(deleteProjectError(error));
    console.error(error);
  }
};
export const getProjectsThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getProjectsLoading());
    const { data } = await roverPcdmURL.get(getProjectURL(productCode));
    dispatch(getProjectsSuccess(data));
  } catch (error) {
    dispatch(getProjectsError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    console.error(error);
  }
};
export const getCompletedProjectsThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getCompletedProjectsLoading());
    const { data } = await roverPcdmURL.get(getCompletedProjectsURL(productCode));
    dispatch(getCompletedProjectsSuccess(data));
  } catch (error) {
    dispatch(getCompletedProjectsError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    console.error(error);
  }
};
export const getPortfoliosThunk = () => async (dispatch) => {
  try {
    const { data } = await roverPcdmURL.get(getPortfoliosURL());
    dispatch(setPortfolioOptions(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getPCodesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverPcdmURL.get(getPCodesURL());
   // let sorted = moveArrayEl(data, data.length - 1, 0);
    dispatch(setPCodeOptions(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getUsedPCodesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverPcdmURL.get(getUsedPCodesURL());
    dispatch(setUsedPCodes(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getProjectDefaultsThunk = (pCode, callback) => async (dispatch) => {
  try {
    dispatch(getProjectDefaultsLoading());
    const { data } = await roverPcdmURL.get(getProjectDefaultsURL(pCode));
    // console.log(data);
    callback(data);
    dispatch(getProjectDefaultsSuccess(data));
  } catch (error) {
    dispatch(getProjectDefaultsError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    console.error(error);
  }
};
export const getBaselineBudgetThunk = (pCode, start, end, storyPoints, callback) => async (
  dispatch
) => {
  try {
    dispatch(getBaseLineBudgetLoading());
    const { data } = await roverPcdmURL.get(getBaseLineBudgetURL(pCode, start, end, storyPoints));
    if (callback) {
      callback(GET_BASELINE_BUDGET_SUCCESS, data);
    }
    dispatch(getBaseLineBudgetSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_BASELINE_BUDGET_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(getBaseLineBudgetError(error));
  }
};

// INITIAL STATE
const initialState = {
  projectDefaults: {
    projectName: "",
    projectType: "",
    investmentPortfolio: "",
    deliveryPortfolio: "",
    financialStatus: "",
    icode: "",
    pcode: "",
    listOfComments: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  usedPCodes: [],
  pCodeOptions: [],
  estimateTypeOptions: [
    { id: 1, desc: "Intake" },
    { id: 2, desc: "Execution" },
  ],
  projectTypeOptions: [
    { id: 1, desc: "Project Funded" },
    { id: 3, desc: "Product Core" },
  ],
  estimationTimingOptions: [
    { id: 1, desc: "During Intake (ROM)" },
    { id: 2, desc: "During PPP" },
  ],
  fundingOptions: [
    { id: 1, desc: "Funded" },
    { id: 2, desc: "Unfunded" },
  ],
  investmentPortfolioOptions: [
    { id: 1, desc: "TD&S" },
    { id: 2, desc: "Retail" },
    { id: 3, desc: "Provider" },
  ],
  deliveryPortfolioOptions: [
    { id: 1, desc: "ADC" },
    { id: 2, desc: "Mandates" },
    { id: 3, desc: "Provider" },
  ],
  saveProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  saveProjectCommentStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
  editProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  completeProjectStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  projects: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: {},
  },
  completedProjectsList: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: {},
  },
  baseLineBudget: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: {},
  },
};

// REDUCERS
const ProjectsReducer = (state = initialState, action) => {
  switch (action.type) {
    case RESET_PROJECT_STATE:
      return {
        ...state,
        ...initialState,
      };
    case SET_PORTFOLIO_OPTIONS:
      return {
        ...state,
        investmentPortfolioOptions: [...action.portfolioOptions],
        deliveryPortfolioOptions: [...action.portfolioOptions],
      };
    case SET_PCODE_OPTIONS:
      return { ...state, pCodeOptions: [...action.pCodeOptions] };
    case GET_USED_PCODES:
      return { ...state, usedPCodes: [...action.pCodes] };
    case GET_PROJECT_DEFAULTS_LOADING:
      return {
        ...state,
        projectDefaults: {
          ...state.projectDefaults,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_PROJECT_DEFAULTS_SUCCESS:
      return {
        ...state,
        projectDefaults: {
          ...action.projectDefaults,
          response: {},
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_PROJECT_DEFAULTS_ERROR:
      return {
        ...state,
        projectDefaults: {
          ...state.projectDefaults,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case SAVE_PROJECT_LOADING:
      return {
        ...state,
        saveProjectStatus: {
          ...state.saveProjectStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_PROJECT_SUCCESS:
      return {
        ...state,
        saveProjectStatus: {
          ...state.saveProjectStatus,
          response: action.saveProject,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_PROJECT_ERROR:
      return {
        ...state,
        saveProjectStatus: {
          ...state.saveProjectStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_PROJECT_LOADING:
      return {
        ...state,
        editProjectStatus: {
          ...state.editProjectStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_PROJECT_SUCCESS:
      return {
        ...state,
        editProjectStatus: {
          ...state.editProjectStatus,
          response: action.editProject,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_PROJECT_ERROR:
      return {
        ...state,
        editProjectStatus: {
          ...state.editProjectStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_PROJECT_LOADING:
      return {
        ...state,
        deleteProjectStatus: {
          ...state.deleteProjectStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_PROJECT_SUCCESS:
      return {
        ...state,
        deleteProjectStatus: {
          ...state.deleteProjectStatus,
          response: action.deleteProject,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_PROJECT_ERROR:
      return {
        ...state,
        deleteProjectStatus: {
          ...state.deleteProjectStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case COMPLETE_PROJECT_LOADING:
      return {
        ...state,
        completeProjectStatus: {
          ...state.completeProjectStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case COMPLETE_PROJECT_SUCCESS:
      return {
        ...state,
        completeProjectStatus: {
          ...state.completeProjectStatus,
          response: action.completeProject,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case COMPLETE_PROJECT_ERROR:
      return {
        ...state,
        completeProjectStatus: {
          ...state.completeProjectStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case SAVE_PROJECT_COMMENT_LOADING:
      return {
        ...state,
        saveProjectCommentStatus: {
          ...state.saveProjectCommentStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_PROJECT_COMMENT_SUCCESS:
      return {
        ...state,
        saveProjectCommentStatus: {
          ...state.saveProjectCommentStatus,
          response: action.saveProjectComment,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_PROJECT_COMMENT_ERROR:
      return {
        ...state,
        saveProjectCommentStatus: {
          ...state.saveProjectCommentStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_PROJECTS_LOADING:
      return {
        ...state,
        projects: { ...state.projects, status: DATA_STATUS.LOADING },
      };
    case GET_PROJECTS_SUCCESS:
      return {
        ...state,
        projects: {
          ...state.projects,
          data: action.projects,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_PROJECTS_ERROR:
      return {
        ...state,
        projects: {
          ...state.projects,
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
      case GET_COMPLETED_PROJECTS_LOADING:
        return {
          ...state,
          completedProjectsList: { ...state.completedProjectsList, status: DATA_STATUS.LOADING },
        };
      case GET_COMPLETED_PROJECTS_SUCCESS:
        return {
          ...state,
          completedProjectsList: {
            ...state.completedProjectsList,
            data: action.completedProjects,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_COMPLETED_PROJECTS_ERROR:
        return {
          ...state,
          completedProjectsList: {
            ...state.completedProjectsList,
            data: [],
            response: action.error,
            status: DATA_STATUS.ERROR,
          },
        };
    case GET_BASELINE_BUDGET_LOADING:
      return {
        ...state,
        baseLineBudget: { ...state.baseLineBudget, status: DATA_STATUS.LOADING },
      };
    case GET_BASELINE_BUDGET_SUCCESS:
      return {
        ...state,
        baseLineBudget: {
          ...state.baseLineBudget,
          data: action.baseLineBudget,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_BASELINE_BUDGET_ERROR:
      return {
        ...state,
        baseLineBudget: {
          data: {},
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default ProjectsReducer;
