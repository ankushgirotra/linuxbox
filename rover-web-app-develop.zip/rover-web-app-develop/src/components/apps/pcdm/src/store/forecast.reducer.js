import roverPcdmURL from "../../../../../apis/pcdm_api";
import {
  getForecastURL,
  getForecastAggregateURL,
  getForecastDollarURL,
  updateForecastChangesURL,
  getForecastsCapacityURL,
  getCompletedForecastIndivudualURL,
} from "./endpoints";
import { DATA_STATUS } from "../constants/service.constant";
import { addNotification, displayCommonError } from "./common.reducer";
import { ACTIONS } from "../constants/action.constants";
import { checkErrorType } from "../templates/forecast.template";

// ACTION TYPES
export const GET_FORECAST = "GET_FORECAST";
export const GET_FORECAST_LOADING = "GET_FORECAST_LOADING";
export const GET_FORECAST_ERROR = "GET_FORECAST_ERROR";

export const GET_FORECAST_COMPLETED = "GET_FORECAST_COMPLETED";
export const GET_FORECAST_LOADING_COMPLETED = "GET_FORECAST_LOADING_COMPLETED";
export const GET_FORECAST_ERROR_COMPLETED = "GET_FORECAST_ERROR_COMPLETED";

export const GET_FORECAST_AGGREGATE_COMPLETED = "GET_FORECAST_AGGREGATE_COMPLETED";
export const GET_FORECAST_LOADING_AGGREGATE_COMPLETED = "GET_FORECAST_LOADING_AGGREGATE_COMPLETED";
export const GET_FORECAST_ERROR_AGGREGATE_COMPLETED = "GET_FORECAST_ERROR_AGGREGATE_COMPLETED";

export const GET_FORECAST_AGGREGATE = "GET_FORECAST_AGGREGATE";
export const GET_FORECAST_LOADING_AGGREGATE = "GET_FORECAST_LOADING_AGGREGATE";
export const GET_FORECAST_ERROR_AGGREGATE = "GET_FORECAST_ERROR_AGGREGATE";

export const GET_FORECAST_CAPACITY = "GET_FORECAST_CAPACITY";
export const GET_FORECAST_CAPACITY_LOADING = "GET_FORECAST_CAPACITY_LOADING";
export const GET_FORECAST_CAPACITY_ERROR = "GET_FORECAST_CAPACITY_ERROR";

export const GET_FORECAST_DOLLAR_SUCCESS = "GET_FORECAST_DOLLAR_SUCCESS";
export const GET_FORECAST_DOLLAR_LOADING = "GET_FORECAST_DOLLAR_LOADING";
export const GET_FORECAST_DOLLAR_ERROR = "GET_FORECAST_DOLLAR_ERROR";

export const UPDATE_FORECAST_CHANGES_SUCCESS = "UPDATE_FORECAST_CHANGES_SUCCESS";
export const UPDATE_FORECAST_CHANGES_LOADING = "UPDATE_FORECAST_CHANGES_LOADING";
export const UPDATE_FORECAST_CHANGES_ERROR = "UPDATE_FORECAST_CHANGES_ERROR";

export const LOG_FORECAST_CHANGE = "LOG_FORECAST_CHANGE";
export const CLEAR_FORECAST_CHANGE = "CLEAR_FORECAST_CHANGE";

export const RESET_FORECAST_STATE = "RESET_FORECAST_STATE";

// ACTION CREATORS
export const logForecastChange = (change) => ({
  type: LOG_FORECAST_CHANGE,
  change,
});
export const clearForecastChange = () => ({ type: CLEAR_FORECAST_CHANGE });
export const resetForecast = () => ({ type: RESET_FORECAST_STATE });
export const getForecasts = (forecasts) => ({
  type: GET_FORECAST,
  forecasts,
});
export const getForecastsLoading = () => ({
  type: GET_FORECAST_LOADING,
});
export const getForecastsError = (error) => ({
  type: GET_FORECAST_ERROR,
  error,
});

export const getForecastsAggregate = (forecastAggregate) => ({
  type: GET_FORECAST_AGGREGATE,
  forecastAggregate,
});
export const getForecastsLoadingAggregate = () => ({
  type: GET_FORECAST_LOADING_AGGREGATE,
});
export const getForecastsErrorAggregate = (error) => ({
  type: GET_FORECAST_ERROR_AGGREGATE,
  error,
});

export const getForecastsCompleted = (forecasts) => ({
  type: GET_FORECAST_COMPLETED,
  forecasts,
});
export const getForecastsLoadingCompleted = () => ({
  type: GET_FORECAST_LOADING_COMPLETED,
});
export const getForecastsErrorCompleted = (error) => ({
  type: GET_FORECAST_ERROR_COMPLETED,
  error,
});

export const getForecastsAggregateCompleted = (forecastAggregate) => ({
  type: GET_FORECAST_AGGREGATE_COMPLETED,
  forecastAggregate,
});
export const getForecastsLoadingAggregateCompleted = () => ({
  type: GET_FORECAST_LOADING_AGGREGATE_COMPLETED,
});
export const getForecastsErrorAggregateCompleted = (error) => ({
  type: GET_FORECAST_ERROR_AGGREGATE_COMPLETED,
  error,
});

export const getForecastsCapacity = (forecastsCapacity) => ({
  type: GET_FORECAST_CAPACITY,
  forecastsCapacity,
});
export const getForecastsCapacityLoading = () => ({
  type: GET_FORECAST_CAPACITY_LOADING,
});
export const getForecastsCapacityError = (error) => ({
  type: GET_FORECAST_CAPACITY_ERROR,
  error,
});

export const getForecastDollarLoading = () => ({
  type: GET_FORECAST_DOLLAR_LOADING,
});
export const getForecastDollarSuccess = (forecastDollar) => ({
  type: GET_FORECAST_DOLLAR_SUCCESS,
  forecastDollar,
});
export const getForecastDollarError = (error) => ({
  type: GET_FORECAST_DOLLAR_ERROR,
  error,
});

export const updateForecastChangesLoading = () => ({
  type: UPDATE_FORECAST_CHANGES_LOADING,
});
export const updateForecastChangesSuccess = (response) => ({
  type: UPDATE_FORECAST_CHANGES_SUCCESS,
  response,
});
export const updateForecastChangesError = (error) => ({
  type: UPDATE_FORECAST_CHANGES_ERROR,
  error,
});

// THUNK CREATORS
export const getForecastsThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getForecastsLoading());
    const { data } = await roverPcdmURL.get(getForecastURL(productCode));
    dispatch(getForecasts(data));
  } catch (error) {
    dispatch(getForecastsError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getForecastsAggregateThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getForecastsLoadingAggregate());
    const { data } = await roverPcdmURL.get(getForecastAggregateURL(productCode,false));
    dispatch(getForecastsAggregate(data));
  } catch (error) {
    console.error(error);
    dispatch(getForecastsErrorAggregate(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getCompletedForecastsThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getForecastsLoadingCompleted());
    const { data } = await roverPcdmURL.get(getCompletedForecastIndivudualURL(productCode));
    dispatch(getForecastsCompleted(data));
  } catch (error) {
    console.error(error);
    dispatch(getForecastsErrorCompleted(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getCompletedForecastsAggregateThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getForecastsLoadingAggregateCompleted());
    const { data } = await roverPcdmURL.get(getForecastAggregateURL(productCode,true));
    dispatch(getForecastsAggregateCompleted(data));
  } catch (error) {
    console.error(error);
    dispatch(getForecastsErrorAggregateCompleted(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getForecastsCapacityThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getForecastsCapacityLoading());
    const { data } = await roverPcdmURL.get(getForecastsCapacityURL(productCode));
    dispatch(getForecastsCapacity(data));
  } catch (error) {
    console.error(error);
    dispatch(getForecastsCapacityError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const updateForecastChangesThunk = (productCode, payload, callback) => async (dispatch) => {
  try {
    dispatch(updateForecastChangesLoading());
    const { data } = await roverPcdmURL.post(updateForecastChangesURL(productCode), payload);
    if (callback) {
      callback(UPDATE_FORECAST_CHANGES_SUCCESS, data);
    }
    dispatch(
      addNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Actuals and forecast table updated",
      })
    );
    dispatch(updateForecastChangesSuccess(data));
  } catch (error) {
    if (callback) {
      callback(UPDATE_FORECAST_CHANGES_ERROR, error);
    }
    dispatch(updateForecastChangesError(error));
    dispatch(
      addNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: "Error in saving Actuals and forecast",
      })
    );
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getForecastDollarThunk = (
  productCode,
  projectEstimateId,
  forecastPoints,
  month,
  callback
) => async (dispatch) => {
  try {
    dispatch(getForecastDollarLoading());
    const { data } = await roverPcdmURL.get(
      getForecastDollarURL(productCode, projectEstimateId, forecastPoints, month)
    );
    if (callback) {
      callback(GET_FORECAST_DOLLAR_SUCCESS, data);
    }
    dispatch(getForecastDollarSuccess(data));
  } catch (error) {
    if (callback) {
      callback(GET_FORECAST_DOLLAR_ERROR, error);
    }
    dispatch(getForecastDollarError(error));
    addNotification({
      title: "Error",
      variant: ACTIONS.ERROR,
      content: "Error in calculating Actuals and forecast",
    });
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

// INITIAL STATE
const initialState = {
  forecasts: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  forecastDollar: { response: [], status: DATA_STATUS.INITIAL, response: {} },
  forecastTableHistory: [],
  updateForecastChangesStatus: { status: DATA_STATUS.INITIAL, response: {} },
  forecastsCapacity: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  forecastAggregate: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  completedForecasts: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  completedForecastAggregate: { data: [], status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
const ForecastsReducer = (state = initialState, action) => {
  switch (action.type) {
    case RESET_FORECAST_STATE:
      return {
        ...state,
        ...initialState,
      };
    case LOG_FORECAST_CHANGE:
      let tempLog = [];
      tempLog = state.forecastTableHistory.slice();
      let index = tempLog.findIndex(
        (el) =>
          el.projectEstimateId === action.change.projectEstimateId &&
          el.month === action.change.month
      );
      if (index >= 0) {
        tempLog[index] = { ...action.change };
      } else {
        tempLog.push({ ...action.change });
      }
      return {
        ...state,
        forecastTableHistory: [...tempLog],
      };
    case CLEAR_FORECAST_CHANGE:
      return {
        ...state,
        forecastTableHistory: [],
      };
    case GET_FORECAST:
      return {
        ...state,
        forecasts: {
          data: action.forecasts,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_FORECAST_LOADING:
      return {
        ...state,
        forecasts: {
          ...state.forecasts,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_FORECAST_ERROR:
      return {
        ...state,
        forecasts: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_FORECAST_AGGREGATE:
      return {
        ...state,
        forecastAggregate: {
          data: {matchedProjects: action.forecastAggregate},
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_FORECAST_LOADING_AGGREGATE:
      return {
        ...state,
        forecastAggregate: {
          ...state.forecastAggregate,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_FORECAST_ERROR_AGGREGATE:
      return {
        ...state,
        forecastAggregate: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
      case GET_FORECAST_COMPLETED:
        return {
          ...state,
          completedForecasts: {
            data: action.forecasts,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_FORECAST_LOADING_COMPLETED:
        return {
          ...state,
          completedForecasts: {
            ...state.completedForecasts,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_FORECAST_ERROR_COMPLETED:
        return {
          ...state,
          completedForecasts: { data: [], status: DATA_STATUS.ERROR, response: action.error },
        };
      case GET_FORECAST_AGGREGATE_COMPLETED:
        return {
          ...state,
          completedForecastAggregate: {
            data: {matchedProjects: action.forecastAggregate},
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_FORECAST_LOADING_AGGREGATE_COMPLETED:
        return {
          ...state,
          completedForecastAggregate: {
            ...state.completedForecastAggregate,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_FORECAST_ERROR_AGGREGATE_COMPLETED:
        return {
          ...state,
          completedForecastAggregate: { data: [], status: DATA_STATUS.ERROR, response: action.error },
        };
    case GET_FORECAST_CAPACITY:
      return {
        ...state,
        forecastsCapacity: {
          data: action.forecastsCapacity,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_FORECAST_CAPACITY_LOADING:
      return {
        ...state,
        forecastsCapacity: {
          ...state.forecastsCapacity,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_FORECAST_CAPACITY_ERROR:
      return {
        ...state,
        forecastsCapacity: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_FORECAST_DOLLAR_LOADING:
      return {
        ...state,
        forecastDollar: {
          ...state.forecastDollar,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_FORECAST_DOLLAR_SUCCESS:
      return {
        ...state,
        forecastDollar: {
          ...state.forecastDollar,
          response: action.forecastDollar,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_FORECAST_DOLLAR_ERROR:
      return {
        ...state,
        forecastDollar: {
          ...state.forecastDollar,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case UPDATE_FORECAST_CHANGES_LOADING:
      return {
        ...state,
        updateForecastChangesStatus: {
          ...state.updateForecastChangesStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_FORECAST_CHANGES_SUCCESS:
      return {
        ...state,
        updateForecastChangesStatus: {
          ...state.updateForecastChangesStatus,
          response: action.response,
          status: DATA_STATUS.SUCCESS,
        },
        forecastTableHistory: [],
      };
    case UPDATE_FORECAST_CHANGES_ERROR:
      return {
        ...state,
        updateForecastChangesStatus: {
          ...state.updateForecastChangesStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default ForecastsReducer;
