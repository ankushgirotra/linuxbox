import roverPcdmURL from "../../../../../apis/pcdm_api";
import { getFollowURL, getProductFollowURL } from "./endpoints";
import { DATA_STATUS } from "../constants/service.constant";
import { checkErrorType } from "../templates/forecast.template";
import { displayCommonError } from "./common.reducer";
// ACTION TYPES
export const GET_FOLLOW_PRODUCT = "GET_FOLLOW_PRODUCT";
export const GET_FOLLOW_PRODUCT_LOADING = "GET_FOLLOW_PRODUCT_LOADING";
export const GET_FOLLOW_PRODUCT_ERROR = "GET_FOLLOW_PRODUCT_ERROR";
export const SET_FOLLOWING = "SET_FOLLOWING";
export const SET_FOLLOWING_LOADING = "SET_FOLLOWING_LOADING";
export const SET_FOLLOWING_ERROR = "SET_FOLLOWING_ERROR";
export const SET_UNFOLLOW = "SET_UNFOLLOW";
export const SET_UNFOLLOW_LOADING = "SET_UNFOLLOW_LOADING";
export const SET_UNFOLLOW_ERROR = "SET_UNFOLLOW_ERROR";

export const GET_PRODUCT_FOLLOWERS = "GET_PRODUCT_FOLLOWERS";
export const GET_PRODUCT_FOLLOWERS_LOADING = "GET_PRODUCT_FOLLOWERS_LOADING";
export const GET_PRODUCT_FOLLOWERS_ERROR = "GET_PRODUCT_FOLLOWERS_ERROR";

// ACTION CREATORS
export const getFollowProduct = (data) => ({
  type: GET_FOLLOW_PRODUCT,
  data,
});
export const getFollowProductLoading = () => ({
  type: GET_FOLLOW_PRODUCT_LOADING,
});
export const getFollowProductError = (error) => ({
  type: GET_FOLLOW_PRODUCT_ERROR,
  error,
});

export const setFollowing = (data) => ({
  type: SET_FOLLOWING,
  data,
});
export const setFollowingLoading = () => ({
  type: SET_FOLLOWING_LOADING,
});
export const setFollowingError = (error) => ({
  type: SET_FOLLOWING_ERROR,
  error,
});

export const setUnfollow = (data) => ({
  type: SET_UNFOLLOW,
  data,
});
export const setUnfollowLoading = () => ({
  type: SET_UNFOLLOW_LOADING,
});
export const setUnfollowError = (error) => ({
  type: SET_UNFOLLOW_ERROR,
  error,
});

export const getProductFollowers = (data) => ({
  type: GET_PRODUCT_FOLLOWERS,
  data,
});
export const getProductFollowersLoading = () => ({
  type: GET_PRODUCT_FOLLOWERS_LOADING,
});
export const getProductFollowersError = (error) => ({
  type: GET_PRODUCT_FOLLOWERS_ERROR,
  error,
});

// THUNK CREATORS
export const getFollowProductThunk = (productCode, employeeId) => async (
  dispatch
) => {
  try {
    dispatch(getFollowProductLoading());
    const { data } = await roverPcdmURL.get(
      getFollowURL(productCode, employeeId)
    );
    dispatch(getFollowProduct(data));
  } catch (error) {
    console.error(error);
    dispatch(getFollowProductError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const setFollowingThunk = (productCode, employeeId, callback) => async (
  dispatch
) => {
  try {
    dispatch(setFollowingLoading());
    const { data } = await roverPcdmURL.post(
      getFollowURL(productCode, employeeId)
    );
    if (callback) {
      callback(SET_FOLLOWING, data);
    }
    dispatch(setFollowing(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SET_FOLLOWING_ERROR, error);
    }
    dispatch(setFollowingError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const setUnFollowThunk = (productCode, employeeId, callback) => async (
  dispatch
) => {
  try {
    dispatch(setUnfollowLoading());
    const { data } = await roverPcdmURL.put(
      getFollowURL(productCode, employeeId)
    );
    if (callback) {
      callback(SET_UNFOLLOW, data);
    }
    dispatch(setUnfollow(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SET_UNFOLLOW_ERROR, error);
    }
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
    dispatch(setUnfollowError(error));
  }
};

export const getProductFollowersThunk = (productCode) => async (
  dispatch
) => {
  try {
    dispatch(getProductFollowersLoading());
    const { data } = await roverPcdmURL.get(
      getProductFollowURL(productCode)
    );
    dispatch(getProductFollowers(data));
  } catch (error) {
    console.error(error);
    dispatch(getProductFollowersError(error));
  }
};

// INITIAL STATE
const initialState = {
  RMProductStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  RMFollowStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  RMUnFollowStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  ProductFollowersList: {data:[], status: DATA_STATUS.INITIAL, response: {} }, 
};

// REDUCERS
const RMFollowReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_FOLLOW_PRODUCT:
      return {
        ...state,
        RMProductStatus: {
          ...state.RMProductStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_FOLLOW_PRODUCT_LOADING:
      return {
        ...state,
        RMProductStatus: {
          ...state.RMProductStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_FOLLOW_PRODUCT_ERROR:
      return {
        ...state,
        RMProductStatus: {
          ...initialState.RMProductStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case SET_FOLLOWING:
      return {
        ...state,
        RMFollowStatus: {
          ...state.RMFollowStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SET_FOLLOWING_LOADING:
      return {
        ...state,
        RMFollowStatus: {
          ...state.RMFollowStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SET_FOLLOWING_ERROR:
      return {
        ...state,
        RMFollowStatus: {
          ...initialState.RMFollowStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case SET_UNFOLLOW:
      return {
        ...state,
        RMUnFollowStatus: {
          ...state.RMUnFollowStatus,
          data: action.data,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SET_UNFOLLOW_LOADING:
      return {
        ...state,
        RMUnFollowStatus: {
          ...state.RMUnFollowStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SET_UNFOLLOW_ERROR:
      return {
        ...state,
        RMUnFollowStatus: {
          ...initialState.RMUnFollowStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
      case GET_PRODUCT_FOLLOWERS:
        return {
          ...state,
          ProductFollowersList: {
            ...state.ProductFollowersList,
            data: action.data,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_PRODUCT_FOLLOWERS_LOADING:
        return {
          ...state,
          ProductFollowersList: {
            ...state.ProductFollowersList,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_PRODUCT_FOLLOWERS_ERROR:
        return {
          ...state,
          ProductFollowersList: {
            ...initialState.ProductFollowersList,
            status: DATA_STATUS.ERROR,
            response: action.error,
          },
        };  
    default:
      return state;
  }
};

export default RMFollowReducer;
