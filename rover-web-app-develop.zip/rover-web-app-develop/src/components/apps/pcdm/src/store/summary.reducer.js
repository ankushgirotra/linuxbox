import roverPcdmURL from "../../../../../apis/pcdm_api";
import { DATA_STATUS } from "../constants/service.constant";
import { getSummaryURL, getResourceForecastURL, publishReportURL, getPublishAnswersURL } from "./endpoints";
import CHART_DATA from "../../utilities/test.json";
import { addNotification } from "./common.reducer";
import { ACTIONS } from "../constants/action.constants";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";
// ACTION TYPES
export const GET_SUMMARY_CHART_LOADING = "GET_SUMMARY_CHART_LOADING";
export const GET_SUMMARY_CHART = "GET_SUMMARY_CHART";
export const GET_SUMMARY_CHART_ERROR = "GET_SUMMARY_CHART_ERROR";

export const GET_RESOURCE_FORECAST_LOADING = "GET_RESOURCE_FORECAST_LOADING";
export const GET_RESOURCE_FORECAST = "GET_RESOURCE_FORECAST";
export const GET_RESOURCE_FORECAST_ERROR = "GET_RESOURCE_FORECAST_ERROR";

export const PUBLISH_REPORT_LOADING = "PUBLISH_REPORT_LOADING";
export const PUBLISH_REPORT_SUCCESS = "PUBLISH_REPORT_SUCCESS";
export const PUBLISH_REPORT_ERROR = "PUBLISH_REPORT_ERROR";

export const RESET_SUMMARY_STATE = "RESET_SUMMARY_STATE";

export const GET_PUBLISH_ANSWERS_LOADING = "GET_PUBLISH_ANSWERS_LOADING";
export const GET_PUBLISH_ANSWERS = "GET_PUBLISH_ANSWERS";
export const GET_PUBLISH_ANSWERS_ERROR = "GET_PUBLISH_ANSWERS_ERROR";

// ACTION CREATORS
export const resetSummary = () => ({ type: RESET_SUMMARY_STATE });

export const getSummaryChartLoading = () => ({
  type: GET_SUMMARY_CHART_LOADING,
});
export const getSummaryChart = (summaryData) => ({
  type: GET_SUMMARY_CHART,
  summaryData,
});
export const getSummaryChartError = (error) => ({
  type: GET_SUMMARY_CHART_ERROR,
  error,
});

export const getResourceForecastLoading = () => ({
  type: GET_RESOURCE_FORECAST_LOADING,
});
export const getResourceForecast = (resourceForecast) => ({
  type: GET_RESOURCE_FORECAST,
  resourceForecast,
});
export const getResourceForecastError = (error) => ({
  type: GET_RESOURCE_FORECAST_ERROR,
  error,
});

export const publishReportLoading = () => ({
  type: PUBLISH_REPORT_LOADING,
});
export const publishReportSuccess = (response) => ({
  type: PUBLISH_REPORT_SUCCESS,
  response,
});
export const publishReportError = (error) => ({
  type: PUBLISH_REPORT_ERROR,
  error,
});

export const getPublishAnswersLoading = () => ({
  type: GET_PUBLISH_ANSWERS_LOADING,
});
export const getPublishAnswers = (publishAnswers) => ({
  type: GET_PUBLISH_ANSWERS,
  publishAnswers,
});
export const getPublishAnswersError = (error) => ({
  type: GET_PUBLISH_ANSWERS_ERROR,
  error,
});

// THUNK CREATORS
export const getSummaryChartThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getSummaryChartLoading());
    const { data } = await roverPcdmURL.get(getSummaryURL(productCode));
    dispatch(getSummaryChart(data));
  } catch (error) {
    dispatch(getSummaryChartError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getResourceForecastThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getResourceForecastLoading());
    const { data } = await roverPcdmURL.get(getResourceForecastURL(productCode));
    dispatch(getResourceForecast(data));
  } catch (error) {
    dispatch(getResourceForecastError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const publishReportThunk = (productCode, payload, callback) => async (dispatch) => {
  try {
    dispatch(publishReportLoading());
    const { data } = await roverPcdmURL.post(publishReportURL(productCode), payload);
    if (callback) {
      callback(PUBLISH_REPORT_SUCCESS, data);
    }
    dispatch(publishReportSuccess(data));
    dispatch(
      addNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Report published successfully",
      })
    );
  } catch (error) {
    if (callback) {
      callback(PUBLISH_REPORT_ERROR, error);
    }
    dispatch(publishReportError(error));
    dispatch(
      addNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: "Error in publishing report",
      })
    );
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getPublishAnswersThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getPublishAnswersLoading());
    const { data } = await roverPcdmURL.get(getPublishAnswersURL(productCode));
    dispatch(getPublishAnswers(data));
  } catch (error) {
    dispatch(getPublishAnswersError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
// INITIAL STATE
const initialState = {
  summaryData: {
    data: { capacityConstraint: 0, demand: 0, capacity: 0, summaryReport: [] },
    mock: [...CHART_DATA.data],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  resourceForecast: {
    data: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  publish: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  publishAnswers : {
    data: [],
    status: DATA_STATUS.INITIAL,
    response: {},
  }
};

// REDUCERS
const SummaryReducer = (state = initialState, action) => {
  switch (action.type) {
    case RESET_SUMMARY_STATE:
      return {
        ...state,
        ...initialState,
      };
    case GET_SUMMARY_CHART_LOADING:
      return {
        ...state,
        summaryData: { ...state.summaryData, status: DATA_STATUS.LOADING },
      };
    case GET_SUMMARY_CHART:
      return {
        ...state,
        summaryData: {
          ...state.summaryData,
          status: DATA_STATUS.SUCCESS,
          data: action.summaryData,
        },
      };
    case GET_SUMMARY_CHART_ERROR:
      return {
        ...state,
        summaryData: {
          ...state.summaryData,
          data: { capacityConstraint: 0, demand: 0, capacity: 0, summaryReport: [] },
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_RESOURCE_FORECAST_LOADING:
      return {
        ...state,
        resourceForecast: {
          ...state.resourceForecast,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_RESOURCE_FORECAST:
      return {
        ...state,
        resourceForecast: {
          ...state.resourceForecast,
          status: DATA_STATUS.SUCCESS,
          data: action.resourceForecast,
        },
      };
    case GET_RESOURCE_FORECAST_ERROR:
      return {
        ...state,
        resourceForecast: {
          ...state.resourceForecast,
          data: [],
          status: DATA_STATUS.ERROR,
        },
      };
    case PUBLISH_REPORT_LOADING:
      return {
        ...state,
        publish: { ...state.publish, status: DATA_STATUS.LOADING },
      };
    case PUBLISH_REPORT_SUCCESS:
      return {
        ...state,
        publish: {
          ...state.publish,
          response: action.response,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case PUBLISH_REPORT_ERROR:
      return {
        ...state,
        publish: { ...state.publish, status: DATA_STATUS.ERROR },
      };
    case GET_PUBLISH_ANSWERS_LOADING:
      return {
        ...state,
        publishAnswers: { ...state.publishAnswers, status: DATA_STATUS.LOADING },
      };
    case GET_PUBLISH_ANSWERS:
      return {
        ...state,
        publishAnswers: {
          ...state.publishAnswers,
          status: DATA_STATUS.SUCCESS,
          data: action.publishAnswers,
        },
      };
    case GET_SUMMARY_CHART_ERROR:
      return {
        ...state,
        publishAnswers: { ...state.publishAnswers, status: DATA_STATUS.ERROR },
      };
    default:
      return state;
  }
};

export default SummaryReducer;
