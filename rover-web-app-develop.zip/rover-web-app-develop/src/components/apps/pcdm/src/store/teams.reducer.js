import roverPcdmURL from "../../../../../apis/pcdm_api";
import { DATA_STATUS } from "../constants/service.constant";
import {
  getProductCalcURL,
  GET_METHODOLOGY_URL,
  getTeamURL,
  saveTeamURL,
  copyTeamURL,
  updateTeamURL,
  getRolledOffTeamURL,
} from "./endpoints";
import { displayCommonError } from "./common.reducer";
import { checkErrorType } from "../templates/forecast.template";
// ACTION TYPES
export const SET_METHODOLOGY_OPTIONS = "SET_METHODOLOGY_OPTIONS";
export const SAVE_TEAM_RESET = "SAVE_TEAM_RESET";
export const SAVE_TEAM_LOADING = "SAVE_TEAM_LOADING";
export const SAVE_TEAM_SUCCESS = "SAVE_TEAM_SUCCESS";
export const SAVE_TEAM_ERROR = "SAVE_TEAM_ERROR";
export const COPY_TEAM_LOADING = "COPY_TEAM_LOADING";
export const COPY_TEAM_SUCCESS = "COPY_TEAM_SUCCESS";
export const COPY_TEAM_ERROR = "COPY_TEAM_ERROR";
export const EDIT_TEAM_RESET = "EDIT_TEAM_RESET";
export const EDIT_TEAM_LOADING = "EDIT_TEAM_LOADING";
export const EDIT_TEAM_SUCCESS = "EDIT_TEAM_SUCCESS";
export const EDIT_TEAM_ERROR = "EDIT_TEAM_ERROR";
export const DELETE_TEAM_RESET = "DELETE_TEAM_RESET";
export const DELETE_TEAM_LOADING = "DELETE_TEAM_LOADING";
export const DELETE_TEAM_SUCCESS = "DELETE_TEAM_SUCCESS";
export const DELETE_TEAM_ERROR = "DELETE_TEAM_ERROR";

export const GET_TEAMS_LOADING = "GET_TEAMS_LOADING";
export const GET_TEAMS_SUCCESS = "GET_TEAMS_SUCCESS";
export const GET_TEAMS_ERROR = "GET_TEAMS_ERROR";
export const GET_ROLLEDOFFTEAMS_LOADING = "GET_ROLLEDOFFTEAMS_LOADING";
export const GET_ROLLEDOFFTEAMS_SUCCESS = "GET_ROLLEDOFFTEAMS_SUCCESS";
export const GET_ROLLEDOFFTEAMS_ERROR = "GET_ROLLEDOFFTEAMS_ERROR";

export const GET_PRODUCT_CALC_LOADING = "GET_PRODUCT_CALC_LOADING";
export const GET_PRODUCT_CALC_SUCCESS = "GET_PRODUCT_CALC_SUCCESS";
export const GET_PRODUCT_CALC_ERROR = "GET_PRODUCT_CALC_ERROR";

export const RESET_TEAM_STATE = "RESET_TEAM_STATE";

// ACTION CREATORS

export const setMethodologyOptions = (methodologies) => ({
  type: SET_METHODOLOGY_OPTIONS,
  methodologies,
});

export const resetTeam = () => ({ type: RESET_TEAM_STATE });

export const saveTeamReset = () => ({
  type: SAVE_TEAM_RESET,
});
export const saveTeamLoading = () => ({
  type: SAVE_TEAM_LOADING,
});
export const saveTeamSuccess = (saveTeam) => ({
  type: SAVE_TEAM_SUCCESS,
  saveTeam,
});
export const saveTeamError = (error) => ({
  type: SAVE_TEAM_ERROR,
  error,
});

export const copyTeamLoading = () => ({
  type: COPY_TEAM_LOADING,
});
export const copyTeamSuccess = (copyTeam) => ({
  type: COPY_TEAM_SUCCESS,
  copyTeam,
});
export const copyTeamError = (error) => ({
  type: COPY_TEAM_ERROR,
  error,
});

export const editTeamReset = () => ({
  type: EDIT_TEAM_RESET,
});
export const editTeamLoading = () => ({
  type: EDIT_TEAM_LOADING,
});
export const editTeamSuccess = (editTeam) => ({
  type: EDIT_TEAM_SUCCESS,
  editTeam,
});
export const editTeamError = (error) => ({
  type: EDIT_TEAM_ERROR,
  error,
});

export const deleteTeamReset = () => ({
  type: DELETE_TEAM_RESET,
});
export const deleteTeamLoading = () => ({
  type: DELETE_TEAM_LOADING,
});
export const deleteTeamSuccess = (deleteTeam) => ({
  type: DELETE_TEAM_SUCCESS,
  deleteTeam,
});
export const deleteTeamError = (error) => ({
  type: DELETE_TEAM_ERROR,
  error,
});

export const getTeamsLoading = () => ({
  type: GET_TEAMS_LOADING,
});
export const getTeamsSuccess = (teams) => ({
  type: GET_TEAMS_SUCCESS,
  teams,
});
export const getTeamsError = (error) => ({
  type: GET_TEAMS_ERROR,
  error,
});
export const getRolledOffTeamsLoading = () => ({
  type: GET_ROLLEDOFFTEAMS_LOADING,
});
export const getRolledOffTeamsSuccess = (rolledOffTeams) => ({
  type: GET_ROLLEDOFFTEAMS_SUCCESS,
  rolledOffTeams,
});
export const getRolledOffTeamsError = (error) => ({
  type: GET_ROLLEDOFFTEAMS_ERROR,
  error,
});
export const getProductCalcLoading = () => ({
  type: GET_PRODUCT_CALC_LOADING,
});
export const getProductCalcSuccess = (productCalculation) => ({
  type: GET_PRODUCT_CALC_SUCCESS,
  productCalculation,
});
export const getProductCalcError = (error) => ({
  type: GET_PRODUCT_CALC_ERROR,
  error,
});

// THUNK CREATORS
export const getProductCalcThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getProductCalcLoading());
    const { data } = await roverPcdmURL.get(getProductCalcURL(productCode));
    dispatch(getProductCalcSuccess(data));
  } catch (error) {
    dispatch(getProductCalcError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const setMethodologyOptionsThunk = () => async (dispatch) => {
  try {
    const { data } = await roverPcdmURL.get(GET_METHODOLOGY_URL);
    dispatch(setMethodologyOptions(data));
  } catch (error) {
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

export const getTeamsThunk = (productCode) => async (dispatch) => {
  try {
    dispatch(getTeamsLoading());
    const { data } = await roverPcdmURL.get(getTeamURL(productCode));
    dispatch(getTeamsSuccess(data));
  } catch (error) {
    dispatch(getTeamsError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const getRolledOffTeamsThunk = (productCode, query) => async (dispatch) => {
  try {
    dispatch(getRolledOffTeamsLoading());
    const { data } = await roverPcdmURL.get(getRolledOffTeamURL(productCode, query));
    dispatch(getRolledOffTeamsSuccess(data));
  } catch (error) {
    dispatch(getRolledOffTeamsError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const saveTeamThunk = (payload, productCode, callback) => async (dispatch) => {
  try {
    dispatch(saveTeamLoading());
    const { data } = await roverPcdmURL.post(saveTeamURL(productCode), payload);
    if (callback) {
      callback(SAVE_TEAM_SUCCESS, data);
    }
    dispatch(saveTeamSuccess(data));
  } catch (error) {
    if (callback) {
      callback(SAVE_TEAM_ERROR, error);
    }
    dispatch(saveTeamError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const copyTeamThunk = (payload, productCode, callback) => async (dispatch) => {
  try {
    dispatch(copyTeamLoading());
    const { data } = await roverPcdmURL.post(copyTeamURL(productCode), payload);
    if (callback) {
      callback(COPY_TEAM_SUCCESS, data);
    }
    dispatch(copyTeamSuccess(data));
  } catch (error) {
    if (callback) {
      callback(COPY_TEAM_ERROR, error);
    }
    dispatch(copyTeamError(error));
    console.error(error);
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const editTeamThunk = (payload, productCode, teamId, callback) => async (dispatch) => {
  try {
    dispatch(editTeamLoading());
    const { data } = await roverPcdmURL.put(updateTeamURL(productCode, teamId), payload);
    if (callback) {
      callback(EDIT_TEAM_SUCCESS, data);
    }
    dispatch(editTeamSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_TEAM_ERROR, error);
    }
    dispatch(editTeamError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};
export const deleteTeamThunk = (payload, productCode, teamId, callback) => async (dispatch) => {
  try {
    dispatch(deleteTeamLoading());
    const { data } = await roverPcdmURL.put(updateTeamURL(productCode, teamId), payload);
    if (callback) {
      callback(DELETE_TEAM_SUCCESS, data);
    }
    dispatch(deleteTeamSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_TEAM_ERROR, error);
    }
    dispatch(deleteTeamError(error));
    if(checkErrorType(error)) {
      dispatch(displayCommonError(error))
    }
  }
};

// INITIAL STATE
const initialState = {
  productCalculation: { status: DATA_STATUS.INITIAL, response: {}, data: [] },
  methodologies: [],
  saveTeamStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  copyTeamStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editTeamStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteTeamStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  teams: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
  rolledOffTeams: {
    status: DATA_STATUS.INITIAL,
    response: {},
    data: [],
  },
};

// REDUCERS
const TeamsReducer = (state = initialState, action) => {
  switch (action.type) {
    case RESET_TEAM_STATE:
      return {
        ...state,
        ...initialState,
      };
    case SET_METHODOLOGY_OPTIONS:
      return { ...state, methodologies: [...action.methodologies] };
    case SAVE_TEAM_RESET:
      return {
        ...state,
        saveTeamStatus: { ...initialState.saveTeamStatus },
      };
    case SAVE_TEAM_LOADING:
      return {
        ...state,
        saveTeamStatus: {
          ...state.saveTeamStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_TEAM_SUCCESS:
      return {
        ...state,
        saveTeamStatus: {
          ...state.saveTeamStatus,
          response: action.saveTeam,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_TEAM_ERROR:
      return {
        ...state,
        saveTeamStatus: {
          ...state.saveTeamStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case COPY_TEAM_LOADING:
      return {
        ...state,
        copyTeamStatus: {
          ...state.copyTeamStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case COPY_TEAM_SUCCESS:
      return {
        ...state,
        copyTeamStatus: {
          ...state.copyTeamStatus,
          response: action.copyTeam,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case COPY_TEAM_ERROR:
      return {
        ...state,
        copyTeamStatus: {
          ...state.copyTeamStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_TEAM_RESET:
      return {
        ...state,
        editTeamStatus: { ...initialState.editTeamStatus },
      };
    case EDIT_TEAM_LOADING:
      return {
        ...state,
        editTeamStatus: {
          ...state.editTeamStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_TEAM_SUCCESS:
      return {
        ...state,
        editTeamStatus: {
          ...state.editTeamStatus,
          response: action.editTeam,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_TEAM_ERROR:
      return {
        ...state,
        editTeamStatus: {
          ...state.editTeamStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_TEAM_RESET:
      return {
        ...state,
        deleteTeamStatus: { ...initialState.deleteTeamStatus },
      };
    case DELETE_TEAM_LOADING:
      return {
        ...state,
        deleteTeamStatus: {
          ...state.deleteTeamStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_TEAM_SUCCESS:
      return {
        ...state,
        deleteTeamStatus: {
          ...state.deleteTeamStatus,
          response: action.deleteTeam,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_TEAM_ERROR:
      return {
        ...state,
        deleteTeamStatus: {
          ...state.deleteTeamStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_TEAMS_LOADING:
      return {
        ...state,
        teams: { ...state.teams, status: DATA_STATUS.LOADING },
      };
    case GET_TEAMS_SUCCESS:
      return {
        ...state,
        teams: {
          ...state.teams,
          data: action.teams,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_TEAMS_ERROR:
      return {
        ...state,
        teams: {
          ...state.teams,
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
      case GET_ROLLEDOFFTEAMS_LOADING:
        return {
          ...state,
          rolledOffTeams: { ...state.rolledOffTeams, status: DATA_STATUS.LOADING },
        };
      case GET_ROLLEDOFFTEAMS_SUCCESS:
        return {
          ...state,
          rolledOffTeams: {
            ...state.rolledOffTeams,
            data: action.rolledOffTeams,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_ROLLEDOFFTEAMS_ERROR:
        return {
          ...state,
          rolledOffTeams: {
            ...state.rolledOffTeams,
            data: [],
            response: action.error,
            status: DATA_STATUS.ERROR,
          },
        };
    case GET_PRODUCT_CALC_LOADING:
      return {
        ...state,
        productCalculation: {
          ...state.productCalculation,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_PRODUCT_CALC_SUCCESS:
      return {
        ...state,
        productCalculation: {
          ...state.productCalculation,
          data: action.productCalculation,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_PRODUCT_CALC_ERROR:
      return {
        ...state,
        productCalculation: {
          data: [],
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default TeamsReducer;
