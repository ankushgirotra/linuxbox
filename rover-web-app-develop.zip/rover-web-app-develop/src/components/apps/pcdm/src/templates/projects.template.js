import React from "react";
import {
  TOOL_TIP_MESSAGE,
  PROJECT_MESSAGES,
  CONSTRAINT_CAPACITY_VALUE,
  CONSTRAINT_CAPACITY_ICON_COLOR,
} from "../constants/message.contants";
import { getFormattedDate, stringToCurrency } from "../services/form.service";
import moment from "moment";
import "./projects.template.scss";
import { CURRENCY, LOCALE } from "../constants/common.constants";
import PublishViewersHistory from "../views/Common/capacityConstraintContainer/viewPublishAnswers"
export const getEstimateTypeTooltip = () => {
  var returnContent = [];
  for (var estimateContent of TOOL_TIP_MESSAGE.ESTIMATE_TYPE) {
    returnContent.push(
      <React.Fragment>
        {estimateContent.note == null ? (
          <div className="estimate-type-tooltip">
            <h6 className="pcdm-head">{estimateContent.title}</h6>
            <ul>
              {estimateContent.points.map((point) => (
                <li>{point}</li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="note-heading">
            <h6>{estimateContent.note.title}: </h6>
            <p>{estimateContent.note.points}</p>
          </div>
        )}
      </React.Fragment>
    );
  }
  return returnContent;
};

export const getPcodeSustainToolTipMessage = () => {
  return (
    <React.Fragment>
      <ul>
        <li>
          <p>
            When creating an <b>Intake</b> estimate, this field is optional. You may type in
            whatever identifier you prefer.
          </p>
        </li>
        <li>
          <p>
            When it becomes an <b>Execution</b> estimate, please select Product Core or a Spark P-Code.
          </p>
        </li>
      </ul>
    </React.Fragment>
  );
};

export const getBaselinePromtMessage = (points, budget, type) => {
  if (type === "NEW") {
    return [
      PROJECT_MESSAGES.SAVING_PROJECT_PROMPT.map((msg) => <p className="text-center">{msg}</p>),
      <React.Fragment>
        <p className="text-center">Your current baseline is</p>
        <p className="text-center">
          <b style={{ color: "#f60" }}>{stringToCurrency(String(budget), "blur", 2)}</b>
        </p>
        <p className="text-center">
          <b style={{ color: "#f60" }}>{points} points</b>
        </p>
        <p className="text-center">
          Do you wish to save this as your baseline budget for this project estimate?
        </p>
        <br></br>
        <div className="note-heading" >
          <h6>NOTE: </h6>
          <p> Projects in Execution cannot revert back to Intake, and the P-Code & Project Name can no longer be edited.</p>
        </div>
      </React.Fragment>,
    ];
  } else if (type === "EDIT") {
    return [
      PROJECT_MESSAGES.EDITING_POINTS_PROMPT.map((msg) => <p className="text-center">{msg}</p>),
      <React.Fragment>
        <p className="text-center">Your new baseline is</p>
        <p className="text-center">
          <b style={{ color: "#f60" }}>{stringToCurrency(String(budget), "blur", 2)}</b>
        </p>
        <p className="text-center">
          <b style={{ color: "#f60" }}>{points} points</b>
        </p>
        <p className="text-center">
          Do you wish to save this as your new baseline budget for this project estimate?
        </p>
      </React.Fragment>,
    ];
  }
};
export const getActualsPopupMessage = (message) => {
    return [
      <React.Fragment>
        <p className="text-center">
          <b style={{ color: "#f60" }}>{message}</b>
        </p>
      </React.Fragment>
    ]
};

export const getOnDeleteMessage = () => [
  PROJECT_MESSAGES.DELETE_PROJECT_PROMPT.map((msg) => <p className="text-center">{msg}</p>),
  <p className="text-center">
    If you wish to Complete the project instead to retain the historical data, please click “No”
    below and edit the story points and end date as necessary before clicking
    <b> Complete Project.</b>
  </p>,
];

export const capacityConstraintStatusToolTip = (capacityConstraint, demand, capacity) => {
  return (
    <React.Fragment>
      <p>The D/C calculation takes three months of demand and capacity data (in story points) starting with the current month, and is calculated as <b>(D-C)/C</b>.
      <br/>
      <br/>
      <b>D</b> = the sum of the next three months of funded demand (high-end estimates are used for Intake projects).
      <br/>
      <b>C</b> = the sum of the next three months of capacity. </p>
      <br/>
      <p>
        The Current Month is <b>{moment().format("MMMM")}</b>
      </p>
      <table className="capacity-demand-value-container">
        <tbody>
          <tr>
            <td>Demand is</td>
            <td>{demand}</td>
          </tr>
          <tr>
            <td>Capacity is</td>
            <td>{capacity}</td>
          </tr>
          <tr>
            <td>D/C is</td>
            <td>{capacityConstraint}%</td>
          </tr>
        </tbody>
      </table>
      <p>Demand/Capacity status is determined by following criteria:</p>
      <div className="range-status-details-container">
        <div className="range-details-container">
          <p className="text-center">
            <b>Range</b>
          </p>
          <ul>
            <li>{CONSTRAINT_CAPACITY_VALUE.HIGH}% &lt;= D/C</li>
            <li>
              {CONSTRAINT_CAPACITY_VALUE.MED_LOW}% &lt;= D/C &lt; {CONSTRAINT_CAPACITY_VALUE.HIGH}%
            </li>
            <li>
              {CONSTRAINT_CAPACITY_VALUE.LOW}% &lt;= D/C &lt; {CONSTRAINT_CAPACITY_VALUE.MED_LOW}%
            </li>
            <li>D/C &lt; {CONSTRAINT_CAPACITY_VALUE.LOW}%</li>
          </ul>
        </div>
        <div className="status-details-container">
          <p className="text-center">
            <b>Status Level</b>
          </p>
          <ul>
            <li>
              <div
                className="color-strip"
                style={{ background: CONSTRAINT_CAPACITY_ICON_COLOR.HIGH }}
              />
              <p className="status-content">High</p>
            </li>
            <li>
              <div
                className="color-strip"
                style={{ background: CONSTRAINT_CAPACITY_ICON_COLOR.MEDIUM }}
              />
              <p className="status-content">Medium</p>
            </li>
            <li>
              <div
                className="color-strip"
                style={{ background: CONSTRAINT_CAPACITY_ICON_COLOR.MED_LOW }}
              />
              <p className="status-content">Med/Low</p>
            </li>
            <li>
              <div
                className="color-strip"
                style={{ background: CONSTRAINT_CAPACITY_ICON_COLOR.LOW }}
              />
              <p className="status-content">Low</p>
            </li>
          </ul>
        </div>
      </div>
    </React.Fragment>
  );
};
export const getBaselineEstimateHistory = (historyList) => {
  let sorted = historyList.slice().sort(function (histry1, histry2) {
    var date1 = moment(histry1.modifiedDate);
    var date2 = moment(histry2.modifiedDate);
    return date2.diff(date1);
  });
  return (
    <ul className="baseline-history-list pcdm-scroll-vertical">
      {sorted.map((list) => {
        return (
          <li>
            <div className="history-date">
              <p>{getFormattedDate(list.modifiedDate, "MM/DD/YYYY")}</p>
              <p>{getFormattedDate(list.modifiedDate, "hh:mm A")}</p>
            </div>
            <div className="history-info">
              <p className="history-budget" style={{ color: "#f60" }}>
                {new Intl.NumberFormat(LOCALE.US, {
                  style: "currency",
                  currency: CURRENCY.USD,
                }).format(list.baselineBudget)}
              </p>
              <p className="history-points" style={{ color: "#f60" }}>
                {list.storyPoints} pts
              </p>
            </div>
          </li>
        );
      })}
    </ul>
  );
};

export const publishDueDateHistory = (publishAnswers) => {
  return (<PublishViewersHistory publishAnswers={publishAnswers} />)
}

export const getSprintVelocityHistory = (historyList) => {
  let sorted = historyList.slice().sort(function (histry1, histry2) {
    var date1 = moment(histry1.modifiedDate);
    var date2 = moment(histry2.modifiedDate);
    return date2.diff(date1);
  });
  const velocityHistoryList = sorted.slice(0,5)
  return (
    <ul className="velocity-history-list pcdm-scroll-vertical">
      {velocityHistoryList.map((list) => {
        return ( 
          <li>
            <div className="history-date">
              <p>{getFormattedDate(list.modifiedDate, "MM/DD/YYYY")}</p>
              <p>{getFormattedDate(list.modifiedDate, "hh:mm A")}</p>
            </div>
            <div className="history-info">
              <p className="history-points" style={{ color: "#f60" }}>
                {list.sprintVelocity} pts
              </p>
            </div>
          </li>
        );
      })} 
    </ul>
  );
};
