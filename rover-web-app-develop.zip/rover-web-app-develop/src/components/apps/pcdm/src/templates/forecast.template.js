import React from "react";

export const matchedProjectTooltipMsg = () => {
  return [
    <p key={1}>
      Projects from your Project Estimates page will appear here after they are moved to{" "}
      <b>Execution</b>.
    </p>,
    <p key={2}>
      If any projects are missing from your actuals or from your Project Estimates page, please
      click the <b>Missing Projects</b> button at the upper right-hand corner of the table to view the
      projects that require your attention.
    </p>,
  ];
};

export const totalBudgetTooltipMsg = () => {
  return (
    <p>
      This reflects your story points and Baseline Estimate from your Project Estimates page. This
      will only change if your Baseline Estimate changes due to an increase or decrease in project
      scope.
    </p>
  );
};

export default function goToCurrentMonth(tableID) {
  console.log(tableID)
  let monthEl = document.getElementById(`forecast-current-month-${tableID}`);
  let scrollArea = document.getElementsByClassName(`forecast-table-v1-${tableID}`);
  let linkEl = document.getElementById(`goto-current-month-${tableID}`);
  console.log(scrollArea, linkEl)
  if (monthEl && scrollArea && scrollArea.length && linkEl) {
    scrollArea[0].scrollLeft =
      monthEl.offsetLeft - (linkEl.offsetLeft + linkEl.offsetWidth) - scrollArea[0].offsetLeft;
  }
};

export const checkErrorType = (error) => {
  if(error && error.response && error.response.status == 504 && error.response.data.message == "Token Verify Error.Please try again"){
    return true
  }else{
    return false
  }
}
