import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Row, Col } from "react-bootstrap";
import axios from 'axios';
import moment from "moment";
import cookie from "react-cookies";
import { searchPcode, selectedProjectCodes } from '../admin.service';
import { check } from "../../../services/validation";
import { FORM_CONTROL_DEFAULT } from "../../../constants/form.constants";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import CustomCheckBox from '../../../components/forms/CheckBoxSubBoxes/subCheckBox';
import FileDownloader from 'js-file-download';
import CustomSelect from "../../../components/forms/SelectDropdown/selectDropdown";


function ProjectEstimatesReport(props) {

  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    selectedProducts: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
    selectedProjects: {
      ...FORM_CONTROL_DEFAULT,
      // required: true,
    },
  });
  const [progress, setProgress] = useState(false)
  const PROJ_EXT_REPORT_FILE_NAME = "adminProjectEstimates";

  const download = (url) => {
    const token = localStorage.getItem("token")
    setProgress(true)
    axios({
      url: `${cookie.load("ROVER_PCD_API")}${url}`,
      // url: `https://rover-web-api-pcd-test.cfaa.azr.hcsctest.net${url}`,
      method: 'GET',
      headers : {
        Authorization : token ? `Bearer ${token}` : ''
      },
      onDownloadProgress(progressEvent){
        // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
        setProgress(true);
      },
      responseType: 'blob',
    }).then(response => {
      setProgress(false)
      // const url = window.URL.createObjectURL(new Blob([response.data]));
      // const link = document.createElement('a');
      // link.href = url;
      // link.target = "_blank";
      // link.setAttribute('download', `Project Estimates ${moment().format("YYYY.MM.DD")}.xlsx`);
      // document.body.appendChild(link);
      // link.click()
      // window.open(url, "_blank").focus()
      FileDownloader(response.data, `Project Estimates ${moment().format("YYYY.MM.DD")}.xlsx`)
    }).catch(error => {
      console.log(error)
      setProgress(false)
    })
  }

  const onSubmit = () => {
    if (noOfProd !== 0) {
      // let noOfSelectedProducts = selectedFilters ? selectedFilters.map(
      //   (prod) => prod.children).flat().length : 0;
      // let noOfActiveProducts = props.products && props.products.data &&
      //   props.products.data.productsResponses ? props.products.data.productsResponses.filter(
      //     (prod) => prod.active === true).length : 0;
      // if (noOfSelectedProducts === noOfActiveProducts && noOfActiveProducts) {
      //   // window.open(
      //   //   `${cookie.load(
      //   //     "ROVER_PCD_API"
      //   //   )}/pcd/products/download/${PROJ_EXT_REPORT_FILE_NAME}`);
      //   download(`/pcd/products/download/${PROJ_EXT_REPORT_FILE_NAME}`)
      // } else if (noOfActiveProducts > noOfSelectedProducts && noOfActiveProducts) {
      //   let filteredProducts = searchPcode(props.products && props.products.data
      //     && props.products.data.productsResponses ?
      //     props.products.data.productsResponses : [], selectedFilters)
      //   // window.open(
      //   //   `${cookie.load(
      //   //     "ROVER_PCD_API"
      //   //   )}/pcd/products/download/${PROJ_EXT_REPORT_FILE_NAME}?${filteredProducts}`);
      //   download(`/pcd/products/download/${PROJ_EXT_REPORT_FILE_NAME}?${filteredProducts}`)
      // }
      let filteredProducts = searchPcode(props.products && props.products.data
        && props.products.data.productsResponses ?
        props.products.data.productsResponses : [], selectedFilters)
      let filteredProjects = selectedProjectCodes(formControls.selectedProjects.value);
      console.log(formControls.selectedProjects.value)
      let symbol = filteredProjects || filteredProjects ? "?":"" ;
      download(`/pcd/products/download/${PROJ_EXT_REPORT_FILE_NAME}?${filteredProducts}${filteredProjects}`)

    } else {
      setFormControls({
        ...formControls,
        selectedProducts: {
          ...formControls.selectedProducts,
          error: noOfProd !== 0 ? false : true,
          errorMsg: noOfProd !== 0 ? "" : "Please select atleast one Product",
        },
      });
    }
  };

  //#region 

  // Filter functionalities
  const CHECK = {
    SELECTED: "SELECTED",
    NOT_SELECTED: "NOT_SELECTED",
    PARTIALLY_SELECTED: "PARTIALLY_SELECTED",
  };

  // Setting list for dropdown
  const [noOfProd, setNoOfProd] = useState(0);
  const [productList, setProductList] = useState({});

  useEffect(() => {
    if (formControls.selectedProducts.error) {
      setFormControls({
        ...formControls,
        selectedProducts: {
          ...formControls.selectedProducts,
          error: noOfProd !== 0 ? false : true,
          errorMsg: noOfProd !== 0 ? "" : "Please select atleast one Product",
        },
      });
    }
  }, [noOfProd])

  useEffect(() => {
    if (props.products && props.products.data && props.products.data.productsResponses) {
      const productList = props.products.data.productsResponses;
      let list = {};
      productList.forEach((el) => {
        if (el.active && !el.testProduct) {
          if (!list[el.portfolio]) {
            list[el.portfolio] = { portfolioId: el.portfolioId, children: [el.name] }
          } else {
            list[el.portfolio] = { ...list[el.portfolio], children: [...list[el.portfolio].children, el.name] }
          }
        }
      })
      setProductList(list);
    }
  }, [props.products])

  useEffect(() => {
    if (productList) {
      selectOrDeselectAll()
    }
  }, [productList])

  //#region // Check and Onclick Function for Select All
  const [selectedFilters, setSelectedFilter] = useState([]);
  const checkAllSelected = () => {
    let allSelected = [...selectedFilters];
    let countA = 0; let countB = 0
    Object.keys(productList).forEach((el) => {
      countA += productList[el].children.length
    })
    allSelected.forEach((el) => {
      countB += el.children.length
    })
    return allSelected.length === 0
      ? CHECK.NOT_SELECTED
      : countA === countB
        ? CHECK.SELECTED
        : CHECK.PARTIALLY_SELECTED;
  }
  const selectOrDeselectAll = () => {
    if (selectedFilters.length !== Object.keys(productList).length) {
      let tempSelected = []
      Object.keys(productList).forEach((el) => {
        let obj = { id: el, children: productList[el].children }
        tempSelected.push(obj);
      })
      setSelectedFilter(tempSelected);
    } else {
      setSelectedFilter([]);
    }
  }
  //#endregion

  // Function for selecting sub Options
  const updateFilters = (element, parent) => {
    let tempFilter = [...selectedFilters];
    let flag = false;
    tempFilter.forEach((el, index) => {
      if (el.id === parent) {
        flag = true;
        if (el.children.includes(element)) {
          let newFilter = el.children.filter((prod) => prod !== element)
          tempFilter[index].children = newFilter;
          setSelectedFilter(tempFilter);
        } else {
          tempFilter[index].children.push(element);
          setSelectedFilter(tempFilter);
        }
      }
    })
    if (!flag) {
      let obj = { id: parent, children: [element] }
      tempFilter.push(obj);
      setSelectedFilter(tempFilter);
    }
  }

  useEffect(() => {
    if (selectedFilters) {
      let count = 0;
      selectedFilters.forEach((el) => {
        count += el.children.length;
      });
      setNoOfProd(count);
    }
  }, [selectedFilters])

  const closeDropdown = () => {
    document.getElementById("dropdown").classList.remove("on");
  }

  const projectCodesCheck = check({
    original: props.projectCodesUsed,
    path: "data",
    checkEmpty: true,
    defaultReturnValue: [],
  });
  const onInputChange = (event) => {
    // const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    setFormControls({
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
    });
  };

  const getToolTipMessage = () => {
    return (<div>
      <p>
        <b>This filter contains all projects that Product Managers have created estimates for in PCDM.
           If you are not getting any results when searching for the P-Code you want to choose,
           please confirm that the Product Manager(s) have added this project to their Project Estimates page and that it is in Execution.</b>
      </p>
      <br/>
      <p>
        <b>By default, all projects that have been estimated will be included in this report.
           If you select any projects in this filter, then the report will only include data for the selected projects.</b>
      </p>
    </div>)
  }

  //#endregion
  return (
    <div className="pcdm-projectestimates-report">
      <Row>
        <Col sm={4} md={4} lg={4} xl={4}>
          <form className="pcdm-form">
            <div className="pcdm-form__form-group">
              <div className="pcdm-form__form-group-field">
                <label className='required text-cap'>Selected Products</label>
                <CustomCheckBox
                  title={'Products'}
                  list={productList}
                  key={'portfolioId'}
                  value={'children'}
                  componentName={'project-estimates-report'}
                  valuesSelected={noOfProd}
                  checkAllSelected={checkAllSelected}
                  selectedFilters={selectedFilters}
                  updateFilters={updateFilters}
                  selectOrDeselectAll={selectOrDeselectAll}
                  setSelectedFilter={setSelectedFilter}
                />
                <div class="error-message-container"><div class="error-message">{formControls.selectedProducts.errorMsg}</div></div>
              </div>
              <div className="pcdm-form__form-group-field">
                  <CustomSelect
                    name="selectedProjects"
                    label={"Selected Projects"}
                    placeholder="Select Projects"
                    formObj={formControls.selectedProjects}
                    config={{
                      options: projectCodesCheck.value,
                      value: "projectName",
                      id: "pcode",
                    }}
                    isMulti={true}
                    formatOptionLabel={(prd) => `${prd.label} (${prd.value})`}
                    isRequired={formControls.selectedProjects.required}
                    onChange={(e) =>
                      onInputChange({
                        target: { name: e.name, value: e.value },
                      })
                    }
                    hasToolTip = {true}
                    toolTipMessage = {getToolTipMessage()}
                    toolTipTitle = {""}
                  />
                </div>
            </div>
          </form>
          <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
            <CustomButton
              variant={BUTTON_VARIANTS.BLUE_GOLD}
              size="md"
              onClick={onSubmit}
              disable={false}
              loading = {progress}
              fluid={true}
            >
              Download Project Estimates Report
            </CustomButton>
          </div>
        </Col>
        <Col sm={{offset:1, span:5}} md={{ offset:1, span:5}} lg={{ offset:1, span:5}} xl={{ offset:1, span:5}}>
          <div className='project-estimates-report-description'>This report will pull all project estimates for the selected products</div>
        </Col>
      </Row>
    </div>
  );
}

export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner,
  projectCodesUsed: state.PCDMAdminReducer.projectCodesUsed,
});

export default connect(mapStateToProps, null)(ProjectEstimatesReport);

