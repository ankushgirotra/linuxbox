import React, { useEffect, useState } from "react";
import { OverlayLoader } from "../../components/DataHandler/dataHandler";
import { Container, Row, Col } from "react-bootstrap";
import { Route, useRouteMatch, useHistory, Switch } from "react-router";
import ManageProducts from "./Manage/Products/manageProductsTable";
import ManageProductLines from "./Manage/ProductLines/manageProductLinesTable";
import ManageTeamRoles from "./Manage/TeamRoles/manageTeamRolesTable";
import List from "../../components/List/list";
import Toaster from "../../components/Toaster/toaster";
import { discardDisplayCommonError } from "../../store/common.reducer";
import { ErrorMessageModal } from "../../components/MessageModal/errorMessageModal";
import {
  setProductLinesThunk,
  setProductsByOwnerThunk
} from "../../store/products.reducer";
import {
  getManageAdminTeamRolesThunk,
  getPublishDueDateThunk,
  getHolidayDetailsThunk,
  getEmployeeDetailsThunk,
  getEmailNotificationStatusThunk
} from "../../store/admin.reducer";
import Configurations from './Manage/Configurations';
import { connect } from "react-redux";
import { DATA_STATUS } from "../../constants/service.constant";
import ManageProductsForm from "./Manage/Products/manageProductsForm";
import { PCDM_ADMIN_ACTIONS, ACTIONS } from "../../constants/action.constants";
import { ERROR_MSG } from "../../constants/message.contants";
import { addNotification } from "../../store/common.reducer";
import { PCDM_ROUTES } from "../../../../../app/Route/constants/pcdmRoutes.constants";
import { getFormattedUserId } from "../../../../../../services/auth.services";
import ManageTeamRolesForm from "./Manage/TeamRoles/manageTeamRolesForm";
import PCDMReports from "./Reports/PCDMReports";
import { formatLanId } from "../../services/lanId.service"
export const filterList = [
  // { id: 1, name: "Manage Products" },
  // { id: 2, name: "Manage Product Lines" },
  // { id: 3, name: "Manage Team Roles" },
  { id: 1, name: "Configurations" },
  { id: 2, name: "Generate Reports" },
];

export function PCDMAdmin(props) {
  const {
    setAllProductLines,
    setAllProducts,
    setAllTeamRoles,
    products,
    showNotification,
    userParams,
    getPublishDueDate,
    getHolidayDetails,
    getEmployeeDetails,
    getEmailNotification,
  } = props;
  const {
    CHILDREN: {
      ADMIN: {
        CHILDREN: { MANAGE_PRD, MANAGE_PRD_LINE, MANAGE_TEAM_ROLE, GENERATE_REPORT, CONFIGURATIONS },
      },
    },
    getMangeProdutRoute,
    getMangeProdutLineRoute,
    getMangeTeamRolesRoute,
    getGenerateReportsRoute,
    getConfigurationsRoute,
  } = PCDM_ROUTES;
  const [showProductForm, setShowProductForm] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState({});
  const [showProductLineForm, setShowProductLineForm] = useState(false);
  const [selectedProductLine, setSelectedProductLine] = useState({});
  const [showTeamRolesForm, setShowTeamRolesForm] = useState(false);
  const [selectedTeamRole, setSelectedTeamRole] = useState({});
  const [formMode, setFormMode] = useState(null);

  const history = useHistory();
  let { url, path } = useRouteMatch();

  useEffect(() => {
    setAllProductLines();
    setAllProducts(formatLanId(userParams));
    setAllTeamRoles();
    getPublishDueDate();
    getHolidayDetails();
    getEmployeeDetails();
    getEmailNotification();
  }, []);

  const onFilterChange = (item) => {
    // if (item.id === 1) {
    //   history.push(`${path}${MANAGE_PRD}`);
    // } else if (item.id === 2) {
    //   history.push(`${path}${MANAGE_PRD_LINE}`);
    // } else if (item.id === 3) {
    //   history.push(`${path}${MANAGE_TEAM_ROLE}`);
    // } else 
    if (item.id === 1) {
      history.push(`${path}${CONFIGURATIONS}`);
      document.title = "Rover PCDM - Admin"
    } else if (item.id === 2) {
      history.push(`${path}${GENERATE_REPORT}`);
      document.title = "Rover PCDM - Reports"
    }
  };
  const discardNotification = () => {
    props.discardDisplayPrompt()
  }
  let currentAction = {};
  // if (history.location.pathname.includes(`${MANAGE_PRD}`)) {
  //   currentAction = filterList[0];
  // } else if (history.location.pathname.includes(`${MANAGE_PRD_LINE}`)) {
  //   currentAction = filterList[1];
  // } else if (history.location.pathname.includes(`${MANAGE_TEAM_ROLE}`)) {
  //   currentAction = filterList[2];
  // } else 
  if (history.location.pathname.includes(`${CONFIGURATIONS}`)) {
    currentAction = filterList[0];
    document.title = "Rover PCDM - Admin"
  } else if (history.location.pathname.includes(`${GENERATE_REPORT}`)) {
    currentAction = filterList[1];
    document.title = "Rover PCDM - Reports"
  }
  const onAddOrEditClick = (formMode, data) => {
    if (
      formMode === PCDM_ADMIN_ACTIONS.ADD_PRODUCT ||
      formMode === PCDM_ADMIN_ACTIONS.EDIT_PRODUCT
    ) {
      setShowProductForm(true);
      setFormMode(formMode);
      setSelectedProduct({ ...data });
    } else if (
      formMode === PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE ||
      formMode === PCDM_ADMIN_ACTIONS.EDIT_PRODUCT_LINE
    ) {
      setShowProductLineForm(true);
      setFormMode(formMode);
      setSelectedProductLine({ ...data });
    } else if (
      formMode === PCDM_ADMIN_ACTIONS.ADD_TEAM_ROLES ||
      formMode === PCDM_ADMIN_ACTIONS.EDIT_TEAM_ROLES
    ) {
      setShowTeamRolesForm(true);
      setFormMode(formMode);
      setSelectedTeamRole({ ...data });
    }
  };
  const onModalClose = async (status, data, keepModal = false) => {
    if (status === ACTIONS.SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      setShowTeamRolesForm(false);
      setShowProductForm(false);
      if (showProductForm) setAllProducts(formatLanId(userParams));
      if (showTeamRolesForm) setAllTeamRoles();
    } else if (status === ACTIONS.ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
      setShowTeamRolesForm(false);
      setShowProductForm(false);
    } else {
      setShowTeamRolesForm(false);
      setShowProductForm(false);
    }
  };
  const getPcdmAdminRoutes = () => {
    return (
      <Switch>
        <Route exact path={PCDM_ROUTES.getAdminRoute()}>
          <>
            <h4 className="pcdm-head">Please select any option</h4>
          </>
        </Route>
        {/* <Route path={`${PCDM_ROUTES.getMangeProdutRoute()}`}>
          <ManageProducts onAddOrEditProduct={onAddOrEditClick} />
        </Route>
        <Route path={`${PCDM_ROUTES.getMangeProdutLineRoute()}`}>
          <ManageProductLines onAddOrEditProductLine={onAddOrEditClick} closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)} />
        </Route>
        <Route path={`${PCDM_ROUTES.getMangeTeamRolesRoute()}`}>
          <ManageTeamRoles onAddOrEditTeamRoles={onAddOrEditClick} />
        </Route> */}
        <Route path={`${PCDM_ROUTES.getConfigurationsRoute()}`}>
          <Configurations onAddOrEditClick={onAddOrEditClick} closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)} />
        </Route>
        <Route path={`${PCDM_ROUTES.getGenerateReportsRoute()}`}>
          <PCDMReports />
        </Route>
      </Switch>
    );
  };
  return (
    <div className="pcdm-admin-container" style={{ position: "relative" }}>
      <OverlayLoader loading={products.status === DATA_STATUS.LOADING || props.projectCodesUsed.status === DATA_STATUS.LOADING } />
      {currentAction.name ? <h4 className="pcdm-head center">{currentAction.name}</h4> : null}
      <Container fluid>
        <Row style={{ marginTop: "10px" }}>
          <Col sm={2} md={2} lg={2} xl={2}>
            <div className="pcdm-admin-filter-container">
              <List
                className={"pcdm-admin-filter-list"}
                list={[...filterList]}
                title={"Admin Actions"}
                onChange={onFilterChange}
                selected={currentAction}
                id="id"
                value="name"
                groupName="pcdm-admin-filter-list"
              />
            </div>
          </Col>
          <Col sm={10} md={10} lg={10} xl={10}>
            {getPcdmAdminRoutes()}
          </Col>
        </Row>
      </Container>
      {showProductForm ? (
        <ManageProductsForm
          formVisible={showProductForm}
          selectedProduct={selectedProduct}
          formMode={formMode}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
        />
      ) : null}
      {showTeamRolesForm ? (
        <ManageTeamRolesForm
          formVisible={showTeamRolesForm}
          selectedTeamRole={selectedTeamRole}
          formMode={formMode}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
        />
      ) : null}
      <Toaster />
      <ErrorMessageModal  errorNotification = {props.errorNotification}
                 discardNotification = {discardNotification} />
    </div>
  );
}

export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner,
  teamRoles: state.PCDMAdminReducer.teamRoles,
  userParams: state.AuthReducer.user,
  publishDueDate : state.PCDMAdminReducer.getPublishDueDate,
  projectCodesUsed: state.PCDMAdminReducer.projectCodesUsed,
  errorNotification: state.CommonPCDMReducer.errorNotification,
});

export const mapDispatchToProps = (dispatch) => ({
  setAllProductLines: () => dispatch(setProductLinesThunk()),
  setAllProducts: (id) => dispatch(setProductsByOwnerThunk(id)),
  setAllTeamRoles: () => dispatch(getManageAdminTeamRolesThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
  getPublishDueDate: () => dispatch(getPublishDueDateThunk()),
  getHolidayDetails: () => dispatch(getHolidayDetailsThunk()),
  getEmployeeDetails: ()=> dispatch(getEmployeeDetailsThunk()),
  discardDisplayPrompt: () => dispatch(discardDisplayCommonError()),
  getEmailNotification: () => dispatch(getEmailNotificationStatusThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(PCDMAdmin);
