import React, { useState, useMemo, useEffect, useCallback } from "react";
import "./forecastTable.scss";
import {
  prepareForecastsData,
  prepareForecastTableData,
} from "../../../services/forecast.service";
import {
  getFormattedDate,
  stringToCurrency,
} from "../../../services/form.service";
import UpdatePoints from "./updatePoints";
import { connect } from "react-redux";
import {
  getForecastDollarThunk,
  GET_FORECAST_DOLLAR_SUCCESS,
  logForecastChange,
} from "../../../store/forecast.reducer";
import ToolTip from "../../../components/ToolTip/ToolTip";
import {
  matchedProjectTooltipMsg,
  totalBudgetTooltipMsg,
} from "../../../templates/forecast.template";
import CustomButton from "../../../components/forms/Button/button";
import { ArrowRightCircle, CheckCircle } from "react-feather";
import moment from "moment";
import DataGrid, {
  SelectColumnFilter,
} from "../../../components/DataGrid/dataGrid";

function RenderForecastTable(props) {
  const {
    forecastsIndividual,
    forecastsAggregate,
    forecastTableHistory,
    logChange,
    productCode,
    forecastDollar,
    updateForecastChangesStatus,
    hasEditAccess,
    isShowCompletedProjectChecked = "false",
    isAggregate = false,
    startMonth,
    endMonth,
    selectedForecast,
  } = props;

  const columns = useMemo(() => [
    {
      Header: "MONTH",
      accessor: "month",
      Cell: ({ row: { original } }) => showMonth(original, "month"),
      disableFilters: true,
    },
    {
      Header: (props) => budgetHeadwithTooltip(),
      accessor: "budget.dollars",
      Cell: ({ row: { original } }) => showBudget(original, "budget"),
      disableFilters: true,
    },
    {
      Header: "FORECAST",
      accessor: "forecast.dollars",
      Cell: ({ row: { original } }) => showForecast(original, "forecast"),
      disableFilters: true,
    },
    {
      Header: "ACTUALS",
      accessor: "actual.dollars",
      Cell: ({ row: { original } }) => showActual(original, "actual"),
      disableFilters: true,
    },
    {
      Header: "VARIANCE",
      accessor: "variance.dollars",
      Cell: ({ row: { original } }) => showVariance(original, "variance"),
      disableFilters: true,
    },
  ]);

  const budgetHeadwithTooltip = () => {
    return (
      <div className="pcdm-table-header" style={{ display: "flex" , float : "right" }}>
        <div className="pcdm-table_col-header">Budget </div>
        <span onClick={(event) => event.stopPropagation()}>
          <ToolTip
            toolTipTitle={"Budget"}
            toolTipMessage={totalBudgetTooltipMsg()}
          ></ToolTip>
        </span>
      </div>
    );
  };
  const getToolTipMessageHtml = (toolTipTitle) => {
    if (toolTipTitle == "startDate") {
      return (
        <div>
          The start date for this project does not match the actuals we received
          for it. Please edit the project start date to reflect the real
          beginning of work.
        </div>
      );
    } else if (toolTipTitle === "endDate") {
      return (
        <div>
          The end date for this project does not match the actuals we received
          for it. Please edit the project end date to reflect the real end of
          work.
        </div>
      );
    } else if (toolTipTitle === "actuals") {
      return (
        <div>
          The start date or end date for this project does not match the actuals
          we received for it. Please edit the project start date or end date to
          reflect the real end of work.
        </div>
      );
    }
  };
  const getToolTipHeader = (toolTipTitle) => {
    if (toolTipTitle == "startDate") {
      return "Incorrect Start Date";
    } else if (toolTipTitle === "endDate") {
      return "Incorrect End Date";
    } else if (toolTipTitle === "actuals") {
      return "Incorrect Start/End Date";
    }
  };
  const updatePoints = (changeObj, payload) => {
    if (
      changeObj.new.value !== null &&
      changeObj.new.value !== "" &&
      (changeObj.old === null ||
        Number(changeObj.old) !== Number(changeObj.new.value))
    ) {
      const forecastDollar = Math.round(
        (payload.totalDollars / payload.totalPoints) * changeObj.new.value
      );
      let newVariance = {
        dollars: forecastDollar - payload.budget.dollars,
        points: changeObj.new.value - payload.budget.points,
      };
      let newPayload = {
        ...payload,
        forecast: { ...payload.forecast, points: changeObj.new.value },
      };
      logChange({
        ...newPayload,
        forecast: { ...newPayload.forecast, dollars: Number(forecastDollar) },
        variance: newVariance,
      });
    }
  };
  const showMonth = (row, key) => {
    // const month = moment(row.month, "MMM YYYY")
    if (row.month == "TOTAL") {
      return <div>{row.month} </div>;
    }
    const month = new Date(row.month).toLocaleString("en-us", {
      month: "long",
    });
    const year = new Date(row.month).getFullYear();
    const value = month + " " + year;
    return <div>{value}</div>;
  };

  const showBudget = (row, key) => {
    const dollar = row.budget.dollars;
    const decimal = Number(dollar) == 0 ? 0 : 2;
    const value = decimal
      ? stringToCurrency(String(dollar), "blur", decimal)
      : "$0";
    const points = row.budget.points + " pts";
    if (row.month == "TOTAL") {
      const flag = Number(row.forecast.points) > Number(row.budget.points);
      return (
        <div>
          <div id="dollars"> {value} </div>
          <div
            id="points"
            title={
              flag
                ? "The forecasted points exceed the baseline budget for this project. Please adjust the project scope if necessary."
                : null
            }
            className={flag ? "redState" : ""}
          >
            {flag ? (
              <span
                className="lnr lnr-warning"
                style={{ marginRight: "3px", fontWeight: "bold" }}
              ></span>
            ) : null}{" "}
            {points}
          </div>
        </div>
      );
    }
    return (
      <div>
        <div id="dollars"> {!row.onlyActuals ? value : null} </div>
        <div id="points">{!row.onlyActuals ? points : null } </div>
      </div>
    );
  };

  const showForecast = (row, key) => {
    const dollar = row.forecast.dollars;
    const decimal = Number(dollar) == 0 ? 0 : 2;
    const value = decimal
      ? stringToCurrency(String(dollar), "blur", decimal)
      : "$0";
    const points = row.forecast.points + " pts";

    if (row.editable && hasEditAccess) {
      let payload = {
        projectEstimateId: selectedForecast.projectEstimateId,
        pcode: selectedForecast.pcode,
        month: getFormattedDate(row.month, "YYYY-MM-DD", "MM/DD/YYYY"),
        totalDollars: selectedForecast.totalBudget,
        totalPoints: selectedForecast.totalPoints,
        forecast: { dollars: 0, points: row.forecast.points },
        budget: { dollars: row.budget.dollars, points: row.budget.points },
      };
      return (
        <div>
          <div id="dollars"> {value} </div>
          <div id="points" className={row.editable ? "isEditable" : ""}>
            <UpdatePoints
              content={
                row.forecast.points === null ||
                row.forecast.points === undefined
                  ? `___ pts`
                  : `${row.forecast.points} pts`
              }
              point={row.forecast.points}
              updatePoints={updatePoints}
              payload={payload}
            />
          </div>
        </div>
      );
    }
    return (
      <div>
        <div id="dollars"> {!row.onlyActuals ? value : null} </div>
        <div id="points">{!row.onlyActuals ? points : null}</div>
      </div>
    );
  };

  const showActual = (row, key) => {
    const dollar = row.actual.dollars;
    const decimal = Number(dollar) == 0 ? 0 : 2;
    const value = decimal
      ? stringToCurrency(String(dollar), "blur", decimal)
      : "$0";
    const points = row.actual.points + " pts";

    const endDate = new Date(
      moment(selectedForecast.plannedEnd).format("MM/DD/YYYY")
    );
    const plannedDate = new Date(
      moment(selectedForecast.plannedStart).format("MM/DD/YYYY")
    );
    const month = new Date(moment(row.month).format("MM/DD/YYYY"));
    const actualTooltipEndDate = moment(month, "MM/DD/YYYY").isAfter(
      moment(endDate).format("MM/DD/YYYY"),
      "month"
    )
      ? true
      : false;
    const actualTooltipStartDate = moment(month, "MM/DD/YYYY").isBefore(
      moment(plannedDate).format("MM/DD/YYYY"),
      "month"
    )
      ? true
      : false;
    const aggregateFlag =
      selectedForecast.projectEstimateId == "pc" ||
      selectedForecast.projectEstimateId == "pf"
        ? true
        : false;
    const actualsOnlyFlag = row.onlyActuals
    return (
      <div>
        <div id="dollars">
          {/* {value} */}
          {!row.onlyActuals ? value : row.actual.dollars || row.actual.points ? value : ""}
          {(actualTooltipEndDate || actualTooltipStartDate) &&
          row.actual.dollars &&
          !aggregateFlag ? (
            <ToolTip
              key={row.month}
              toolTipTitle={getToolTipHeader(
                actualTooltipStartDate ? "startDate" : "endDate"
              )}
              toolTipMessage={getToolTipMessageHtml(
                actualTooltipStartDate ? "startDate" : "endDate"
              )}
              content={() => (
                <span className="custom-tool-tip-alert-icon">
                  <i
                    className="fas fa-exclamation-circle"
                    title="Click to get info"
                  ></i>
                </span>
              )}
            ></ToolTip>
          ) : null}
        </div>
        <div id="points">
          {/* {points} */}
          {!row.onlyActuals ? points : row.actual.points || row.actual.dollars ? points : ""}
          {(actualTooltipEndDate || actualTooltipStartDate) &&
          row.actual.points &&
          !aggregateFlag ? (
            <ToolTip
              key={row.month}
              toolTipTitle={getToolTipHeader(
                actualTooltipStartDate ? "startDate" : "endDate"
              )}
              toolTipMessage={getToolTipMessageHtml(
                actualTooltipStartDate ? "startDate" : "endDate"
              )}
              content={() => (
                <span className="custom-tool-tip-alert-icon">
                  <i
                    className="fas fa-exclamation-circle"
                    title="Click to get info"
                  ></i>
                </span>
              )}
            ></ToolTip>
          ) : null}
        </div>
      </div>
    );
  };

  const showVariance = (row, key) => {
    const dollar = "$" + row.variance.dollars;
    const decimal = Number(row.variance.dollars) == 0 ? 0 : 2;
    const value = decimal
      ? stringToCurrency(String(dollar), "blur", decimal)
      : "$0";
    const points = row.variance.points + " pts";
    if (row.variance.dollars < 0) {
      return (
        <div>
          <div id="dollars" className="red">
            {/* {" "} */}
            {/* -{value}{" "} */}
            {!row.onlyActuals ? `-${value}` : null}
          </div>
          <div id="points">{!row.onlyActuals ? points : null}</div>
        </div>
      );
    }
    return (
      <div>
        <div id="dollars"> {!row.onlyActuals ? value : null} </div>
        <div id="points">{!row.onlyActuals ? points : null}</div>
      </div>
    );
  };

  const data = useMemo(
    () =>
      prepareForecastTableData(
        selectedForecast,
        forecastTableHistory
      ),
    [
      selectedForecast,
      forecastTableHistory,
      forecastsIndividual,
      forecastsAggregate,
    ]
  );
  
  useEffect(() => {
    // gotToCurrentMonth();
  
  });
  const gotToCurrentMonth = () => {
    let monthEl = document.getElementById(`forecast-table-previous-month-id`);
    // let scrollArea = document.getElementsByClassName(`forecast-table-v2-container`);
    // let linkEl = document.getElementById(`goto-current-month-${tableID}`);
    // if (monthEl && scrollArea && scrollArea.length && linkEl) {
    //   scrollArea[0].scrollLeft =
    //     monthEl.offsetLeft - (linkEl.offsetLeft + linkEl.offsetWidth) - scrollArea[0].offsetLeft;
    // }
    if (monthEl) {
      monthEl.scrollIntoView(true);
    }
  };
  const flag = selectedForecast.actualStart && selectedForecast.actualEnd && 
    (moment(selectedForecast.actualStart).startOf("month") < moment(selectedForecast.plannedStart).startOf("month") ||
      moment(selectedForecast.actualEnd).endOf("month") > moment(selectedForecast.plannedEnd).endOf("month")) ? true :false;
  return (
    <React.Fragment>
      <div key={selectedForecast.projectEstimateId} >
        <span className="projectName">{selectedForecast.projectName}</span>
        <span className="projectCode">
          {selectedForecast.projectEstimateId != "pc" &&
          selectedForecast.projectEstimateId != "pf"
            ? ` | ${selectedForecast.pcode} `
            : null}
          {flag ? <ToolTip
            key={`${selectedForecast.pcode}`}
            toolTipTitle={getToolTipHeader('actuals')}
            toolTipMessage={getToolTipMessageHtml('actuals')}
            content={() => (
              <span className="custom-tool-tip-alert-icon">
                <i className="fas fa-exclamation-circle" title="Click to get info"></i>&nbsp;
              </span>
            )}
            toolTipPlacement="right"
        ></ToolTip>
            :null } 
          {selectedForecast.completed ? <i className="fas fa-check-circle completed-icon"></i> :null}
        </span>
        <span>
        </span>
      </div>
      <div
        className="forecast-table-v2-container pcdm-scroll-vertical"
        id="forecast_Table_V2"
      >
        <DataGrid
          data={data}
          columns={columns}
          // toolTip={getToolTip}
          showUpdatedDataGrid={true}
          noRowText={"Click Add project button to start creating projects"}
          getRowClassName={(row) => {
            if (
              new Date(row.original.month).getMonth() ==
                new Date().getMonth() &&
              new Date(row.original.month).getFullYear() ==
                new Date().getFullYear()
            ) {
              return "forecast-table-current-month";
            } else {
              return "";
            }
          }}
          getRowId={(row) => {
            if (
              new Date(row.original.month).getMonth() ==
                new Date().getMonth() &&
              new Date(row.original.month).getFullYear() ==
                new Date().getFullYear()
            ) {
              return "forecast-table-current-month-id";
            } else if (
              moment(row.original.month) >=
                moment().startOf("month").subtract(1, "month") &&
              moment(row.original.month) <= moment().startOf("month")
            ) {
              return "forecast-table-previous-month-id";
            } else {
              return "";
            }
          }}
          getCellClassName={(cell) => {
            if (
              cell.column.Header == "FORECAST" &&
              cell.row.original.editable
            ) {
              return "editable-forecast-cell";
            } else {
              return "";
            }
          }}
        />
      </div>
    </React.Fragment>
  );
}

export const mapStateToProps = (state) => ({
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
  forecastDollar: state.ForecastsReducer.forecastDollar,
  updateForecastChangesStatus:
    state.ForecastsReducer.updateForecastChangesStatus,
});
export const mapDispatchToProps = (dispatch) => ({
  getForecastDollar: (
    productCode,
    projectEstimateId,
    forecastPoints,
    month,
    callback
  ) =>
    dispatch(
      getForecastDollarThunk(
        productCode,
        projectEstimateId,
        forecastPoints,
        month,
        callback
      )
    ),
  logChange: (change) => dispatch(logForecastChange(change)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RenderForecastTable);
