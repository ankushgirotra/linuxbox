import React from "react";
import moment from 'moment';
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { team } from "../../../../test_fixtures/team.mock";
import { methodologies } from "../../../../test_fixtures/common.mock";
import { TeamForm } from "./teamForm";
import {
	FORM_DATE_FORMAT,
	MONTH_DATE_YEAR_FORMAT,
	TEAM_END_DATE_MAX,
	TEAM_START_DATE_MAX,
	TEAM_START_DATE_MIN,
	DEFAULT_SPRINT_OPTION_ID,
	MIN_SPRINT_VELOCITY,
	MAX_SPRINT_VELOCITY,
	TEAM_END_DATE_MIN,
} from "../../../constants/form.constants";
import { DEFAULT_MSG_MODAL_CONFIG } from "../../../components/MessageModal/messageModal";
import { DATA_STATUS } from "../../../constants/service.constant";
import { appendPointsToValue } from "../../../services/form.service";

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());

const baseProps = {
	teamDetails: team,
	closeModal: jest.fn(),
	mode: "ADD_TEAM",
	methodologies: methodologies,
	productCode: team.productCode,
	saveTeamStatus: DATA_STATUS.INITIAL,
	copyTeamStatus: DATA_STATUS.INITIAL,
	editTeamStatus: DATA_STATUS.INITIAL,
	deleteTeamStatus: DATA_STATUS.INITIAL,
	saveTeam:jest.fn()
};

let component = null;
const getWrapper = () => shallow(<TeamForm {...baseProps} />);

fdescribe("add Team Details", () => {
	beforeEach(() => {
		component = getWrapper();
	});
	describe("Component initate properly", () => {
		it("TeamComposition renders in UI without crashing", async () => {
			const wrapper = getWrapper();
			expect(wrapper).toMatchSnapshot();
		});
	});
	describe("pn Reaching form Populate", () => {
		it(" should update formState values", () => {
			const wrapper = getWrapper();
			wrapper.instance().formPopulate();
			expect(wrapper.state().formControls.teamName.value).toEqual(team.name);
		});
	});
	describe("on changing month values", () => {
		it("  should be validated and added to formState if start month is added", async () => {
			const wrapper = getWrapper();
			let startDateExpected = new Date("Tue Jan 14 2020 00:00:00 GMT+0530");
			wrapper.instance().manageMonthSelection("startMonth", startDateExpected);
			let startDateMoment = moment(startDateExpected, FORM_DATE_FORMAT);
			let endDateMinExpected = startDateMoment.add(1, "day").format(MONTH_DATE_YEAR_FORMAT);
			let endDateExpected = null;
			expect(wrapper.state().formControls.startMonth.value).toEqual(startDateExpected);
			expect(wrapper.state().formControls.endMonth.value).toEqual(endDateExpected);
		});
		it(" they should be validated and added to formState if end date is added", async () => {
			const wrapper = getWrapper();
			let endDateExpected = new Date("Fri Aug 27 2021 23:59:59 GMT+0530");
			wrapper.instance().manageMonthSelection("endMonth", endDateExpected);

			expect(wrapper.state().formControls.endMonth.value).toEqual(endDateExpected);
		});
	});
	describe("on Input Change ", () => {
		it("  should update name in  state if Name is changed", () => {
			const wrapper = getWrapper();
			const event = {
				target: {
					name: "teamName",
					value: "SPARK",
				},
			};
			wrapper.instance().onInputChange(event);
			expect(wrapper.state().formControls.teamName.value).toEqual("SPARK");
		});
		it("  should update Sprint length  in  state if Sprint length is changed", async () => {
			const wrapper = getWrapper();
			const event = {
				target: {
					name: "sprintLength",
					value: "3 weeks",
				},
			};
			wrapper.instance().onInputChange(event);
			expect(wrapper.state().formControls.sprintLength.value).toEqual("3 weeks");
		});
		it("  should update Sprint length  in  state if Sprint length is changed", async () => {
			const wrapper = getWrapper();
			const event = {
				target: {
					name: "scrumMaster",
					value: "Ken",
				},
			};
			wrapper.instance().onInputChange(event, "Ken");
			expect(wrapper.state().formControls.scrumMaster.value).toEqual("Ken");
		});
	});
	describe("on Sprint Velocity Change ", () => {
		it("  should update Sprint Velocity in  state", () => {
			const wrapper = getWrapper();
			const event = {
				value: "3",
				error: false,
				errorMessage: "",
			};
			wrapper.instance().onSprintVelocityChange(event, "blur");
			expect(wrapper.state().formControls.sprintVelocity.value).toEqual("3 points");
		});
	});
	describe("On sbumit click", () => {
		it("should validate form and throw  error if team name is empty ", async () => {
			const wrapper = getWrapper();
			wrapper.instance().onSubmit();
			expect(wrapper.state().formControls.error).toEqual(true);
			expect(wrapper.state().formControls.teamName.errorMsg).toEqual('Please fill out this field')
		});
		it("should validate form and update formState", async () => {
			const wrapper = getWrapper();
			let formState = {
				formControls: {
					error: false,
					errorMessage: "",
					errorDetail: "",
					teamName: {
						value: team.name,
						error: false,
						errorMsg: "",
						required: true,
					},
					methodology: {
						value: team.methodology,
						error: false,
						errorMsg: "",
						required: true,
					},
					sprintLength: {
						value: team.sprintLength,
						error: false,
						errorMsg: "",
						required: true,
					},
					sprintVelocity: {
						value: appendPointsToValue(team.sprintVelocity),
						error: false,
						errorMsg: "",
						min: MIN_SPRINT_VELOCITY,
						max: MAX_SPRINT_VELOCITY,
						required: true,
					},
					scrumMaster: {
						value: team.scrumMaster,
						error: false,
						errorMsg: "",
						required: false,
					},
					startMonth: {
						value: team.startMonth,
						error: false,
						errorMsg: "",
						min: TEAM_START_DATE_MIN,
						max: TEAM_START_DATE_MAX,
						required: true,
					},
					endMonth: {
						value: team.endMonth,
						error: false,
						errorMsg: "",
						min: TEAM_END_DATE_MIN,
						max: TEAM_END_DATE_MAX,
						disabled: false,
						required: true,
					},
				},
			};
			wrapper.setState({formControls: formState.formControls });
			wrapper.instance().onSubmit();
			expect(wrapper.state().savingTeam).toEqual(true);
		});
	});
	
});
