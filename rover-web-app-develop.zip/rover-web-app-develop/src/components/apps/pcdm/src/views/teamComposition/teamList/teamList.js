import React, { useState } from "react";
import "../../../../utilities/pcdm_common.scss";
import "./teamList.scss";
import ToolTip from "../../../components/ToolTip/ToolTip";
import {
  TEAM_LIST_NAME,
  TOOL_TIP_TITLE,
} from "../../../constants/action.constants";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import List from "../../../components/List/list";
import moment from "moment";
import { PlusSquare, PlusCircle, Plus,HelpCircle } from "react-feather";
import CustomButton from "../../../components/forms/Button/button";

export default function TeamList(props) {
  const {
    activeTeams,
    selectedTeamId,
    addTeam,
    canEdit,
    rolledOffTeams,
    nonExtendableLength,
    index,
    getMoreRolledOffTeams,
  } = props;

  const showEmptyList = () => {
    return (
      <div className="list-empty">
        <p>No teams found</p>
        {canEdit ? (
          <p>
            Click <b>+</b> icon to start creating a team
          </p>
        ) : null}
      </div>
    );
  };

  const checkTeamsEndDate = (teamRow) => {
    var endDate = moment(teamRow.endMonth).utc().format();
    var currentDate = moment().utc().format();
    var futureDate = moment(currentDate).add(14, "days");
    var diffInDates = moment(endDate).isAfter(futureDate);
    return !diffInDates;
  };

  /* const checkTeamsEndDate1 = (teamRow) => { 
    var endDate = moment(teamRow.endMonth).utc().format();  // moment.utc(teamRow.endMonth).format();
    var currentDate = moment().utc().format();              // moment.utc().format();
    var diffInDates = moment(endDate).diff(currentDate ,"days")
    return diffInDates <14 ? true : false
  }; */

  const showHead = (title) => {
    return title == TEAM_LIST_NAME.EXISTING_TEAMS ? (
      <div className={`teams-head ${canEdit ? `teams-head--active ` : ``}`} key={1}>
        <p className={canEdit ? "withAddButton" : "withoutAddButton"}>
          {title}
        </p>
        {canEdit ? (
          <CustomButton
            onClick={addTeam}
            title={"Click to add team"}
            className="team-add-link"
          >           
            <Plus size="15" strokeWidth="3" />
            <span className="ml-1">Add Team</span>
          </CustomButton>
        ) : null}
      </div>
    ) : (
        <div className="teams-head teams-head--rolled-off" key={1}>
          <p>{title}</p>
          <ToolTip
            toolTipTitle={TOOL_TIP_TITLE.ROLLED_OFF_TEAMS}
            toolTipMessage={TOOL_TIP_MESSAGE.ROLLED_OFF_TEAMS}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info"
                onClick={(event) => event.stopPropagation()}>
                <HelpCircle
                  size="16"
                  color="#3b77fe"
                  strokeWidth={2}
                />
              </span>
            )}
          />
        </div>
    );
  };
  return (
    <div className="team-list-container">
      <List
        className={"active-teams"}
        list={activeTeams}
        title={() => showHead(TEAM_LIST_NAME.EXISTING_TEAMS)}
        onChange={(t) => props.onTeamClick(t.teamId)}
        selected={{ teamId: selectedTeamId }}
        id="teamId"
        value="name"
        emptyTxt={showEmptyList}
        groupName="active-teams"
        hasToolTip={true}
        checkToolTip={(teamRow) => checkTeamsEndDate(teamRow)}
        hideRadioButton={true}
      />
      <List
        className={"rolled-off-teams"}
        list={rolledOffTeams}
        title={() => showHead(TEAM_LIST_NAME.ROLLED_OFF_TEAMS)}
        onChange={(t) => props.onTeamClick(t.teamId)}
        selected={{ teamId: selectedTeamId }}
        id="teamId"
        value="name"
        emptyTxt={nonExtendableLength > 0 ? "" : "No teams rolled off"}
        groupName="rolled-off-teams"
        isRolledOffTeams={nonExtendableLength > index ? true : false}
        getMore={getMoreRolledOffTeams}
        hideRadioButton={true}
      />
    </div>
  );
}
