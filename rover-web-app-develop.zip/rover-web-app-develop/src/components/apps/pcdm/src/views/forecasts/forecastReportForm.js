import React, { useState, useEffect } from "react";
import { FormModal } from "../../components/FormModal/formModal";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../components/forms/Button/button";
import Datepicker from "../../components/Datepicker/datepicker";
import {
  FORM_CONTROL_DEFAULT,
  FORM_DATE_FORMAT,
  MONTH_YEAR_FORMAT,
} from "../../constants/form.constants";
import moment from "moment";
import cookie from "react-cookies";
import axios from "axios";
import CustomCheckBox, { CustomCheck } from "../../../../../shared/CustomCheckBox/customCheckBox";

export default function ProjectForecastsForm(props) {
  const { showForecastReport, setShowReportForm } = props;
  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    startMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    endMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
  });
  const [progress, setProgress] = useState(false);
  const manageMonthSelection = (type, date) => {
    const { endMonth } = formControls;
    let valueInMoment = moment(date, FORM_DATE_FORMAT);
    let validatedEndMonth = endMonth.value;

    if (type === "startMonth") {
      if (
        endMonth.value &&
        valueInMoment.isAfter(moment(endMonth.value, FORM_DATE_FORMAT))
      ) {
        validatedEndMonth = "";
      }
      setFormControls({
        ...formControls,
        edited: true,
        startMonth: {
          ...formControls.startMonth,
          value: date,
          error: false,
        },
        endMonth: {
          ...formControls.endMonth,
          disabled: false,
          value: validatedEndMonth,
          min: date,
          error: false,
        },
      });
    } else if (type === "endMonth") {
      setFormControls({
        ...formControls,
        edited: true,
        startMonth: {
          ...formControls.startMonth,
          error: false,
        },
        endMonth: {
          ...formControls.endMonth,
          value: date,
          error: false,
        },
      });
    }
  };
  const CHECK = {
    SELECTED: "SELECTED",
    NOT_SELECTED: "NOT_SELECTED",
    PARTIALLY_SELECTED: "PARTIALLY_SELECTED",
  };
  const [includeCompleted, setIncludeCompleted] = useState(false)
  const onSelectCheckbox = () => {
    setIncludeCompleted(!includeCompleted)
  }
  const checkSelected = () => {
    return includeCompleted ? CHECK.SELECTED : CHECK.NOT_SELECTED
  }
  const onSubmit = () => {
    const { startMonth, endMonth } = formControls;
    if (startMonth.value && endMonth.value) {
      let st = moment(startMonth.value)
        .startOf("month")
        .hour(0)
        .minute(0)
        .second(0)
        .millisecond(0)
        .format("YYYY-MM-DD");
      let ed = moment(endMonth.value)
        .endOf("month")
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format("YYYY-MM-DD");
      const token = localStorage.getItem("token");
      const productCode = localStorage.getItem("productCode");
      setProgress(true);
      axios({
        url: `${cookie.load(
          "ROVER_PCD_API"
        )}/pcd/products/download/forecastDetails?startMonth=${st}&endMonth=${ed}&includeCompleted=${includeCompleted}&productCode=${productCode}`,
        method: "GET",
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
        },
        onDownloadProgress(progressEvent) {
          // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
          setProgress(true);
        },
        responseType: "blob",
      })
        .then((response) => {
          setProgress(false);
          const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement("a");
          link.href = url;
          link.target = "_blank";
          link.setAttribute(
            "download",
            `Forecast_details_from_${st}_to_${ed}.xlsx`
          );
          document.body.appendChild(link);
          link.click();
          // window.open(url, "_blank").focus()
          setShowReportForm(false);
        })
        .catch((error) => {
          console.log(error);
          setProgress(false);
        });
    } else {
      setFormControls({
        ...formControls,
        startMonth: {
          ...formControls.startMonth,
          error: startMonth.value ? false : true,
          errorMsg: startMonth.value ? "" : "Please select End Month",
        },
        endMonth: {
          ...formControls.endMonth,
          error: endMonth.value ? false : true,
          errorMsg: endMonth.value ? "" : "Please select End Month",
        },
      });
    }
  };
  const getFormContent = () => {
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field form-group-field--inline">
            <Datepicker
              name="startMonth"
              label={"Start Month"}
              formObj={formControls.startMonth}
              isRequired={formControls.startMonth.required}
              onChange={manageMonthSelection}
              placeholderText={"Ex: Jan, 2020"}
              dateFormat={MONTH_YEAR_FORMAT}
              showMonthYearPicker={true}
            />
            {/* </div> */}
            {/* <div className="pcdm-form__form-group-field"> */}
            <Datepicker
              name="endMonth"
              label={"End Month"}
              formObj={formControls.endMonth}
              isRequired={formControls.endMonth.required}
              onChange={manageMonthSelection}
              dateFormat={MONTH_YEAR_FORMAT}
              placeholderText={"Ex: Apr, 2021"}
              showMonthYearPicker={true}
            />
          </div>
          <CustomCheckBox
              list={[{ key: 1, value: "Include Completed Projects" }]}
              key={"key"}
              value={"value"}
              onCheckboxClick={(filter) => onSelectCheckbox()}
              isSelected={checkSelected}
            />
          {/* <div class="error-message-container"><div class="error-message">{formControls.selectedProducts.errorMsg}</div></div> */}
        </div>
        {formControls.error ? <p>{formControls.errorMessage}</p> : null}
      </form>
    );
  };

  const getFooter = () => {
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.BLUE_GOLD}
          size="md"
          onClick={onSubmit}
          disable={!formControls.edited}
          loading={progress}
          // fluid = {true}
        >
          Download Forecasts Report
        </CustomButton>
      </div>
    );
  };
  const closePopupModal = () => {
    setShowReportForm(false);
  }
  return (
    <>
      <FormModal
        isLoading={false}
        visible={showForecastReport}
        closeModal={() => closePopupModal()}
        header="Export Project Forecasts"
        content={() => getFormContent()}
        footer={() => getFooter()}
        className="project-form"
      />
    </>
  );
}
