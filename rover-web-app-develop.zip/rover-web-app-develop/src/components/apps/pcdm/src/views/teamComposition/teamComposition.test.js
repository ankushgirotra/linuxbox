import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import mockAxios from "axios";
import { products } from "../../../test_fixtures/product.mock";
import { teams } from "../../../test_fixtures/teams.mock";
import { TeamComposition, mapStateToProps } from "./teamComposition.js";
import { methodologies, roleOptions, productCalculation } from "../../../test_fixtures/common.mock";
import { ACTIONS } from "../../constants/action.constants";
import { ADMIN_PERMISSIONS } from "../../constants/access.constants";
import { DATA_STATUS } from "../../constants/service.constant";
import TeamForm from "./teamForm/teamForm"

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());

const baseProps = {
  setMethodologyOptions: jest.fn(),
  getTeams: jest.fn(),
  getProductCalc: jest.fn(),
  getProjects: jest.fn(),
  getSummaryChart: jest.fn(),
  getResourceForecast: jest.fn(),
  showNotification: jest.fn(),
  refreshProductMonthly: jest.fn(),
  getRolledOffTeamsCall: jest.fn(),
  getProductManagerName: jest.fn(),
  productDetails: { ...products[0] },
  productCode: products[0].productCode,
  methodologies: [...methodologies],
  teams: { data: [...teams], status: DATA_STATUS.INITIAL },
  rolledOffTeams: { data: [...teams], status: DATA_STATUS.INITIAL },
  saveTeamStatus: {},
  productCalculation: { data: { ...productCalculation } },
  iiqRole: {PCDM : {VIEW:false, ADMIN:false, EDIT:true}},
  loggedInUser: { user: { id: "ADMIN" }, permissions: [...ADMIN_PERMISSIONS] },
  pcdmAccess: { productCode: "", delegateLanId: "", writeAccess: false },
};
let component = null;
const getWrapper = () => shallow(<TeamComposition {...baseProps} />);
fdescribe("add PCDMContainer component", () => {
  beforeEach(() => {
    component = getWrapper();
  });
  describe("Component initate properly", () => {
    it("TeamComposition renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("On team selection", () => {
    it("Should change tab onClick", () => {
      const wrapper = getWrapper();
      wrapper.find('#teamList').props().onTeamClick(teams[0].teamId)
      wrapper.update();
      wrapper.find('#teamComponent').props()
      expect(wrapper.find('#teamList').props().selectedTeamId).toEqual(teams[0].teamId)
      // wrapper.instance().onTeamSelection(teams[0].teamId);
      // expect(wrapper.state().selectedTeamId).toEqual(teams[0].teamId);
    });
  });
  describe("On modal event", () => {
    it("modall success", () => {
      const wrapper = getWrapper();
      wrapper.find('#teamList').props().addTeam()
      wrapper.update();
      wrapper.find('#openTeamForm').props().closeModal(ACTIONS.SUCCESS, {
        message: "message on success",
        teamId: teams[1].teamId,
      });
      expect(wrapper.find(TeamForm).length).toEqual(0)
      // wrapper.instance().onModalClose(ACTIONS.SUCCESS, {
      //   message: "message on success",
      //   teamId: teams[1].teamId,
      // });
      // expect(wrapper.state().openTeamForm).toEqual(false);
    });
    it("Modal error", () => {
      const wrapper = getWrapper();
      wrapper.find('#teamList').props().addTeam()
      wrapper.update();
      wrapper.find('#openTeamForm').props().closeModal(ACTIONS.Error, {  message: "message on error" });
    //   wrapper.instance().onModalClose(ACTIONS.ERROR, { message: "message on error" });
    });
    it("modal default", () => {
      const wrapper = getWrapper();
      wrapper.find('#teamList').props().addTeam()
      wrapper.update();
      wrapper.find('#openTeamForm').props().closeModal(ACTIONS.WARNING, {  message: "message on error" });
      expect(wrapper.find(TeamForm).length).toEqual(0)
    //   wrapper.instance().onModalClose(ACTIONS.WARNING, { message: "message on error" });
    //   expect(wrapper.state().openTeamForm).toEqual(false);
    });
  });
});
