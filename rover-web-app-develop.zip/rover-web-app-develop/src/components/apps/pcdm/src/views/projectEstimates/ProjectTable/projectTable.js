import React, { useMemo, useState } from "react";
import moment from "moment";
import { HelpCircle, AlertCircle } from "react-feather";
import {
  roundOff, stringToCurrency,
  getFormattedDate, formatNumberWithCommaSeprated
} from "../../../services/form.service";
import { FORM_DATE_FORMAT, PROJECT_OPTIONS } from "../../../constants/form.constants";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import { PROJECT_ACTIONS, TOOL_TIP_TITLE } from "../../../constants/action.constants";
import {
  getStartDateTooltipMsg, getEndDateTooltipMsg,
  getEstimateTypeTooltipMessage, getStartEndDateTooltipMsg
} from "../../../constants/tooltip.messages";
import estimateHistory from "../../../../../../../shared/img/icon-img/history.PNG";
import { getBaselineEstimateHistory } from "../../../templates/projects.template";
import DataGrid, { SelectColumnFilter } from "../../../components/DataGrid/dataGrid";
import Datepicker from "../../../components/Datepicker/datepicker";
import DateRangePicker from "../../../components/DateRangePicker/dateRangePicker";
import ToolTip from "../../../components/ToolTip/ToolTip";
import "./projectTable.scss";

export function ProjectTable({
  projects,
  showCompletedProjects,
  onAddOrEditProject,
  canEdit,
}) {

  const [baselineHistoryList, setbaselineHistoryList] = useState([]);
  
  const columns = useMemo(() => [
    {
      Header: (props) => estimateTypeHeadWithToolTip(),
      accessor: "estimateType",
      Cell: ({ row: { original } }) => showEstimate(original, "estimateType"),
      Filter: SelectColumnFilter,
      filter: "includes",
    },
    // {
    //   Header: "I-Code",
    //   accessor: "icode",
    //   disableFilters: true,
    // },
    {
      Header: "P-Code",
      accessor: "pcode",
    },
    {
      Header: "Project Type",
      accessor: "projectType",
      Filter: SelectColumnFilter,
      Cell: ({ row: { original } }) => formatProjectType(original, "projectType"),
      filter: "includes",
    },
    {
      Header: "Project Name",
      accessor: "projectName",
    },
  /* {
     Header: "Investment Portfolio",
     accessor: "investmentPortfolio",
     Filter: SelectColumnFilter,
     filter: "includes",
   },
   {
     Header: "Delivery Portfolio",
     accessor: "deliveryPortfolio",
     Filter: SelectColumnFilter,
     filter: "includes",
   } */
    {
      Header: "Points",
      accessor: "storyPoints",
      disableFilters: true,
      Cell: ({ row: { original } }) => showPoints(original, "storyPoints", "range", "maxStoryPoints"),
    },
    {
      Header: "Dates",
      accessor: "plannedStart",
      Cell: ({ row: { original } }) => showDate(original, "plannedStart", "plannedEnd"),
      Filter: ({ column: { filterValue = [], setFilter, preFilteredRows, id } }) => {
        return (
          <div className="pcdm-proj_est-date_range_filter">
            {/* --> Filter with two inputs
            <div className="pcdm-proj_est-date_range_filter">
              <Datepicker
                name="startRange"
                label={""}
                formObj={{ value: filterValue[0] ? filterValue[0] : undefined }}
                isRequired={false}
                onChange={(name, startDate) => setFilter((range = []) => [startDate ? startDate : undefined, range[1]])}
                dateFormat={FORM_DATE_FORMAT}
                placeholderText={"MM/DD/YYYY"}
                portalId={"root-potal-pcdm"}
                clearable={true}
                className={"pcdm-filter-input"}
              // customInput={true}
              />
              <Datepicker
                name="endRange"
                label={""}
                formObj={{ value: filterValue[1] ? filterValue[1] : undefined }}
                isRequired={false}
                onChange={(name, endDate) => setFilter((range = []) => [range[0], endDate ? endDate : undefined])}
                dateFormat={FORM_DATE_FORMAT}
                placeholderText={"MM/DD/YYYY"}
                portalId={"root-potal-pcdm"}
                clearable={true}
                className={"pcdm-filter-input"}
              // customInput={true}
              />
            </div> */}
            
            <DateRangePicker
              startRangeDate={filterValue[0] ? filterValue[0] : undefined}
              endRangeDate={filterValue[1] ? filterValue[1] : undefined}
              onStartDateChange={
                (startDate) => setFilter((range = []) =>
                  [startDate ? startDate : undefined, range[1]])
              }
              onEndDateChange={
                (endDate) => setFilter((range = []) =>
                  [range[0], endDate ? endDate : undefined])
              }
              isClearable={true}
              className={"pcdm-filter-input"}
              usePortal={true}
            />
          </div>
        );
      },
      filter: (rows, id, filterValue) => {

        let startRange = !(filterValue[0] === "" || filterValue[0] === undefined || filterValue[0] === null)
        let endRange = !(filterValue[1] === "" || filterValue[1] === undefined || filterValue[1] === null)

        if (startRange && endRange) {
          let startRangeRows = rows.filter((row) => {
            return moment(
              getFormattedDate(row.original[id[0]], FORM_DATE_FORMAT)
            ).isSameOrAfter(getFormattedDate(filterValue[0], FORM_DATE_FORMAT));
          });
          return startRangeRows.filter((row) => {
            return moment(
              getFormattedDate(row.original["plannedEnd"], FORM_DATE_FORMAT)
            ).isSameOrBefore(getFormattedDate(filterValue[1], FORM_DATE_FORMAT));
          });
        } else if (startRange) {
          return rows.filter((row) => {
            return moment(
              getFormattedDate(row.original[id[0]], FORM_DATE_FORMAT)
            ).isSameOrAfter(getFormattedDate(filterValue[0], FORM_DATE_FORMAT));
          });
        } else if (endRange) {
          return rows.filter((row) => {
            return moment(
              getFormattedDate(row.original["plannedEnd"], FORM_DATE_FORMAT)
            ).isSameOrBefore(getFormattedDate(filterValue[1], FORM_DATE_FORMAT));
          });
        } else {
          return rows;
        }
      },
    },
    /*
    {
      Header: "End",
      accessor: "plannedEnd",
      Cell: ({ row: { original } }) => showDate(original, "plannedEnd"),
      Filter: ({ column: { filterValue, setFilter, preFilteredRows, id } }) => {
        return (
          <Datepicker
            name="plannedEnd"
            label={""}
            formObj={{ value: filterValue ? filterValue : null }}
            isRequired={false}
            onChange={(name, date) => setFilter(date)}
            dateFormat={FORM_DATE_FORMAT}
            portalId={"root-potal-pcdm"}
            clearable={true}
            className={"pcdm-filter-input"}
          />
        );
      },
      filter: (rows, id, filterValue) => {
        if (
          filterValue === "" ||
          filterValue === undefined ||
          filterValue === null
        ) {
          return rows;
        } else {
          return rows.filter((row) => {
            return moment(
              getFormattedDate(row.original[id[0]], FORM_DATE_FORMAT)
            ).isSameOrBefore(getFormattedDate(filterValue, FORM_DATE_FORMAT));
          });
        }
      },
    }, */
    {
      Header: "Funding",
      accessor: "funding",
      Filter: SelectColumnFilter,
      filter: "includes",
    },
    {
      Header: (props) => getHeaderWithTooltip("totalProjectHours", "Est. Hours"),
      accessor: "totalProjectHours",
      Cell: ({ row: { original } }) => showHours(original, "totalProjectHours", "range", "maxTotalProjectHours"),
      disableFilters: true,
    },
    {
      Header: (props) => getHeaderWithTooltip("totalProjectCost", "Est. Cost"),
      accessor: "totalProjectCost",
      Cell: ({ row: { original } }) => showCost(original, "totalProjectCost", "range", "maxTotalProjectCost"),
      disableFilters: true,
    },
    {
      Header: (props) => getHeaderWithTooltip("baselineBudget", "Baseline"),
      accessor: "baselineBudget",
      Cell: ({ row: { original } }) => showBudget(original, "baselineBudget"),
      disableFilters: true,
    },
  ]);

  const data = useMemo(() => [...projects.filter((project) => project.active)]);

  const estimateTypeHeadWithToolTip = () => {
    return (
      <div className="pcdm-table-header">
        <div className="pcdm-table_col-header">Estimate Type </div>
        <span onClick={(event) => event.stopPropagation()}>
          <ToolTip
            toolTipMessage={getEstimateTypeTooltipMessage()}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info"
                onClick={(event) => event.stopPropagation()}>
                <HelpCircle
                  size="13"
                  color="#3b77fe"
                  strokeWidth={2}
                />
              </span>
            )}
            margin={"20px"} />
        </span>
      </div>
    );
  };

  const getHeaderToolTip = (title) => {
    var toolTipTitle = "";
    var toolTipMessage = "";
    if (title == "baselineBudget") { //adding the tooltip to header
      toolTipTitle = TOOL_TIP_TITLE.BASELINE_ESTIMATES;
      toolTipMessage = getToolTipMessageHtml(TOOL_TIP_TITLE.BASELINE_ESTIMATES);
    } else if (title === "totalProjectHours") {
      toolTipTitle = "Estimated Hours";
      toolTipMessage = TOOL_TIP_MESSAGE.EST_HRS;
    } else if (title === "totalProjectCost") {
      toolTipTitle = "Estimated Cost";
      toolTipMessage = TOOL_TIP_MESSAGE.EST_COST;
    } else {
      return null;
    }
    return (
      <ToolTip
        toolTipTitle={toolTipTitle}
        toolTipMessage={toolTipMessage}
        content={() => (
          <span className="custom-tool-tip" title="Click to get info"
            onClick={(event) => event.stopPropagation()}>
            <HelpCircle
              size="13"
              color="#3b77fe"
              strokeWidth={2}
            />
          </span>
        )}
        margin={"20px"} />
    );
  };

  const getHeaderWithTooltip = (name, header) => {
    return (
      <div className="pcdm-table-header">
        <div className="pcdm-table_col-header">{header}</div>
        <span onClick={(event) => event.stopPropagation()}>
          {getHeaderToolTip(name)}
        </span>
      </div>
    );
  };

  const formatProjectType = (row, key) => {
    let projectType = PROJECT_OPTIONS.filter((pro) => pro.desc === row[key])[0].value;
    return <label title={projectType}> {projectType} </label>;
  };

  const showDate = (row, key1, key2) => {
    const value1 = getFormattedDate(row[key1], FORM_DATE_FORMAT);
    const value2 = getFormattedDate(row[key2], FORM_DATE_FORMAT);
    const widthVal = key1 === "plannedStart" || "plannedEnd" ? "80%" : "100%";
    const value = `${value1} - ${value2}`;
    return (
      <label
        className="wrap"
        title={value}
        style={{ cusrsor: "pointer", width: `${widthVal}` }}
      >
        {value}
      </label>
    );
  };

  const showEstimate = (row, key) => {
    if (row.completed) {
      return (
        <div className="show-completed-icon">
          <label>{row[key]}</label>
          <i className="fas fa-check-circle"></i>
        </div>
      );
    } else {
      return `${row[key]}`;
    }
  };

  const showPoints = (row, key, isRange, key1) => {
    const value = row[isRange] && row[key1] ? formatNumberWithCommaSeprated(row[key])
      .concat("-").concat(formatNumberWithCommaSeprated(row[key1])) :
      formatNumberWithCommaSeprated(row[key]);
    return <label title={value}>{value}</label>;
  };

  const showHours = (row, key, isRange, key1) => {
    const value = row[isRange] && row[key1] ?
      formatNumberWithCommaSeprated(roundOff(parseFloat(row[key]), 1, true)).concat("-")
        .concat(formatNumberWithCommaSeprated(roundOff(parseFloat(row[key1]), 1, true)))
      : formatNumberWithCommaSeprated(roundOff(parseFloat(row[key]), 1, true));
    return <label title={value} className="calculations_style">{value}</label>;
  };

  const showCost = (row, key, isRange, key1) => {
    const roundOffVal = roundOff(parseFloat(row[key]), 2);
    const value = stringToCurrency(String(roundOffVal), "blur", 2);
    if (row[isRange] && row[key1]) {
      const roundOffVal1 = roundOff(parseFloat(row[key1]), 2);
      const value2 = stringToCurrency(String(roundOffVal1), "blur", 2);
      const valInRange = String(value).concat("-").concat(String(value2))
      return <label title={valInRange} className="calculations_style" >{valInRange}</label>
    };
    return <label title={value} className="calculations_style">{value}</label>;
  };

  const showBudget = (row, key) => {
    const roundOffVal = roundOff(parseFloat(row[key]), 2);
    const value = stringToCurrency(String(roundOffVal), "blur", 2);
    return <label className="wrap calculations_style" title={value}>{value}</label>;
  };

  const getToolTipMessageHtml = (toolTipTitle) => {
    if (toolTipTitle == TOOL_TIP_TITLE.BASELINE_ESTIMATES) {
      return (
        <div>
          {TOOL_TIP_MESSAGE.BASELINE_ESTIMATES[0]}
          <b>{TOOL_TIP_MESSAGE.BASELINE_ESTIMATES[1]}</b>
          {TOOL_TIP_MESSAGE.BASELINE_ESTIMATES[2]}
        </div>
      );
    } else if (toolTipTitle == TOOL_TIP_TITLE.START) {
      return (
        <div>
          Projects must move to <b>Execution</b> once they begin in order for
          them to appear on the Forecasts page. Please edit this project's
          Estimate Type field to <b>Execution</b> if the project will begin on
          the current start date, or move the start date if it will not.
        </div>
      );
    } else {
      return null;
    }
  };

  /*
  const getToolTip = (title) => {
    var toolTipTitle = "";
    var toolTipMessage = "";
    if (title == "baselineBudget") { //adding the tooltip to header
      toolTipTitle = TOOL_TIP_TITLE.BASELINE_ESTIMATES;
      toolTipMessage = getToolTipMessageHtml(TOOL_TIP_TITLE.BASELINE_ESTIMATES);
    } else if (title === "totalProjectHours") {
      toolTipTitle = "Estimated Hours";
      toolTipMessage = TOOL_TIP_MESSAGE.EST_HRS;
    } else if (title === "totalProjectCost") {
      toolTipTitle = "Estimated Cost";
      toolTipMessage = TOOL_TIP_MESSAGE.EST_COST;
    } else {
      return null;
    }
    return (
      <ToolTip
        toolTipTitle={toolTipTitle}
        toolTipMessage={toolTipMessage}
        content={() => (
          <span className="custom-tool-tip" title="Click to get info"
            onClick={(event) => event.stopPropagation()}>
            <HelpCircle
              size="13"
              color="#3b77fe"
              strokeWidth={2}
            />
          </span>
        )}
      ></ToolTip>
    );
  };

  const showInvalidTooltipmsg = (actualStartDate,actualEndDate) => {
    return (
      <div className="startdate_enddate_tooltip">
        <div className="text-justify">
          {getStartDateTooltipMsg(
            actualStartDate.format("MMMM"),
            actualStartDate.format("YYYY")
          )}
        </div>

        <div className="text-justify">
          {getEndDateTooltipMsg(
            actualEndDate.format("MMMM"),
            actualEndDate.format("YYYY")
          )}
        </div>
      </div>
    );
  }; */
  
  const getPlannedStartEndTooltip = (
    type,
    projectStartDate,
    projectEndDate,
    actualStartDate,
    actualEndDate,
    original
  ) => {
    let isIntakeExpiring = false;
    let _14DaysBefore = moment(original.plannedStart).subtract(14, "days");
    isIntakeExpiring = moment().isSameOrAfter(_14DaysBefore);
  
    if (original.estimateType.toUpperCase() === "INTAKE" && isIntakeExpiring) {
      return (
        <ToolTip
          key={`${original.projectEstimateId}`}
          toolTipTitle={"Move to Execution"}
          toolTipMessage={getToolTipMessageHtml("Start")}
          content={() => (
            <span className="custom-tool-tip" title="Click to get info">
              <AlertCircle size="15" color="#d50000" strokeWidth={2.5} />
            </span>
          )}
          toolTipPlacement="right"
        ></ToolTip>
      );
    } else if (original.estimateType.toUpperCase() === "EXECUTION") {
      if (
        actualStartDate._isValid &&
        !projectStartDate.isSameOrBefore(actualStartDate, "month") &&
        actualEndDate._isValid &&
        !projectEndDate.isSameOrAfter(actualEndDate, "month")
      ) {
        return (
          <ToolTip
            key={`${original.projectEstimateId}-start`}
            toolTipTitle={"Invaild Date"}
            toolTipMessage={getStartEndDateTooltipMsg(actualStartDate.format("MMMM"),
              actualStartDate.format("YYYY"), actualEndDate.format("MMMM"),
              actualEndDate.format("YYYY"))}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info">
                <AlertCircle size="15" color="#d50000" strokeWidth={2.5} />
              </span>
            )}
            toolTipPlacement="right"
          ></ToolTip>
        );
      } else if (
        actualStartDate._isValid &&
        !projectStartDate.isSameOrBefore(actualStartDate, "month")
      ) {
        return (
          <ToolTip
            key={`${original.projectEstimateId}-start`}
            toolTipTitle={"Invaild Start Date"}
            toolTipMessage={getStartDateTooltipMsg(
              actualStartDate.format("MMMM"),
              actualStartDate.format("YYYY")
            )}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info">
                <AlertCircle size="15" color="#d50000" strokeWidth={2.5} />
              </span>
            )}
            toolTipPlacement="right"
          ></ToolTip>
        );
      } else if (
        actualEndDate._isValid &&
        !projectEndDate.isSameOrAfter(actualEndDate, "month")
      ) {
        return (
          <ToolTip
            key={`${original.projectEstimateId}end`}
            toolTipTitle={"Invaild End Date"}
            toolTipMessage={getEndDateTooltipMsg(
              actualEndDate.format("MMMM"),
              actualEndDate.format("YYYY")
            )}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info">
                <AlertCircle size="15" color="#d50000" strokeWidth={2.5} />
              </span>
            )}
            toolTipPlacement="right"
          ></ToolTip>
        );
      }
    }
  };

  /*
  const getPlannedStartEndTooltip = (
    type,
    projectStartDate,
    projectEndDate,
    actualStartDate,
    actualEndDate,
    original
  ) => {
    let isIntakeExpiring = false;
    let _14DaysBefore = moment(original.plannedStart).subtract(14, "days");
    isIntakeExpiring = moment().isSameOrAfter(_14DaysBefore);

    if (type.toUpperCase() === "PLANNEDSTART") {
      if (
        original.estimateType.toUpperCase() === "EXECUTION" &&
        actualStartDate._isValid &&
        !projectStartDate.isSameOrBefore(actualStartDate, "month")
      ) {
        return (
          <ToolTip
            key={`${original.projectEstimateId}-start`}
            toolTipTitle={"Invaild Start Date"}
            toolTipMessage={getStartDateTooltipMsg(
              actualStartDate.format("MMMM"),
              actualStartDate.format("YYYY")
            )}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info">
                <AlertCircle
                  size="15"
                  color="#d50000"
                  strokeWidth={2.5}
                />
              </span>
            )}
            toolTipPlacement="right"
          ></ToolTip>
        );
      } else if (
        original.estimateType.toUpperCase() === "INTAKE" &&
        isIntakeExpiring
      ) {
        return (
          <ToolTip
            key={`${original.projectEstimateId}`}
            toolTipTitle={"Move to Execution"}
            toolTipMessage={getToolTipMessageHtml("Start")}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info">
                <AlertCircle
                  size="15"
                  color="#d50000"
                  strokeWidth={2.5}
                />
              </span>
            )}
            toolTipPlacement="right"
          ></ToolTip>
        );
      }
    } else if (
      type.toUpperCase() === "PLANNEDEND" &&
      original.estimateType.toUpperCase() === "EXECUTION" &&
      actualEndDate._isValid &&
      !projectEndDate.isSameOrAfter(actualEndDate, "month")
    ) {
      return (
        <ToolTip
          key={`${original.projectEstimateId}end`}
          toolTipTitle={"Invaild End Date"}
          toolTipMessage={getEndDateTooltipMsg(
            actualEndDate.format("MMMM"),
            actualEndDate.format("YYYY")
          )}
          content={() => (
            <span className="custom-tool-tip" title="Click to get info">
              <AlertCircle
                size="15"
                color="#d50000"
                strokeWidth={2.5}
              />
            </span>
          )}
          toolTipPlacement="right"
        ></ToolTip>
      );
    }
  }; */

  return (
    <div className="project-data-grid-container sc-scroll-vertical">
      <DataGrid
        data={data}
        columns={columns}
        // toolTip={getToolTip}
        showUpdatedDataGrid = {true}
        onCellClick={(row, cell) => {
          if (
            cell.column.id !== "baselineBudget" &&
            cell.column.id !== "plannedStart" &&
            cell.column.id !== "plannedEnd"
          ) {
            var projectAction = row.original.completed
              ? PROJECT_ACTIONS.REOPEN_PROJECT
              : PROJECT_ACTIONS.EDIT_PROJECT;
            if (canEdit) {
              onAddOrEditProject(projectAction, {
                ...row.original,
              });
            }
          }
        }}
        appendToCell={(row, cell) => {
          if (
            row.original.baselineEstimatesHistoryResponseList.length &&
            cell.column.id === "baselineBudget"
          ) {
            return (
              <ToolTip
                key={`${row.original.projectEstimateId}`}
                toolTipTitle={"Baseline History"}
                toolTipMessage={() =>
                  getBaselineEstimateHistory(baselineHistoryList)
                }
                content={() => (
                  <img
                    className="baseline-icon"
                    src={estimateHistory}
                    onClick={() => {
                      setbaselineHistoryList(
                        row.original.baselineEstimatesHistoryResponseList
                      );
                    }}
                  />
                )}
                toolTipPlacement="left"
              ></ToolTip>
            );
          } else if (
            cell.column.id === "plannedStart"
            //  ||
            // cell.column.id === "plannedEnd"
          ) {
            let projectStartDate = moment(row.original.plannedStart).utc();
            let projectEndDate = moment(row.original.plannedEnd).utc();
            let actualStartDate = moment(row.original.actualStartDate).utc();
            let actualEndDate = moment(row.original.actualEndDate).utc();
            return getPlannedStartEndTooltip(
              cell.column.id,
              projectStartDate,
              projectEndDate,
              actualStartDate,
              actualEndDate,
              row.original
            );
          }
        }}
        getCellClassName={(cell) =>
          cell.column.id !== "baselineBudget"
            ? !cell.column.id.startsWith("planned")
              ? "cell-onclick wrap"
              : "cell-onclick start-date"
            : "pos-rel"
        }
        getRowId={(row) =>
          row.original.completed ? "completed-project" : ""
        }
        noRowText={"Click Add project button to start creating projects"}
      />
    </div>
  );
}
