import React, { Component } from "react";
import RoleForm from "./roleForm/roleForm";
import RolesTable from "./RolesTable/rolesTable";
import { getTeamsThunk, getProductCalcThunk } from "../../../store/teams.reducer";
import { getProjectsThunk } from "../../../store/projects.reducer";
import { getSummaryChartThunk, getResourceForecastThunk } from "../../../store/summary.reducer";
import { setRoleOptionsThunk } from "../../../store/roles.reducer";
import { connect } from "react-redux";
import { ACTIONS, TEAM_ACTIONS } from "../../../constants/action.constants";
import { addNotification } from "../../../store/common.reducer";
import { ERROR_MSG } from "../../../constants/message.contants";
import { getTeamsRolesThunk , refreshProductThunk, refreshProductMonthlyThunk } from "../../../store/teamCalculations.reducer";

export class Roles extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRole: {},
      showRoleForm: false,
      formMode: TEAM_ACTIONS.ADD_ROLE,
    };
  }

  componentDidMount = async () => {
    await this.props.setRoleOptions();
  };

  onModalClose =  (status, data, keepModal = false, completeReload = true) => {
    if (status === ACTIONS.SUCCESS) {
      this.props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      if (!keepModal) {
        this.setState({ showRoleForm: false });
      }
       this.props.getTeams(localStorage.getItem("productCode"));
       this.props.getTeamsRoles(localStorage.getItem("productCode"));
      if (completeReload) {
         this.props.refreshProduct(localStorage.getItem("productCode"),  ()=> {
           this.props.getProductCalc(localStorage.getItem("productCode"));
          //  this.props.getProjects(localStorage.getItem("productCode"));
           this.props.getSummaryChart(localStorage.getItem("productCode"));
           this.props.getResourceForecast(localStorage.getItem("productCode"));
        })
      }
      this.props.refreshProductMonthly(localStorage.getItem("productCode"), () => {
        this.props.getProjects(localStorage.getItem("productCode"),);
     });
    } else if (status === ACTIONS.ERROR) {
      this.props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
    } else if (!keepModal) {
      this.setState({ showRoleForm: false });
    }
  };

  onAddOrEditRoleClick = (formMode, data) => {
    if (formMode === TEAM_ACTIONS.ADD_ROLE) {
      this.setState({
        showRoleForm: true,
        formMode: TEAM_ACTIONS.ADD_ROLE,
        selectedRole: {},
      });
    } else if (formMode === TEAM_ACTIONS.EDIT_ROLE) {
      this.setState({
        showRoleForm: true,
        formMode: TEAM_ACTIONS.EDIT_ROLE,
        selectedRole: { ...data },
      });
    }
  };

  getHeader = () => {
    const { formMode } = this.state;
    if (formMode === TEAM_ACTIONS.ADD_ROLE) {
      return "Add Role";
    } else if (formMode === TEAM_ACTIONS.EDIT_ROLE) {
      return "Edit Role";
    }
  };

  render() {
    const { showRoleForm, selectedRole, formMode } = this.state;
    const { roles, team,  canEditRole,iiqRole, teamsRoles  } = this.props;
    const selectedTeamRoles = teamsRoles ? teamsRoles.filter((role)=> role.teamId === team.teamId) : []
    if(roles!=null){
      roles.sort((a,b)=>{
        let name1=a.roleName;
        let name2=b.roleName;
        if(name1<name2)
          return -1;
        if(name1>name2)
          return 1;
        return 0;
      })
    }
    return (
      <div>
        <RolesTable
          onAddOrEditRole={this.onAddOrEditRoleClick}
          roles={roles}
          // roleCalculation={roleCalculation}
          teamRoles={selectedTeamRoles}
          canEditRole={canEditRole}
          iiqRole={iiqRole}
        />
        {showRoleForm ? (
          <RoleForm
            formVisible={showRoleForm}
            header={this.getHeader()}
            selectedRole={selectedRole}
            formMode={formMode}
            roles={roles}
            team={team}
            closeModal={(status, data, keepModal, completeReload) => this.onModalClose(status, data, keepModal, completeReload)}
          />
        ) : null}
      </div>
    );
  }
}

export const mapStateToProps = (state) => ({
  roles: state.RolesReducer.roles,
  teams: state.TeamsReducer.teams.data,
  iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
  teamsRoles: state.TeamCalculationsReducer.teamsRoles.data,
});

export const mapDispatchToProps = (dispatch) => ({
  setRoleOptions: () => dispatch(setRoleOptionsThunk()),
  getTeams: (productId) => dispatch(getTeamsThunk(productId)),
  getTeamsRoles: (productId) => dispatch(getTeamsRolesThunk(productId)),
  getProductCalc: (productCode) => dispatch(getProductCalcThunk(productCode)),
  getProjects: (productCode) => dispatch(getProjectsThunk(productCode)),
  getSummaryChart: (productCode) => dispatch(getSummaryChartThunk(productCode)),
  getResourceForecast: (productCode) => dispatch(getResourceForecastThunk(productCode)),
  refreshProductMonthly: (productCode, callback) =>
    dispatch(refreshProductMonthlyThunk(productCode, callback)),
  showNotification: (notification) => dispatch(addNotification(notification)),
  refreshProduct: (productCode, callback) =>
    dispatch(refreshProductThunk(productCode, callback)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Roles);
