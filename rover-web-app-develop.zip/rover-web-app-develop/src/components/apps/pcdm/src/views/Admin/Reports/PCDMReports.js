import React, { useState, useEffect } from "react";
import { RoverNavigationExtended } from "../../../components/NavigationExtended/navigationExtended";
import ForecastReport from "./forecastReport";
import AccountabilityReport from "./accountabilityReport";
import AvgCostPerPointReport from "./avgCostPerPointReport";
import ProjectEstimatesReport from "./projectEstimatesReport";
import PCDMUsersReport from './PCDMUsersReport';
import TeamsDataReport from './teamsDataReport';
import AllocationReport from "./allocationReport";
import "./PCDMReports.scss";

export default function PCDMReports() {
  const [selectedTab, setSelectedTab] = useState(1);
  useEffect(()=>{
    document.title = "Rover PCDM - Reports"
  },[])
  return (
    <div>
      <RoverNavigationExtended
        className="pcdm-report-generation-container"
        navList={[
          {
            navKey: 1,
            header: () => <>Forecast Report</>,
            content: () => <ForecastReport />,
          },
          {
            navKey: 2,
            header: () => <>Accountability Report</>,
            content: () => <AccountabilityReport />,
          },
          {
            navKey: 3,
            header: () => <>Avg Cost Per Point</>,
            content: () => <AvgCostPerPointReport />,
          },
          {
            navKey: 4,
            header: () => <> Project Estimates</>,
            content: () => <ProjectEstimatesReport />,
          },
          {
            navKey: 5,
            header: () => <>Product Delegates</>,
            content: () => <PCDMUsersReport />,
          },
          {
            navKey: 6,
            header: () => <>Teams Data</>,
            content: () => <TeamsDataReport />,
          },
          {
            navKey: 7,
            header: () => <>{"Allocations >100%"}</>,
            content: () => <AllocationReport />,
          },
        ]}
        activeKey={selectedTab}
        onTabChange={(tab) => setSelectedTab(tab)}
      />
    </div>
  );
}
