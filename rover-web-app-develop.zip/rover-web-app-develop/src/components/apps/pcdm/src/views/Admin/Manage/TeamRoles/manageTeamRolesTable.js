import React, { useMemo } from "react";
import { connect } from "react-redux";
import DataGrid from "../../../../components/DataGrid/dataGrid";
import { PlusCircle } from "react-feather";
import CustomButton from "../../../../components/forms/Button/button";
import "./manageTeamRoles.scss";
import { PCDM_ADMIN_ACTIONS } from "../../../../constants/action.constants";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import sortBy from "../../../../../../../../services/helper.service";
import { CURRENCY, LOCALE } from "../../../../constants/common.constants";

export function ManageTeamRoles(props) {
  const { teamRoles, onAddOrEditTeamRoles } = props;
  const columns = useMemo(() => [
    {
      Header: (props) => teamRoleHead(),
      accessor: "roleName",
      Cell: ({ row: { original } }) => showProduct(original, "roleName"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Employee Default Rate",
      accessor: "employeeDefaultRate",
      Cell: ({ row: { original } }) => showDollerRate(original, "employeeDefaultRate"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Onshore Contractor Default Rate",
      accessor: "onshoreContractorDefaultRate",
      Cell: ({ row: { original } }) => showDollerRate(original, "onshoreContractorDefaultRate"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Offshore Contractor Default Rate",
      accessor: "offshoreContractorDefaultRate",
      Cell: ({ row: { original } }) => showDollerRate(original, "offshoreContractorDefaultRate"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Nearshore Contractor Default Rate",
      accessor: "nearshoreContractorDefaultRate",
      Cell: ({ row: { original } }) => showDollerRate(original, "nearshoreContractorDefaultRate"),
      disableFilters: true,
      disableSortBy: true,
    },
  ]);
  const showProduct = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() => onAddOrEditTeamRoles(PCDM_ADMIN_ACTIONS.EDIT_TEAM_ROLES, { ...row })}
      >
        {row.roleName}
      </LinkExtended>
    );
  };

  const showDollerRate = (row, key) => {
    if (!isNaN(row[key]) && row[key] !== "") {
      return new Intl.NumberFormat(LOCALE.US, {
        style: "currency",
        currency: CURRENCY.USD,
      })
        .format(row[key])
        .replace(".00", "");
    }
    return <span className="empty-dollar">$___</span>;
  };
  const teamRoleHead = () => (
    <div className="add-products-head">
      <p>Role Name</p>
      <CustomButton
        onClick={() => null} //onAddOrEditProduct(PCDM_ADMIN_ACTIONS.ADD_PRODUCT, {})
        title={"Click to add Role"}
        className="products-add-link"
      >
        <span className='mr-1'>ADD</span>
        <PlusCircle size="15" strokeWidth={3} />
      </CustomButton>
    </div>
  );
  return (
    <div className="manage-team-roles-container pcdm-scroll-vertical">
      <DataGrid
        data={sortBy(teamRoles, "roleName") || []}
        columns={columns}
        noRowText={"Click + icon to start adding Role "}
      />
    </div>
  );
}

export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner.data,
  teamRoles: state.PCDMAdminReducer.teamRoles.data,
});

export const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(ManageTeamRoles);
