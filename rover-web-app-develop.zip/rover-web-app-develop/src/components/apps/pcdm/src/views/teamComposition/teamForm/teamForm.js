import React, { Component } from "react";
import TextField from "../../../components/forms/textField/textField";
import SelectDropdown from "../../../components/forms/select/select";
import "./teamForm.scss";
import Datepicker from "../../../components/Datepicker/datepicker";
import {
  DEFAULT_SPRINT_OPTION_ID,
  SPRINT_OPTIONS,
  MONTH_DATE_YEAR_FORMAT,
  FORM_DATE_FORMAT,
  TEAM_END_DATE_MIN,
  TEAM_END_DATE_MAX,
  TEAM_START_DATE_MIN,
  TEAM_START_DATE_MAX,
  DB_DATE_FORMAT,
  MIN_SPRINT_VELOCITY,
  MAX_SPRINT_VELOCITY,
} from "../../../constants/form.constants";
import { TEAM_ACTIONS, ACTIONS } from "../../../constants/action.constants";
import moment from "moment";
import {
  saveTeamThunk,
  editTeamThunk,
  deleteTeamThunk,
  saveTeamReset,
  editTeamReset,
  deleteTeamReset,
  copyTeamThunk,
} from "../../../store/teams.reducer";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import { connect } from "react-redux";
import { DATA_STATUS } from "../../../constants/service.constant";
import ErrorMsg from "../../../components/forms/errorMsg/errorMsg";
import {
  MessageModal,
  DEFAULT_MSG_MODAL_CONFIG,
} from "../../../components/MessageModal/messageModal";
import { validateTeamForm, handleTeamAPIResponse } from "../../../services/team.service";
import { getFormattedDate, appendPointsToValue } from "../../../services/form.service";
import { TEAM_MESSAGES } from "../../../constants/message.contants";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import { FormModal } from "../../../components/FormModal/formModal";
import Checkbox from "../../../components/forms/Checkbox/checkbox";
import CustomSelect from "../../../components/forms/SelectDropdown/selectDropdown";
import AsyncSelect from "../../../components/forms/SelectDropdown/AsyncSelect";
const TEAM_INITIAL_STATE = {
  messageModalConfig: {
    ...DEFAULT_MSG_MODAL_CONFIG,
  },
  keepForm: false,
  copyRoles: false,
  scrumMasterName:"",
  scrumMasterOptions:[],
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    teamName: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
    },
    methodology: {
      value: null,
      error: false,
      errorMsg: "",
      required: true,
    },
    sprintLength: {
      value: DEFAULT_SPRINT_OPTION_ID,
      error: false,
      errorMsg: "",
      required: true,
    },
    sprintVelocity: {
      value: "",
      error: false,
      errorMsg: "",
      min: MIN_SPRINT_VELOCITY,
      max: MAX_SPRINT_VELOCITY,
      required: true,
    },
    scrumMaster: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disabled: true,
    },
    scrumMasterNEW: {
      value: null,
      error: false,
      errorMsg: "",
      required: true,
    },
    startMonth: {
      value: null,
      error: false,
      errorMsg: "",
      min: TEAM_START_DATE_MIN,
      max: TEAM_START_DATE_MAX,
      required: true,
    },
    endMonth: {
      value: null,
      error: false,
      errorMsg: "",
      min: TEAM_END_DATE_MIN,
      max: TEAM_END_DATE_MAX,
      disabled: true,
      required: true,
    },
  },
};
export class TeamForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ...TEAM_INITIAL_STATE,
      messageModalConfig: {
        ...TEAM_INITIAL_STATE.messageModalConfig,
        onClose: this.deleteAction,
      },
      completeReload:true,
    };
  }
  componentDidMount() {
    if (this.props.mode == TEAM_ACTIONS.EDIT_TEAM || this.props.mode == TEAM_ACTIONS.COPY_TEAM) {
      this.formPopulate();
    }
  }
  resetForm = () => {
    this.setState({
      ...TEAM_INITIAL_STATE,
      messageModalConfig: {
        ...TEAM_INITIAL_STATE.messageModalConfig,
        onClose: this.deleteAction,
      },
    });
  };

  handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleTeamAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData
    );
    if (this.state.keepForm) {
      this.resetForm();
      this.props.closeModal(modal.action, modal.props, true);
    } else if (modal) {
      this.props.closeModal(modal.action, modal.props, false, this.state.completeReload);
    } else if (returnState) {
      this.setState({ ...returnState });
    }
  };

  
  formPopulate = () => {
    const {
      name,
      methodology,
      sprintLength,
      sprintVelocity,
      scrumMaster,
      scrumMasterNew,
      scrumMasterNewId,
      startMonth,
      endMonth,
    } = this.props.teamDetails;
    const { formControls } = this.state;
    this.setState({
      scrumMasterName: scrumMasterNew,
      formControls: {
        ...formControls,
        teamName: { ...formControls.teamName, value: name },
        methodology: { ...formControls.methodology, value: methodology },
        sprintLength: { ...formControls.sprintLength, value: sprintLength },
        sprintVelocity: {
          ...formControls.sprintVelocity,
          value: appendPointsToValue(sprintVelocity),
        },
        scrumMaster: { ...formControls.scrumMaster, value: scrumMaster },
        scrumMasterNEW: { ...formControls.scrumMasterNEW, value: scrumMasterNewId },
        startMonth: {
          ...formControls.startMonth,
          value: getFormattedDate(startMonth, "DATE"),
        },
        endMonth: {
          ...formControls.endMonth,
          value: getFormattedDate(endMonth, "DATE"),
          disabled: false,
          min: moment(startMonth).add(1, "day").toDate(),
        },
      },
    });
  };
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
    
  };
  onScrumInputChange = (event) => {
    const { formControls } = this.state;
    const { scrumMasterNames } = this.props;
    let selected;
    console.log(event)
      if(event.value === "000000"){
        this.setState({scrumMasterName:"N/A (Unnammed Resource)"})
      }else{
        selected = scrumMasterNames.data.find(el=>el.employeeId === event.value)
        this.setState({scrumMasterName:selected.name})
      }
      this.setState({
        formControls: {
          ...formControls,
          edited: true,
          error: false,
          scrumMasterNEW: {
            ...formControls["scrumMasterNEW"],
            error: false,
            value: selected ? selected.employeeId : "000000",
          },
        },
      });
  }
  onSprintVelocityChange = (event, on) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: event.error,
        sprintVelocity: {
          ...formControls.sprintVelocity,
          error: event.error,
          value:
            on === "blur"
              ? event.value === ""
                ? event.value
                : appendPointsToValue(Number(event.value))
              : event.value,
          errorMsg: event.errorMessage,
        },
      },
    });
  };
  manageMonthSelection = (type, date) => {
    const { formControls } = this.state;
    let value = moment(date, FORM_DATE_FORMAT);
    if (type === "startMonth") {
      let ed = formControls.endMonth.value,
        ed_disable = formControls.endMonth.disabled,
        ed_min = formControls.endMonth.min;
      if (value.isValid()) {
        ed_min = value.add(1, "day").format(MONTH_DATE_YEAR_FORMAT);
      }
      if (value.isValid() && !formControls.endMonth.value) {
        // If start month is selected and end month is empty enable end month and update its min
        ed_disable = false;
      } else if (
        formControls.endMonth.value &&
        value.isAfter(
          moment(formControls.endMonth.value, MONTH_DATE_YEAR_FORMAT)
        ) /*||
           moment(formControls.endMonth.value, MONTH_DATE_YEAR_FORMAT).diff(
            value,
            "months"
          ) <= 0 */
      ) {
        // If start month is after selected end month or start month end month diff is Less than 1 month ,
        // then reset the end month and its min
        ed = "";
        ed_disable = false;
      }
      this.setState({
        formControls: {
          ...formControls,
          error: false,
          edited: true,
          startMonth: {
            ...formControls.startMonth,
            error: false,
            value: date,
          },
          endMonth: {
            ...formControls.endMonth,
            value: ed,
            disabled: ed_disable,
            min: new Date(getFormattedDate(ed_min)),
          },
        },
      });
    } else if (type === "endMonth") {
      this.setState({
        formControls: {
          ...formControls,
          error: false,
          edited: true,
          endMonth: {
            ...formControls.endMonth,
            error: false,
            value: date,
          },
        },
      });
    }
  };
  reqPayload = () => {
    const { copyRoles,  } = this.state;
    const { teamDetails, mode, teamsRoles } = this.props;
    let payload = {
      name: this.state.formControls.teamName.value.trimRight(),
      methodology: this.state.formControls.methodology.value,
      sprintLength: this.state.formControls.sprintLength.value,
      sprintVelocity: Number(this.state.formControls.sprintVelocity.value.replace(/[^0-9]/g, "")),
      scrumMaster: this.state.formControls.scrumMaster.value.trimRight(),
      startMonth: moment(this.state.formControls.startMonth.value)
        .hour(0)
        .minute(0)
        .second(0)
        .millisecond(0)
        .format(DB_DATE_FORMAT),
      endMonth: moment(this.state.formControls.endMonth.value)
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format(DB_DATE_FORMAT),
      active: true,
      scrumMasterNew: this.state.scrumMasterName,
      scrumMasterNewId: this.state.formControls.scrumMasterNEW.value,
    };
    if (mode == TEAM_ACTIONS.COPY_TEAM && copyRoles) {
      payload = {
        ...payload,
        teamRoleAddRequestList: teamsRoles && teamsRoles.length ? teamsRoles.filter((role)=> role.teamId ===teamDetails.teamId ) : [],
      };
    }
    return payload;
  };
  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls, copyRoles } = this.state;
    let validation = validateTeamForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      this.setState({ savingTeam: true });
      let payload = this.reqPayload();
      if (this.props.mode == TEAM_ACTIONS.ADD_TEAM) {
        this.setState({completeReload : false})
        await this.props.saveTeam(
          payload,
          localStorage.getItem("productCode"),
          this.handleResponse
        );
      } else if (this.props.mode == TEAM_ACTIONS.COPY_TEAM) {
        const { teamsRoles, teamDetails } = this.props
        const roles = teamsRoles && teamsRoles.length ? teamsRoles.filter((role)=> role.teamId ===teamDetails.teamId ) : [];
        if(!copyRoles) {
          this.setState({completeReload : false})
        }else if( copyRoles && roles.length === 0 ){
          this.setState({completeReload : false})
        }else if( copyRoles && roles.length > 0 ){
          this.setState({completeReload : true})
        }
        await this.props.copyTeam(
          payload,
          localStorage.getItem("productCode"),
          this.handleResponse
        );
      } else if (this.props.mode == TEAM_ACTIONS.EDIT_TEAM) {
        const {  sprintLength,  sprintVelocity,  startMonth,  endMonth, teamId } = this.props.teamDetails;
        const { teamsRoles } = this.props
        const roles = teamsRoles && teamsRoles.length ? teamsRoles.filter((role)=> role.teamId ===teamId ) : [];
        if(roles.length === 0) {
          this.setState({completeReload : false})
        }else{
          const completeReload =  sprintLength == formControls.sprintLength.value &&
            sprintVelocity === Number(formControls.sprintVelocity.value.split(" ")[0].trim()) &&
            new Date(startMonth).getTime() === new Date(formControls.startMonth.value).getTime() &&
            new Date(endMonth).getTime() === new Date(formControls.endMonth.value).getTime() 
          this.setState({completeReload : !completeReload})
        }
        await this.props.editTeam(
          payload,
          localStorage.getItem("productCode"),
          this.props.teamDetails.teamId,
          this.handleResponse
        );
      }
    }
  };
  onDeleteClick = () => {
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: TEAM_MESSAGES.DELETE_TEAM_PROMPT_MESSAGE,
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };
  handleDelete = async (buttonClicked, data) => {
    const { messageModalConfig } = this.state;
    const { teamsRoles, teamDetails } = this.props
    if (
      buttonClicked === ACTIONS.YES &&
      messageModalConfig.message === TEAM_MESSAGES.DELETE_TEAM_PROMPT_MESSAGE
    ) {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          title: "Do Not Delete",
          message: TEAM_MESSAGES.DELETE_TEAM_PROMPT_YES,
          variant: ACTIONS.OK,
          visible: true,
          onClose: this.handleDelete,
          dialogClassName: "team-msg-dialog",
          customContent: () => [
            TEAM_MESSAGES.DELETE_TEAM_PROMPT_YES.map((msg) => <p className="text-center">{msg}</p>),
          ],
        },
      });
    } else if (
      buttonClicked === ACTIONS.NO &&
      messageModalConfig.message === TEAM_MESSAGES.DELETE_TEAM_PROMPT_MESSAGE
    ) {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          title: "Delete",
          message: TEAM_MESSAGES.DELETE_TEAM_PROMPT_NO,
          visible: true,
          onClose: this.handleDelete,
          dialogClassName: "team-msg-dialog",
          customContent: () => [
            TEAM_MESSAGES.DELETE_TEAM_PROMPT_NO.map((msg) => <p className="text-center">{msg}</p>),
          ],
        },
      });
    } else if (
      buttonClicked === ACTIONS.YES &&
      messageModalConfig.message[0] === TEAM_MESSAGES.DELETE_TEAM_PROMPT_NO[0]
    ) {
      let payload = { ...this.reqPayload(), active: false };
      const roles = teamsRoles && teamsRoles.length ? teamsRoles.filter((role)=> role.teamId ===teamDetails.teamId ) : [];
      if(roles.length === 0){
        this.setState({completeReload : false})
      }
      await this.props.deleteTeam(
        payload,
        localStorage.getItem("productCode"),
        this.props.teamDetails.teamId,
        this.handleResponse
      );
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    } else if (
      buttonClicked === ACTIONS.CLOSE ||
      buttonClicked === ACTIONS.OK ||
      (buttonClicked === ACTIONS.NO &&
        messageModalConfig.message[0] === TEAM_MESSAGES.DELETE_TEAM_PROMPT_NO[0])
    ) {
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    }
  };
  // onFormatOptionLabel = (data) => {
  //   return <div><span className="formatOptionLabel">{data.label} </span> <span className="formatOptionvalue">- {data.value2.lanId}</span></div>
  // }
  onFormatOptionLabel = (data) => {
  return <div><span className="formatOptionLabel">{data.label} </span>
   <span className="formatOptionvalue">{data.value !== "000000" ?`- ${data.value2}`:null}</span></div>
  }
  getTeamForm = () => {
    const { formControls, copyRoles, scrumMasterOptions } = this.state;
    const { scrumMasterNames } = this.props;
    const { methodologies, mode } = this.props;
    let sortedList=[]
    if (scrumMasterNames && scrumMasterNames.data && scrumMasterNames.data.length) {
      sortedList = scrumMasterNames.data.sort((a,b)=>{if(a.name>b.name) return 1
        else if(a.name<b.name) return -1
        else return 0
      })
      sortedList.unshift({name:"N/A (Unnammed Resource)", employeeId:"000000"})
      // this.setState({ scrumMasterOptions: sortedList.slice(0, 100) });
    }
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field form-group-field--inline ">
            <TextField
              name="teamName"
              label={"Team name"}
              formObj={formControls.teamName}
              isRequired={formControls.teamName.required}
              type="text"
              onChange={this.onInputChange}
            />
          {/* </div> */}
          {/* <div className="pcdm-form__form-group-field"> */}
            <CustomSelect
              name="methodology"
              label={"Methodology"}
              placeholder="Select a Methodology Type"
              formObj={formControls.methodology}
              config={{
                 options: methodologies,
                 value: "description",
                 id: "description",
              }}
              formatOptionLabel={(prd) => `${prd.label}`}
              isRequired={formControls.methodology.required}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
          <div className="pcdm-form__form-group-field form-group-field--inline ">
            <CustomSelect
              name="sprintLength"
              label={"Sprint length"}
              placeholder="Select Sprint Length"
              formObj={formControls.sprintLength}
              config={{
                 options: SPRINT_OPTIONS,
                 value: "desc",
                 id: "desc",
              }}
              formatOptionLabel={(prd) => `${prd.label}`}
              isRequired={formControls.sprintLength.required}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            /> 
            <TextField
              name="sprintVelocity"
              label={"Sprint velocity"}
              formObj={formControls.sprintVelocity}
              isRequired={formControls.sprintVelocity.required}
              type="number"
              placeholder="points"
              min={formControls.sprintVelocity.min}
              max={formControls.sprintVelocity.max}
              onChange={(e) => this.onSprintVelocityChange(e, "")}
              onBlur={(e) => this.onSprintVelocityChange(e, "blur")}
            />
          </div>
          {/* {this.props.mode !== TEAM_ACTIONS.ADD_TEAM ? 
          <div className="pcdm-form__form-group-field">
          <TextField
            name="scrumMaster"
            label={"Scrum master/Team lead"}
            formObj={formControls.scrumMaster}
            isRequired={formControls.scrumMaster.required}
            type="text"
            onChange={this.onInputChange}
          />
        </div> : null} */}
          <div className="pcdm-form__form-group-field form-group-field--inline ">
            <AsyncSelect
              name="scrumMasterNEW"
              label={"Scrum master/Team lead"}
              placeholder="Select Scrum master/Team lead"
              formObj={formControls.scrumMasterNEW}
              config={{
                 options: [...sortedList],
                 value: "name",
                 id: "employeeId",
                 id2: "lanId",
              }}
              containerClassName = "scrumMasterTooltip"
              // formatOptionLabel={(prd) => `${prd.label}`}
              isRequired={formControls.scrumMasterNEW.required}
              onChange={(e) => {
                this.onScrumInputChange(e)
              }
              }
              formatOptionLabel={(prd) =>
                // `${prd.value}  -  ${prd.label}`
                this.onFormatOptionLabel(prd)
              }
              customLabel={true}
              showDefaultValues = {true}
              // onInputChange={this.onInputOptionChange}
              errorTooltip = {formControls.scrumMasterNEW.error}
              toolTipMessage = {TOOL_TIP_MESSAGE.SCRUM_MASTER_NEW}
            /> 
          {/* </div> */}
          <div className="pcdm-form__form-group-field form-group-field--inline ">
            <Datepicker
              name="startMonth"
              label={"Start Date"}
              formObj={formControls.startMonth}
              isRequired={formControls.startMonth.required}
              onChange={this.manageMonthSelection}
              dateFormat={MONTH_DATE_YEAR_FORMAT}
              customInput={true}
            />
            <Datepicker
              name="endMonth"
              label={"End Date"}
              formObj={formControls.endMonth}
              isRequired={formControls.endMonth.required}
              onChange={this.manageMonthSelection}
              dateFormat={MONTH_DATE_YEAR_FORMAT}
              customInput={true}
            />
          </div>
          </div>
          {mode === TEAM_ACTIONS.COPY_TEAM ? (
            <div className="pcdm-form__form-group-field copy-team-roster-checkbox">
              <Checkbox
                label={"Copy Rosters from this team"}
                checked={copyRoles}
                onChange={() =>
                  this.setState({
                    copyRoles: !copyRoles,
                  })
                }
              />
            </div>
          ) : null}
        </div>
        {formControls.error ? (
          <ErrorMsg message={formControls.errorMessage} errorDetail={formControls.errorDetail} />
        ) : null}
      </form>
    );
  };
  getFooter = () => {
    const { edited } = this.state.formControls;
    const { mode } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          onClick={() => {
            this.setState({ keepForm: false });
            this.onSubmit();
          }}
        >
          Save
        </CustomButton>
        {mode === TEAM_ACTIONS.ADD_TEAM ? (
        <div className="form-add-another-button">
          <CustomButton
            variant={BUTTON_VARIANTS.LIGHT}
            size="md"
            onClick={() => {
              this.setState({ keepForm: true });
              this.onSubmit();
            }}
          >
            Save and Add Another
          </CustomButton>
        </div>  
        ) : null}
        {mode === TEAM_ACTIONS.EDIT_TEAM ? (
        <div className="form-delete-button">
          <CustomButton
            disable={edited}
            variant={BUTTON_VARIANTS.ERROR}
            onClick={this.onDeleteClick}
            size="md"
          >
            Delete
          </CustomButton>
        </div>
        ) : null}
        {/* <div >
          <a
            onClick={this.props.closeModal}
            className="form-cancel-button"
          >
            Cancel
          </a>
        </div> */}
         <div id="cancel_button">
            <a role="button"
              className="collapse-link"
              aria-expanded="false"
              onClick={this.props.closeModal} >Cancel</a>
          </div>
      </div>
    );
  };
  render() {
    const { messageModalConfig } = this.state;
    const {
      saveTeamStatus,
      editTeamStatus,
      deleteTeamStatus,
      copyTeamStatus,
      header,
      closeModal,
      formVisible,
    } = this.props;
    return (
      <>
        <FormModal
          isLoading={
            saveTeamStatus.status === DATA_STATUS.LOADING ||
            copyTeamStatus.status === DATA_STATUS.LOADING ||
            editTeamStatus.status === DATA_STATUS.LOADING ||
            deleteTeamStatus.status === DATA_STATUS.LOADING
          }
          visible={formVisible}
          closeModal={closeModal}
          header={header}
          content={this.getTeamForm}
          footer={this.getFooter}
          className="team-form pcdm-form-new"
          isSCForm={true}
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

export const mapStateToProps = (state) => ({
  saveTeamStatus: state.TeamsReducer.saveTeamStatus,
  copyTeamStatus: state.TeamsReducer.copyTeamStatus,
  editTeamStatus: state.TeamsReducer.editTeamStatus,
  deleteTeamStatus: state.TeamsReducer.deleteTeamStatus,
  teamsRoles: state.TeamCalculationsReducer.teamsRoles.data,
  scrumMasterNames: state.TeamCalculationsReducer.scrumMasterData,
});
export const mapDispatchToProps = (dispatch) => ({
  saveTeam: (payload, productCode, callback) =>
    dispatch(saveTeamThunk(payload, productCode, callback)),
  copyTeam: (payload, productCode, callback) =>
    dispatch(copyTeamThunk(payload, productCode, callback)),
  editTeam: (payload, productCode, teamId, callback) =>
    dispatch(editTeamThunk(payload, productCode, teamId, callback)),
  deleteTeam: (payload, productCode, teamId, callback) =>
    dispatch(deleteTeamThunk(payload, productCode, teamId, callback)),
  resetSaveTeam: () => dispatch(saveTeamReset()),
  resetEditTeam: () => dispatch(editTeamReset()),
  resetDeleteTeam: () => dispatch(deleteTeamReset()),
});
export default connect(mapStateToProps, mapDispatchToProps)(TeamForm);