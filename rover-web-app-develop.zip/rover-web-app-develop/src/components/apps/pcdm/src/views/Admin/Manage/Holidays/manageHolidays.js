import React, { useMemo, useState } from "react";
import { connect } from "react-redux";
import DataGrid from "../../../../components/DataGrid/dataGrid";
import CustomButton from "../../../../components/forms/Button/button";
import "../../admin.scss";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import ManageHolidayForm from "./manageHolidayForm";
import { addNotification } from "../../../../store/common.reducer";
import {
  ACTIONS,
  PCDM_ADMIN_ACTIONS
} from "../../../../constants/action.constants";
import { ADMIN_MANAGE_HOLIDAYS } from "../../../../constants/message.contants";
import { MONTH_DATE_YEAR_FORMAT } from "../../../../constants/form.constants";
import { getHolidayDetailsThunk } from "../../../../store/admin.reducer";
import moment from "moment";
import { PlusCircle } from "react-feather";

export function ManageHolidays(props) {

  const { holiDayDetails, showNotification, getHolidayDetails } = props;

  const [formOpen, setFormOpen] = useState(false);
  const [selectedHoliday, setSelectedHoliday] = useState({})
  const [formMode, setFormMode] = useState(null)

  const holidayArr = useMemo(() => {
    let tempHoliday = holiDayDetails.length ?  [...holiDayDetails] : []
    tempHoliday = tempHoliday.map((holiday) => ({
      holidayName: holiday.holidayName,
      holidayDate: holiday.holidayDate,
      holidayId: holiday.holidayId,
    }));
    return tempHoliday;
  }, [holiDayDetails])

  const columns = useMemo(() => [
    {
      Header: (props) => holidayHead(),
      accessor: "holidayName",
      Cell: ({ row: { original } }) => showHolidayName(original, "holidayName"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Date",
      accessor: "holidayDate",
      Cell: ({ row: { original } }) => showHolidayDate(original, "holidayDate"),
      disableFilters: true,
      disableSortBy: false,
      sortTypes: "datetime",
    },
  ]);

  const holidayHead = () => (
    <div className="add-holidays-head">
      <p>Holiday</p>
      <CustomButton
        onClick={() => onAddorEditHolidays(PCDM_ADMIN_ACTIONS.ADD_HOLIDAY, {})}
        title={"Click to add Holiday"}
        className="holidays-add-link"
      >
        <span className='mr-1'>Add</span>
        <PlusCircle size="15" strokeWidth={3} />
      </CustomButton>
    </div>
  );

  const showHolidayName = (row, key) => {
    return (
      <LinkExtended className="td-product" onClick={() => onAddorEditHolidays(PCDM_ADMIN_ACTIONS.EDIT_HOLIDAY, { ...row})}>
        {row.holidayName}
      </LinkExtended>
    );
  };

  const showHolidayDate = (row, key) => {
    let date = moment(row.holidayDate).format(MONTH_DATE_YEAR_FORMAT);
    return date;
  }

  const onAddorEditHolidays = (formmode, data) => {
    setFormOpen(true);
    setSelectedHoliday({ ...data})
    setFormMode(formmode)
  };

  const onModalClose = (status, data, keepModal = false) => {
    if (status === PCDM_ADMIN_ACTIONS.ADD_HOLIDAY_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: ADMIN_MANAGE_HOLIDAYS.ADD_HOLIDAY_SUCCESS_MSG,
      });
    } else if (status === PCDM_ADMIN_ACTIONS.ADD_HOLIDAY_ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: data && data.response && data.response.data && data.response.data.length
          ? data.response.data[0].message : ADMIN_MANAGE_HOLIDAYS.ADD_HOLIDAY_ERROR_MSG,
      });
    }else if (status === PCDM_ADMIN_ACTIONS.EDIT_HOLIDAY_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: ADMIN_MANAGE_HOLIDAYS.EDIT_HOLIDAY_SUCCESS_MSG,
      });
    } else if (status === PCDM_ADMIN_ACTIONS.EDIT_HOLIDAY_ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: data && data.response && data.response.data && data.response.data.length
          ? data.response.data[0].message : ADMIN_MANAGE_HOLIDAYS.ADD_HOLIDAY_ERROR_MSG,
      });
    } else if (status === PCDM_ADMIN_ACTIONS.DELETE_HOLIDAY_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: ADMIN_MANAGE_HOLIDAYS.DELETE_HOLIDAY_SUCCESS_MSG,
      });
    } else if (status === PCDM_ADMIN_ACTIONS.DELETE_HOLIDAY_ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: data && data.response && data.response.data && data.response.data.length
          ? data.response.data[0].message : ADMIN_MANAGE_HOLIDAYS.DELETE_HOLIDAY_ERROR_MSG,
      });
    }
    getHolidayDetails();
    setFormOpen(false);
  };

  return (
    <div className="manage-holidays-container pcdm-scroll-vertical">
      <DataGrid
        data={holidayArr}
        columns={columns}
        noRowText={"Click + icon to start adding Holiday"}
      />
      {formOpen ? <ManageHolidayForm
        formOpen={formOpen}
        closePopupModal={onModalClose}
        holiDayDetails={holiDayDetails}
        selectedHoliday = {selectedHoliday}
        formMode = {formMode}
      /> : null}
    </div>
  );
}

export const mapStateToProps = (state) => ({
  holiDayDetails: state.PCDMAdminReducer.getHolidayDetails.data,
});

export const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
  getHolidayDetails: () => dispatch(getHolidayDetailsThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageHolidays);
