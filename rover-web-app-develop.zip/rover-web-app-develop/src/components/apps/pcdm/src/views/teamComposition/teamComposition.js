import React, { useState, useEffect } from "react";
import Info from "../../components/info/info";
import "./teamComposition.scss";
import { Container, Row, Col } from "react-bootstrap";
import TeamList from "./teamList/teamList";
import Team from "./team/team";
import TeamForm from "./teamForm/teamForm";
import {
  TEAM_ACTIONS,
  ACTIONS,
  TEAM_LIST_NAME,
  TOOL_TIP_TITLE,
} from "../../constants/action.constants";
import { TOOL_TIP_MESSAGE, ERROR_MSG } from "../../constants/message.contants";
import {
  setMethodologyOptionsThunk,
  getTeamsThunk,
  getProductCalcThunk,
  getRolledOffTeamsThunk,
} from "../../store/teams.reducer";
import {
  getSummaryChartThunk,
  getResourceForecastThunk,
} from "../../store/summary.reducer";
import CustomButton from "../../components/forms/Button/button";
import { getProjectsThunk } from "../../store/projects.reducer";
import { connect } from "react-redux";
import { TEAM_EDIT, ROLE_EDIT } from "../../constants/access.constants";
import { roundOff, stringToCurrency } from "../../services/form.service";
import ToolTip from "../../components/ToolTip/ToolTip";
import moment from "moment";
import { withRouter } from "react-router";
import ExtendTeamForm from "./extendTeamForm/ExtendTeamForm";
import { addNotification } from "../../store/common.reducer";
import { OverlayLoader } from "../../components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../constants/service.constant";
import {
  DEFAULT_MSG_MODAL_CONFIG,
  MessageModal,
} from "../../components/MessageModal/messageModal";
import CustomCheckBox, { CustomCheck } from "../../../../../shared/CustomCheckBox/customCheckBox";
import { getAccess } from "../../../../../../services/auth.services";
import { Download, HelpCircle } from "react-feather";
import axios from "axios";
import {
  refreshProductThunk,
  setMonthDataCalculationsThunk,
  getTeamsSprintVelocityThunk,
  getTeamsRolesThunk,
  refreshProductMonthlyThunk,
} from "../../store/teamCalculations.reducer";
import ExportTeamCompositionForm from "./exportTeamCmpositionForm";

export function TeamComposition(props) {
  const [openTeamForm, setOpenTeamForm] = useState(false);
  const [openExtendForm, setOpenExtendForm] = useState(false);
  const [selectedTeamId, setSelectedTeamId] = useState(null);
  const [formMode, setFormMode] = useState(TEAM_ACTIONS.ADD_TEAM);
  const [messageModalConfig, setMessageModalConfig] = useState({
    ...DEFAULT_MSG_MODAL_CONFIG,
  });
  const [progress, setProgress] = useState(null);
  const [extendable, setExtendable] = useState([]);
  const [saveRolledOffTeams, setSaveRolledOffTeams] = useState([]);
  const onTeamSelection = (teamId) => {
    setSelectedTeamId(teamId);
  };
  const {
    getTeams,
    productCode,
    getProductCalc,
    getProjects,
    getSummaryChart,
    getResourceForecast,
    teams,
    productDetails,
    methodologies,
    productCalculation,
    saveTeamStatus,
    setMethodologyOptions,
    loggedInUser: { user, permissions },
    pcdmAccess,
    rolledOffTeams,
    getRolledOffTeamsCall,
    refreshProduct,
    monthCalculations,
    refreshProductMonthly,
  } = props;
  const onModalClose = async (
    status,
    data,
    keepModal = false,
    completeReload = true
  ) => {
    if (status === ACTIONS.SUCCESS) {
      props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      if (data.teamId) {
        setSelectedTeamId(data.teamId);
      }
      if (!keepModal) {
        setOpenExtendForm(false);
        setOpenTeamForm(false);
      }
      getTeams(productCode);
      refreshProductMonthly(productCode, () => {
        getProjects(productCode);
     });
      props.getTeamsSprintVelocity(productCode);
      if (data.copyRoles) {
         props.getTeamsRoles(productCode);
      }
      if (
        data.endMonth &&
        !(moment().diff(moment(data.endMonth), "months") < 1)
      ) {
        setSaveRolledOffTeams([]);
        await getRolledOffTeamsCall(productCode, "");
      }
      
      setSelectedTeamId(data.teamId);
      reloadApis(data, completeReload);
    } else if (status === ACTIONS.ERROR) {
      props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
    } else if (!keepModal) {
      setOpenTeamForm(false);
      setOpenExtendForm(false);
    }
  };

  const reloadApis =  (data, completeReload) => {
    if (data.actionType) {
      if (data.actionType === TEAM_ACTIONS.ADD_TEAM) {
        if (data.copyRoles && data.noOfRosters > 0) {
          monthCalculations(data.teamId,  () => {
             refreshProduct(productCode, () => {
               getProductCalc(productCode);
              //  getProjects(productCode);
               getSummaryChart(productCode);
               getResourceForecast(productCode);
            });
          });
        } else if (
          (data.copyTeam && data.noOfRosters === 0) ||
          !data.copyTeam
        ) {
           monthCalculations(data.teamId, () => {});
        }
      } else if (data.actionType === TEAM_ACTIONS.EDIT_TEAM) {
        if (data.startMonthFlag || data.endMonthFlag) {
           monthCalculations(data.teamId, () => {
             refreshProduct(productCode, () => {
               getProductCalc(productCode);
              //  getProjects(productCode);
               getSummaryChart(productCode);
               getResourceForecast(productCode);
            });
          });
        } else if (completeReload) {
           refreshProduct(productCode, () => {
             getProductCalc(productCode);
            //  getProjects(productCode);
             getSummaryChart(productCode);
             getResourceForecast(productCode);
          });
        }
      }else if(data.actionType === TEAM_ACTIONS.DELETE_TEAM){
        if(completeReload){
           refreshProduct(productCode, () => {
             getProductCalc(productCode);
            //  getProjects(productCode);
             getSummaryChart(productCode);
             getResourceForecast(productCode);
          });
        }
      }
    }
  };

  useEffect(() => {
    getTeams(productCode);
    setMethodologyOptions();
    getProductCalc(productCode);
     props.getTeamsRoles(productCode);
    //  props.scrumMasterList();
  }, []);
  useEffect(() => {
    if (teams.data && teams.data.length) {
      let extendable_ = [];
      teams.data.map((team) => {
        if (isTeamRolledOff(team)) {
          extendable_.push(team);
        }
      });
      extendable_.sort(function (team1, team2) {
        var date1 = moment(team1.endMonth);
        var date2 = moment(team2.endMonth);
        return date2.diff(date1);
      });
      setExtendable(extendable_);
      setSaveRolledOffTeams([]);
    }
  }, [teams]);
  const getMoreRolledOffTeams = () => {
    if (saveRolledOffTeams.length === 0) {
      getRolledOffTeamsCall(productCode, "");
    } else {
      let query = "?";
      let count = 0;
      saveRolledOffTeams.forEach((team) => {
        if (count > 0) {
          query = query + "&";
        }
        query = query + "id=" + team.teamId;
        count = count + 1;
      });
      getRolledOffTeamsCall(productCode, query);
    }
  };
  useEffect(() => {
    if (
      rolledOffTeams.data &&
      rolledOffTeams.data.length &&
      rolledOffTeams.status === DATA_STATUS.SUCCESS
    ) {
      setSaveRolledOffTeams([...saveRolledOffTeams, ...rolledOffTeams.data]);
    }
  }, [rolledOffTeams]);
  const showCost = (costVal) => {
    const roundOffVal = roundOff(parseFloat(costVal), 2);
    return stringToCurrency(String(roundOffVal), "blur", 2);
  };
  const getSelectedTeamDetails = (teamId) => {
    const team = teams.data.filter(
      (team) => team.teamId && team.teamId === teamId
    )[0];
    const team2 = saveRolledOffTeams.length
      ? saveRolledOffTeams.filter(
          (team) => team.teamId && team.teamId === teamId
        )[0]
      : undefined;
    return team ? team : team2;
  };
  const getTeamCalc = (teamId) => {
    if (
      productCalculation.data.teamCalculation &&
      productCalculation.data.teamCalculation.length
    ) {
      return productCalculation.data.teamCalculation.filter(
        (team) => team.teamId === teamId
      )[0];
    } else {
      return {};
    }
  };
  const getActiveTeams = () => {
    if (teams.data && teams.data.length) {
      return teams.data.filter((team) => !isTeamRolledOff(team));
    } else {
      return [];
    }
  };
  const getRolledOffTeams = () => {
    if (teams.data && teams.data.length) {
      return teams.data.filter((team) => isTeamRolledOff(team));
    } else {
      return [];
    }
  };
  const isTeamRolledOff = (team) => {
    /* below codition is added as A FIX , on delete getting team as null where team.endDate is throwing
    undefined error */
    if (team === null || team === undefined) {
      return true;
    }
    return moment(team.endMonth).isBefore(moment());
  };

  const isEligibleForExtend = (team) => {
    if (team === null || team === undefined) {
      return false;
    }
    return moment().diff(moment(team.endMonth), "months") < 1;
  };
  const onAddTeamClick = () => {
    setFormMode(TEAM_ACTIONS.ADD_TEAM);
    setOpenTeamForm(true);
  };
  const onEditTeamClick = () => {
    setFormMode(TEAM_ACTIONS.EDIT_TEAM);
    setOpenTeamForm(true);
  };
  const onCopyTeamClick = () => {
    setFormMode(TEAM_ACTIONS.COPY_TEAM);
    setOpenTeamForm(true);
  };
  const onExtendTeamClick = () => {
    setFormMode(TEAM_ACTIONS.EXTEND_TEAM);
    setOpenExtendForm(true);
  };
  const getHeader = () => {
    if (formMode === TEAM_ACTIONS.ADD_TEAM) {
      return "Add Team";
    } else if (formMode === TEAM_ACTIONS.EDIT_TEAM) {
      return "Edit Team";
    } else if (formMode === TEAM_ACTIONS.EXTEND_TEAM) {
      return "Extend Team";
    } else if (formMode === TEAM_ACTIONS.COPY_TEAM) {
      return "Copy Team";
    }
  };
  
  const [showExportTeamForm, setShowExportTeamForm] = useState(false)
  
  
  const closeMessageModal = () => {
    setMessageModalConfig({
      ...messageModalConfig,
      visible: false,
    });
  };
  const exportTeamComposition = () => {
    setShowExportTeamForm(true)
  };

  const onCloseExportTeamForm = () => {
    setShowExportTeamForm(false)
  }
  // const info = {
  //   "Product Manager": productDetails ? props.getProductManagerName() : null,
  //   "Product Line": productDetails && productDetails.portfolio,
  //   Product: productDetails && productDetails.name,
  //   "PRD Code": productDetails && productDetails.productCode,
  // };
  const tolltipMsgElement = () => {
    return (
      <div>
        <b>Avg. Cost Per Point</b> is calculated by dividing the Total Team Cost
        for all active teams by the Total Team Capacity for all active teams
        (teams are considered active if they have not yet rolled off and if they
        have at least one saved role).
        <br />
        <br />
        <b>Total Team Capacity</b> = (Team Velocity / (Team Sprint Length * 5))
        * the number of business days between the Team Start Date and End Date
        <br />
        <br />
        <b>Total Team Cost</b> = (Team Cost per Sprint / (Team Sprint Length *
        5)) * the number of business days between the Team Start Date and End
        Date
      </div>
    );
  };
  return (
    <div className="pcdm-container" style={{ position: "relative" }}>
      <OverlayLoader
        loading={
          teams.status === DATA_STATUS.LOADING ||
          rolledOffTeams.status === DATA_STATUS.LOADING
        }
      />

      <Container fluid>
        <Row className="pcdm-team_comp-container">
          <Col sm={12} md={12} lg={12} xl={12} className="pcdm-tc_panel"> 
            <div className="product-info">
              {!props.iiqRole.PCDM.VIEW &&
                (<div className="export-team-btn">
                  <CustomButton
                    onClick={() => exportTeamComposition()}
                    title={"Click to Export Team Composition"}
                    className="export-team-button"
                  >
                    <Download size={15} strokeWidth={3} />
                    <span>Export Team Composition Data</span>
                  </CustomButton>
                </div>
                )}
              <div className="avg-cost">
                <span>Average Cost Per Point: {""}
                {productCalculation.data
                  ? showCost(productCalculation.data.avgCostPerPoint)
                  : ""}
                <ToolTip
                  toolTipTitle={TOOL_TIP_TITLE.AVG_COST_PER_POINT}
                  toolTipMessage={tolltipMsgElement}
                ></ToolTip> </span>
              </div>
            </div>
            <TeamList
              id="teamList"
              activeTeams={getActiveTeams()}
              rolledOffTeams={[...extendable, ...saveRolledOffTeams]}
              onTeamClick={(t) => onTeamSelection(t)}
              selectedTeamId={selectedTeamId}
              teamListTitle={TEAM_LIST_NAME.EXISTING_TEAMS}
              addTeam={onAddTeamClick}
              canEdit={pcdmAccess.writeAccess}
              nonExtendableLength={productCalculation.data.rolledOffTeamCount}
              index={saveRolledOffTeams.length}
              getMoreRolledOffTeams={getMoreRolledOffTeams}
            />
          </Col>

          <Col sm={12} md={12} lg={12} xl={12} className="pcdm-tc_info_n_table">
            {selectedTeamId ? (
              <Team
                id="teamComponent"
                // teamCalculation={getTeamCalc(selectedTeamId)}
                selectedTeam={getSelectedTeamDetails(selectedTeamId)}
                editTeam={onEditTeamClick}
                copyTeam={onCopyTeamClick}
                extendTeam={onExtendTeamClick}
                haveEditTeamPermission={pcdmAccess.writeAccess}
                haveEditRolePermission={pcdmAccess.writeAccess}
                isRolledOff={() =>
                  isTeamRolledOff(getSelectedTeamDetails(selectedTeamId))
                }
                isEligibleForExtend={() =>
                  isEligibleForExtend(getSelectedTeamDetails(selectedTeamId))
                }
                history={props.history}
              />
            ) : null}
          </Col>
        </Row>
      </Container>
      {openTeamForm ? (
        <TeamForm
          id="openTeamForm"
          formVisible={openTeamForm}
          header={getHeader()}
          teamDetails={getSelectedTeamDetails(selectedTeamId)}
          closeModal={(status, data, keepModal, completeReload) =>
            onModalClose(status, data, keepModal, completeReload)
          }
          mode={formMode}
          methodologies={methodologies}
          productCode={productCode}
        />
      ) : null}
      {openExtendForm ? (
        <ExtendTeamForm
          formVisible={openExtendForm}
          header={getHeader()}
          teamDetails={getSelectedTeamDetails(selectedTeamId)}
          closeModal={(status, data, keepModal, completeReload) =>
            onModalClose(status, data, keepModal, completeReload)
          }
          mode={formMode}
          isRolledOff={isTeamRolledOff(getSelectedTeamDetails(selectedTeamId))}
          productCode={productCode}
        />
      ) : null}
      {showExportTeamForm ? (
        <ExportTeamCompositionForm 
          formVisible = {showExportTeamForm}
          closeModal = {() => onCloseExportTeamForm()}
          productCode = {productCode}
          includeRolledOffCheckbox = {productCalculation.data.rolledOffTeamCount > 0 || extendable.length >0 ? "Include Rolled Off Teams" : null} 

          />
      ) : null}
      <MessageModal {...messageModalConfig} />
      {/* {...messageModalConfig} loading={progress} checkboxSelected = {includeRolledOff}
      checkboxLabel = {productCalculation.data.rolledOffTeamCount > 0 || extendable.length >0 ? "Include Rolled Off Teams" : null} 
      checkboxOnChange={onSelectCheckbox} /> */}
    </div>
  );
}
export const mapStateToProps = (state) => ({
  methodologies: state.TeamsReducer.methodologies,
  teams: state.TeamsReducer.teams,
  rolledOffTeams: state.TeamsReducer.rolledOffTeams,
  saveTeamStatus: state.TeamsReducer.saveTeamStatus,
  productCalculation: state.TeamsReducer.productCalculation,
  loggedInUser: state.AuthReducer,
  iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
});

export const mapDispatchToProps = (dispatch) => ({
  setMethodologyOptions: () => dispatch(setMethodologyOptionsThunk()),
  getTeams: (productCode) => dispatch(getTeamsThunk(productCode)),
  getProductCalc: (productCode) => dispatch(getProductCalcThunk(productCode)),
  getProjects: (productCode) => dispatch(getProjectsThunk(productCode)),
  getSummaryChart: (productCode) => dispatch(getSummaryChartThunk(productCode)),
  getResourceForecast: (productCode) =>
    dispatch(getResourceForecastThunk(productCode)),
  showNotification: (notification) => dispatch(addNotification(notification)),
  getRolledOffTeamsCall: (productCode, query) =>
    dispatch(getRolledOffTeamsThunk(productCode, query)),
  refreshProduct: (productCode, callback) =>
    dispatch(refreshProductThunk(productCode, callback)),
  refreshProductMonthly: (productCode, callback) =>
    dispatch(refreshProductMonthlyThunk(productCode, callback)),
  monthCalculations: (teamId, callback) =>
    dispatch(setMonthDataCalculationsThunk(teamId, callback)),
  getTeamsSprintVelocity: (productCode) =>
    dispatch(getTeamsSprintVelocityThunk(productCode)),
  getTeamsRoles: (productCode) => dispatch(getTeamsRolesThunk(productCode)),
  // scrumMasterList: () => dispatch(getScrumMasterThunk()),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TeamComposition)
);

