import React, { Component, useState, useEffect } from "react";
import { FormModal } from "../../../../components/FormModal/formModal";
import TextField from "../../../../components/forms/textField/textField";
import { PRODUCT_LINE_FORM_DEFAULT } from "../../../../constants/form.constants";
import { setProductLinesThunk } from "../../../../store/products.reducer";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../../../components/forms/Button/button";
import * as CONSTANTS from "./productLine.constants";
import { setProductsByOwnerThunk } from "../../../../store/products.reducer";
import { saveProductLineThunk, addProductLineThunk } from "../../../../store/productLine.reducer";
import { connect, useDispatch, useSelector } from "react-redux";
import { handleProductLineAPIResponse } from "../../../../services/Admin/admin.productLine.service";
import { DATA_STATUS } from "../../../../constants/service.constant";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import { formatLanId } from "../../../../services/lanId.service";
import { PCDM_ADMIN_ACTIONS } from "../../../../constants/action.constants";

const PROJECT_INITIAL_STATE = {
  keepForm: false,
  formControls: {
    error: false,
    errorMessage: "",
    errorDetail: "",
    isEdited: false,
    productLineName: {
      ...PRODUCT_LINE_FORM_DEFAULT,
      required: true,
    },
    productLineId: {
      ...PRODUCT_LINE_FORM_DEFAULT,
      required: true,
    },
  },
};

export function ProductLine(props) {
  const {
    header,
    closePopupModel,
    formVisible,
    formOpen,
    currentRow,
    tableData,
    setTableData,
    saveProductLineStatus,
    addProductLineStatus,
    setAllProductLines,
    formMode,
  } = props;

  const [state, setState] = React.useState({ ...PROJECT_INITIAL_STATE });

  useEffect(() => {
    if (
      formMode == PCDM_ADMIN_ACTIONS.EDIT_PRODUCT_LINE &&
      formOpen &&
      currentRow &&
      currentRow.original &&
      currentRow.original.portfolioName
    ) {
      setState({
        ...PROJECT_INITIAL_STATE,
        formControls: {
          ...state.formControls,
          isEdited: false,
          productLineName: {
            ...state.formControls.productLineName,
            value: currentRow.original.portfolioName,
            portfolioId: currentRow.original.portfolioId,
            error: false,
            errorMsg: "",
          },
        },
      });
    } else if (formMode == PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE) {
      setState({
        ...PROJECT_INITIAL_STATE,
      });
    }
  }, [formOpen, currentRow, formMode]);

  const resetForm = (row) => {
    setState({
      ...PROJECT_INITIAL_STATE,
      formControls: {
        ...state.formControls,
        productLineName: {
          ...state.formControls.productLineName,
          value: row.portfolioName,
        },
      },
    });
  };

  const onInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setState({
      ...state,
      formControls: {
        ...state.formControls,
        isEdited: true,
        [name]: {
          ...state.formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  const getProjectForm = () => {
    return (
      <fieldset>
        <form className="pcdm-form">
          <div className="pcdm-form__form-group">
            <div className="pcdm-form__form-group-field form-group-field--inline-4 ">
              {formMode == PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE ? (
                <TextField
                  name="productLineId"
                  label={"Product Line ID"}
                  formObj={state.formControls.productLineId}
                  isRequired={state.formControls.productLineId.required}
                  type="text"
                  name="productLineId"
                  onChange={(e) =>
                    onInputChange({
                      target: { name: e.target.name, value: e.target.value },
                    })
                  }
                />
              ) : null}
              <TextField
                name="productLineName"
                label={"Product Line Name"}
                formObj={state.formControls.productLineName}
                isRequired={state.formControls.productLineName.required}
                type="text"
                name="productLineName"
                onChange={(e) =>
                  onInputChange({
                    target: { name: e.target.name, value: e.target.value },
                  })
                }
              />
            </div>
          </div>
        </form>
      </fieldset>
    );
  };

  const validateForm = (formControls, productLineData) => {
    let formState = {
      ...formControls,
      error: false,
      errorMessage: "",
    };
    for (const [key, valueObj] of Object.entries(formControls)) {
      if (key === "productLineName") {
        if (valueObj.value.trim() === "" || valueObj.value.trim() === null) {
          formState = {
            ...formState,
            error: true,
            [key]: {
              ...formState[key],
              error: true,
              errorMsg: CONSTANTS.PROD_LINE_NAME_REQ,
            },
          };
        } else {
          productLineData.map((value) => {
            if (
              formState[key].value &&
              value.portfolioName &&
              value.portfolioName.toLowerCase() ===
                formState[key].value.toLowerCase() &&
              value.portfolioId !== formState[key].portfolioId
            ) {
              formState = {
                ...formState,
                error: true,
                [key]: {
                  ...formState[key],
                  error: true,
                  errorMsg: CONSTANTS.DUPLICATE_RECORD,
                },
              };
            }
          });
        }
      }
    }
    return formState;
  };

  const handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleProductLineAPIResponse(
      props,
      state,
      responseType,
      responseData
    );
    if (modal) {
      props.closeModal(modal.action, modal.props, "");
    } else if (returnState) {
      setState({ ...state, ...returnState });
    }
  };

  const onSubmit = async (e) => {
    const Validate = validateForm(state.formControls, tableData);
    if (Validate.error) {
      setState({ ...state, formControls: Validate });
    } else {
      let payload = {
        productLineName: state.formControls.productLineName.value,
        productLineID: formMode==PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE 
          ? state.formControls.productLineId.value
          : state.formControls.productLineName.portfolioId,
      };
      if(formMode == PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE){
        await props.addProductLine(payload, handleResponse)
      }else if(formMode == PCDM_ADMIN_ACTIONS.EDIT_PRODUCT_LINE){
        await props.saveProductLine(payload, handleResponse);
      }
      // tableData.map((row) => {
      //   if (row.portfolioId === currentRow.original.portfolioId) {
      //     row.portfolioName = state.formControls.productLineName.value;
      //   }
      // });
      // setTableData(tableData);
      closePopupModel("", "", "");
    }
  };

  const getProjectFooter = () => {
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          onClick={() => {
            setState({ ...state, keepForm: false });
            onSubmit();
          }}
        >
          Save
        </CustomButton>
      </div>
    );
  };

  // After Successful update
  useEffect(() => {
    if (
      saveProductLineStatus &&
      saveProductLineStatus.status &&
      saveProductLineStatus.status === DATA_STATUS.SUCCESS
    ) {
      setAllProductLines();
      props.setProductsByOwner(formatLanId(props.userParams));
    }
  }, [saveProductLineStatus]);

  useEffect(() => {
    if (
      addProductLineStatus &&
      addProductLineStatus.status &&
      addProductLineStatus.status === DATA_STATUS.SUCCESS
    ) {
      setAllProductLines();
      props.setProductsByOwner(formatLanId(props.userParams));
    }
  }, [addProductLineStatus]);

  return (
    <>
      <FormModal
        isLoading={saveProductLineStatus.status === DATA_STATUS.LOADING || 
          addProductLineStatus.status === DATA_STATUS.LOADING}
        visible={formOpen}
        closeModal={(status, data, keepModal) =>
          closePopupModel(status, data, keepModal)
        }
        header={
          formMode === PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE
            ? "ADD PRODUCT LINE"
            : "EDIT PRODUCT LINE"
        }
        content={() => getProjectForm()}
        footer={() => getProjectFooter()}
        className="project-form"
      />
    </>
  );
}
export const mapStateToProps = (state) => ({
  saveProductLineStatus: state.ProductLinesReducer.saveProductLineStatus,
  addProductLineStatus: state.ProductLinesReducer.addProductLineStatus,
  loggedInUser: state.AuthReducer,
  userParams: state.AuthReducer.user,
});

export const mapDispatchToProps = (dispatch) => ({
  saveProductLine: (productFormData, callback) =>
    dispatch(saveProductLineThunk(productFormData, callback)),
  setAllProductLines: () => dispatch(setProductLinesThunk()),
  setProductsByOwner: (id) => dispatch(setProductsByOwnerThunk(id)),
  addProductLine: (payload, callback) => dispatch(addProductLineThunk(payload, callback)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ProductLine);
