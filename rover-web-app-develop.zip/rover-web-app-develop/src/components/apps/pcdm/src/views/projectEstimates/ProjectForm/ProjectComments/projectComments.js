import React, { useState } from "react";
import TextArea from "../../../../components/forms/TextArea/textArea";
import CustomButton, { BUTTON_VARIANTS } from "../../../../components/forms/Button/button";
import "./projectComments.scss";
import DataHandler from "../../../../components/DataHandler/dataHandler";
import Comment from "../../../../components/Feed/Comment/comment";
import {
  validateCommentForm,
  saveCommentPayload,
  handleProjectAPIResponse,
} from "../../../../services/project.service";
import { connect } from "react-redux";
import { saveProjectCommentThunk, getProjectsThunk } from "../../../../store/projects.reducer";
import moment from "moment";
import { addNotification } from "../../../../store/common.reducer";
import { ACTIONS } from "../../../../constants/action.constants";
import { DATA_STATUS } from "../../../../constants/service.constant";

export function ProjectComments(props) {
  const {
    selectedProject,
    getProjects,
    manager,
    lanId,
    addProjectComment,
    closeModal,
    showNotification,
    saveProjectCommentStatus,
  } = props;
  const [formControl, setFormControl] = useState({
    error: false,
    comment: {
      value: "",
      required: true,
      error: false,
      errorMsg: "",
    },
  });
  const onChange = (event) => {
    const name = event.target.name; //event.target.name;
    const value = event.target.value;
    setFormControl({
      ...formControl,
      error: false,
      [name]: {
        ...formControl[name],
        error: false,
        value: value,
      },
    });
  };
  const clearForm = () => {
    setFormControl({
      error: false,
      comment: {
        value: "",
        required: true,
        error: false,
        errorMsg: "",
      },
    });
  };
  const handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleProjectAPIResponse(
      props,
      formControl,
      responseType,
      responseData
    );
    if (modal) {
      getProjects(selectedProject.productCode);
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Project comments added successfully",
      });
      clearForm();
    } else {
      setFormControl({
        ...returnState,
      });
    }
  };

  const onSubmit = () => {
    let validation = validateCommentForm(formControl);
    if (validation.error) {
      setFormControl({ ...validation });
    } else {
      let payload = saveCommentPayload(formControl, manager, lanId);
      addProjectComment(
        payload,
        selectedProject.productCode,
        selectedProject.projectEstimateId,
        handleResponse
      );
    }
  };
  const showName = (comment) => {
    return "UserName";
  };

  const _comments = selectedProject
    ? selectedProject.listOfComments
      ? selectedProject.listOfComments
      : []
    : [];
  _comments.sort(function (comment1, comment2) {
    var date1 = moment(comment1.createdDate);
    var date2 = moment(comment2.createdDate);
    return date2.diff(date1);
  });
  const loading = saveProjectCommentStatus.status === DATA_STATUS.LOADING;
  return (
    <div className="project-comment-container">
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextArea
              rows={5}
              cols={5}
              name="comment"
              label="New comment"
              onChange={onChange}
              placeholder="Type comment here..."
              isRequired={formControl.comment.required}
              formObj={formControl.comment}
            />
          </div>
        </div>
        <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
          <CustomButton
            disable={loading}
            loading={loading}
            variant={BUTTON_VARIANTS.PRIMARY}
            size="md"
            onClick={onSubmit}
          >
            Save Comment
          </CustomButton>
        </div>
      </form>
      <div className="comments-view-container pcdm-scroll-vertical">
        <DataHandler
          loader={{ show: formControl.error, state: false }}
          showData={_comments.length}
          emptyDataMessage="No comments found. Add comments above to show here"
        >
          {_comments.map((comment) => (
            <Comment
              comment={comment}
              name={{ key: "lanId", custom: (comment) => showName(comment) }}
              time={{ key: "createdDate" }}
              content={{ key: "comments" }}
            />
          ))}
        </DataHandler>
      </div>
    </div>
  );
}

export const mapStateToProps = (state) => ({
  listOfComments: state.ProjectsReducer.projectDefaults.listOfComments,
  saveProjectCommentStatus: state.ProjectsReducer.saveProjectCommentStatus,
});
export const mapDispatchToProps = (dispatch) => ({
  getProjects: (productCode) => dispatch(getProjectsThunk(productCode)),
  addProjectComment: (payload, productCode, projectEstimateId, callBack) =>
    dispatch(saveProjectCommentThunk(payload, productCode, projectEstimateId, callBack)),
  showNotification: (notification) => dispatch(addNotification(notification)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ProjectComments);
