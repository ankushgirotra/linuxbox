import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import roleForm, { RoleForm } from "./roleForm";
import { ACTIONS, TEAM_ACTIONS } from "../../../../constants/action.constants";
import { Function } from "core-js";
import { rolesDetails } from "../../../../../test_fixtures/rolesDetails.mock";
import { team } from "../../../../../test_fixtures/team.mock";
import { DEFAULT_MSG_MODAL_CONFIG } from "../../../../components/MessageModal/messageModal";
import { roleAfterApiCall } from "../../../../services/role.service";
import { roleInitialState } from "../../../../store/roles.reducer";

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());
const baseProps = {
  selectedRole: {},
  mode: TEAM_ACTIONS.ADD_ROLE,
  roles: rolesDetails,
  team: team,
  saveRole: jest.fn(),
  editRole: jest.fn(),
  deleteRole: jest.fn(),
  closeModal: expect.any(Function),
  saveRoleStatus: roleInitialState.saveRoleStatus,
  editRoleStatus: roleInitialState.editRoleStatus,
  deleteRoleStatus: roleInitialState.deleteRoleStatus,
};

let component = null;
const getWrapper = () => shallow(<RoleForm {...baseProps} />);
const state = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    error: false,
    errorDetail: "",
    errorMessage: "",
    role: {
      error: false,
      errorMsg: "",
      required: true,
      value: 2,
    },
    resourceName: {
      error: false,
      errorMsg: "",
      required: false,
      value: "",
    },
    resourceType: {
      error: false,
      errorMsg: "",
      required: true,
      value: "Offshore Contractor",
    },
    allocation: {
      error: false,
      errorMsg: "",
      max: 100,
      min: 0,
      required: true,
      value: "80%",
    },
    rate: {
      error: false,
      errorMsg: "",
      required: true,
      value: "$75.00",
    },
  },
};
fdescribe("add/edit roles", () => {
  beforeEach(() => {
    component = getWrapper();
  });
  describe("Component initate properly", () => {
    it("Roles renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("on rate change value change ", () => {
    it(" should update state", async () => {
      let wrapper = getWrapper();
      let event = {
        target: {
          value: "10",
        },
      };
      let blur = "";
      wrapper.instance().onRateChange(event, blur);
      expect(wrapper.state().formControls.rate.value).toEqual("$10");
    });
  });
  describe("on allocation value change ", () => {
    it(" should update state", async () => {
      let wrapper = getWrapper();
      let event = {
        value: "10",
        error: false,
      };
      let blur = "";
      wrapper.instance().onAllowcationChange(event, blur);
      expect(wrapper.state().formControls.error).toEqual(false);
      expect(wrapper.state().formControls.allocation.error).toEqual(false);
      expect(wrapper.state().formControls.allocation.value).toEqual("10");
    });
    it(" should update state value with % symbol when blur", async () => {
      let wrapper = getWrapper();
      let event = {
        value: "10",
        error: false,
      };
      let blur = "blur";
      wrapper.instance().onAllowcationChange(event, blur);
      expect(wrapper.state().formControls.error).toEqual(false);
      expect(wrapper.state().formControls.allocation.error).toEqual(false);
      expect(wrapper.state().formControls.allocation.value).toEqual("10%");
    });
    it(" should update state empty value if empty value is sent", async () => {
      let wrapper = getWrapper();
      let event = {
        value: "",
        error: false,
      };
      let blur = "blur";
      wrapper.instance().onAllowcationChange(event, blur);
      expect(wrapper.state().formControls.error).toEqual(false);
      expect(wrapper.state().formControls.allocation.error).toEqual(false);
      expect(wrapper.state().formControls.allocation.value).toEqual("");
    });
  });
  describe("on delete click ", () => {
    it(" should update state", async () => {
      let wrapper = getWrapper();
      wrapper.instance().onDeleteClick();
      expect(wrapper.state().messageModalConfig.title).toEqual("Delete");
      expect(wrapper.state().messageModalConfig.message).toEqual(
        "Are you sure you want to delete this role?"
      );
      expect(wrapper.state().messageModalConfig.visible).toEqual(true);
    });
  });
  describe("on input change value change ", () => {
    it(" should update state", async () => {
      let wrapper = getWrapper();
      let event = {
        target: {
          value: "10",
        },
      };
      let blur = "";
      wrapper.instance().onRateChange(event, blur);
      expect(wrapper.state().formControls.rate.value).toEqual("$10");
    });
  });
  // describe("on input value  change ", () => {
  //   it(" should update state rate value $0 as default Rate if it is Role is DAS ", async () => {
  //     let wrapper = getWrapper();
  //     let event = {
  //       target: {
  //         value: 7,
  //         name: "role",
  //       },
  //     };
  //     wrapper.instance().onInputChange(event);
  //     expect(wrapper.state().formControls.error).toEqual(false);
  //     expect(wrapper.state().formControls.rate.value).toEqual("$0.00");
  //     expect(wrapper.state().formControls.role.value).toEqual(7);
  //   });
  //   it(" should update state rate value $0 as default Rate if it is Role is DAS role", async () => {
  //     let wrapper = getWrapper();
  //     let event = {
  //       target: {
  //         value: 1,
  //         name: "role",
  //       },
  //     };
  //     wrapper.instance().onInputChange(event);
  //     expect(wrapper.state().formControls.error).toEqual(false);
  //     expect(wrapper.state().formControls.rate.value).toEqual("$0.00");
  //     expect(wrapper.state().formControls.role.value).toEqual(1);
  //   });
  // });
  describe("on clicking submit value  change ", () => {
    it("Form submit on success validation", async () => {
      let wrapper = getWrapper();
      wrapper.setState({ ...state });
      let event = {
        preventDefault: () => {},
      };
      wrapper.instance().onSubmit(event);
      expect(wrapper.state().formControls.error).toEqual(false);
    });
    it(" should update state if there is error", async () => {
      let wrapper = getWrapper();
      wrapper.setState({
        error: true,
        ...state.formControls,
      });
      let event = {
        preventDefault: () => {},
      };
      wrapper.instance().onSubmit(event);
      expect(wrapper.state().formControls.error).toEqual(true);
    });
    it(" should update state error value on editing", async () => {
      const getWrapper = () => shallow(<RoleForm {...baseProps} />);
      let wrapper = getWrapper();
      wrapper.setState({
        ...state,
      });
      let event = {
        preventDefault: () => {},
      };
      wrapper.instance().onSubmit(event);
      expect(wrapper.state().formControls.error).toEqual(false);
    });
  });
  describe("on clicking handle delete  ", () => {
    it(" should change messageModalConfig.visible and deletingRole state  value when button is Yes", async () => {
      let wrapper = getWrapper();
      let button = ACTIONS.YES;
      wrapper.instance().handleDelete(button, {});
      expect(wrapper.state().messageModalConfig.visible).toEqual(false);
    });
    it(" should change messageModalConfig.visible state when button is other value", async () => {
      let wrapper = getWrapper();
      let button = ACTIONS.YES_NO;
      wrapper.instance().handleDelete(button, {});
      expect(wrapper.state().messageModalConfig.visible).toEqual(false);
    });
  });
});
