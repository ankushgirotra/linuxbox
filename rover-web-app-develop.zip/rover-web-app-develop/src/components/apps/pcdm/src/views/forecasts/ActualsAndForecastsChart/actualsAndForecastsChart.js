import React, { useMemo, useState } from "react";
import "./actualsAndForecastsChart.scss";
import PCDMComposedChart from "../../../components/ComposedChart/composedChart";
import { CURRENCY, LOCALE } from "../../../constants/common.constants";
import { convertToCurrency, getForecastchartData } from "../../../services/forecast.chart.service";
import { check } from "../../../services/validation";
import moment from "moment";

const ACTUAL_BAR = {
  key: "actualsTotal",
  fill: "rgb(2, 32, 92)",
  name: "Actuals",
  barSize: 30,
  label: "forecastToActualChange",
};

const FORECAST_BAR_TOTAL = {
  key: "forecastTotal",
  fill: "rgb(237, 126, 47)",
  name: "Forecasts",
  barSize: 30,
};

const ORIGNAL_BUDGET_TOTAL = {
  required: true,
  dataKey: "originalBudgetTotal",
  stroke: "rgb(87, 110, 162)",
  strokeWidth: 2,
  name: "Budget",
};

const CAPACITY_LINE = {
  required: true,
  dataKey: "capacity",
  stroke: "rgb(49, 151, 65)",
  strokeWidth: 2,
  name: "Capacity",
};

export default function ActualsAndForecastsChart(props) {
  const { selectedPcodes, forecasts, forecastsCapacity, productCoreAggregate, startIndex, endIndex } = props;
  const { flag, value } = check({
    path: "data.matchedProjects",
    checkEmpty: true,
    defaultReturnValue: [],
    original: forecasts,
  });
  const [brushIndex, setBrushIndex] = useState({
    startIndex: 0,
    endIndex: 0,
  });
  // const chartDataList = useMemo(
  //   () => getForecastchartData(selectedPcodes, value, forecastsCapacity),
  //   [selectedPcodes, value, forecastsCapacity]
  // );
  const [chartDataList, setchartDataList] = useState([]);
  React.useEffect(() => {
    setchartDataList(getForecastchartData(selectedPcodes, value, forecastsCapacity, productCoreAggregate))
  }, [selectedPcodes, value, forecastsCapacity, productCoreAggregate])
  
  // const defaultPosition = useMemo(() => {
  //   if (
  //     chartDataList.length &&
  //     (brushIndex.endIndex > chartDataList.length - 1 || brushIndex.endIndex === 0)
  //   ) {
  //     let start = chartDataList.findIndex(
  //       (el) => el.month === moment().startOf("month").format("M/D/YYYY")
  //     ),
  //       end = 0;
  //     if (start != -1 && start + 3 <= chartDataList.length - 1) {
  //       end = start + 3;
  //     } else {
  //       end = chartDataList.length > 6 ? 6 : chartDataList.length - 1;
  //     }
  //     if (start != -1 && start - 3 > 0) {
  //       start = start - 3;
  //     } else {
  //       start = 0;
  //     }
  //     setBrushIndex({
  //       startIndex: start,
  //       endIndex: end,
  //     });
  //   }
  // }, [chartDataList]);

  const customToolTip = (payload) => {
    let percent_variance = payload[0].payload.forecastToActualChange;
    let temp = payload.filter((val)=> val.dataKey === 'capacity');
    let forecastTooltip = [];
    forecastTooltip.push(
      (
        <div className="custom-tooltip" key={0}>
          <span style={{ color: `${temp[0].color}` }}>{temp[0].name.toLowerCase()}{temp[0].dataKey === "actuals" ? ' (Project Funded)' : ''}</span>
          <span>-</span>
          <span>{convertToCurrency(temp[0].value, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
        </div>
      )
    )
    let forecastTooltip1 = payload.map((el, index) => {
      if (el.dataKey === 'forecastTotal') {
        return (
          <>
            <div className="custom-tooltip" key={index + 1}>
              <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()} (Project Funded)</span>
              <span>-</span>
              <span>{convertToCurrency(el.payload.forecast, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
            </div>
            <div className="custom-tooltip" key={index + 2}>
              <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()} (Product Core)</span>
              <span>-</span>
              <span>{convertToCurrency(el.payload.forecastPC, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
            </div>
          </>
        )
      } else if (el.dataKey === "originalBudgetTotal") {
        return (
          <>
            <div className="custom-tooltip" key={index + 2}>
              <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()} (Project Funded)</span>
              <span>-</span>
              <span>{convertToCurrency(el.payload.originalBudget, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
            </div>
            <div className="custom-tooltip" key={index + 3}>
              <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()} (Product Core)</span>
              <span>-</span>
              <span>{convertToCurrency(el.payload.originalBudgetPC, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
            </div>
          </>
        )
      } else if (el.dataKey === "capacity") {
        return <></>
      } else if (el.dataKey === "actualsTotal") {
        return (
          <>
            <div className="custom-tooltip" key={index + 1}>
              <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()} (Project Funded)</span>
              <span>-</span>
              <span>{convertToCurrency(el.payload.actuals, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
            </div>
            <div className="custom-tooltip" key={index + 2}>
              <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()} (Product Core)</span>
              <span>-</span>
              <span>{convertToCurrency(el.payload.actualsPC, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
            </div>
          </>
        )
      }
      // return (
      //   <div className="custom-tooltip" key={index + 1}>
      //     <span style={{ color: `${el.color}` }}>{el.name.toLowerCase()}{el.dataKey === "actuals" ? ' (Project Funded)' : ''}</span> -
      //     <span>{convertToCurrency(el.value, LOCALE.US, CURRENCY.USD).replace(".00", "")}</span>
      //   </div>
      // )
    });
    if (percent_variance) {
      forecastTooltip1.push(
        <div className="custom-tooltip" key={6}>
          <span style={{ color: "black" }}>% Variance -</span>
          {/* <span>-</span> */}
          <span style={{ color: "grey", fontWeight: "bolder" }}>
            {payload[0].payload.forecastToActualChange}
          </span>
        </div>
      );
    }
    return [...forecastTooltip, ...forecastTooltip1];
  };
 
  const [chartConfig, setchartConfig] = useState({
    loading: false,
    xAxisKey: "month",
    barConfig: [{ ...ACTUAL_BAR }, { ...FORECAST_BAR_TOTAL }],
    lineConfig: [{ ...ORIGNAL_BUDGET_TOTAL }, { ...CAPACITY_LINE }],
  });
  const yAxisFormatter = (value) => {
    // if (value) {
    //   if (Number(value) > 1000000000) {
    //     return `$${Math.round(Number(value) / 1000000000).toString()} B`;
    //   } else if (Number(value) > 1000000) {
    //     return `$${Math.round(Number(value) / 1000000).toString()} M`;
    //   } else if (Number(value) > 10000) {
    //     return `$${Math.round(Number(value) / 10000).toString()} K`;
    //   }
    // }
    // return convertToCurrency(value, LOCALE.US, CURRENCY.USD).replace(".00", "");
    return new Intl.NumberFormat(LOCALE.US, { style: 'currency', currency: CURRENCY.USD, maximumSignificantDigits: 3 }).format(value)
  };
  return (
    <PCDMComposedChart
      chartLoading={false}
      {...chartConfig}
      points={chartDataList}
      legendVerticalAlign="bottom"
      yAxisFormatter={(value) => yAxisFormatter(value)}
      xAxisFormatter={(value) => {
        return moment(value, "MM/DD/YYYY").format("MMM YYYY");
      }}
      brushConfig={{
        dataKey: "month",
        startIndex: startIndex,
        endIndex: endIndex,
        onChange: (points) =>
          setBrushIndex({
            startIndex: points.startIndex,
            endIndex: points.endIndex,
          }),
      }}
      customToolTip={customToolTip}
    />
  );
}
