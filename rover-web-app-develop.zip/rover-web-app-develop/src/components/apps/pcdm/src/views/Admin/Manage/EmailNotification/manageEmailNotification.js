import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import {
  getEmailNotificationStatusThunk,
  updateEmailNotificationStatusThunk,
} from "../../../../store/admin.reducer";
import { addNotification } from "../../../../store/common.reducer";
import { FORM_CONTROL_DEFAULT } from "../../../../constants/form.constants";
import { ACTIONS, PCDM_ADMIN_ACTIONS } from "../../../../constants/action.constants";
import { ERROR_MSG } from "../../../../constants/message.contants";
import { DATA_STATUS } from "../../../../constants/service.constant";
import { OverlayLoader } from "../../../../components/DataHandler/dataHandler";
import Toaster from "../../../../components/Toaster/toaster";
import Switch from "../../../../components/forms/Switch/switch";


const MANAGE_EMAIL_NOTIFICATION_INITIAL_STATE = {
  sendEmail: {
    ...FORM_CONTROL_DEFAULT,
  },
};

function ManageEmailNotification(props) {

  const { showNotification, getEmailNotification, updateEmailNotification,
    emailNotificationStatus, updateEmailNotificationStatus } = props;

  const [formControls, setFormControls] = useState(MANAGE_EMAIL_NOTIFICATION_INITIAL_STATE);

  useEffect(() => {
    if (emailNotificationStatus && emailNotificationStatus.data) {
      setFormControls({
        ...formControls,
        sendEmail: {
          ...formControls.sendEmail,
          value: emailNotificationStatus.data.sendEmails ? "On" : "Off",
          error: false,
          errorMsg: "",
        }
      });
    }
  }, [emailNotificationStatus]);

  const onCallback = (status, responseData) => {
    if (status === PCDM_ADMIN_ACTIONS.UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: responseData ? "Send Email Notifications is enabled successfully" :
          "Send Email Notifications is disabled successfully",
      });
    } else if (status === PCDM_ADMIN_ACTIONS.UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
      getEmailNotification();
    }
  };

  const onSendEmailChange = async (value) => {
    let sendMailStatus = value === "On" ? 1 : 0;
    setFormControls({
      ...formControls,
      sendEmail: {
        ...formControls.sendEmail,
        value: value,
      },
    });
    await updateEmailNotification(sendMailStatus, onCallback)
  };

  return (
    <>
      <OverlayLoader
        loading={emailNotificationStatus.status === DATA_STATUS.LOADING ||
          updateEmailNotificationStatus.status === DATA_STATUS.LOADING}
      />
      <div className='admin-container sc-admin-attrition-container'>
        <div className="admin-automation_switch">
          <Switch
            name={"sendEmail"}
            label={"Send Email Notifications"}
            config={{
              options: [
                { id: 1, desc: "On" },
                { id: 2, desc: "Off" },
              ],
              id: "desc",
              value: "desc",
            }}
            formObj={formControls.sendEmail}
            className="profile-creation-slider"
            onChange={onSendEmailChange}
          />
        </div>
        <Toaster />
      </div>
    </>
  );
}

const mapStateToProps = (state) => ({
  emailNotificationStatus: state.PCDMAdminReducer.emailNotificationStatus,
  updateEmailNotificationStatus: state.PCDMAdminReducer.updateEmailNotificationStatus,
});

const mapDispatchToProps = (dispatch) => ({
  getEmailNotification: () => dispatch(getEmailNotificationStatusThunk()),
  updateEmailNotification: (status, callback) =>
    dispatch(updateEmailNotificationStatusThunk(status, callback)),
  showNotification: (notification) => dispatch(addNotification(notification)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageEmailNotification);