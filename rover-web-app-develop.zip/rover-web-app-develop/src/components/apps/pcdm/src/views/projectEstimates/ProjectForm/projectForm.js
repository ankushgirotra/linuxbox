import React, { Component } from "react";
import "./projectForm.scss";
import TextField from "../../../components/forms/textField/textField";
import SelectDropdown from "../../../components/forms/select/select";
import {
  PROJECT_ACTIONS,
  ACTIONS,
  TOOL_TIP_TITLE,
} from "../../../constants/action.constants";
import CustomSelect from "../../../components/forms/SelectDropdown/selectDropdown";
import {
  DEFAULT_MSG_MODAL_CONFIG,
  MessageModal,
} from "../../../components/MessageModal/messageModal";
import ErrorMsg from "../../../components/forms/errorMsg/errorMsg";
import { connect } from "react-redux";
import Datepicker from "../../../components/Datepicker/datepicker";
import ToolTip from "../../../components/ToolTip/ToolTip";

import {
  EST_TYPE_PCODE,
  FORM_DATE_FORMAT,
  FORM_CONTROL_DEFAULT,
  STORY_PTS_MIN,
  STORY_PTS_MAX,
  MONTH_DATE_YEAR_FORMAT,
  PRODUCT_CORE,
  TEAM_END_DATE_MIN,
  TEAM_END_DATE_MAX,
  TEAM_START_DATE_MIN,
  TEAM_START_DATE_MAX,
} from "../../../constants/form.constants";
import {
  saveProjectThunk,
  editProjectThunk,
  deleteProjectThunk,
  getProjectDefaultsThunk,
  completeProjectThunk,
  getBaselineBudgetThunk,
  GET_BASELINE_BUDGET_SUCCESS,
} from "../../../store/projects.reducer";
import moment from "moment";
import {
  validateProjectForm,
  populateProjectForm,
  modifyFormForEstimateType,
  modifyFormForPCode,
  getDeletePayload,
  getAddOrEditPayload,
  getMarkCompletePayload,
  handleProjectAPIResponse,
  populateAddMissingEstForm,
} from "../../../services/project.service";
import {
  PROJECT_MESSAGES,
  TOOL_TIP_MESSAGE,
} from "../../../constants/message.contants";
import { getFormattedDate } from "../../../services/form.service";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../../components/forms/Button/button";
import Switch from "../../../components/forms/Switch/switch";
import { DATA_STATUS } from "../../../constants/service.constant";
import { FormModal } from "../../../components/FormModal/formModal";
import ProjectComments from "./ProjectComments/projectComments";
import {
  getEstimateTypeTooltip,
  getBaselinePromtMessage,
  getOnDeleteMessage,
  getPcodeSustainToolTipMessage,
  getActualsPopupMessage,
} from "../../../templates/projects.template";
import DisableView from "../../../../../../shared/common/DisableView/disableView";
import { OverlayLoader } from "../../../components/DataHandler/dataHandler";
import {
  getStartDateTooltipMsg,
  getactualStartDateTooltipMsg,
  getEndDateTooltipMsg,
  getactualEndDateTooltipMsg,
  getDeleteTooltipMsg,
} from "../../../constants/tooltip.messages";
import { OverlayTrigger } from "react-bootstrap";

const PROJECT_INITIAL_STATE = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  keepForm: false,
  formControls: {
    error: false,
    errorMessage: "",
    errorDetail: "",
    isEdited: false,
    estimateType: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    iCode: {
      ...FORM_CONTROL_DEFAULT,
    },
    pCode: {
      ...FORM_CONTROL_DEFAULT,
    },
    projectName: {
      ...FORM_CONTROL_DEFAULT,
    },
    projectType: {
      ...FORM_CONTROL_DEFAULT,
    },
    investmentPortfolio: {
      ...FORM_CONTROL_DEFAULT,
    },
    deliveryPortfolio: {
      ...FORM_CONTROL_DEFAULT,
    },
    points: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      min: STORY_PTS_MIN,
      max: STORY_PTS_MAX,
      // highEndRangePointsValue: "",
    },
    highEndRangePoints: {
      ...FORM_CONTROL_DEFAULT,
      min: STORY_PTS_MIN,
      max: STORY_PTS_MAX,
      required: false,
    },
    plannedStart: {
      ...FORM_CONTROL_DEFAULT,
      min: TEAM_START_DATE_MIN,
      max: TEAM_START_DATE_MAX,
      required: true,
    },
    plannedEnd: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      min: TEAM_END_DATE_MIN,
      max: TEAM_END_DATE_MAX,
      disabled: true,
    },
    funding: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    baselineBudget: {
      ...FORM_CONTROL_DEFAULT,
      value: 0.0,
    },
    actualStartDate: {
      ...FORM_CONTROL_DEFAULT,
      value: null,
    },
    actualEndDate: {
      ...FORM_CONTROL_DEFAULT,
      value: null,
    },
  },
  isRangeNow: false,
  selectedProjectDefaults: {},
  completeReload: false,
};

export class ProjectForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...PROJECT_INITIAL_STATE };
  }
  componentDidMount = () => {
    const { formControls } = this.state;
    if (
      this.props.formMode === PROJECT_ACTIONS.EDIT_PROJECT ||
      this.props.formMode === PROJECT_ACTIONS.REOPEN_PROJECT
    ) {
      this.populateFileds(this.props.selectedProject);
    } else if (this.props.formMode === PROJECT_ACTIONS.ADD_PROJECT) {
      this.setState({
        ...modifyFormForEstimateType(
          formControls,
          this.props.estimateTypes[0].desc
        ),
      });
    } else if (this.props.formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES) {
      this.getProjectDetailsForMissingest(this.props.selectedProject.pcode);
    }
  };

  resetForm = () => {
    this.setState({
      ...PROJECT_INITIAL_STATE,
      ...modifyFormForEstimateType(
        PROJECT_INITIAL_STATE.formControls,
        this.props.estimateTypes[0].desc
      ),
    });
  };
  populateFileds = (project) => {
    const { formControls, isRangeNow } = this.state;
    this.setState(
      {
        formControls: {
          ...populateProjectForm(formControls, project),
        },
        isRangeNow: project && project.range,
      },
      () => {
        let validation = validateProjectForm(this.state.formControls);
        if (validation.error) {
          this.setState({ formControls: { ...validation } });
        } else if (
          !this.props.selectedProject.estimateType === EST_TYPE_PCODE
        ) {
          this.defaultProjectDetails(this.props.selectedProject.pcode);
        }
      }
    );
  };

  defaultProjectDetails = async (pCode) => {
    const { formControls } = this.state;
    await this.props.getProjectDefaults(pCode, (projectDefaults) => {
      this.setState({
        ...modifyFormForPCode(formControls, pCode, projectDefaults),
      });
    });
  };

  getProjectDetailsForMissingest = async (pCode) => {
    const { formControls } = this.state;
    await this.props.getProjectDefaults(pCode, (projectDefaults) => {
      this.setState({
        formControls: {
          ...populateAddMissingEstForm(formControls, projectDefaults),
        },
      });
    });
  };

  onProjectNameChange = (event) => {
    const { formControls } = this.state;
    const { pCodeOptions } = this.props;
    const name = event.target.name;
    const value = event.target.value;
    if (value !== "") {
      let searchedPrj = pCodeOptions.filter((prj) => prj.projectName === value);
      if (searchedPrj.length) {
        this.defaultProjectDetails(searchedPrj[0].pcode);
      }
    }
  };
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    if (
      formControls.estimateType.value === EST_TYPE_PCODE &&
      name === "pCode" &&
      value !== ""
    ) {
      this.defaultProjectDetails(value);
    } else {
      this.setState({
        formControls: {
          ...formControls,
          isEdited: true,
          [name]: {
            ...formControls[name],
            error: false,
            value: value,
          },
        },
      });
    }
  };
  onEstimateTypeChange = (value) => {
    const { formControls } = this.state;
    if (value === EST_TYPE_PCODE) {
      this.setState({ isRangeNow: false });
    }

    this.setState(
      {
        ...modifyFormForEstimateType(formControls, value),
      },
      () => {
        if (value === EST_TYPE_PCODE && formControls.pCode.value !== "") {
          this.defaultProjectDetails(formControls.pCode.value);
        }
      }
    );
  };

  onPointsChange = (event) => {
    const { formControls, isRangeNow } = this.state;
    // console.log(isRangeNow , formControls.highEndRangePoints)
    this.setState({
      formControls: {
        ...formControls,
        error: event.error,
        isEdited: true,
        points: {
          ...formControls.points,
          error: event.error,
          value: event.value,
          errorMsg: event.errorMessage,
        },
      },
    });
  };

  onPointsRangeValueChange = (event) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        error: event.error,
        isEdited: true,
        highEndRangePoints: {
          ...formControls.highEndRangePoints,
          required: true,
          error: event.error,
          value: event.value,
          errorMsg: event.errorMessage,
        },
      },
    });
  };

  onPointsRangeLinkChange = () => {
    const { isRangeNow, formControls } = this.state;
    let isRangeValue = isRangeNow;
    this.setState({
      isRangeNow: !isRangeValue,
      formControls: {
        ...formControls,
        highEndRangePoints: {
          ...formControls.highEndRangePoints,
          required: !isRangeValue,
          error: false,
          errorMsg: "",
        },
      },
    });
  };

  manageMonthSelection = (type, date) => {
    let value = moment(date, FORM_DATE_FORMAT);
    const { formControls } = this.state;
    if (type === "plannedStart") {
      let ed = formControls.plannedEnd.value,
        ed_disable = formControls.plannedEnd.disabled,
        ed_min = value.add(1, "day").format(FORM_DATE_FORMAT);
      if (value.isValid() && !formControls.plannedEnd.value) {
        // If start month is selected and end month is empty enable end month and update its min
        ed_disable = false;
      } else if (
        formControls.plannedEnd.value &&
        value.isAfter(moment(formControls.plannedEnd.value, FORM_DATE_FORMAT))
      ) {
        // If start month is after selected end month , then reset the end month and its min
        ed = "";
        ed_disable = false;
      }
      this.setState({
        formControls: {
          ...formControls,
          isEdited: true,
          plannedStart: {
            ...formControls.plannedStart,
            value: date,
            error: false,
          },
          plannedEnd: {
            ...formControls.plannedEnd,
            value: ed,
            disabled: ed_disable,
            min: new Date(getFormattedDate(ed_min)),
          },
        },
      });
    } else if (type === "plannedEnd") {
      this.setState({
        formControls: {
          ...formControls,
          isEdited: true,
          plannedStart: {
            ...formControls.plannedStart,
            error: false,
          },
          plannedEnd: {
            ...formControls.plannedEnd,
            value: date,
            error: false,
          },
        },
      });
    }
  };

  handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleProjectAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData
    );
    if (this.state.keepForm) {
      if (modal.action === ACTIONS.SUCCESS) {
        this.resetForm();
      }
      this.props.closeModal(modal.action, modal.props, true, this.state.completeReload);
    } else if (modal) {
      this.props.closeModal(modal.action, modal.props,false, this.state.completeReload);
    }
    if (returnState) {
      if (
        returnState &&
        returnState.formControls &&
        returnState.formControls.errorResponse
      ) {
        if (
          returnState.formControls.errorResponse &&
          returnState.formControls.errorResponse.errorMsg &&
          returnState.formControls.errorResponse !==
            this.state.formControls.errorResponse
        ) {
          const errorResponse = returnState.formControls.errorResponse;
          this.setState({ ...returnState }, () => {
            this.validationActualsPopup(
              errorResponse.errorMsg,
              errorResponse.fieldName
            );
          });
        }
      } else {
        this.setState({ ...returnState });
      }
    }
  };

  onSaveClick = (month, year, date) => {
    if (date === "START") {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          title: "Actuals Conflict",
          message: getactualStartDateTooltipMsg(month, year),
          visible: true,
          onClose: this.handleSaveClick,
        },
      });
    } else if (date === "END") {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          message: getactualEndDateTooltipMsg(month, year),
          title: "Actuals Conflict",
          visible: true,
          onClose: this.handleSaveClick,
        },
      });
    }
  };

  handleSaveClick = async (button, data) => {
    const { formControls } = this.state;
    const { formMode, selectedProject } = this.props;
    if (button === ACTIONS.YES) {
      if (
        formControls.estimateType.value == EST_TYPE_PCODE &&
        selectedProject.estimateType == "Intake"
      ) {
        this.getBaselineEst("NEW");
      } else if (
        formControls.estimateType.value == EST_TYPE_PCODE &&
        Number(formControls.points.value) !==
          Number(selectedProject.storyPoints)
      ) {
        this.getBaselineEst("EDIT");
      } else {
        this.onSaveProject();
      }
      this.setState({
        messageModalConfig: {
          ...this.state.messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...this.state.messageModalConfig,
          visible: false,
        },
      });
    }
  };

  onSubmit = (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls, isRangeNow } = this.state;
    const { formMode, selectedProject } = this.props;
    let validation = validateProjectForm(formControls, isRangeNow);
    if (validation.error) {
      console.log(validation);
      this.setState({ formControls: { ...validation } });
    } else {
      if (
        formMode == PROJECT_ACTIONS.ADD_PROJECT ||
        formMode == PROJECT_ACTIONS.ADD_MISSING_ESTIMATES
      ) {
        if (formControls.estimateType.value == EST_TYPE_PCODE) {
          this.getBaselineEst("NEW");
        } else {
          this.onSaveProject();
        }
      } else if (
        formMode == PROJECT_ACTIONS.EDIT_PROJECT ||
        formMode == PROJECT_ACTIONS.REOPEN_PROJECT
      ) {
        if (
          formControls.estimateType.value == "Execution" &&
          moment(formControls.plannedStart.value).utc()._isValid &&
          moment(selectedProject.actualStartDate).utc()._isValid &&
          !moment(formControls.plannedStart.value)
            .utc()
            .isSameOrBefore(
              moment(selectedProject.actualStartDate).utc(),
              "month"
            )
        ) {
          this.onSaveClick(
            moment(selectedProject.actualStartDate).utc().format("MMMM"),
            moment(selectedProject.actualStartDate).utc().format("YYYY"),
            "START"
          );
        } else if (
          formControls.estimateType.value == "Execution" &&
          moment(formControls.plannedEnd.value).utc()._isValid &&
          moment(selectedProject.actualEndDate).utc()._isValid &&
          !moment(formControls.plannedEnd.value)
            .utc()
            .isSameOrAfter(moment(selectedProject.actualEndDate).utc(), "month")
        ) {
          this.onSaveClick(
            moment(selectedProject.actualEndDate).utc().format("MMMM"),
            moment(selectedProject.actualEndDate).utc().format("YYYY"),
            "END"
          );
        } else if (
          formControls.estimateType.value == EST_TYPE_PCODE &&
          selectedProject.estimateType == "Intake"
        ) {
          this.getBaselineEst("NEW");
        } else if (
          formControls.estimateType.value == EST_TYPE_PCODE &&
          Number(formControls.points.value) !==
            Number(selectedProject.storyPoints)
        ) {
          this.getBaselineEst("EDIT");
        } else {
          this.onSaveProject();
        }
      }
    }
  };
  getBaselineEst = async (type) => {
    const { plannedStart, plannedEnd, points } = this.state.formControls;
    let start = moment(plannedStart.value)
      .hour(0)
      .minute(0)
      .second(0)
      .millisecond(0)
      .format("YYYY-MM-DD");
    let end = moment(plannedEnd.value)
      .hour(23)
      .minute(59)
      .second(59)
      .millisecond(999)
      .format("YYYY-MM-DD");
    await this.props.getBaselineEstimate(
      localStorage.getItem("productCode"),
      start,
      end,
      Number(points.value),
      (status, res) => {
        if (status === GET_BASELINE_BUDGET_SUCCESS) {
          this.savingProjectprompt(
            res.baselineBudget ? res.baselineBudget : 0,
            type
          );
        }
      }
    );
  };
  savingProjectprompt = (baselineBudget, type) => {
    const { points } = this.state.formControls;
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title:
          type === "NEW" ? "Baseline Estimate" : "Baseline Estimate Change",
        visible: true,
        onClose: (button, data) =>
          this.handleSaveProject(button, data, baselineBudget),
        dialogClassName: "project-prompt-modal",
        customContent: () =>
          getBaselinePromtMessage(points.value, baselineBudget, type),
      },
    });
  };
  validationActualsPopup = (errMsg, type) => {
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        variant: "OK",
        title:
          type === "plannedStart" ? "Invalid Start Date" : "Invalid End Date",
        visible: true,
        onClose: (button, data) => this.closeMessageModal(),
        dialogClassName: "project-prompt-modal",
        customContent: () => getActualsPopupMessage(errMsg),
      },
    });
  };

  handleSaveProject = async (button, data, baselineBudget) => {
    this.closeMessageModal();
    if (button === ACTIONS.YES) {
      this.setState(
        {
          formControls: {
            ...this.state.formControls,
            baselineBudget: {
              ...this.state.formControls.baselineBudget,
              value: baselineBudget,
            },
          },
        },
        () => this.onSaveProject()
      );
    }
  };
  onSaveProject = async () => {
    const { formControls, isRangeNow } = this.state;
    const { formMode, selectedProject } = this.props;
    let payload = getAddOrEditPayload(
      formMode,
      formControls,
      selectedProject,
      isRangeNow
    );
    if (
      formMode == PROJECT_ACTIONS.ADD_PROJECT ||
      formMode == PROJECT_ACTIONS.ADD_MISSING_ESTIMATES
    ) {
      await this.props.saveProject(
        payload,
        localStorage.getItem("productCode"),
        this.handleResponse
      );
    } else if (
      formMode == PROJECT_ACTIONS.EDIT_PROJECT ||
      formMode == PROJECT_ACTIONS.REOPEN_PROJECT
    ) {
      if(formMode === PROJECT_ACTIONS.EDIT_PROJECT){
        if(selectedProject.estimateType == "Execution"){
          if(selectedProject.storyPoints != formControls.points.value ||
            // selectedProject.maxStoryPoints != formControls.highEndRangePoints.value ||
            // selectedProject.range != isRangeNow ||
            // selectedProject.pcode != formControls.pCode.value ||
            // selectedProject.projectName != formControls.projectName.value ||
            // selectedProject.projectType != formControls.projectType.value ||
            // selectedProject.funding != formControls.funding.value ||
            new Date(selectedProject.plannedStart).getTime() != new Date(formControls.plannedStart.value).getTime() ||
            new Date(selectedProject.plannedEnd).getTime() != new Date(formControls.plannedEnd.value).getTime() ||
            selectedProject.estimateType != formControls.estimateType.value){
              this.setState({completeReload:true})
            }else{
              this.setState({completeReload:false})
            }
        }
        // else{
        //   if(selectedProject.storyPoints != formControls.points.value ||
        //       selectedProject.maxStoryPoints != formControls.highEndRangePoints.value ||
        //       selectedProject.range != isRangeNow ||
        //       new Date(selectedProject.plannedStart).getTime() != new Date(formControls.plannedStart.value).getTime() ||
        //       new Date(selectedProject.plannedEnd).getTime() != new Date(formControls.plannedEnd.value).getTime() ||
        //       selectedProject.estimateType != formControls.estimateType.value){
        //         this.setState({completeReload : true})
        //   }else{
        //     this.setState({completeReload:false})
        //   }
        // }
      }
      await this.props.editProject(
        payload,
        localStorage.getItem("productCode"),
        this.props.selectedProject.projectEstimateId,
        this.handleResponse
      );
    }
  };

  onDeleteClick = () => {
    let validation = validateProjectForm(this.state.formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          title: "Delete",
          visible: true,
          onClose: this.handleDelete,
          dialogClassName: "project-prompt-modal",
          customContent: getOnDeleteMessage,
        },
      });
    }
  };
  handleDelete = async (button, data) => {
    this.closeMessageModal();
    if (button === ACTIONS.YES) {
      await this.props.deleteProject(
        { ...getDeletePayload(this.props.selectedProject) },
        localStorage.getItem("productCode"),
        this.props.selectedProject.projectEstimateId,
        this.handleResponse
      );
    }
  };
  onCompleteProjectClick = () => {
    const pEndDate = this.props.selectedProject.plannedEnd;
    const todayDate = moment().hour(23).minute(59).second(59).millisecond(999);
    if (moment(pEndDate).isSameOrBefore(todayDate)) {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          title: "Complete Project",
          message: PROJECT_MESSAGES.COMPLETE_PROJECT_CONFIRM,
          visible: true,
          dialogClassName: "project-prompt-modal",
          onClose: this.handleCompleteProject,
          variant: ACTIONS.YES_NO,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...DEFAULT_MSG_MODAL_CONFIG,
          title: "Complete Project",
          message: PROJECT_MESSAGES.COMPLETE_PROJECT_ED_DT_FUTURE,
          visible: true,
          dialogClassName: "project-prompt-modal",
          onClose: this.handleCompleteProject,
          variant: ACTIONS.ERROR,
        },
      });
    }
  };
  handleCompleteProject = async (button, data) => {
    this.closeMessageModal();
    if (button === ACTIONS.YES) {
      await this.props.completeProject(
        { ...getMarkCompletePayload(this.props.selectedProject) },
        localStorage.getItem("productCode"),
        this.props.selectedProject.projectEstimateId,
        this.handleResponse
      );
    }
  };

  closeMessageModal = () => {
    this.setState({
      messageModalConfig: {
        ...this.state.messageModalConfig,
        visible: false,
      },
    });
  };

  checkTooltipContent = (plannedDate, actualDate, estimateType) => {
    let formattedPlannedDate = moment(plannedDate).utc();
    let formattedActualDate = moment(actualDate).utc();
    if (
      formattedPlannedDate._isValid &&
      formattedActualDate._isValid &&
      !formattedPlannedDate.isSameOrBefore(formattedActualDate, "month") &&
      estimateType === "Execution"
    ) {
      return true;
    } else {
      return false;
    }
  };

  getTooltipMessage = (gvnDate, startOrEnd) => {
    let formattedGvnDate =
      gvnDate !== null ? moment(gvnDate).format("MM/DD/YYYY") : 0;
    let date = moment(gvnDate).utc();
    let month = date.format("MMMM");
    let year = date.format("YYYY");
    if (startOrEnd === "start") {
      return getStartDateTooltipMsg(month, year);
    } else if (startOrEnd === "end") {
      return getEndDateTooltipMsg(month, year);
    }
  };

  getProjectForm = () => {
    const { formControls, isRangeNow } = this.state;
    const {
      estimateTypes,
      projectType,
      fundings,
      investmentPortfolios,
      deliveryPortfolios,
      pCodeOptions,
    } = this.props;
    const { formMode, selectedProject } = this.props;
    return (
      <fieldset disabled={formMode == PROJECT_ACTIONS.REOPEN_PROJECT}>
        <form className="pcdm-form">
          <div className="pcdm-form__form-group">
            <div className="pcdm-form__form-group-field est_type-switch">
              <Switch
                name={"estimateType"}
                label={"Estimate Type"}
                config={{
                  options: [...estimateTypes],
                  id: "desc",
                  value: "desc",
                }}
                className="estimate-type-slider"
                formObj={formControls.estimateType}
                isRequired={formControls.estimateType.required}
                onChange={this.onEstimateTypeChange}
                hasToolTip={true}
                toolTipTitle={TOOL_TIP_TITLE.ESTIMATE_TYPE}
                toolTipMessage={getEstimateTypeTooltip}
                disable={
                  ((formMode === PROJECT_ACTIONS.EDIT_PROJECT ||
                    // formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES ||
                    formMode === PROJECT_ACTIONS.REOPEN_PROJECT) &&
                    selectedProject.estimateType &&
                    selectedProject.estimateType === EST_TYPE_PCODE) ||
                  formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES
                }
                disabledErrorMessage={
                  formMode != PROJECT_ACTIONS.REOPEN_PROJECT
                    ? PROJECT_MESSAGES.EXECUTION_TYPE_LOCKED_ERROR
                    : null
                }
              />
            </div>
            <div className="project-form__form-group-field">
              <div className="pcdm-form__form-group-field form-group-field--inline proj_form-inline">
                {formControls.estimateType.value === EST_TYPE_PCODE ? (
                  <CustomSelect
                    name="pCode"
                    label={"P-Code/Core"}
                    formObj={formControls.pCode}
                    config={{
                      options: [...pCodeOptions],
                      id: "pcode",
                      value: "pcode",
                    }}
                    isRequired={formControls.pCode.required}
                    onChange={(e) =>
                      this.onInputChange({
                        target: { name: e.name, value: e.value },
                      })
                    }
                    hasToolTip={true}
                    toolTipTitle={TOOL_TIP_TITLE.P_CODE_CORE}
                    toolTipMessage={getPcodeSustainToolTipMessage}
                    disable={
                      formControls.pCode.readOnly ||
                      ((formMode === PROJECT_ACTIONS.EDIT_PROJECT ||
                        formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES) &&
                        selectedProject.estimateType &&
                        selectedProject.estimateType === EST_TYPE_PCODE)
                    }
                    disabledErrorMessage={
                      PROJECT_MESSAGES.EXECUTION_TYPE_PCODE_ERROR
                    }
                  />
                ) : (
                    <TextField
                      name="pCode"
                      label={"P-Code/Core"}
                      formObj={formControls.pCode}
                      isRequired={formControls.pCode.required}
                      type="text"
                      onChange={this.onInputChange}
                      hasToolTip={true}
                      toolTipTitle={TOOL_TIP_TITLE.P_CODE_CORE}
                      toolTipMessage={getPcodeSustainToolTipMessage}
                    />
                  )}
                {formControls.estimateType.value === EST_TYPE_PCODE &&
                  formControls.pCode.value !== PRODUCT_CORE ? (
                    <CustomSelect
                      name="projectName"
                      label={"Project Name"}
                      formObj={formControls.projectName}
                      config={{
                        options: [
                          ...pCodeOptions.filter(
                            (opt) =>
                              opt.projectName !== "" && opt.pcode !== PRODUCT_CORE
                          ),
                        ],
                        id: "projectName",
                        value: "projectName",
                      }}
                      isRequired={formControls.projectName.required}
                      onChange={(e) =>
                        this.onProjectNameChange({
                          target: { name: e.name, value: e.value },
                        })
                      }
                      disable={
                        formControls.pCode.readOnly ||
                        ((formMode === PROJECT_ACTIONS.EDIT_PROJECT ||
                          formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES) &&
                          selectedProject.estimateType &&
                          selectedProject.estimateType === EST_TYPE_PCODE)
                      }
                      disabledErrorMessage={
                        PROJECT_MESSAGES.EXECUTION_TYPE_PROJECT_NAME_ERROR
                      }
                    />
                  ) : (
                    <TextField
                      name="projectName"
                      label={"Project Name"}
                      formObj={formControls.projectName}
                      isRequired={formControls.projectName.required}
                      type="text"
                      onChange={this.onInputChange}
                    />
                  )}
              </div>
              <div className="pcdm-form__form-group-field form-group-field--inline proj_form-inline">
                <SelectDropdown
                  name="funding"
                  label={"Funding"}
                  formObj={formControls.funding}
                  config={{
                    options: [...fundings],
                    id: "desc",
                    value: "desc",
                  }}
                  isRequired={formControls.funding.required}
                  onChange={this.onInputChange}
                  hasToolTip={true}
                  toolTipTitle={TOOL_TIP_TITLE.FUNDING}
                  toolTipMessage={TOOL_TIP_MESSAGE.FUNDING}
                />
                <SelectDropdown
                  name="projectType"
                  label={"Project Type"}
                  formObj={formControls.projectType}
                  config={{
                    options: [...projectType],
                    id: "desc",
                    value: "desc",
                  }}
                  isRequired={formControls.projectType.required}
                  onChange={this.onInputChange}
                  hasToolTip={true}
                  toolTipTitle={TOOL_TIP_TITLE.PROJECT_TYPE}
                  toolTipMessage={TOOL_TIP_MESSAGE.PROJECT_TYPE}
                />
              </div>
              <div className="pcdm-form__form-group-field form-group-field--inline proj_form-inline">
                {(formMode === PROJECT_ACTIONS.ADD_PROJECT ||
                  formMode === PROJECT_ACTIONS.EDIT_PROJECT) &&
                  formControls.estimateType.value === "Intake" ? (
                    <TextField
                      name="points"
                      label={isRangeNow ? "Story Point Range" : "Story Points"}
                      formObj={formControls.points}
                      isRequired={formControls.points.required}
                      type="number"
                      min={formControls.points.min}
                      onChange={this.onPointsChange}
                      // Range Functions
                      hasRange={true}
                      isRangeNow={isRangeNow}
                      rangeLinkText={isRangeNow ? "Enter points" : "Enter range"}
                      highEndRangeName="highEndRangePoints"
                      rangeFormObj={formControls.highEndRangePoints}
                      highEndRangeMin={formControls.points.value}
                      onRangeValueChange={this.onPointsRangeValueChange}
                      onRangeLinkChange={this.onPointsRangeLinkChange}
                    />
                  ) : (
                    <TextField
                      name="points"
                      label={"Story Points"}
                      formObj={formControls.points}
                      isRequired={formControls.points.required}
                      type="number"
                      min={formControls.points.min}
                      onChange={this.onPointsChange}
                    />
                  )}
                <div className="pcdm-form__form-group-field form-group-field--inline proj_form-inline">
                  <Datepicker
                    name="plannedStart"
                    label={"Start Date"}
                    hasToolTip={this.checkTooltipContent(
                      formControls.plannedStart.value,
                      formControls.actualStartDate.value,
                      formControls.estimateType.value
                    )}
                    toolTipTitle={"Invaild Start Date"}
                    toolTipMessage={this.getTooltipMessage(
                      formControls.actualStartDate.value,
                      "start"
                    )}
                    toolTipPlacement={"right"}
                    formObj={formControls.plannedStart}
                    isRequired={formControls.plannedStart.required}
                    onChange={this.manageMonthSelection}
                    dateFormat={FORM_DATE_FORMAT}
                    customInput={true}
                  />
                  <Datepicker
                    name="plannedEnd"
                    label={"End Date"}
                    hasToolTip={this.checkTooltipContent(
                      formControls.actualEndDate.value,
                      formControls.plannedEnd.value,
                      formControls.estimateType.value
                    )}
                    toolTipTitle={"Invaild End Date"}
                    toolTipMessage={this.getTooltipMessage(
                      formControls.actualEndDate.value,
                      "end"
                    )}
                    toolTipPlacement={"right"}
                    formObj={formControls.plannedEnd}
                    isRequired={formControls.plannedEnd.required}
                    onChange={this.manageMonthSelection}
                    dateFormat={FORM_DATE_FORMAT}
                    customInput={true}
                  />
                </div>
              </div>
              {/* <div className="pcdm-form__form-group-field form-group-field--inline">
              {formControls.estimateType.value === EST_TYPE_PCODE &&
              formControls.pCode.value !== "Sustain"
                ? [
                    <TextField
                      name="investmentPortfolio"
                      label={"Investment Portfolio"}
                      formObj={formControls.investmentPortfolio}
                      isRequired={formControls.investmentPortfolio.required}
                      type="text"
                      onChange={this.onInputChange}
                    />,
                    <TextField
                      name="deliveryPortfolio"
                      label={"Delivery Portfolio"}
                      formObj={formControls.deliveryPortfolio}
                      isRequired={formControls.deliveryPortfolio.required}
                      type="text"
                      onChange={this.onInputChange}
                    />,
                  ]
                : [
                    <SelectDropdown
                      name="investmentPortfolio"
                      label={"Investment Portfolio"}
                      formObj={formControls.investmentPortfolio}
                      config={{
                        options: [...investmentPortfolios],
                        id: "description",
                        value: "description",
                      }}
                      isRequired={formControls.investmentPortfolio.required}
                      onChange={this.onInputChange}
                    />,
                    <SelectDropdown
                      name="deliveryPortfolio"
                      label={"Delivery Portfolio"}
                      formObj={formControls.deliveryPortfolio}
                      config={{
                        options: [...deliveryPortfolios],
                        id: "description",
                        value: "description",
                      }}
                      isRequired={formControls.deliveryPortfolio.required}
                      onChange={this.onInputChange}
                    />,
                  ]}
            </div> */}
              <div className="pcdm-form__form-group-field form-group-field--inline proj_form-inline proj_form-last_elmt">
                <TextField
                  name="iCode"
                  label={"I-Code"}
                  formObj={formControls.iCode}
                  isRequired={formControls.iCode.required}
                  type="text"
                  onChange={this.onInputChange}
                />
              </div>
            </div>
          </div>
          {formMode == PROJECT_ACTIONS.REOPEN_PROJECT ? (
            <DisableView className="reopen-project-form-button">
              <p className="reopen-content">
                {PROJECT_MESSAGES.REOPEN_PROJECT_MESSAGE}
              </p>
              <CustomButton
                variant={BUTTON_VARIANTS.PRIMARY}
                size="md"
                onClick={() => {
                  this.setState({ keepForm: false });
                  this.onSubmit();
                }}
              >
                Re-Open Project
              </CustomButton>
            </DisableView>
          ) : null}
          {formControls.error ? (
            <ErrorMsg
              message={formControls.errorMessage}
              errorDetail={formControls.errorDetail}
            />
          ) : null}
        </form>
      </fieldset>
    );
  };
  getProjectCommentForm = () => {
    const { manager, lanId, selectedProject, formMode } = this.props;
    return (
      <ProjectComments
        manager={manager}
        lanId={lanId}
        selectedProject={selectedProject}
        formMode={formMode}
      />
    );
  };
  getUnableToEditStartandEnd = () => {
    const { formControls } = this.state;
    const {
      formMode,
      deleteProjectStatus,
      completeProjectStatus,
      selectedProject,
    } = this.props;

    if (
      selectedProject.actuals &&
      formControls.estimateType.value ==
        "Execution" && (
          !moment(formControls.plannedStart.value)
            .utc()
            .isSame(moment(selectedProject.plannedStart).utc()) ||
            !moment(formControls.plannedEnd.value)
              .utc()
              .isSame(moment(selectedProject.plannedEnd).utc())
        )
    ) {
      if (
        moment(selectedProject.plannedStart)
          .utc()
          .isSameOrBefore(
            moment(selectedProject.actualStartDate).utc(),
            "month"
          ) &&
        moment(formControls.plannedStart.value)
          .utc()
          .isAfter(moment(selectedProject.actualStartDate).utc(), "month")
      ) {
        return (
          <ToolTip
            toolTipTitle={"Unable to  Edit"}
            toolTipMessage={getStartDateTooltipMsg(
              moment(selectedProject.actualStartDate).utc().format("MMMM"),
              moment(selectedProject.actualStartDate).utc().format("YYYY")
            )}
            content={() => (
              <CustomButton
                variant={BUTTON_VARIANTS.PRIMARY}
                size="md"
                onClick={() => {
                  this.setState({ keepForm: false });
                  // this.onSubmit();
                }}
              >
                Save
              </CustomButton>
            )}
            toolTipPlacement="top"
          ></ToolTip>
        );
      } else if (
        moment(selectedProject.actualEndDate)
          .utc()
          .isSameOrBefore(moment(selectedProject.plannedEnd).utc(), "month") &&
        moment(formControls.plannedEnd.value)
          .utc()
          .isBefore(moment(selectedProject.actualEndDate).utc(), "month")
      ) {
        return (
          <ToolTip
            toolTipTitle={"Unable to  Edit"}
            toolTipMessage={getEndDateTooltipMsg(
              moment(selectedProject.actualEndDate).utc().format("MMMM"),
              moment(selectedProject.actualEndDate).utc().format("YYYY")
            )}
            content={() => (
              <CustomButton
                variant={BUTTON_VARIANTS.PRIMARY}
                size="md"
                onClick={() => {
                  this.setState({ keepForm: false });
                  //this.onSubmit();
                }}
              >
                Save
              </CustomButton>
            )}
            toolTipPlacement="top"
          ></ToolTip>
        );
      }
    }
    return (
      <CustomButton
        variant={BUTTON_VARIANTS.PRIMARY}
        size="md"
        onClick={() => {
          this.setState({ keepForm: false });
          this.onSubmit();
        }}
      >
        Save
      </CustomButton>
    );
  };
  getProjectFooter = () => {
    const { formControls } = this.state;
    const {
      formMode,
      deleteProjectStatus,
      completeProjectStatus,
      selectedProject,
    } = this.props;
    let disableDelete =
      deleteProjectStatus.status === DATA_STATUS.LOADING ||
      formControls.error ||
      formControls.isEdited;
    let disableComplete =
      completeProjectStatus.status === DATA_STATUS.LOADING ||
      formControls.error ||
      formControls.isEdited;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        {formMode === PROJECT_ACTIONS.EDIT_PROJECT ? (
          this.getUnableToEditStartandEnd()
        ) : (
          <CustomButton
            variant={BUTTON_VARIANTS.PRIMARY}
            size="md"
            onClick={() => {
              this.setState({ keepForm: false });
              this.onSubmit();
            }}
          >
            Save
          </CustomButton>
        )}
        {formMode === PROJECT_ACTIONS.ADD_PROJECT ? (
          <div className="form-add-another-button">
            <CustomButton
              variant={BUTTON_VARIANTS.LIGHT}
              size="md"
              onClick={() => {
                this.setState({ keepForm: true });
                this.onSubmit();
              }}
            >
              Save and Add Another
            </CustomButton>
          </div>
        ) : null}
        {formMode === PROJECT_ACTIONS.EDIT_PROJECT ? (
          selectedProject.actualStartDate &&
          selectedProject.actualEndDate &&
          formControls.estimateType.value == "Execution" ? (
            <ToolTip
              toolTipTitle={"Unable to  Delete"}
              toolTipMessage={getDeleteTooltipMsg(
                moment(selectedProject.actualEndDate).utc().format("MMMM"),
                moment(selectedProject.actualEndDate).utc().format("YYYY")
              )}
              content={() => (
                <div className="form-delete-button">
                  <CustomButton
                    key={1}
                    disable={disableDelete}
                    variant={BUTTON_VARIANTS.ERROR}
                    //onClick={this.onDeleteClick}
                    size="md"
                  >
                    Delete
                  </CustomButton>
                </div>
              )}
              toolTipPlacement="top"
            ></ToolTip>
          ) : (
            <div className="form-delete-button">
              <CustomButton
                key={1}
                disable={disableDelete}
                variant={BUTTON_VARIANTS.ERROR}
                onClick={this.onDeleteClick}
                size="md"
              >
                Delete
              </CustomButton>
            </div>
          )
        ) : null}
        {formMode === PROJECT_ACTIONS.EDIT_PROJECT &&
        selectedProject.estimateType === EST_TYPE_PCODE ? (
          <div className="form-comp_proj-button">
            <CustomButton
              key={2}
              disable={disableComplete}
              variant={BUTTON_VARIANTS.SUCCESS}
              onClick={this.onCompleteProjectClick}
              size="md"
            >
              Complete Project
            </CustomButton>
          </div>
        ) : (
          <div id="cancel_button">
            <a
              role="button"
              className="collapse-link"
              aria-expanded="false"
              onClick={this.props.closeModal}
            >
              Cancel
            </a>
          </div>
        )}
      </div>
    );
  };
  render() {
    const { messageModalConfig } = this.state;
    const {
      header,
      closeModal,
      formVisible,
      formMode,
      saveProjectStatus,
      editProjectStatus,
      deleteProjectStatus,
      completeProjectStatus,
      baseLineBudgetStatus,
      projectDefaults,
    } = this.props;
    return (
      <>
        <FormModal
          isLoading={
            saveProjectStatus.status === DATA_STATUS.LOADING ||
            editProjectStatus.status === DATA_STATUS.LOADING ||
            baseLineBudgetStatus.status === DATA_STATUS.LOADING ||
            completeProjectStatus.status === DATA_STATUS.LOADING ||
            deleteProjectStatus.status === DATA_STATUS.LOADING ||
            projectDefaults.status === DATA_STATUS.LOADING
          }
          visible={formVisible}
          closeModal={() => closeModal()}
          header={header}
          content={() =>
            formMode === PROJECT_ACTIONS.PROJECT_COMMENT
              ? this.getProjectCommentForm()
              : this.getProjectForm()
          }
          footer={() =>
            formMode === PROJECT_ACTIONS.PROJECT_COMMENT ||
            formMode === PROJECT_ACTIONS.REOPEN_PROJECT
              ? null
              : this.getProjectFooter()
          }
          className="pcdm-project_form pcdm-form-new"
          isSCForm={true}
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

export const mapStateToProps = (state) => ({
  saveProjectStatus: state.ProjectsReducer.saveProjectStatus,
  editProjectStatus: state.ProjectsReducer.editProjectStatus,
  deleteProjectStatus: state.ProjectsReducer.deleteProjectStatus,
  completeProjectStatus: state.ProjectsReducer.completeProjectStatus,
  projectDefaults: state.ProjectsReducer.projectDefaults,
  pCodeOptions: state.ProjectsReducer.pCodeOptions,
  usedPCodes: state.ProjectsReducer.usedPCodes,
  baseLineBudgetStatus: state.ProjectsReducer.baseLineBudget,
});
export const mapDispatchToProps = (dispatch) => ({
  saveProject: (payload, productCode, callback) =>
    dispatch(saveProjectThunk(payload, productCode, callback)),
  editProject: (payload, productCode, projectId, callback) =>
    dispatch(editProjectThunk(payload, productCode, projectId, callback)),
  deleteProject: (payload, productCode, projectId, callback) =>
    dispatch(deleteProjectThunk(payload, productCode, projectId, callback)),
  completeProject: (payload, productCode, projectId, callback) =>
    dispatch(completeProjectThunk(payload, productCode, projectId, callback)),
  getProjectDefaults: (pCode, callback) =>
    dispatch(getProjectDefaultsThunk(pCode, callback)),
  getBaselineEstimate: (pCode, start, end, storyPoints, callback) =>
    dispatch(getBaselineBudgetThunk(pCode, start, end, storyPoints, callback)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ProjectForm);
