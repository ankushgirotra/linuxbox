import React, { useState } from "react";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import cookie from "react-cookies";
import { Row, Col } from "react-bootstrap";
import CustomCheckBox, { CustomCheck } from "../../../../../../shared/CustomCheckBox/customCheckBox";
import { CHECK } from "../../../../../timesheet/constants/timesheet.constants";
import "./PCDMReports.scss";
import axios from 'axios';
import moment from "moment";
import FileDownloader from 'js-file-download';

const FILE_NAME = "usersReport";

export default function PCDMUsersReport() {
    const [progress, setProgress] = useState(false);
    const onSubmit = () => {
        
            // window.open(`${cookie.load("ROVER_PCD_API")}/pcd/products/download/${FILE_NAME}?${users}`);
            const token = localStorage.getItem("token")
            setProgress(true)
            axios({
                url: `${cookie.load("ROVER_PCD_API")}/pcd/products/download/${FILE_NAME}`,
                method: 'GET',
                headers: {
                    Authorization: token ? `Bearer ${token}` : ''
                },
                onDownloadProgress(progressEvent) {
                    // const progressValue = Math.round((progressEvent.loaded / progressEvent.total) * 100);
                    setProgress(true);
                },
                responseType: 'blob',
            }).then(response => {
                setProgress(false)
                // const url = window.URL.createObjectURL(new Blob([response.data]));
                // const link = document.createElement('a');
                // link.href = url;
                // link.target = "_blank";
                // link.setAttribute('download', `Product Delegates ${moment().format("YYYY.MM.DD")}.xlsx`);
                // document.body.appendChild(link);
                // link.click()
                FileDownloader(response.data, `Product Delegates ${moment().format("YYYY.MM.DD")}.xlsx`)
                // window.open(url, "_blank").focus()
            }).catch(error => {
                console.log(error)
                setProgress(false)
            })
        
    };
   
    
    return (
        <div className="pcdm-accountability-report">
            <Row>
                <Col sm={4} md={4} lg={4} xl={4}>
                    <div className={`pcdm-btn-wrapper`}>
                        
                        <div className='pcdm-btn-wrapper pcdm-btn-wrapper--inline'>
                            <CustomButton variant={BUTTON_VARIANTS.BLUE_GOLD} size="md" loading={progress} fluid={true} onClick={onSubmit}>
                                Generate Product Delegates Report
                            </CustomButton>
                        </div>
                    </div>
                </Col>
                <Col sm={{ offset: 1, span: 5 }} md={{ offset: 1, span: 5 }} lg={{ offset: 1, span: 5 }} xl={{ offset: 1, span: 5 }}>
                    <div className={`pcdm-btn-wrapper`}>
                        <div className='accountability-report-description'>This report will provide a list of all product managers and product manager delegates.</div>
                    </div>
                </Col>
            </Row>
        </div >
    );
}
