import React from 'react';
import PCDMReports from "../../Admin/Reports/PCDMReports";
import { Container, Row, Col } from "react-bootstrap";
import { ChevronLeft } from "react-feather";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import { useHistory } from "react-router";
import { PCDM_ROUTES } from "../../../../../../app/Route/constants/pcdmRoutes.constants";

export default function PCDMReportView(props) {
    const history = useHistory();
    const backToPCDM = (e) => {
        history.push(PCDM_ROUTES.getHomeRoute())
    }
    return (
        <div className="pcdm-admin-container" style={{ position: "relative" }}>
            {<h4 className="pcdm-head center">GENERATE REPORTS</h4>}
            <Container fluid>
                <Row className='justify-content-md-center pl-1'>
                    <Col lg={{ offset: '1' }} xl={{ offset: '1' }}>
                        <CustomButton
                            variant={BUTTON_VARIANTS.PRIMARY}
                            onClick={(event) => backToPCDM(event)} 
                            title={"Click to go back to PCDM"}
                            className="products-add-link"
                        >
                            <div>
                                <ChevronLeft size="15" strokeWidth={3} />
                                <span className='mr-1'>Back to PCDM</span>
                            </div>
                        </CustomButton>
                    </Col>
                </Row>
                <Row className='justify-content-md-center' style={{ marginTop: "10px" }}>
                    <Col sm={10} md={10} lg={10} xl={10}>
                        <PCDMReports />
                    </Col>
                </Row>
            </Container>
        </div>
    )
}
