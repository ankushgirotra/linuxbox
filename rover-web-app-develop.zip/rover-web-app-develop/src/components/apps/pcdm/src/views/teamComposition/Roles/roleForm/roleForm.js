import React, { Component } from "react";
import "./roleForm.scss";
import TextField from "../../../../components/forms/textField/textField";
import SelectDropdown from "../../../../components/forms/select/select";
import CustomSelect from "../../../../components/forms/SelectDropdown/selectDropdown";
import AsyncSelect from "../../../../components/forms/SelectDropdown/AsyncSelect";
import {
  RESOURCE_OPTIONS,
  DEFAUL_RATE_FOR_DAS,
  DEFAULT_RATE_FOR_NON_DAS,
  RESOURCE_TYPE,
} from "../../../../constants/form.constants";
import { connect } from "react-redux";
import { DATA_STATUS } from "../../../../constants/service.constant";
import ErrorMsg from "../../../../components/forms/errorMsg/errorMsg";
import {
  MessageModal,
  DEFAULT_MSG_MODAL_CONFIG,
} from "../../../../components/MessageModal/messageModal";
import {
  stringToCurrency,
  stringToPercentage,
} from "../../../../services/form.service";
import {
  saveRoleThunk,
  editRoleThunk,
  deleteRoleThunk,
} from "../../../../store/roles.reducer";
import {
  validateRoleForm,
  handleRoleAPIResponse,
} from "../../../../services/role.service";
import {
  TEAM_ACTIONS,
  ACTIONS,
  TOOL_TIP_TITLE,
} from "../../../../constants/action.constants";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../../../components/forms/Button/button";
import {
  INFO_MESSAGES,
  TOOL_TIP_MESSAGE,
} from "../../../../constants/message.contants";
import { FormModal } from "../../../../components/FormModal/formModal";
const ROLE_INITIAL_STATE = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  keepForm: false,
  completeReload: true,
  resourceNewName: "",
  resourceNameOptions: [],
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    role: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
    },
    resourceName: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disabled: true,
    },
    resourceNameNEW: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
    },
    resourceType: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
    },
    allocation: {
      value: "",
      error: false,
      errorMsg: "",
      min: 0,
      max: 100,
      required: true,
    },
    rate: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
    },
  },
};
export class RoleForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ROLE_INITIAL_STATE };
  }
  componentDidMount() {
    if (this.props.formMode === TEAM_ACTIONS.EDIT_ROLE) {
      this.populateFileds(this.props.selectedRole);
    }
  }
  populateFileds = (role) => {
    const { formControls } = this.state;
    this.setState({
      resourceNewName: role.resourceNameNew,
      formControls: {
        ...formControls,
        role: { ...formControls.role, value: role.roleId },
        resourceName: {
          ...formControls.resourceName,
          value: role.resourceName,
        },
        resourceNameNEW: {
          ...formControls.resourceNameNEW,
          value: role.resourceIdNew,
        },
        resourceType: {
          ...formControls.resourceType,
          value: role.resourceType,
        },
        allocation: {
          ...formControls.allocation,
          value: stringToPercentage(role.allocation),
        },
        rate: {
          ...formControls.rate,
          value: stringToCurrency(String(role.rate), "blur", 2),
        },
      },
    });
  };
  getDefaultRate = (roleId, resourceType) => {
    const { roles } = this.props;
    let roleSelected;
    for (var role of roles) {
      if (roleId == role.roleId) {
        roleSelected = role;
      }
    }
    if (resourceType == RESOURCE_TYPE.EMPLOYEE) {
      return roleSelected.employeeDefaultRate;
    } else if (resourceType == RESOURCE_TYPE.OFFSHORE_CONTRACTOR) {
      return roleSelected.offshoreContractorDefaultRate;
    } else if (resourceType == RESOURCE_TYPE.ONSHORE_CONTRACTOR) {
      return roleSelected.onshoreContractorDefaultRate;
    } else if (resourceType == RESOURCE_TYPE.NEARSHORE_CONTRACTOR) {
      return roleSelected.nearshoreContractorDefaultRate;
    } else {
      return 0;
    }
  };
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    // let rateDefault = { ...formControls.rate };
    // if (name === "role") {
    //   let resourceType = formControls.resourceType.value;
    //   if (resourceType !== "" || resourceType !== null) {
    //     let rate = this.getDefaultRate(value, resourceType);
    //     rateDefault = {
    //       ...rateDefault,
    //       error: false,
    //       value: stringToCurrency(String(rate), "blur", 2),
    //     };
    //   }
    // } else if (name === "resourceType") {
    //   let roleId = formControls.role.value;
    //   if (roleId !== "" && roleId !== null) {
    //     let rate = this.getDefaultRate(roleId, value);
    //     rateDefault = {
    //       ...rateDefault,
    //       error: false,
    //       value: stringToCurrency(String(rate), "blur", 2),
    //     };
    //   }
    // }
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        // rate: {
        //   ...rateDefault,
        // },
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  onAllowcationChange = (event, on) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: event.error,
        allocation: {
          ...formControls.allocation,
          error: event.error,
          value:
            on === "blur"
              ? event.value === ""
                ? event.value
                : stringToPercentage(Number(event.value))
              : event.value,
          errorMsg: event.errorMessage,
        },
      },
    });
  };
  onRateChange = (event, on) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        rate: {
          ...formControls.rate,
          error: false,
          value: stringToCurrency(event.target.value, on, 2),
        },
      },
    });
  };
  onDeleteClick = () => {
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: "Are you sure you want to delete this role?",
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };
  handleDelete = async (button, data) => {
    const { team, selectedRole } = this.props;
    if (button === ACTIONS.YES) {
      let payload = { ...this.reqPayload(), active: false };
      this.props.deleteRole(
        payload,
        localStorage.getItem("productCode"),
        team.teamId,
        selectedRole.teamRoleId,
        this.handleResponse
      );
      this.setState({
        messageModalConfig: {
          ...this.state.messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...this.state.messageModalConfig,
          visible: false,
        },
      });
    }
  };
  resetForm = () => {
    this.setState({ ...ROLE_INITIAL_STATE });
  };
  handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleRoleAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData
    );
    if (this.state.keepForm) {
      this.resetForm();
      this.props.closeModal(
        modal.action,
        modal.props,
        true,
        this.state.completeReload
      );
    } else if (modal) {
      this.props.closeModal(
        modal.action,
        modal.props,
        false,
        this.state.completeReload
      );
    } else if (returnState) {
      this.setState({ ...returnState });
    }
  };
  reqPayload = () => {
    const { formControls } = this.state;
    let payload = {
      roleId: Number(formControls.role.value),
      resourceName: formControls.resourceName.value.trimRight(),
      resourceType: formControls.resourceType.value,
      allocation: Number(formControls.allocation.value.replace(/[^0-9]/g, "")),
      rate: parseFloat(
        formControls.rate.value.trim().replace("$", "").replace(/,/g, "")
      ),
      resourceNameNew: this.state.resourceNewName,
      resourceIdNew: formControls.resourceNameNEW.value,
      active: true,
    };
    return payload;
  };
  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;

    let validation = validateRoleForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (payload.rate == 0) {
        this.handleRateOnSubmit(payload);
      } else {
        this.saveOrEditRole(payload);
      }
    }
  };
  handleRateOnSubmit = (payload) => {
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Role rate",
        message: "Are you sure you want to save this role with a $0.00 rate?",
        visible: true,
        onClose: (button, data) => {
          if (button === ACTIONS.YES) {
            this.setState({
              messageModalConfig: {
                ...this.state.messageModalConfig,
                visible: false,
              },
            });
            this.saveOrEditRole(payload);
          }
          this.setState({
            messageModalConfig: {
              ...this.state.messageModalConfig,
              visible: false,
            },
          });
        },
      },
    });
  };
  saveOrEditRole = async (payload) => {
    const { formMode, team, selectedRole } = this.props;
    const { formControls } = this.state;
    if (formMode === TEAM_ACTIONS.ADD_ROLE) {
      await this.props.saveRole(
        payload,
        localStorage.getItem("productCode"),
        team.teamId,
        this.handleResponse
      );
    } else if (formMode === TEAM_ACTIONS.EDIT_ROLE) {
      const completeReload =
        selectedRole.resourceType === formControls.resourceType.value &&
        stringToCurrency(String(selectedRole.rate), "blur", 2) ===
          formControls.rate.value &&
        stringToPercentage(Number(selectedRole.allocation)) ===
          formControls.allocation.value;
      this.setState({ completeReload: !completeReload });
      await this.props.editRole(
        payload,
        localStorage.getItem("productCode"),
        team.teamId,
        selectedRole.teamRoleId,
        this.handleResponse
      );
    }
  };
  getRoleInfoStyle = () => {
    return {
      color: "red",
      "font-style": "italic",
      "font-size": "10.5px",
    };
  };
  onNameInputChange = (event) => {
    const { formControls } = this.state;
    let selected;
    let rateDefault = { ...formControls.rate };
    if (event.value === "000000") {
      this.setState({ resourceNewName: "N/A (Unnammed Resource)" });
    } else {
      selected = this.props.resourceNameList.data.find(
        (el) => el.employeeId === event.value
      );
      this.setState({ resourceNewName: selected.name });
      
    }
    let resourceRate = ""
    if(selected && selected.orgRelationship == 'EMP'){
      // if(selected.rate > 1 ){
      //   resourceRate = stringToCurrency(String(selected.rate), "blur", 2)
      // }else{
      //   resourceRate = stringToCurrency(String(84.0), "blur", 2)
      // }
      resourceRate = stringToCurrency(String(87.0), "blur", 2)

    }else if(selected && selected.rate){
      resourceRate = stringToCurrency(String(selected.rate), "blur", 2)
    }
    let resourceType = ""
    if(selected && selected.orgRelationship == 'CWR' && selected.location){
      if(selected.location=="MEX01" || selected.location=="CAN01" || selected.location=="CAN04" ){
        resourceType=RESOURCE_OPTIONS[3].desc;
      }else if(selected.location=="IND01" || selected.location=="PHL01"){
        resourceType=RESOURCE_OPTIONS[2].desc;
      }else{
        resourceType=RESOURCE_OPTIONS[1].desc;
      }
    }else if(selected && selected.orgRelationship == 'EMP'){
      resourceType=RESOURCE_OPTIONS[0].desc;
    }
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        resourceNameNEW: {
          ...formControls["resourceNameNEW"],
          error: false,
          value: selected ? selected.employeeId : "000000",
        },
        rate: {
          ...rateDefault,
          error: false,
          value: resourceRate,
        },
        resourceType: {
          ...resourceType,
          error: false,
          value: selected ? resourceType : null,
          disabled: selected ? true : false

        }
      },
    });
  };
  // onFormatOptionLabel = (data) => {
  //   // ? "" :- data.value2.lanId
  //   return <div><span className="formatOptionLabel">{data.label} </span> <span className="formatOptionvalue">- {data.value2.lanId}</span></div>
  // }
  onFormatOptionLabel = (data) => {
    return (
      <div>
        <span className="formatOptionLabel">{data.label} </span>
        <span className="formatOptionvalue">
          {data.value !== "000000" ? `- ${data.value2}` : null}
        </span>
      </div>
    );
  };
  resourceNameTooltip = () => {
    return (
      <>
        This field will now be connected to real PeopleSoft records so we can
        track resource allocation across product teams. Please select a resource
        if this role has been filled, or select <b>N/A</b> if it has not yet
        been staffed.{" "}
      </>
    );
  };
  getRoleForm = () => {
    const { formControls, resourceNameOptions } = this.state;
    const { roles, formMode } = this.props;
    const { resourceNameList } = this.props;
    let sortedList = [];
    if (
      resourceNameList &&
      resourceNameList.data &&
      resourceNameList.data.length
    ) {
      sortedList = resourceNameList.data.sort((a, b) => {
        if (a.name > b.name) return 1;
        else if (a.name < b.name) return -1;
        else return 0;
      });
      sortedList.unshift({
        name: "N/A (Unnammed Resource)",
        employeeId: "000000",
      });
      // this.setState({ resourceNameOptions: sortedList.slice(0, 100) });
    }
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <CustomSelect
              name="role"
              label={"Role"}
              placeholder="Select Role Type"
              formObj={formControls.role}
              config={{
                options: roles,
                value: "roleName",
                id: "roleId",
              }}
              formatOptionLabel={(prd) => `${prd.label}`}
              isRequired={formControls.role.required}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
              info={
                formMode === TEAM_ACTIONS.ADD_ROLE ? INFO_MESSAGES.ROLE : null
              }
              infoStyle={this.getRoleInfoStyle}
            />
          </div>
          <div className="pcdm-form__form-group-field form-group-field--inline ">
            <AsyncSelect
              name="resourceNameNEW"
              label={"Resource Name"}
              placeholder="Select Resource Name"
              formObj={formControls.resourceNameNEW}
              config={{
                options: sortedList,
                value: "name",
                id: "employeeId",
                id2: "lanId",
              }}
              formatOptionLabel={(prd) => this.onFormatOptionLabel(prd)}
              isRequired={formControls.resourceNameNEW.required}
              onChange={(e) => this.onNameInputChange(e)}
              showDefaultValues={true}
              customLabel={true}
            />

            <CustomSelect
              name="resourceType"
              label={"Resource Type"}
              placeholder="Select Resource Type"
              formObj={formControls.resourceType}
              config={{
                options: RESOURCE_OPTIONS,
                value: "desc",
                id: "desc",
              }}
              formatOptionLabel={(prd) => `${prd.label}`}
              isRequired={formControls.resourceType.required}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
              hasToolTip={true}
              toolTipTitle={TOOL_TIP_TITLE.RESOURCE_TYPE}
              toolTipMessage={TOOL_TIP_MESSAGE.RESOURCE_TYPE}
            />
          </div>
          {/* {formMode === TEAM_ACTIONS.EDIT_ROLE ? (
            <div className="pcdm-form__form-group-field">
              <AsyncSelect
                name="resourceNameNEW"
                label={"Resource Name NEW"}
                placeholder="Select Resource Name"
                formObj={formControls.resourceNameNEW}
                config={{
                  options: sortedList,
                  value: "name",
                  id: "employeeId",
                  id2: "lanId",
                }}
                formatOptionLabel={(prd) => this.onFormatOptionLabel(prd)}
                isRequired={formControls.resourceNameNEW.required}
                isRequired={formControls.resourceNameNEW.required}
                onChange={(e) => this.onNameInputChange(e)}
                hasToolTip={true}
                redTooltip={true}
                customLabel={true}
                getToolTipMessage={this.resourceNameTooltip}
                showDefaultValues={true}
              />
            </div>
          ) : null} */}
          <div className="pcdm-form__form-group-field form-group-field--inline ">
            <TextField
              name="allocation"
              label={"Allocation(%)"}
              formObj={formControls.allocation}
              isRequired={formControls.allocation.required}
              type="number"
              min={formControls.allocation.min}
              max={formControls.allocation.max}
              allowDecimal={false}
              onBlur={(e) => this.onAllowcationChange(e, "blur")}
              onChange={(e) => this.onAllowcationChange(e, "")}
              hasToolTip={true}
              toolTipTitle={"Allocation(%)"}
              toolTipMessage={TOOL_TIP_MESSAGE.ALLOCATION}
            />
            <TextField
              name="rate"
              label={"Rate($)"}
              formObj={formControls.rate}
              isRequired={formControls.rate.required}
              type="text"
              onBlur={(e) => this.onRateChange(e, "blur")}
              onChange={(e) => this.onRateChange(e, "")}
            />
          </div>
        </div>
        {formControls.error ? (
          <ErrorMsg
            message={formControls.errorMessage}
            errorDetail={formControls.errorDetail}
          />
        ) : null}
      </form>
    );
  };

  getFooter = () => {
    const { formMode } = this.props;
    const { edited } = this.state.formControls;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          onClick={() => {
            this.setState({ keepForm: false });
            this.onSubmit();
          }}
        >
          Save
        </CustomButton>
        {formMode === TEAM_ACTIONS.ADD_ROLE ? (
          <div className="form-add-another-button">
            <CustomButton
              variant={BUTTON_VARIANTS.LIGHT}
              size="md"
              onClick={() => {
                this.setState({ keepForm: true });
                this.onSubmit();
              }}
            >
              Save and Add Another
            </CustomButton>
          </div>
        ) : null}
        {formMode === TEAM_ACTIONS.EDIT_ROLE ? (
          <div className="form-delete-button">
            <CustomButton
              disable={edited}
              variant={BUTTON_VARIANTS.ERROR}
              onClick={this.onDeleteClick}
              size="md"
            >
              Delete
            </CustomButton>
          </div>
        ) : null}
        <div id="cancel_button">
          <a
            role="button"
            className="collapse-link"
            aria-expanded="false"
            onClick={this.props.closeModal}
          >
            Cancel
          </a>
        </div>
      </div>
    );
  };
  render() {
    const {
      formVisible,
      closeModal,
      header,
      saveRoleStatus,
      editRoleStatus,
      deleteRoleStatus,
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          isLoading={
            saveRoleStatus.status === DATA_STATUS.LOADING ||
            editRoleStatus.status === DATA_STATUS.LOADING ||
            deleteRoleStatus.status === DATA_STATUS.LOADING
          }
          visible={formVisible}
          closeModal={() => closeModal()}
          header={header}
          content={() => this.getRoleForm()}
          footer={() => this.getFooter()}
          className="role-form pcdm-form-new"
          isSCForm={true}
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

export const mapStateToProps = (state) => ({
  saveRoleStatus: state.RolesReducer.saveRoleStatus,
  editRoleStatus: state.RolesReducer.editRoleStatus,
  deleteRoleStatus: state.RolesReducer.deleteRoleStatus,
  resourceNameList: state.TeamCalculationsReducer.scrumMasterData,
});

export const mapDispatchToProps = (dispatch) => ({
  saveRole: (roleFormData, productCode, teamId, callback) =>
    dispatch(saveRoleThunk(roleFormData, productCode, teamId, callback)),
  editRole: (roleFormData, productCode, teamId, teamRoleId, callback) =>
    dispatch(
      editRoleThunk(roleFormData, productCode, teamId, teamRoleId, callback)
    ),
  deleteRole: (roleFormData, productCode, teamId, teamRoleId, callback) =>
    dispatch(
      deleteRoleThunk(roleFormData, productCode, teamId, teamRoleId, callback)
    ),
});
export default connect(mapStateToProps, mapDispatchToProps)(RoleForm);

