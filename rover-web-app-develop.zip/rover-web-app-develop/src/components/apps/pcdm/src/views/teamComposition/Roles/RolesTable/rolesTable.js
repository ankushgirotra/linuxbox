import React, { useState, useMemo } from "react";
import { Popover, OverlayTrigger } from "react-bootstrap";
import { Eye, EyeOff, Plus, HelpCircle, AlertCircle } from "react-feather";
import {
  stringToCurrency,
  roundOff,
  formatNumberWithCommaSeprated,
} from "../../../../services/form.service";
import sortBy from "../../../../../../../../services/helper.service";
import { TOOL_TIP_MESSAGE } from "../../../../constants/message.contants";
import { RESOURCE_OPTIONS as resList } from "../../../../constants/form.constants";
import {
  TEAM_ACTIONS,
  TOOL_TIP_TITLE,
} from "../../../../constants/action.constants";
import CustomButton from "../../../../components/forms/Button/button";
import ToolTip from "../../../../components/ToolTip/ToolTip";
import DataGrid from "../../../../components/DataGrid/dataGrid";
import AllocationPopOver from "./allocationPopover"
import "./rolesTable.scss";

export default function RolesTable({
  onAddOrEditRole,
  roles,
  teamRoles,
  canEditRole,
  iiqRole,
}) {
  // roleCalculation
  const [hideRate, setHideRate] = useState(true);

  const columns = useMemo(() => [
    {
      Header: (props) => roleHead(),
      accessor: "roleId",
      Cell: ({ row: { original } }) => showRole(original, "roleId"),
      disableFilters: true,
      disableSortBy: false,
    },
    {
      Header: "Name",
      accessor: "resourceNameNew",
      Cell: ({ row: { original } }) => formatResourceName(original, "resourceIdNew", "resourceNameNew"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Resource type",
      accessor: "resourceType",
      Cell: ({ row: { original } }) => formatResourceType(original, "resourceType"),
      disableFilters: true,
    },
    {
      Header: "Allocation",
      accessor: "allocation",
      disableFilters: true,
      Cell: ({ row: { original } }) => showAllocation(original, "allocation"),
    },
    
    // {
    //   Header: (props)=> showNameNewHead(),
    //   accessor: "resourceNameNew",
    //   disableFilters: true,
    //   disableSortBy: true,
    // },
  ]);

  if (iiqRole.TITLE !== "VIEWER") {
    columns.splice(4, 0, {
      Header: (props) => roleRateHead(),
      accessor: "rate",
      disableFilters: true,
      Cell: ({ row: { original } }) => showRate(original, "rate"),
      disableSortBy: true,
    });
    columns.splice(5, 0, {
      Header: (props) => sprintHoursHeadWithToolTip(),
      accessor: "sprintHours",
      disableFilters: true,
      Cell: ({ row: { original } }) => showHour(original, "sprintHours"),
    });
    columns.splice(6, 0, {
      Header: "Sprint Cost",
      accessor: "sprintCost",
      disableFilters: true,
      Cell: ({ row: { original } }) => showCost(original, "sprintCost"),
    });
  }

  const roleHead = () => {
    return (
      <div className="add-role-head">
        <div>Role</div>
        {canEditRole ? (
          <span className="add_role-btn">
            <CustomButton
              onClick={(e) => {
                e.stopPropagation();
                onAddOrEditRole(TEAM_ACTIONS.ADD_ROLE, {});
              }}
              title={"Click to add role"}
              className="role-add-link"
            >
              <Plus size="15" strokeWidth="3" />
              <span className="ml-1">Add Role</span>
            </CustomButton>
          </span>
        ) : null}
      </div>
    );
  };

  const showRole = (row, key) => {
    let curRole = roles.length
      ? roles.filter((role) => role.roleId === row.roleId)[0]
      : null;
    return canEditRole ? (
      <label
        className="td-role cursor-ptr"
        title={curRole ? curRole.roleName : ""} //changed curRole.description
        onClick={() => onAddOrEditRole(TEAM_ACTIONS.EDIT_ROLE, { ...row })}
      >
        {curRole ? curRole.roleName : ""}
      </label>
    ) : (
      <label className="td-role" title={curRole ? curRole.roleName : ""}>
        {curRole ? curRole.roleName : ""}
      </label>
    );
  };

  const formatResourceType = (row, key) => {
    let resourceType = resList.filter((res) => res.desc === row[key])[0].value;
    return <label title={resourceType}> {resourceType} </label>;
  };

  const formatResourceName = (row, key, value) => {
    let resourceName = row[key] ? row[key] === "000000" ? "N/A" : row[value] : "N/A";
    let validResName = resourceName !== "N/A";
    if (validResName) {
      return (
        <AllocationPopOver resourceName={resourceName} resourceId={row[key]} />
      );
    } else {
      return <label title={resourceName}> {resourceName} </label>;
    }
  };

  const showAllocation = (row, key) => {
    const value = `${row[key]}%`;
    return <label title={value}>{value}</label>;
  };

  const resourceNameTooltip = () => {
    return (
      <>
        This field will now be connected to real PeopleSoft records so we can
        track resource allocation across product teams. Please select a resource
        if this role has been filled, or select <b>N/A</b> if it has not yet
        been staffed.{" "}
      </>
    );
  };

  const showNameNewHead = () => {
    return (
      <div className="sprint-hours-head">
        <span>
          Name NEW
          <ToolTip
            toolTipMessage={resourceNameTooltip()}
            content={() => (
              <span className="custom-tool-tip" title="Click to get info">
                <AlertCircle size="15" color="#d50000" strokeWidth={2.5} />
              </span>
            )}
          />
        </span>
      </div>
    );
  };

  const roleRateHead = () => {
    return (
      <div className="rate-head">
        <div>Rate</div>
        <span
          className="rate-toggle"
          onClick={() => setHideRate(!hideRate)}
          title={
            "Click to hide/unhide hourly rates. Rates are confidential, so please be aware of your surroundings."
          }
        >
          {hideRate ? (
            <EyeOff size="13" strokeWidth={3} stroke="#3b77fe" /> //color="#b5b5b5"
          ) : (
            <Eye size="13" strokeWidth={3} stroke="#3b77fe" />
          )}
        </span>
      </div>
    );
  };

  const showRate = (row, key) => {
    const value = stringToCurrency(String(row[key]), "blur", 2);
    return (
      <label className={`${hideRate ? `hide-it` : ``}`} title={value}>
        {value}
      </label>
    );
  };

  const sprintHoursHeadWithToolTip = () => {
    return (
      <div className="sprint-hours-head">
        <span>
          {" "}
          Sprint Hours
          <ToolTip
            toolTipTitle={TOOL_TIP_TITLE.SPRINT_HOURS}
            toolTipMessage={TOOL_TIP_MESSAGE.SPRINT_HOURS}
            content={() => (
              <span
                className="custom-tool-tip"
                title="Click to get info"
                onClick={(event) => event.stopPropagation()}
              >
                <HelpCircle size="16" color="#3b77fe" strokeWidth={2} />
              </span>
            )}
          />
        </span>
      </div>
    );
  };

  const showHour = (row, key) => {
    // let roleCalc = getCalc(row);
    if (row && (row.sprintHours || row.sprintHours >= 0)) {
      const value = formatNumberWithCommaSeprated(
        roundOff(parseFloat(row.sprintHours), 1, true)
      );
      return (
        <span title={value} className="ml-3 calculations_style">
          {value}
        </span>
      );
    } else {
      return <span title={""}></span>;
    }
  };

  const showCost = (row, key) => {
    // let roleCalc = getCalc(row);
    if (row && (row.sprintCost || row.sprintCost >= 0)) {
      const roundOffVal = roundOff(parseFloat(row.sprintCost), 2);
      const value = stringToCurrency(String(roundOffVal), "blur", 2);
      return <label title={value} className="calculations_style">{value}</label>;
    } else {
      return <label title={""}></label>;
    }
  };

  /*
  const toolTipSprintHour = () => {
    return (
      <Popover className="custom-popover">
        <Popover.Title className="custom-popover-header">
          {TOOL_TIP_TITLE.SPRINT_HOURS}
        </Popover.Title>
        <Popover.Content className="custom-popover-content">
          {TOOL_TIP_MESSAGE.SPRINT_HOURS}
        </Popover.Content>
      </Popover>
    );
  };

  const sprintHoursHeadWithToolTip = () => {
    return (
      <div className="sprint-hours-head">
        <span>Sprint Hours
          <span onClick={(event) => event.stopPropagation()}>
            <OverlayTrigger
              trigger="click"
              rootClose
              placement="auto"
              overlay={toolTipSprintHour()}
            >
              <span className="custom-tool-tip" title="Click to get info">
                <HelpCircle size="17" strokeWidth={2} stroke="#3b77fe" />
              </span>
            </OverlayTrigger>
          </span>
        </span>
      </div>
    );
  };

  const getCalc = (currRole) => {
    return roleCalculation.filter((role) => role.teamRoleId === currRole.teamRoleId)[0] || 0;
  };

  const alteredTeamRoles = useMemo(() => {
    let tempArray = teamRoles.map((role, index) => {
      return {
        ...role,
        sprintHours: getCalc(role).sprintHours,
        sprintCost: getCalc(role).sprintCost,
      };
    });
    return [...tempArray];
  }, [teamRoles]); 

  const sorted = sortBy(alteredTeamRoles, "lastModifiedDate", "date"); */

  const sorted = useMemo(
    () => [...sortBy(teamRoles, "lastModifiedDate", "date")],
    [teamRoles]
  );

  return (
    <div className="role-table-container pcdm-scroll-vertical">
      <DataGrid
        data={sorted}
        columns={columns}
        showUpdatedDataGrid={true}
        noRowText={
          canEditRole
            ? "Click + icon to start adding roles to the team"
            : "No Roles found"
        }
      />
    </div>
  );
}
