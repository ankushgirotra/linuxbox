import "./CapacityConstraintStatusContainer.scss";
import React from "react";
import {
  CONSTRAINT_CAPACITY_ICON_COLOR,
  CONSTRAINT_CAPACITY_STATUS,
  CONSTRAINT_CAPACITY_VALUE,
} from "../../../constants/message.contants";
import { TOOL_TIP_TITLE } from "../../../constants/action.constants";
import ToolTip from "../../../components/ToolTip/ToolTip";
import { capacityConstraintStatusToolTip, publishDueDateHistory } from "../../../templates/projects.template";
import { connect } from "react-redux";
import PublishReport from "./publishReport";
import { getFormattedDate ,getUTCFormattedDate } from "../../../services/form.service";
import moment from "moment";
import LastPublishIcon from "../../../../../../../shared/img/icon-img/LastPublishIcon.png";
import {getPublishAnswersThunk } from "../../../store/summary.reducer";
import RMFOllowProduct from "./RMFollowProduct"
import { HelpCircle } from "react-feather"
function CapacityConstraintStatusContainer(props) {
  const { capacityConstraint, maxcapacityConstraint, demand, capacity,
    lastPublished ,nextPublishDueDate , previousPublishDueDate , actualsUploadDate } = props.summary;
  const { loggedInUser } = props
  const { ROVER_IIQ_ROLES } = loggedInUser;
  let dCValueStatus = "DEFAULT";
  if (maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.LOW) {
    dCValueStatus = "LOW";
  } else if (
    maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.LOW &&
    maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.MED_LOW
  ) {
    dCValueStatus = "MED_LOW";
  } else if (
    maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.MED_LOW &&
    maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.HIGH
  ) {
    dCValueStatus = "MEDIUM";
  } else if (maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.HIGH) {
    dCValueStatus = "HIGH";
  }
  var iconProperties = {
    style: {
      backgroundColor: CONSTRAINT_CAPACITY_ICON_COLOR[dCValueStatus],
    },
    status: CONSTRAINT_CAPACITY_STATUS[dCValueStatus],
  };
  let is30Day = moment().diff(moment(lastPublished), "days") >= 30;

  let canBlink = () => {
		if (
			nextPublishDueDate != null &&
			nextPublishDueDate != undefined &&
			actualsUploadDate != null &&
			actualsUploadDate != undefined &&
			previousPublishDueDate != null &&
      previousPublishDueDate != undefined &&
      nextPublishDueDate != null &&
			nextPublishDueDate != undefined 
		) {
      //checking actual upload date is in between prev and next publish Due date
      //If it is true the we have to blink the date
			let isActualUploadDateBetween = moment(actualsUploadDate).isBetween(
				moment(previousPublishDueDate),
				moment(nextPublishDueDate)
      );
      //checking last publish date is in between actual upload date and next publish Due date
      //If it is true , then publish is done and we should stop blinking 
      //If it is false , then publish is not done after actuals upload and we should blinking 
			let isLastPublishDateBetween = moment(lastPublished).isBetween(
				moment(actualsUploadDate),
				moment(nextPublishDueDate)
      ); 
			return isActualUploadDateBetween&&!isLastPublishDateBetween;
		}
		return false;
  };

  let colorOfText=()=>{
      if (
        nextPublishDueDate != null &&
        nextPublishDueDate != undefined &&
        actualsUploadDate != null &&
        actualsUploadDate != undefined &&
        previousPublishDueDate != null &&
        previousPublishDueDate != undefined &&
        nextPublishDueDate != null &&
        nextPublishDueDate != undefined 
      ) {
        let isActualUploadDateBetween = moment(actualsUploadDate).isBetween(
          moment(previousPublishDueDate),
          moment(nextPublishDueDate)
        );
        
        return (isActualUploadDateBetween)?'red':'black';
      }
      return 'black';
    };
  return (
    <div className="capacity-constraint-container">
      <div className="capacity-constraint-head" key={1}>
        <p>Capacity Constraint Status</p>
        <ToolTip
          toolTipTitle={TOOL_TIP_TITLE.CONSTRAINT_CAPACITY_STATUS}
          toolTipMessage={capacityConstraintStatusToolTip(maxcapacityConstraint, demand, capacity)}
          content={() => (
            // <HelpCircle size={3} strokeWidth={2} />
            <span className="fa-question-icon-style">
              <i className="far fa-question-circle" title="Click to get info"></i>
            </span>
          )}
        ></ToolTip>
      </div>
      <div className="capacity-constraint-body">
        <div className="capacity-info" >
        <div className="capacity-constraint-status-container">
          <div className="capacity-constraint-avatar" style={iconProperties.style} />
          <span className="capacity-constraint-status">{iconProperties.status}</span>
        </div>
        <div className="divider">|</div>
        <div className="capacity-constraint-value">
          <p>D/C value:&nbsp;<span>{maxcapacityConstraint}%</span></p>
        </div>
        </div>
      <div className="info2" > 
      <div className="dates-info" >  
        <div className={`publish-date ${is30Day ? `publish-date-exceed` : ``}`}>
          <span style={{'color':'black'}} >Last Published: </span>
          <span> 
          {lastPublished ? getFormattedDate(lastPublished, "MM/DD/YYYY")  : "--"}
          {lastPublished ? <ToolTip
                toolTipTitle={"Capacity Constraint History"}
                toolTipMessage={publishDueDateHistory(props.publishAnswers)}
                content={() => (
                  <img
                    className="publishViewers-icon"
                    src={LastPublishIcon}
                  />
                )}
                toolTipPlacement="left"
              ></ToolTip> : null }
              </span>
        </div>
        
        <div className={`next-publish-date`}>
          <span style={{'color':'black'}}>Next Publish Due: </span>
          <span class={`${canBlink() ? `blink` : ``}`} style={{'color':colorOfText()}}>
            {nextPublishDueDate ? getUTCFormattedDate(nextPublishDueDate, "MM/DD/YYYY") : "--"}
          </span>
        </div>
      </div>
        <div>
        {props.pcdmAccess.writeAccess ? (
          <PublishReport
            dcStatus={iconProperties}
            capacityConstraint={maxcapacityConstraint}
            checkForecastChanges={props.checkForecastChanges}
          />
        ) : null}
        {ROVER_IIQ_ROLES.RESOURCE_MANAGER ? <RMFOllowProduct /> : null}
        </div>
      </div>
    </div>
    </div>
  );
}

export const mapStateToProps = (state) => ({
  summary: state.SummaryReducer.summaryData.data,
  publishAnswers: state.SummaryReducer.publishAnswers.data,
  loggedInUser: state.AuthReducer,
});

export default connect(mapStateToProps)(CapacityConstraintStatusContainer);
