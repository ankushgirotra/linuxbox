import React, { Component, useState, useEffect, useMemo } from "react";
import Info from "../../components/info/info";
import "./summary.scss";
import { Container, Row, Col } from "react-bootstrap";
import { connect } from "react-redux";
import moment from "moment";
import PCDMComposedChart from "../../components/ComposedChart/composedChart";
import { getSummaryChartThunk, getResourceForecastThunk, getPublishAnswersThunk } from "../../store/summary.reducer";
import { setRoleOptionsThunk } from "../../store/roles.reducer";
import InitialEstimatesTable from "./SummaryTable/initialEstimatesTable";
import { ProductResourceForecastTable } from "./SummaryTable/productResourceForecastTable";
import List from "../../components/List/list";
// import { FORM_DATE_FORMAT } from "../../constants/form.constants";
import { getFormattedDate } from "../../services/form.service";
import Collapsible from "../../components/Collapsible/collapsible";
import { DATA_STATUS } from "../../constants/service.constant";
import DataHandler from "../../components/DataHandler/dataHandler";
import { withRouter } from "react-router";
import ExtraCapacityShape from "../../services/chart.service";
import { RefreshCw } from "react-feather";
import Switch from "../../components/forms/Switch/switch";
// import { FORM_CONTROL_DEFAULT } from "../../constants/form.constants";
import Datepicker from "../../components/Datepicker/datepicker";
import {
  FORM_CONTROL_DEFAULT,
  MONTH_YEAR_FORMAT,
  FORM_DATE_FORMAT,
} from "../../constants/form.constants";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../components/forms/Button/button";

export const filterList = [
  { id: 1, name: "All" },
  { id: 2, name: "Funded" },
  { id: 3, name: "Unfunded" },
];

export const intakeEstimatesFilterOptions = [
  { id: 1, name: "high-end Intake estimates" },
  { id: 2, name: "low-end Intake estimates" },
];

export const FUNDED = [
  { key: "projectFunded", fill: "#010260", name: "Project Funded" }, // #f47862
  { key: "productCore", fill: "#B5C3E0", name: "Product Core" }, // #e8a838
];
export const EXTRA_CAPACITY = [
  {
    key: "extraCapacity",
    fill: "#923031",
    name: "Extra Capacity",
    stroke: "#00000000",
    customShape: (props) => <ExtraCapacityShape {...props} />,
  },
];
export const UNFUNDED = [{ key: "unfunded", fill: "#FCC00A", name: "Unfunded" }]; //#f47862
export const CAPACITY = {
  required: true,
  dataKey: "capacity",
  stroke: "#78A552",
  strokeWidth: 2,
  name: "Capacity",
}; //#028ee6

function Summary(props) {
  const { productCode, chartData, productDetails, chartLoading, resourceForecast, roles } = props;

  const [chartConfig, setChartConfig] = useState({
    loading: false,
    xAxisKey: "month",
    barConfig: {
      required: true,
      stack: [...FUNDED, ...UNFUNDED, ...EXTRA_CAPACITY],
      barSize: 30,
    },
    lineConfig: [{ ...CAPACITY }],
  });
  const [currentFilter, setCurrentFilter] = useState(filterList[0]);
  const [actualChartData, setActualChartData] = useState([]);
  const [chartDataInstance, setChartDataInstance] = useState([]);
  useEffect(() => {
    props.getSummaryChart(productCode);
    props.getPublishAnswers(productCode)
    props.setRoleOptions();
    props.getResourceForecast(productCode);
  }, [])
  useEffect(() => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    let filteredArray = []
    // let endDate = new Date(currentYear+1, 2, 31)
    // let startDate = new Date(currentYear, 9, 1)
    let endDate = new Date(currentYear, 11, 31)
    if (currentMonth > 5) {
      let startDate = new Date(currentYear, 0, 1)
      filteredArray = chartData.filter((el) => new Date(el.month) >= startDate && new Date(el.month) <= endDate)
    } else {
      let startDate2 = new Date()
      startDate2.setMonth(currentMonth - 6)
      startDate2.setDate(1)
      filteredArray = chartData.filter((el) => new Date(el.month) >= startDate2 && new Date(el.month) <= endDate)
    }
    // filteredArray = chartData.filter((el) => new Date(el.month) >= startDate && new Date(el.month) <= endDate)
    let data = chartData;
    let minStartDate;
    if (chartData.length) {
      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j < data.length; j++) {
          if (new Date(data[i].month) < new Date(data[j].month)) {
            let temp = data[i];
            data[i] = data[j];
            data[j] = temp;
          }
        }
      }
      minStartDate = new Date(data[0].month)
    }
    if (filteredArray.length) {
      let endMonthFirstDate = new Date(filteredArray[filteredArray.length - 1].month);
      let endMonthLastDate = new Date (moment(endMonthFirstDate).endOf("month"));
      let maxEndDate = new Date(data[data.length - 1].month)
      let maxEndLastDate= new Date (moment(maxEndDate).endOf("month"));
      setActualChartData(filteredArray)
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          value: new Date(filteredArray[0].month),
          min: minStartDate,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          disabled: false,
          value: endMonthLastDate,
          min: new Date(filteredArray[0].month),
          max: maxEndLastDate,
          error: false,
          // value: new Date(filteredArray[filteredArray.length - 1].month),
          // max: new Date(data[data.length - 1].month),        
        },
      })
    }

  }, [chartData])
  useEffect(() => {
    setChartDataInstance(chartData)
  }, [chartData])
  const onFilterChange = (item) => {
    let isFunded = item.id === 2;
    let isAll = item.id === 1;
    setCurrentFilter(item)
    setChartConfig({
      ...chartConfig,
      barConfig: {
        ...chartConfig.barConfig,
        stack: isAll
          ? [...FUNDED, ...UNFUNDED, ...EXTRA_CAPACITY]
          : isFunded
            ? [...FUNDED, ...EXTRA_CAPACITY]
            : [...UNFUNDED],
      },
      lineConfig: isFunded || isAll ? [{ ...CAPACITY }] : [],
    });
  };

  const chartTableLow = useMemo(() => {
    return actualChartData.length ? actualChartData.map((el) => {
      const newEl = {
        capacity: el.capacity,
        extraCapacity: el.extraCapacity,
        month: el.month,
        productCore: el.productCore,
        projectFunded: el.projectFunded,
        unfunded: el.unfunded,
      }
      return newEl;
    }) : []
  }
    , [actualChartData]);
  const chartTableHigh = useMemo(() => {
    return actualChartData.length ? actualChartData.map((el) => {
      const newEl = {
        capacity: el.capacity,
        extraCapacity: el.maxRangeExtraCapacity,
        month: el.month,
        productCore: el.maxRangeProductCore,
        projectFunded: el.maxRangeProjectFunded,
        unfunded: el.maxRangeUnfunded,
      }
      return newEl;
    }) : []
  }
    , [actualChartData]);
  const [chartDataCalc, setChartData] = useState(chartTableLow);
  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    storyPointMode: {
      ...FORM_CONTROL_DEFAULT,
      value: 2,
      required: false,
    },
  });
  useEffect(() => {
    if (formControls.storyPointMode.value === 1) {
      setChartData(chartTableLow)
    } else {
      setChartData(chartTableHigh);
    }
  }, [formControls.storyPointMode.value, chartTableLow, actualChartData, chartTableHigh])
  const onIntakeEstimatesChange = (value) => {
    setFormControls({
      ...formControls,
      edited: true,
      storyPointMode: {
        ...formControls.storyPointMode,
        value: value,
      },
    });
  }
  const [brushIndex, setBrushIndex] = useState({
    startIndex: 0,
    endIndex: 0,
  });
  useEffect(() => {
    if (
      actualChartData.length
    ) {
      let start = actualChartData.findIndex((el) => el.month === moment().format("MMM YYYY")),
        end = 0;
      /* If there is current month and 3 months from current month is exist in chart period 
      then set 3 months from current month as end index */
      if (start < 0) {
        start = 0;
      }
      if (start + 3 <= actualChartData.length - 1) {
        end = start + 3;
      } else {
        end = actualChartData.length - 1;
      }
      if (start != -1 && start - 3 > 0) {
        start = start - 3;
      } else {
        start = 0;
      }
      setBrushIndex({
        startIndex: start,
        endIndex: end,
      });
    }
  }, [actualChartData]);

  const customToolTip = (payload) => {
    let list =
      currentFilter.id == 1
        ? ["capacity", "projectFunded", "productCore", "unfunded", "extraCapacity"]
        : currentFilter.id == 2
          ? ["capacity", "projectFunded", "productCore", "extraCapacity"]
          : ["unfunded"];
    let forecastTooltip = list.map((el, index) => {
      let obj = payload.filter((item) => item.dataKey === el)[0];
      return (
        <div className="custom-tooltip" key={index}>
          <span style={{ color: `${obj.color}` }}>{obj.name.toLowerCase()}</span>
          <span>-</span>
          <span>{obj.value.toLocaleString()}</span>
        </div>
      );
    });
    return forecastTooltip;
  };
  const [formControlsDate, setFormControlsDate] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    startMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    endMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
  });
  const manageMonthSelection = (type, date) => {
    const { endMonth } = formControlsDate;
    let valueInMoment = moment(date, FORM_DATE_FORMAT);
    let validatedEndMonth = endMonth.value;

    if (type === "startMonth") {

      if (endMonth.value && valueInMoment.isAfter(moment(endMonth.value, FORM_DATE_FORMAT))) {
        validatedEndMonth = "";
      }
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          value: date,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          disabled: false,
          value: validatedEndMonth,
          min: date,
          error: false,
        },
      });
    } else if (type === "endMonth") {
      let lastDate= new Date (moment(date).endOf("month"));
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          value: date ? lastDate : null,
          error: false,
        },
      });
    }
  };

  const chartHeader = () => {
    return <div className="chart-header"> <p>FILTER</p></div>
  }

  const getTimeRangeHeader = () => {
    return (
      <>
        <p className="withAddButton"> Time range </p>
        <CustomButton
          onClick={() => { onSubmit() }}
          className="time_range-btn"
        >
          <RefreshCw size={13} strokeWidth={3} />
          <span>Refresh</span>
        </CustomButton>
      </>
    )
  }

  const onSubmit = () => {
    const filteredArray = chartDataInstance.length ? chartDataInstance.filter((el) =>
      new Date(el.month) >= new Date(formControlsDate.startMonth.value) &&
      new Date(el.month) <= new Date(formControlsDate.endMonth.value)) : []
    setActualChartData(filteredArray);
  };


  // const info = {
  //   "Product Manager": productDetails ? props.getProductManagerName() : null,
  //   "Product Line": productDetails && productDetails.portfolio,
  //   Product: productDetails && productDetails.name,
  //   "PRD Code": productDetails && productDetails.productCode,
  //   "Last Updated":
  //     productDetails && productDetails.lastModifiedDate
  //       ? moment(productDetails.lastModifiedDate).format("MM/DD/YYYY hh:mm A")
  //       : "",
  // };
  return (
    <div className="pcdm-container">
      <Container fluid>
        {/* <Collapsible>
          <Row>
            <Col sm={12} md={3} lg={3} xl={3}>
              <div className="summary-info">
                <Info info={info} history={props.history} />
              </div>
            </Col>
          </Row>
        </Collapsible> */}
        <DataHandler
          loader={{
            state: chartLoading === DATA_STATUS.LOADING,
            show: true,
          }}
          showData={chartDataInstance.length}
          emptyDataMessage="Add Teams and Projects to view Capacity & Demand Estimates"
        >
          <Row className="demand-capacity-graph">
            <Col sm={3} md={3} lg={3} xl={3} className="summary-filter-container">
              <div className="sticky-top fixedit">
                <div className="chart-filter-container-summary">
                  <List
                    className={"chart-filter-list"}
                    list={[...filterList]}
                    title={() => chartHeader()}
                    onChange={onFilterChange}
                    selected={currentFilter}
                    id="id"
                    value="name"
                    groupName="chart-filter-list"
                    hideRadioButton={true}
                  />
                </div>
                <div className="list-select-container time-range-summary" >
                  <div className="teams-head pcdm-time_range-header"> {getTimeRangeHeader()} </div>
                  <div className="time-range-summary-dates">
                    <form className="pcdm-form">
                      <div className="pcdm-form__form-group">
                        <div className="pcdm-form__form-group-field">
                          <Datepicker
                            name="startMonth"
                            label={"Start Month"}
                            formObj={formControlsDate.startMonth}
                            isRequired={formControlsDate.startMonth.required}
                            onChange={manageMonthSelection}
                            placeholderText={"Ex: Jan, 2020"}
                            dateFormat={MONTH_YEAR_FORMAT}
                            showMonthYearPicker={true}
                            customInput={true}
                          />
                        </div>
                        <div className="pcdm-form__form-group-field">
                          <Datepicker
                            name="endMonth"
                            label={"End Month"}
                            formObj={formControlsDate.endMonth}
                            isRequired={formControlsDate.endMonth.required}
                            onChange={manageMonthSelection}
                            dateFormat={MONTH_YEAR_FORMAT}
                            placeholderText={"Ex: Apr, 2021"}
                            showMonthYearPicker={true}
                            customInput={true}
                          />
                        </div>
                        {/* <div className="float-right" >
                        <CustomButton
                          variant={BUTTON_VARIANTS.PRIMARY}
                          size="md"
                          onClick={() => {
                            onSubmit();
                          }}
                          fluid = {true}
                        >
                          Refresh
                          </CustomButton>
                      </div> */}
                      </div>
                    </form>

                  </div>
                </div>
              </div>
            </Col>

            <Col sm={9} md={9} lg={9} xl={9} className="pcdm-summary-graph_N_table ">
              <Row>
                <Col sm={12} md={12} lg={12} xl={12}>
                  <div className="custom-summary-chart">
                    <h4 className="pcdm-head center">
                      <span>Capacity & Demand Estimates</span>
                      {chartLoading === DATA_STATUS.LOADING ? null : (
                        <span
                          title="click to refresh Capacity & Demand Estimates"
                          className="summary-refresh"
                          onClick={() => {
                            props.getSummaryChart(props.productCode)
                            // this.setState({startIndex:this.state.initialStartIndex, endIndex: this.state.initialEndIndex})
                          }}
                        >
                          <RefreshCw size={13} strokeWidth={3} />
                        </span>
                      )}
                    </h4>
                    <PCDMComposedChart
                      chartLoading={chartLoading}
                      {...chartConfig}
                      points={chartDataCalc}
                      brushConfig={{
                        dataKey: "month",
                        startIndex: brushIndex.startIndex,
                        endIndex: brushIndex.endIndex,
                        onChange: (points) =>
                          setBrushIndex({
                            startIndex: points.startIndex,
                            endIndex: points.endIndex,
                          }),
                      }}
                      customToolTip={customToolTip}
                    />
                  </div>
                </Col>
              </Row>

              {chartLoading === DATA_STATUS.LOADING || chartDataInstance.length === 0 ? null : (
                <Row>
                  <Col sm={12} md={12} lg={12} xl={12}>
                    <div className="summary-intake-estimates-switch-option">
                      <Switch
                        name={"intakeEstimatesSwitch"}
                        config={{
                          options: [
                            { id: 1, value: "Use low-end Intake estimates" },
                            { id: 2, value: "Use high-end Intake estimates" },
                          ],
                          id: "id",
                          value: "value",
                        }}
                        className="summary-intake-estimates-switch"
                        formObj={formControls.storyPointMode}
                        onChange={onIntakeEstimatesChange}
                      />
                    </div>
                    <InitialEstimatesTable
                      initialEstimates={chartDataCalc.slice(
                        brushIndex.startIndex,
                        brushIndex.endIndex + 1
                      )}
                    />
                  </Col>
                </Row>
              )}
        
              <Row>
                <Col sm={12} md={12} lg={12} xl={12}>
                  <ProductResourceForecastTable resourceForecast={resourceForecast} roles={roles} />
                </Col>
              </Row>  

            </Col>

          </Row>

        </DataHandler>

      </Container>
    </div>
  );
}

export const mapStateToProps = (state) => {
  const chartData = [...(state.SummaryReducer.summaryData.data.summaryReport || [])];
  let props = {
    chartData: [
      ...chartData.map((el) => {
        let temp = {
          ...el,
          month: getFormattedDate(el.month, "MMM YYYY", FORM_DATE_FORMAT),
        };
        return temp;
      }),
    ],
    chartLoading: state.SummaryReducer.summaryData.status,
    resourceForecast: state.SummaryReducer.resourceForecast,
    roles: state.RolesReducer.roles,
  };
  return props;
};

export const mapDispatchToProps = (dispatch) => ({
  getSummaryChart: (productCode) => dispatch(getSummaryChartThunk(productCode)),
  getResourceForecast: (productCode) => dispatch(getResourceForecastThunk(productCode)),
  setRoleOptions: () => dispatch(setRoleOptionsThunk()),
  getPublishAnswers: (productCode) => dispatch(getPublishAnswersThunk(productCode)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Summary));

