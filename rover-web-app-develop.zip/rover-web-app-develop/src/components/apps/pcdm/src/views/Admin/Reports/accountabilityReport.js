import React, { useState } from "react";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import cookie from "react-cookies";
import { Row, Col } from "react-bootstrap";
import FileDownloader from "js-file-download";
import "./PCDMReports.scss";
import axios from 'axios';

const ACC_REPORT_FILE_NAME = "Accountability";
const CAP_REPORT_FILE_NAME = "CapacityConstraint"
export default function AccountabilityReport() {
  const [progress, setProgress] = useState(false)
  const [capProgress, setCapProgress] = useState(false)
  const onSubmit = () => {
    const token = localStorage.getItem("token")
    setProgress(true)
    axios({
      url: `${cookie.load("ROVER_PCD_API")}/pcd/products/reports/${ACC_REPORT_FILE_NAME}`,
      // url: `https://rover-web-api-pcd-dev.test.hcscint.net/pcd/products/reports/${ACC_REPORT_FILE_NAME}`,
      method: 'GET',
      headers : {
        Authorization : token ? `Bearer ${token}` : ''
      },
      onDownloadProgress(progressEvent){
        // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
        setProgress(true);
      },
      responseType: 'blob',
    }).then(response => {
      setProgress(false)
      FileDownloader(response.data, `${ACC_REPORT_FILE_NAME}.csv`)
    }).catch(error => {
      console.log(error)
      setProgress(false)
    })
  };

  const onCapacityReportSubmit = () => {
    const token = localStorage.getItem("token")
    setCapProgress(true)
    axios({
      url: `${cookie.load("ROVER_PCD_API")}/pcd/products/capacity/reports/${CAP_REPORT_FILE_NAME}`,
      // url: `https://rover-web-api-pcd-dev.test.hcscint.net/pcd/products/capacity/reports/${CAP_REPORT_FILE_NAME}`,
      method: 'GET',
      headers : {
        Authorization : token ? `Bearer ${token}` : ''
      },
      onDownloadProgress(progressEvent){
        // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
        setCapProgress(true);
      },
      responseType: 'blob',
    }).then(response => {
      setCapProgress(false)
      FileDownloader(response.data, `${CAP_REPORT_FILE_NAME}.csv`)
    }).catch(error => {
      console.log(error)
      setCapProgress(false)
    })
  }
  return (
    <div className="pcdm-accountability-report">
      <Row>
        <Col sm={4} md={4} lg={4} xl={4}>
          <div className={`pcdm-btn-wrapper`}>
            <CustomButton variant={BUTTON_VARIANTS.BLUE_GOLD} size="md" loading = {progress} fluid={true} onClick={onSubmit}>
              Publish Accountability Report
            </CustomButton>
          </div>
          <div className={`pcdm-btn-wrapper`} style={{"padding":"2em 0em"}}>
            <CustomButton variant={BUTTON_VARIANTS.BLUE_GOLD} size="md" loading = {capProgress} fluid={true} onClick={onCapacityReportSubmit}>
              Publish Capacity Constraint Report
            </CustomButton>
          </div>
        </Col>
        <Col sm={{ offset: 1, span: 5 }} md={{ offset: 1, span: 5 }} lg={{ offset: 1, span: 5 }} xl={{ offset: 1, span: 5 }}>
          <div className={`pcdm-btn-wrapper`}>
            <div className='accountability-report-description'>This report will show the last date that each product published in PCDM, along with the product’s capacity constraint status at the time.</div>
          </div>
        </Col>
      </Row>
    </div>
  );
}
