import React, { useState, useEffect, useMemo } from "react"; 
import RowColHeaderTable from "../../../components/Table/table";
import "./initialEstimatesTable.scss";

export default function InitialEstimatesTable({ initialEstimates = [] }) {

  const [headerColWidth, setHeaderColWidth] = useState("190px");    // default/initial values

  const [dataColWidth, setDataColWidth] = useState("100px");        // default/initial values

  const showEmptyValue = (row, col) => {
    if (
      row[col.accessor] === null ||
      row[col.accessor] === undefined ||
      Number(row[col.accessor]) === 0
    ) {
      return <span className="empty-capacity-vs-demand">-</span>;
    } else {
      return row[col.accessor];
    }
  };

  const DEFAULT_TABLE_ROW_CONFIG = [
    { head: "Capacity", key: "capacity" },
    { head: "Project Funded (Funded)", key: "projectFunded" },
    { head: "Product Core (Funded)", key: "productCore" },
    { head: "Unfunded", key: "unfunded" },
    { head: "Extra Capacity", key: "extraCapacity" },
  ];
  
  const columns = useMemo(() => {
    return initialEstimates.length
      ? initialEstimates.reduce((acc, curr, index, arr) => {
          acc.push({ head: curr.month, accessor: curr.month });
          return acc;
        }, [])
      : [];
  }, [initialEstimates]);

  useEffect(() => {
    if(initialEstimates.length){
      let dateCol = 50/(initialEstimates.length);
      // let headerCol = Math.min(12,dateCol*1.5);
      let headerCol = 12;
      setHeaderColWidth(`${headerCol}vw`);
      setDataColWidth(`${dateCol}vw`);      
    }
  },[initialEstimates])

  const rows = useMemo(() => {
    return initialEstimates.length
      ? initialEstimates.reduce(
          (acc, curr, index, arr) => {
            for (const [key, value] of Object.entries(curr)) {
              if (key !== "month" && key!=="maxRangeUnfunded" && key!=="maxRangeProjectFunded" && key!=="maxRangeProductCore" && key!=="maxRangeExtraCapacity") {
                
                let index = acc.findIndex((el) => el.key === key);
                // let newValue = new Intl.NumberFormat('en-US').format(value);
                acc[index][curr.month] = value.toLocaleString('en-US');
              }
            }
            return acc;
          },
          [...DEFAULT_TABLE_ROW_CONFIG]
        )
      : [];
  }, [initialEstimates]);

  return (
    <div className="estimate-table-container">
      <RowColHeaderTable
        colWidths={[headerColWidth, ...columns.map((head) => dataColWidth)]}
        customRowColHead=""
        columns={[...columns]}
        rows={[...rows]}
        className={"estimate-table pcdm-scroll-vertical"}
        customCell={showEmptyValue}
        isStriped={false}
      />
    </div>
  );
}
