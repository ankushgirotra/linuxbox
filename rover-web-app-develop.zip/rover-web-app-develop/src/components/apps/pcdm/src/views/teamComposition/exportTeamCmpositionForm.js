import React, { useState } from "react";
import { ACTIONS } from "../../constants/action.constants";
import { connect } from "react-redux";
import { ERROR_MSG } from "../../constants/message.contants";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../components/forms/Button/button";
import { addNotification } from "../../store/common.reducer";
import { FormModal } from "../../components/FormModal/formModal";
import Checkbox from "../../components/forms/Checkbox/checkbox";
import cookie from "react-cookies";
import axios from "axios";
import moment from "moment";

export function ExportTeamCompositionForm(props) {
  const { formVisible, closeModal, productCode, showNotification } = props;

  const [includeRolledOff, setIncludeRolledOff] = useState(false);
  const [accept, setAccept] = useState("");
  const [progress, setProgress] = useState(false);
  const [redTextLabel, setRedTextLabel] = useState(false);
  const onRolledOffCheckboxClick = () => {
    setIncludeRolledOff(!includeRolledOff);
  };
  const onAcceptConditions = () => {
    if (!accept) {
      setRedTextLabel(false);
    }
    setAccept(!accept);
  };
  const handleExportTeamComposition = () => {
    const token = localStorage.getItem("token");
    setProgress(true);
    axios({
      url: `${cookie.load(
        "ROVER_PCD_API"
      )}/pcd/products/${productCode}/teams/reports?rolledOffTeams=${includeRolledOff}`,
      method: "GET",
      headers: {
        Authorization: token ? `Bearer ${token}` : "",
      },
      responseType: "blob",
    })
      .then((response) => {
        setProgress(false);
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.target = "_blank";
        link.setAttribute(
          "download",
          `Team Composition ${moment().format("YYYY.MM.DD")}.csv`
        );
        document.body.appendChild(link);
        link.click();
        // window.open(url, "_blank").focus()
        closeModal()
      })
      .catch((error) => {
        console.log(error);
        showNotification({
            title: "Error",
            variant: ACTIONS.ERROR,
            content: ERROR_MSG.DOWNLOAD_ERROR,
          });
        setProgress(false);
        closeModal()
      });
  };

  const getModelMessage = () => {
    return (
      <div className="export-team-body">
        <div className="export-team-model">
          <p>
            {" "}
            This extract will include sensitive financial data, including
            confidential resource rates. Please be aware of your surroundings
            and please do not share this data with anybody outside of HCSC
            management.
          </p>
        </div>
        <div className="export-form-checkboxes">
          <Checkbox
            label={"Include Rolled-Off Teams in this extract"}
            checked={includeRolledOff}
            className={"export_team-checkbox"}
            onChange={() => onRolledOffCheckboxClick()}
          />
        </div>
        <div className="export-form-checkboxes">
          <Checkbox
            label={
              "I understand that this data is confidential and will ensure that it remains private."
            }
            checked={accept}
            className={
              redTextLabel
                ? `export_team-checkbox redText_label`
                : "export_team-checkbox"
            }
            onChange={() => onAcceptConditions()}
          />
        </div>
      </div>
    );
  };

  const checkConditions = () => {
    if (accept) {
      handleExportTeamComposition();
      setRedTextLabel(false);
    } else {
      setRedTextLabel(true);
    }
  };

  const getFooter = () => {
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          loading={progress}
          onClick={() => checkConditions()}
        >
          Export
        </CustomButton>
        <div id="cancel_button">
          <a
            role="button"
            className="collapse-link"
            aria-expanded="false"
            onClick={closeModal}
          >
            Cancel
          </a>
        </div>
      </div>
    );
  };

  return (
    <>
      <FormModal
        visible={formVisible}
        closeModal={closeModal}
        header={"Export Team Composition"}
        content={getModelMessage()}
        footer={getFooter()}
        className="export-team-comp-form pcdm-form-new"
        isSCForm={true}
      />
    </>
  );
}

export const mapStateToProps = (state) => ({});
export const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ExportTeamCompositionForm);
