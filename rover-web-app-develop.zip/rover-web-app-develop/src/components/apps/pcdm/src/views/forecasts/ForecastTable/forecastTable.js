import React, { useState, useMemo, useEffect, useCallback } from "react";
import "./forecastTable.scss";
import { check } from "../../../services/validation";
import { prepareForecastsData } from "../../../services/forecast.service";
import { CURRENCY, LOCALE, PCDM_TABS } from "../../../constants/common.constants";
import NestedTable from "../../../components/NestedTable/nestedTable";
import { getFormattedDate, stringToCurrency } from "../../../services/form.service";
import UpdatePoints from "./updatePoints";
import { connect } from "react-redux";
import {
  getForecastDollarThunk,
  GET_FORECAST_DOLLAR_SUCCESS,
  logForecastChange,
} from "../../../store/forecast.reducer";
import { DATA_STATUS } from "../../../constants/service.constant";
import SelectDropdown from "../../../components/forms/select/select";
import CustomSelect from "../../../components/forms/SelectDropdown/selectDropdown";
import ToolTip from "../../../components/ToolTip/ToolTip";
import {
  matchedProjectTooltipMsg,
  totalBudgetTooltipMsg,
} from "../../../templates/forecast.template";
import CustomButton from "../../../components/forms/Button/button";
import { ArrowRightCircle, CheckCircle } from "react-feather";
import TextField from "../../../components/forms/textField/textField";
import moment from "moment";
import debounce from 'lodash.debounce';

function ForecastTable(props) {
  const {
    forecasts,
    activeTab,
    forecastTableHistory,
    logChange,
    productCode,
    forecastDollar,
    updateForecastChangesStatus,
    hasEditAccess,
    isShowCompletedProjectChecked = "false",
    isAggregate = false,
    tableID = 'individual',
    startMonth,
    endMonth
  } = props;
  useEffect(() => {
    gotToCurrentMonth();
  });

  const [selectedProjectType, setSelectedProjectType] = useState("");
  const [searchedKeyword, setSearchedKeyword] = useState("");

  useEffect(()=>{
    setSearchedKeyword("")
  },[forecasts])

  const checkForecastsFiltered = check({
    path: "data.matchedProjects",
    original: forecasts,
    checkEmpty: true,
    defaultReturnValue: [],   
  });
  checkForecastsFiltered.value.sort(function (project1, project2) {
    return Number(project1.pcode.slice(1,)) - Number(project2.pcode.slice(1,))
  });
  const SelectColumnFilter = () => {
    const options = useMemo(() => {
      const options = new Set();
      checkForecastsFiltered.value.forEach((row) => {
        options.add(row.projectType);
      });
      return [...options.values()];
    }, [forecasts,checkForecastsFiltered.value]);
    return (
      <select
        value={selectedProjectType}
        onChange={(e) => {
          onProjectTypeChange(e.target.value || "");
        }}
      >
        <option value="">All Estimates</option>
        {options.map((option, index) => (
          <option key={index} value={option}>
            {option}
          </option>
        ))}
      </select>
    );
  }

  const onProjectTypeChange = (selectedVal) => {
    setSelectedProjectType(selectedVal);
  };
  
  const deBounceSearch = useCallback(
    debounce((nextValue) => {setSearchedKeyword(nextValue)},800)
  ,[])

  const onProjectNameSearch = (searchedVal) => {
    deBounceSearch(searchedVal);
  };
  
  const showColHead = (props) => {
    const { thProps, value } = props;
    if (value === "") {
      return (
        <th {...thProps} className="forecast-table-actions">

         { (!isAggregate) ?
         <>
         <p className="forecast-search" title={"Search P-Code or Project Name"}>
            <TextField
              name="searchByProjectName"
              placeholder={"Search P-Code or Project Name"}
              formObj={searchedKeyword}
              value={searchedKeyword}
              className='pcdm-input-search'
              // type="String"
              onChange={(e) => onProjectNameSearch(e.target.value || "")}
            />
          </p>

          <div className="forecast-filter-type"
            id={`goto-current-month-${tableID}`}> {SelectColumnFilter()} </div>
          </> : <div  id={isAggregate ?`goto-current-month-${tableID}`: null}></div>}
          
        </th>

      );
    } else if (value.toLowerCase() === "projects") {
      return (
        <th {...thProps}>
          Projects
          <ToolTip toolTipTitle={"Projects"} toolTipMessage={matchedProjectTooltipMsg()}></ToolTip>
        </th>
      );
    } else if (value.toLowerCase() === "total budget") {
      return (
        <th {...thProps}>
          {value}
          <ToolTip toolTipTitle={"Total Budget"} toolTipMessage={totalBudgetTooltipMsg()}></ToolTip>
        </th>
      );
    } else if (value.toLowerCase() === "variance") {
      return (
        <th {...thProps} className="forecast-rt-bd">
          {value}
        </th>
      );
    }
  };
  const getToolTipMessageHtml = (toolTipTitle) => {
    if (toolTipTitle == 'startDate') {
      return (
        <div>
          The start date for this project does not match the actuals we received for it. Please edit the project start date to reflect the real beginning of work.
        </div>
      );
    } else if(toolTipTitle === 'endDate') {
      return (
        <div>
          The end date for this project does not match the actuals we received for it. Please edit the project end date to reflect the real end of work.
        </div>
      )
    }  else if(toolTipTitle === 'actuals') {
      return (
        <div>
          The start date or end date for this project does not match the actuals we received for it. Please edit the project start date or end date to reflect the real end of work.
        </div>
      )
    }
  }
  const getToolTipHeader =  (toolTipTitle) => {
    if (toolTipTitle == 'startDate') {
      return (
        'Incorrect Start Date'
      );
    } else if(toolTipTitle === 'endDate') {
      return (
        'Incorrect End Date'
      )
    }  else if(toolTipTitle === 'actuals') {
      return (
        'Incorrect Start/End Date'
      )
    }
  }
  const showRowHead = (cellProps, row, col, thProps) => {
    if (cellProps.content.includes("pts") && col.accessor === "budget") {
      let totalPoints = row.original.listOfForecastAndActualData
        .map((month) => month.forecast.points)
        .reduce((a, b) => Number(a) + Number(b), 0);
      if (totalPoints > row.original.totalPoints) {
        return (
          <th
          {...thProps}
          className={row && row.original && row.original.completed ? 'warning-head-th completed-project' : "warning-head-th"}
            title={
              "The forecasted points exceed the baseline budget for this project. Please adjust the project scope if necessary."
            }
          >
            <span
              className="lnr lnr-warning"
              style={{ marginRight: "3px", fontWeight: 600 }}
            ></span>
            {cellProps.content}
          </th>
        );
      }
    } else if (col.accessor === "pCode") {

      const completedProject = row.original.completed ? 'show-completed-icon' : '';
      const fafaCircle = row.original.completed ? 'fas fa-check-circle' : '';

      let actualTooltip = false;
      const endDate = moment(row.original.plannedEnd).format('MM/DD/YYYY');
      const plannedDate = moment(row.original.plannedStart).format('MM/DD/YYYY');
      actualTooltip = row && (row.actualsBeforeStart || row.actualsAfterEnd) ? true : false;

      return (
        <th {...thProps} className={row && row.original && row.original.completed ? 'forecast-project-th completed-project' : "forecast-project-th"} title={row.original.projectName}>
          <span className={`forecast-project-pcode ${completedProject}`}>{cellProps.content}

            {row && row.original && row.original.completed ? <CheckCircle size="14" strokeWidth={2} />: null}
            {actualTooltip && !isAggregate ?
              <ToolTip
                key={`${row.original.pcode}`}
                toolTipTitle={getToolTipHeader('actuals')}
                toolTipMessage={getToolTipMessageHtml('actuals')}
                content={() => (
                  <span className="custom-tool-tip-alert-icon">
                    <i className="fas fa-exclamation-circle" title="Click to get info"></i>
                  </span>
                )}
                toolTipPlacement="right"
            ></ToolTip>: null}

          </span>
          <p className="forecast-project-name">{row.original.projectName}</p>
        </th>
      );
    }
    return <th {...thProps}>{cellProps.content}</th>;
  };
  const showCell = (cellProps, row, col, tdProps) => {
    let paths = col.accessor.split(".");
    let length = paths.length;
    paths.splice(length - 1);
    if (length > 1) {
      const { flag, value } = check({
        path: paths.join("."),
        defaultReturnValue: "",
        original: row,
      });
      if (value.active === false) {
        return showInvalidCell(cellProps, value, tdProps, col, row);
      }
      else if (value.active === true) {
        if (value.variant === "DOLLAR") {
          return showDollar(row, col, value, cellProps, tdProps);
        } else if (value.variant === "POINT") {
          return showPoints(row, col, value, cellProps, tdProps);
        }
      }
    }
    return cellProps.content;
  };
  const showDollar = (row, col, valueObj, cellProps, tdProps) => {
    // Set formatted currency as initial content
    let formatCurrency = new Intl.NumberFormat(LOCALE.US, {
      style: "currency",
      currency: CURRENCY.USD,
    })
      .format(cellProps.content)
      .replace(".00", "");
    let decidedContent = formatCurrency;

    // Show empty value if content is null
    if (cellProps.content === null) {
      decidedContent = "";
    }
    // Adding right border 
    let additionalClass = "";
    if (col.accessor.includes("variance")) {
      additionalClass += "forecast-rt-bd ";
    }

    const completedClass = row && row.original && row.original.completed ? 'completed-project' : 'td-active';
    return (
      <td
        {...tdProps}
        className={`${completedClass} td-dollar ${getNumberedClass(cellProps.content)} ${additionalClass}`}
      >
        {decidedContent}
      </td>
    );
  };
  const showInvalidCell = (cellProps,value, tdProps, col, row) => {
    let additionalClass = "";
    if (col.accessor.includes("variance")) {
      additionalClass += "forecast-rt-bd ";
    }
    // Tooltip for Actuals before start and after end Date
    let appliedClass = '';
    let decidedContent = cellProps.content ? cellProps.content : '';
      // Checking the variant
    if (value.variant === "DOLLAR") {
        let formatCurrency = new Intl.NumberFormat(LOCALE.US, {
          style: "currency",
          currency: CURRENCY.USD,
    })
          .format(cellProps.content)
          .replace(".00", "");
        decidedContent = formatCurrency;
        appliedClass = 'td-dollar';
    } else if (value.variant === "POINT") {
        decidedContent = `${cellProps.content} pts`;
        appliedClass = 'td-point';
    }
    let actualTooltipEndDate = false;
    let actualTooltipStartDate = false;
    const endDate = new Date(moment(row.original.plannedEnd).format('MM/DD/YYYY'));
    const plannedDate = new Date(moment(row.original.plannedStart).format('MM/DD/YYYY'));
    if (col.accessor.includes("actual")) {
      const month = new Date(moment(col.accessor.substring(0,10)).format('MM/DD/YYYY'));
      actualTooltipEndDate = decidedContent !== "" && (moment(month, "MM/DD/YYYY").isAfter(moment(endDate).format("MM/DD/YYYY"), 'month')) ? true: false;
      actualTooltipStartDate = decidedContent !== "" && (moment(month, "MM/DD/YYYY").isBefore(moment(plannedDate).format("MM/DD/YYYY"), 'month')) ? true: false;
    }
    // Show empty value if content is null
    if (cellProps.content === null) {
      decidedContent = "";
    }
  const completedClass = row && row.original && row.original.completed ? 'completed-project' : decidedContent &&  decidedContent !== '' ? 'td-active' : 'td-inactive';
  return ( decidedContent &&  decidedContent !== '' ? 
          <td
                {...tdProps}
                className={`${completedClass} ${appliedClass} ${getNumberedClass(cellProps.content)} ${additionalClass}`}
              >
            {
                (actualTooltipEndDate || actualTooltipStartDate) && 
                  <>{decidedContent}
                  {/* {appliedClass === 'td-dollar' &&  */}
                  <ToolTip
                        key={`${row.original.pcode}`}
                        toolTipTitle={getToolTipHeader(actualTooltipStartDate ? 'startDate' : 'endDate')}
                        toolTipMessage={getToolTipMessageHtml(actualTooltipStartDate ? 'startDate' : 'endDate')}
                        content={() => (
                          <span className="custom-tool-tip-alert-icon">
                            <i className="fas fa-exclamation-circle" title="Click to get info"></i>
                          </span>
                        )}
                        toolTipPlacement="right"
                    ></ToolTip>
                    {/* } */}
                  </>
                }
          </td>
          : <td {...tdProps} className={`${completedClass} ${additionalClass}`}></td>);
  };
  const showPoints = (row, col, valueObj, cellProps, tdProps) => {
    let decidedContent = `${cellProps.content} pts`;
    if (col.accessor.includes("forecast")) {
      if (valueObj.editable && hasEditAccess && tableID === 'individual') {
        return getEditableTd(row, col, cellProps, tdProps);
      }
    }
    if (cellProps.content === null) {
      decidedContent = "";
    }
    let additionalClass = "";
    if (col.accessor.includes("variance")) {
      additionalClass += "forecast-rt-bd ";
    }
    const completedClass = row && row.original && row.original.completed ? 'completed-project' : 'td-active';
    return (
      <td
        {...tdProps}
        className={`${completedClass} td-point ${getNumberedClass(cellProps.content)} ${additionalClass}`}
      >
        {decidedContent}
      </td>
    );
  };
  const getEditableTd = (row, col, cellProps, tdProps) => {
    const month = getFormattedDate(col.accessor.split(".")[0], "YYYY-MM-DD", "MM/DD/YYYY")
    const val = row.original.listOfForecastAndActualData.filter(el=>month === getFormattedDate(el.month, "YYYY-MM-DD", "MM/DD/YYYY"))[0]
    let payload = {
      projectEstimateId: row.original.projectEstimateId,
      pcode: row.original.pcode,
      month: getFormattedDate(col.accessor.split(".")[0], "YYYY-MM-DD", "MM/DD/YYYY"),
      totalDollars: row.original.totalBudget,
      totalPoints: row.original.totalPoints,
      forecast: { dollars: 0, points: cellProps.content },
      budget: {dollars:val.budget.dollars, points:val.budget.points }
    };
    const completedClass = row && row.original && row.original.completed ? 'completed-project' : 'td-active';
    return (
      <td {...tdProps} className={`${completedClass} td-point td-pts-editable`}>
        <UpdatePoints
          content={
            cellProps.content === null || cellProps.content === undefined
              ? `___ pts`
              : `${cellProps.content} pts`
          }
          point={cellProps.content}
          updatePoints={updatePoints}
          payload={payload}
        />
      </td>
    );
  };
  const updatePoints = (changeObj, payload) => {
    if (
      changeObj.new.value !== null &&
      changeObj.new.value !== "" &&
      (changeObj.old === null || Number(changeObj.old) !== Number(changeObj.new.value))
    ) {
      const forecastDollar =
        Math.round((payload.totalDollars / payload.totalPoints) * changeObj.new.value);
      let newVariance = {
        dollars : forecastDollar - payload.budget.dollars,
        points : changeObj.new.value - payload.budget.points
      }
      let newPayload = {
        ...payload,
        forecast: { ...payload.forecast, points: changeObj.new.value },
      };
      logChange({
        ...newPayload,
        forecast: { ...newPayload.forecast, dollars: Number(forecastDollar) },
        variance : newVariance
      });
      // props.getForecastDollar(
      //   productCode,
      //   newPayload.projectEstimateId,
      //   newPayload.forecast.points,
      //   newPayload.month,
      //   (status, data) => {
      //     if (status === GET_FORECAST_DOLLAR_SUCCESS) {
      //       logChange({
      //         ...newPayload,
      //         forecast: { ...newPayload.forecast, dollars: data.forecastDollar },
      //         variance: data.variance,
      //       });
      //     } else {
      //     }
      //   }
      // );
    }
  };
  const getNumberedClass = (value) => {
    if (Number(value) === 0) {
      return "zero-td";
    } else if (Number(value) < 0) {
      return "negative-td";
    } else {
      return "positive-td";
    }
  };
  const { finalArray, columnPaths, headerConfig, colWidths } = useMemo(
    () =>
      prepareForecastsData(
        checkForecastsFiltered.value,
        forecastTableHistory,
        selectedProjectType,
        showCell,
        showRowHead,
        showColHead,
        searchedKeyword,
        tableID,
        startMonth,
        endMonth
      ),
    [forecasts, startMonth, endMonth, checkForecastsFiltered.value, forecastTableHistory ,selectedProjectType, searchedKeyword, isShowCompletedProjectChecked]
  );
  const gotToCurrentMonth = () => {
    let monthEl = document.getElementById(`forecast-current-month-${tableID}`);
    let scrollArea = document.getElementsByClassName(`forecast-table-v1-${tableID}`);
    let linkEl = document.getElementById(`goto-current-month-${tableID}`);
    if (monthEl && scrollArea && scrollArea.length && linkEl) {
      scrollArea[0].scrollLeft =
        monthEl.offsetLeft - (linkEl.offsetLeft + linkEl.offsetWidth) - scrollArea[0].offsetLeft;
    }
  };
  return checkForecastsFiltered.flag && activeTab === PCDM_TABS.FORECASTS ? (
    <NestedTable
      className={`forecast-table-v1-${tableID} pcdm-scroll-vertical`}
      finalArray={finalArray}
      columnPaths={columnPaths}
      headerConfig={headerConfig}
      colWidths={colWidths}
    />
  ) : null;
}

export const mapStateToProps = (state) => ({
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
  forecastDollar: state.ForecastsReducer.forecastDollar,
  updateForecastChangesStatus: state.ForecastsReducer.updateForecastChangesStatus,
});
export const mapDispatchToProps = (dispatch) => ({
  getForecastDollar: (productCode, projectEstimateId, forecastPoints, month, callback) =>
    dispatch(
      getForecastDollarThunk(productCode, projectEstimateId, forecastPoints, month, callback)
    ),
  logChange: (change) => dispatch(logForecastChange(change)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ForecastTable);