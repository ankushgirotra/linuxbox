import React, { Component } from "react";
import "./manageTeamRoles.scss";
import { FORM_CONTROL_DEFAULT } from "../../../../constants/form.constants";
import { PCDM_ADMIN_ACTIONS } from "../../../../constants/action.constants";
import CustomButton, { BUTTON_VARIANTS } from "../../../../components/forms/Button/button";
import {
  validateManageTeamRolesForm,
  handleTeamRoleAPIResponse,
} from "../../../../services/Admin/admin.teamRoles";
import ErrorMsg from "../../../../components/forms/errorMsg/errorMsg";
import TextField from "../../../../components/forms/textField/textField";
import { FormModal } from "../../../../components/FormModal/formModal";
import { stringToCurrency } from "../../../../services/form.service";
import { modifyTeamRoleRateThunk } from "../../../../store/admin.reducer";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import { DATA_STATUS } from "../../../../constants/service.constant";
import { connect } from "react-redux";
import { LOCALE, CURRENCY } from "../../../../constants/common.constants";

export class ManageTeamRolesForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formControls: {
        edited: false,
        error: false,
        errorMessage: "",
        errorDetail: "",
        roleName: {
          ...FORM_CONTROL_DEFAULT,
          required: true,
          readOnly: true
        },
        employeeDefaultRate: {
          ...FORM_CONTROL_DEFAULT,
        },
        onshoreContractorDefaultRate: {
          ...FORM_CONTROL_DEFAULT,
        },
        offshoreContractorDefaultRate: {
          ...FORM_CONTROL_DEFAULT,
        },
        nearshoreContractorDefaultRate: {
          ...FORM_CONTROL_DEFAULT,
        },
      },
    };
  }
  componentDidMount = async () => {
    const { formMode } = this.props;
    if (formMode === PCDM_ADMIN_ACTIONS.EDIT_TEAM_ROLES) {
      this.populateTeamRateForm();
    }
  };
  handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleTeamRoleAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData
    );
    if (modal) {
      this.props.closeModal(modal.action, modal.props);
    } else if (returnState) {
      this.setState({ ...returnState });
    }
  };
  populateTeamRateForm = () => {
    const { formControls } = this.state;
    const { selectedTeamRole } = this.props;
    this.setState({
      formControls: {
        ...formControls,
        roleName: {
          ...formControls.roleName,
          value: selectedTeamRole.roleName,
        },
        employeeDefaultRate: {
          ...formControls.employeeDefaultRate,
          value: this.showDollerRate(selectedTeamRole.employeeDefaultRate),
        },
        onshoreContractorDefaultRate: {
          ...formControls.onshoreContractorDefaultRate,
          value: this.showDollerRate(selectedTeamRole.onshoreContractorDefaultRate),
        },
        offshoreContractorDefaultRate: {
          ...formControls.offshoreContractorDefaultRate,
          value: this.showDollerRate(selectedTeamRole.offshoreContractorDefaultRate),
        },
        nearshoreContractorDefaultRate: {
          ...formControls.nearshoreContractorDefaultRate,
          value: this.showDollerRate(selectedTeamRole.nearshoreContractorDefaultRate),
        },
      },
    });
  };
  showDollerRate = (val) => {
    if (!isNaN(val) && val !== "") {
      return new Intl.NumberFormat(LOCALE.US, {
        style: "currency",
        currency: CURRENCY.USD,
      })
        .format(val)
        .replace(".00", "");
    }
    return null;
  };
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };
  onRateChange = (event, on, field) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [field]: {
          ...formControls[field],
          error: false,
          value: stringToCurrency(event.target.value, on, 2),
        },
      },
    });
  };
  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode } = this.props;
    let validation = validateManageTeamRolesForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === PCDM_ADMIN_ACTIONS.ADD_TEAM_ROLES) {
        // await this.props.saveProduct(payload, this.handleResponse);
      } else if (formMode === PCDM_ADMIN_ACTIONS.EDIT_TEAM_ROLES) {
        await this.props.modifyTeamRoleRate(payload, this.handleResponse);
      }
    }
  };
  reqPayload = () => {
    const { formControls } = this.state;
    const { formMode, userParams } = this.props;
    return {
      roleName: formControls.roleName.value.trim(),
      empRate: formControls.employeeDefaultRate.value
        ? parseFloat(
            formControls.employeeDefaultRate.value.trim().replace("$", "").replace(/,/g, "")
          )
        : null,
      onshoreRate: formControls.onshoreContractorDefaultRate.value
        ? parseFloat(
            formControls.onshoreContractorDefaultRate.value
              .trim()
              .replace("$", "")
              .replace(/,/g, "")
          )
        : null,
      offshoreRate: formControls.offshoreContractorDefaultRate.value
        ? parseFloat(
            formControls.offshoreContractorDefaultRate.value
              .trim()
              .replace("$", "")
              .replace(/,/g, "")
          )
        : null,
        nearshoreRate: formControls.nearshoreContractorDefaultRate.value
        ? parseFloat(
            formControls.nearshoreContractorDefaultRate.value
              .trim()
              .replace("$", "")
              .replace(/,/g, "")
          )
        : null,
      lanId: getFormattedUserId(userParams),
      addFlag: formMode === PCDM_ADMIN_ACTIONS.ADD_TEAM_ROLES,
      Active: true,
    };
  };
  getTeamRoleForm = () => {
    const { formControls } = this.state;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="roleName"
              label={"Role Name"}
              formObj={formControls.roleName}
              isRequired={formControls.roleName.required}
              onChange={this.onInputChange}
              
            />
            <TextField
              name="employeeDefaultRate"
              label={"Employee Default Rate($)"}
              formObj={formControls.employeeDefaultRate}
              isRequired={formControls.employeeDefaultRate.required}
              type="text"
              placeholder="$___"
              onBlur={(e) => this.onRateChange(e, "blur", "employeeDefaultRate")}
              onChange={(e) => this.onRateChange(e, "", "employeeDefaultRate")}
            />
            <TextField
              name="onshoreContractorDefaultRate"
              label={"Onshore Contractor Rate($)"}
              formObj={formControls.onshoreContractorDefaultRate}
              isRequired={formControls.onshoreContractorDefaultRate.required}
              type="text"
              placeholder="$___"
              onBlur={(e) => this.onRateChange(e, "blur", "onshoreContractorDefaultRate")}
              onChange={(e) => this.onRateChange(e, "", "onshoreContractorDefaultRate")}
            />
            <TextField
              name="offshoreContractorDefaultRate"
              label={"Offshore Contractor Rate($)"}
              formObj={formControls.offshoreContractorDefaultRate}
              isRequired={formControls.offshoreContractorDefaultRate.required}
              type="text"
              placeholder="$___"
              onBlur={(e) => this.onRateChange(e, "blur", "offshoreContractorDefaultRate")}
              onChange={(e) => this.onRateChange(e, "", "offshoreContractorDefaultRate")}
            />
            <TextField
              name="nearshoreContractorDefaultRate"
              label={"Near-shore Contractor Rate($)"}
              formObj={formControls.nearshoreContractorDefaultRate}
              isRequired={formControls.nearshoreContractorDefaultRate.required}
              type="text"
              placeholder="$___"
              onBlur={(e) => this.onRateChange(e, "blur", "nearshoreContractorDefaultRate")}
              onChange={(e) => this.onRateChange(e, "", "nearshoreContractorDefaultRate")}
            />
          </div>
        </div>
        {formControls.error ? (
          <ErrorMsg message={formControls.errorMessage} errorDetail={formControls.errorDetail} />
        ) : null}
      </form>
    );
  };
  getFooter = () => {
    const { formMode } = this.props;
    const { formControls } = this.state;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          onClick={() => {
            this.onSubmit();
          }}
          disable={!formControls.edited}
        >
          Save
        </CustomButton>
      </div>
    );
  };
  render() {
    const { formVisible, formMode, closeModal, modifyTeamRoleRateStatus } = this.props;
    return (
      <FormModal
        isLoading={modifyTeamRoleRateStatus.status === DATA_STATUS.LOADING}
        visible={formVisible}
        closeModal={() => closeModal()}
        header={formMode === PCDM_ADMIN_ACTIONS.ADD_TEAM_ROLES ? "Add Role" : "Edit Role"}
        content={this.getTeamRoleForm()}
        footer={this.getFooter()}
        className="team-role-form"
      />
    );
  }
}
export const mapStateToProps = (state) => ({
  modifyTeamRoleRateStatus: state.PCDMAdminReducer.modifyTeamRoleRateStatus,
  userParams: state.AuthReducer.user,
});

export const mapDispatchToProps = (dispatch) => ({
  modifyTeamRoleRate: (formData, callback) => dispatch(modifyTeamRoleRateThunk(formData, callback)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ManageTeamRolesForm);
