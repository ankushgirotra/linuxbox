import React, { useState, useEffect } from "react";
import { FormModal } from "../../../../components/FormModal/formModal";
import TextField from "../../../../components/forms/textField/textField";
import CustomButton, { BUTTON_VARIANTS } from "../../../../components/forms/Button/button";
import { connect } from "react-redux";
import {
    FORM_CONTROL_DEFAULT,
    FORM_DATE_FORMAT
} from "../../../../constants/form.constants";
import { validateHolidayForm } from "../../../../services/Admin/admin.product.service";
import Datepicker from "../../../../components/Datepicker/datepicker";
import { addHolidayThunk, editHolidayThunk, deleteHolidayThunk } from "../../../../store/admin.reducer";
import moment from "moment";
import { DB_DATE_FORMAT } from "../../../../constants/form.constants";
import { PCDM_ADMIN_ACTIONS, ACTIONS } from "../../../../constants/action.constants";
import { getFormattedDate } from "../../../../services/form.service";
import {
    DEFAULT_MSG_MODAL_CONFIG,
    MessageModal,
} from "../../../../components/MessageModal/messageModal";

export function ManageHolidayForm(props) {

    const { formOpen, closePopupModal, addHoliday, editHoliday, holiDayDetails, formMode, selectedHoliday, deleteHoliday } = props;
    const [formControls, setFormControls] = useState({
        edited: false,
        error: false,
        errorMessage: "",
        holidayName: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
        holidayDate: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
    });

    useEffect(() => {
        if (formMode === PCDM_ADMIN_ACTIONS.ADD_HOLIDAY) {
            setFormControls({
                ...formControls,
                edited: false,
                error: false,
                errorMessage: "",
                holidayName: {
                    value: "",
                    required: true,
                    error: false,
                    errorMsg: "",
                },
                holidayDate: {
                    value: "",
                    required: true,
                    error: false,
                    errorMsg: "",
                },
            });
        } else if (formMode === PCDM_ADMIN_ACTIONS.EDIT_HOLIDAY) {
            setFormControls({
                ...formControls,
                edited: false,
                error: false,
                errorMessage: "",
                holidayName: {
                    value: selectedHoliday.holidayName,
                    required: true,
                    error: false,
                    errorMsg: "",
                },
                holidayDate: {
                    value: new Date(getFormattedDate(selectedHoliday.holidayDate)),
                    required: true,
                    error: false,
                    errorMsg: "",
                },
            });
        }

    }, [formOpen]);

    const onInputChange = (name, value) => {
        setFormControls({
            ...formControls,
            edited: true,
            error: false,
            errorMessage: "",
            [name]: {
                ...formControls[name],
                value: value,
                error: false,
                errorMsg: "",
            },
        });
    };

    const getFormContent = () => {
        return (
            <form className="pcdm-form">
                <div className="pcdm-form__form-group">
                    <div className="pcdm-form__form-group-field form-group-field--inline">
                        <TextField
                            name="holidayName"
                            label={"Holiday"}
                            placeholder={"Enter the name of Holiday"}
                            formObj={formControls.holidayName}
                            isRequired={formControls.holidayName.required}
                            type="text"
                            onChange={(e) => onInputChange(e.target.name, e.target.value)}
                        />
                        <Datepicker
                            name="holidayDate"
                            label={"Date"}
                            placeholderText={"MM/DD/YYYY"}
                            popperPlacement={"auto"}
                            formObj={formControls.holidayDate}
                            isRequired={formControls.holidayDate.required}
                            onChange={onInputChange}
                            dateFormat={FORM_DATE_FORMAT}
                        />
                    </div>
                </div>
                {formControls.error ? <p>{formControls.errorMessage}</p> : null}
            </form>
        );
    };

    const onSubmit = (e) => {
        let validate = validateHolidayForm(formControls);
        if (validate.error) {
            // console.log(validate);
            setFormControls(validate);
        } else if (formMode === PCDM_ADMIN_ACTIONS.ADD_HOLIDAY) {
            let nameOfHoliday = formControls.holidayName.value;
            let dateEntered = moment(formControls.holidayDate.value).hour(0).minute(0)
                .second(0).millisecond(0).format(DB_DATE_FORMAT);
            let payload = { holidayName: nameOfHoliday, holidayDate: dateEntered }
            addHoliday(payload, closePopupModal);
        } else if (formMode === PCDM_ADMIN_ACTIONS.EDIT_HOLIDAY) {
            let nameOfHoliday = formControls.holidayName.value;
            let dateEntered = moment(formControls.holidayDate.value).hour(0).minute(0)
                .second(0).millisecond(0).format(DB_DATE_FORMAT);
            let payload = { holidayName: nameOfHoliday, holidayDate: dateEntered }
            let id = selectedHoliday.holidayId
            editHoliday(id, payload, closePopupModal);
        }
    };

    const handleDelete = (action, data) => {
        if (action === ACTIONS.YES) {
            deleteHoliday(selectedHoliday.holidayId, closePopupModal);
            setMessageModelConfig({
                visible: false,
            })
        } else {
            setMessageModelConfig({
                visible: false,
            })
        }
    }
    const getFooter = () => {
        return (
            <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
                <CustomButton
                    variant={BUTTON_VARIANTS.PRIMARY}
                    size="md"
                    onClick={(e) => onSubmit(e)}
                    disable={!formControls.edited}
                >
                    Save
                </CustomButton>
                {formMode === PCDM_ADMIN_ACTIONS.EDIT_HOLIDAY &&
                    <CustomButton
                        variant={BUTTON_VARIANTS.ERROR}
                        size="md"
                        onClick={(e) => setMessageModelConfig({
                            ...messageModalConfig,
                            message: 'Are you sure you want to delete this holiday?',
                            variant: ACTIONS.YES_NO,
                            visible: true,
                            title: 'Delete holiday',
                            onClose: handleDelete,
                            dialogClassName: 'save-changes-model'
                        })}
                    >
                        Delete
                </CustomButton>}
            </div>
        );
    };
    const [messageModalConfig, setMessageModelConfig] = useState({ ...DEFAULT_MSG_MODAL_CONFIG })
    return (
        <>
            <FormModal
                isLoading={false}
                visible={formOpen}
                closeModal={(status, data, keepModal) => closePopupModal(status, data, keepModal)}
                header={formMode === PCDM_ADMIN_ACTIONS.ADD_HOLIDAY ? 'ADD HOLIDAY' : 'EDIT HOLIDAY'}
                content={() => getFormContent()}
                footer={() => getFooter()}
                className="project-form"
            />
            <MessageModal {...messageModalConfig} />
        </>
    );

}
export const mapStateToProps = (state) => ({});

export const mapDispatchToProps = (dispatch) => ({
    addHoliday: (payload, callback) => dispatch(addHolidayThunk(payload, callback)),
    editHoliday: (id, payload, callback) => dispatch(editHolidayThunk(id, payload, callback)),
    deleteHoliday: (holidayId, callback) => dispatch(deleteHolidayThunk(holidayId, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageHolidayForm);