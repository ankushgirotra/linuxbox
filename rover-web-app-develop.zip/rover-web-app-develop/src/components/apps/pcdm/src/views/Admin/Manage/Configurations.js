import React, { useState } from "react";
import { RoverNavigationExtended } from "../../../components/NavigationExtended/navigationExtended";
import ManageProducts from "./Products/manageProductsTable";
import ManageProductLines from "./ProductLines/manageProductLinesTable";
import ManageTeamRoles from "./TeamRoles/manageTeamRolesTable";
import PublishDueNote from "./PublishDueDate/publishDueDate"
import UploadActuals from "../Reports/uploadActuals";
import ManageHolidays from "./Holidays/manageHolidays";
import SendEmail from "./SendEmail/SendEmail";
import ManageEmailNotification from "./EmailNotification/manageEmailNotification";
import "../Reports/PCDMReports.scss";


export default function Configurations(props) {
  const [selectedTab, setSelectedTab] = useState(1);
  const { onAddOrEditClick, closeModal } = props;
  return (
    <div>
      <RoverNavigationExtended
        className="pcdm-report-generation-container"
        navList={[
          {
            navKey: 1,
            header: () => <>Manage Products</>,
            content: () => (
              <ManageProducts onAddOrEditProduct={onAddOrEditClick} />
            ),
          },
          {
            navKey: 2,
            header: () => <>Manage Product Lines</>,
            content: () => (
              <ManageProductLines
                onAddOrEditProductLine={onAddOrEditClick}
                closeModal={closeModal}
              />
            ),
          },
          {
            navKey: 3,
            header: () => <>Manage Holidays</>,
            content: () => (
              <ManageHolidays />
            ),
          },
          {
            navKey: 4,
            header: () => <>Manage Team Roles</>,
            content: () => (
              <ManageTeamRoles onAddOrEditTeamRoles={onAddOrEditClick} />
            ),
          },
          {
            navKey: 5,
            header: () => <>Upload Actuals</>,
            content: () => <UploadActuals />,
          },
          {
            navKey: 6,
            header: () => <>Publish Due Date</>,
            content: () => (
              <PublishDueNote />
            ),
          },
          {
            navKey: 7,
            header: () => <>Send Email</>,
            content: () => (
              <SendEmail selectedTab = {selectedTab} />
            ),
          },
          {
            navKey: 8,
            header: () => <>Manage Email Notifications</>,
            content: () => (
              <ManageEmailNotification />
            ),
          },
        ]}
        activeKey={selectedTab}
        onTabChange={(tab) => setSelectedTab(tab)}
      />
    </div>
  );
}
