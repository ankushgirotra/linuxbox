import React, { useState, useEffect, useMemo } from "react";
import moment from "moment";
import { roundOff, stringToCurrency } from "../../services/form.service";
import {
  CONSTRAINT_CAPACITY_ICON_COLOR,
  CONSTRAINT_CAPACITY_STATUS,
  CONSTRAINT_CAPACITY_VALUE,
} from "../../constants/message.contants";
import DataGrid from "../../components/DataGrid/dataGrid";


export default function CapacityTable({capacityConstraintsList,currentPcodesList}) {

  const [tableData, setTableData] = useState([]);

  useEffect(() => {
    let arr = [];
    capacityConstraintsList.forEach((el) => {
      const flag = currentPcodesList.filter(
        (pcode) => pcode.productCode == el.productCode
      )[0];
      if (flag && (flag.active == true || flag.active == "Yes") && flag.testProduct !== true) {
        arr.push(el);
      }
    });
    console.log(arr);
    setTableData(arr);
  }, [capacityConstraintsList, currentPcodesList]);

  const columns = useMemo(() => [
    {
      Header: "Products",
      accessor: "name",
      disableFilters: true,
    },
    {
      Header: "Capacity Constraint Status",
      accessor: "maxcapacityConstraint",
      disableFilters: true,
      disableSortBy: true,
      Cell: ({ row: { original } }) => showCapacity(original, "maxcapacityConstraint"),
    },
    {
      Header: "Last Publish Date",
      accessor: "lastpublished",
      disableFilters: true,
      disableSortBy: true,
      Cell: ({ row: { original } }) => showLastPublish(original, "lastpublished"),
    },
    {
      Header: "Average Cost per Point",
      accessor: "avgCostperpoint",
      disableFilters: true,
      Cell: ({ row: { original } }) => showAvgCostPerPoint(original, "avgCostperpoint"),
    },
  ]);

  const getColorName = (maxcapacityConstraint) => {
    if (maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.LOW) {
      return "LOW";
    } else if (
      maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.LOW &&
      maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.MED_LOW
    ) {
      return "MED_LOW";
    } else if (
      maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.MED_LOW &&
      maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.HIGH
    ) {
      return "MEDIUM";
    } else if (maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.HIGH) {
      return "HIGH";
    }
  };

  const showCapacity = (row, key) => {
    const state = getColorName(row[key]);
    var iconProperties = {
      style: {
        backgroundColor: CONSTRAINT_CAPACITY_ICON_COLOR[state],
      },
      status: CONSTRAINT_CAPACITY_STATUS[state],
    };
    return (
      <div className="capacity-info">
        <div className="capacity-constraint-status-container">
          <div
            className="capacity-constraint-avatar"
            style={iconProperties.style}
          />
          <span className="capacity-constraint-status">
            {iconProperties.status}
          </span>
        </div>
        <div className="divider">|</div>
        <div className="capacity-constraint-value">
          <p>
            D/C value:&nbsp;<span>{row[key]}%</span>
          </p>
        </div>
      </div>
    );
  };

  const showLastPublish = (row, key) => {
    let is30Day = moment().diff(moment(row[key]), "days") >= 30;
    return (
      <div>
        <span
          className={`publish-date ${
            is30Day || row[key].includes("N/A") ? `publish-date-exceed` : ``
          }`}
        >
          {row[key]}
        </span>
      </div>
    );
  };

  const showAvgCostPerPoint = (row, key) => {
    const roundOffVal = roundOff(parseFloat(row[key]), 2);
    return stringToCurrency(String(roundOffVal), "blur", 2);
  };

  return (
    <div className="capacity-constraints-table-container">
      <div className="capacity-constraints-table">
        <DataGrid
          data={tableData}
          columns={columns}
          showUpdatedDataGrid={true}
          noRowText={"No Products found"}
        />
      </div>
    </div>
  );
}
