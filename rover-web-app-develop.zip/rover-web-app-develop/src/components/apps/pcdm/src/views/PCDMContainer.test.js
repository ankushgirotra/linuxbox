import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import mockAxios from "axios";

import { PCDMContainer, mapStateToProps } from "./PCDMContainer";
import { initialState } from "../store/admin.reducer";

Enzyme.configure({ adapter: new EnzymeAdapter() });
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());

const baseProps = {
  productDetails: {},
  forecastTableHistory: [
    { month: "2020-06-06", pcode: "P00001234", projectEstimateId: 1, forecast: { points: 1 } },
  ],
  match: { params: { productCode: "PRD00000123" } },
  pcdmAccess: initialState.pcdmAccess,
  getPCDMAccess: jest.fn(),
  getEmployeeDetails: jest.fn(),
};

let component = null;
const getWrapper = () => shallow(<PCDMContainer {...baseProps} />);
describe("add PCDMContainer component", () => {
  beforeEach(() => {
    component = shallow(<PCDMContainer {...baseProps} />).setState({
      activeTab: "TEAM_COMPOSITION",
    });
  });
  describe("Component initate properly", () => {
    it("PCDMContainer renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("Change tabs onclik", () => {
    it("Should change tab onClick", () => {
      const wrapper = getWrapper();
      wrapper.instance().OnTabChange("PROJECT_ESTIMATES");
    });
  });
});
