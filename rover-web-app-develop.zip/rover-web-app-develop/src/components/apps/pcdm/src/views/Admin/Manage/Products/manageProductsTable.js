import React, { useMemo, useState } from "react";
import { connect } from "react-redux";
import DataGrid from "../../../../components/DataGrid/dataGrid";
import { PlusCircle } from "react-feather";
import CustomButton from "../../../../components/forms/Button/button";
import "../../admin.scss";
import { PCDM_ADMIN_ACTIONS } from "../../../../constants/action.constants";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import { Container, Row, Col, Badge } from "react-bootstrap";
import Checkbox from "../../../../components/forms/Checkbox/checkbox";

export function ManageProducts(props) {

  const { products, onAddOrEditProduct, productLines } = props;
  const [showDeactivatedProducts , setShowDeactivatedProducts] = useState(false);
  const columns = useMemo(() => [
    {
      Header: (props) => productHead(),
      accessor: "name",
      Cell: ({ row: { original } }) => showProduct(original, "name"),
      disableFilters: true,
      disableSortBy: false,
    },
    {
      Header: "PRD Code",
      accessor: "productCode",
      disableFilters: true,
      disableSortBy: false,
    },
    {
      Header: "Product Line",
      accessor: "portfolio",
      disableFilters: true,
      disableSortBy: false,
    },
    {
      Header: "Product Manager",
      accessor: "manager",
      disableFilters: true,
      disableSortBy: false,
    },
  ]);
  const showProduct = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() => onAddOrEditProduct(PCDM_ADMIN_ACTIONS.EDIT_PRODUCT, { ...row })}
      >
        {row.name}
      </LinkExtended>
    );
  };
  const productHead = () => (
    <div className="add-products-head">
      <p>Product Name</p>
      <CustomButton
        onClick={(event) => {
          event.stopPropagation();
          onAddOrEditProduct(PCDM_ADMIN_ACTIONS.ADD_PRODUCT, {})
        }} 
        title={"Click to add Product"}
        className="products-add-link"
      >
        <span className='mr-1'>ADD</span>
        <PlusCircle size="15" strokeWidth={3} />
      </CustomButton>
    </div>
  );
  const getDeactivateProductsCheckBoxLabel = (noOfDeactivatedProducts, show) => (
    <>
      Show Deactivated Products
      {show ? (
        <Badge style={{ marginLeft: "3px" }} variant="danger">
          {noOfDeactivatedProducts}
        </Badge>
      ) : null}
    </>
  );
  const getPortfolioName = (portfolioId) => {
    let portfolio = {};
    if (productLines && productLines.length) {
      portfolio = productLines.find((el) => el.portfolioId === portfolioId);
    }
    return portfolio && portfolio.portfolioName ?  portfolio.portfolioName : "";
  };

  let allProductArr = useMemo(() => {
    let tempProducts = products && products.productsResponses ? [...products.productsResponses] : [];
    tempProducts = tempProducts.map((prd) => ({
      ...prd,
      portfolio: getPortfolioName(prd.portfolioId),
    }));
    return tempProducts;
  }, [products, productLines]);

  let activeProductArr = useMemo(() => {
    let tempactiveProducts = products && products.productsResponses ? [...products.productsResponses] : [];
    tempactiveProducts = tempactiveProducts.filter(
      (prdt) => prdt.active === true).map((prd) => ({
        ...prd, portfolio: getPortfolioName(prd.portfolioId),
      }));
    return tempactiveProducts;
  }, [products, productLines]);

  return (
    <>
      <Row>
        <Col style={{ paddingBottom: "5px" }}>
          <Checkbox
            label={getDeactivateProductsCheckBoxLabel((allProductArr.length - activeProductArr.length), showDeactivatedProducts)}
            checked={showDeactivatedProducts}
            onChange={() => setShowDeactivatedProducts(!showDeactivatedProducts)}
          />
        </Col>
      </Row>
      <Row>
        <Col>
          <div className="manage-products-container pcdm-scroll-vertical">
            <DataGrid
              data={showDeactivatedProducts ? allProductArr : activeProductArr}
              columns={columns}
              getRowClassName={(row) => !row.original.active ? "deactivated-products" : ""}
              noRowText={"Click + icon to start adding Product "}
            />
          </div>
        </Col>
      </Row>
    </>
  );
}
export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner.data,
  productLines: state.ProductsReducer.productLines.data,
});

export const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(ManageProducts);
