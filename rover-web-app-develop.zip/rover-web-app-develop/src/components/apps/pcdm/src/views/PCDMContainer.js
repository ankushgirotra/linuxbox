import React, { Component } from "react";
import TeamComposition from "./teamComposition/teamComposition";
import ProjectEstimates from "./projectEstimates/projectEstimates";
import Summary from "./summary/summary";
import Forecasts from "./forecasts/forecasts";
import "./style.scss";
import { connect } from "react-redux";
import { changeTab } from "../store/common.reducer";
import { PCDM_TABS } from "../constants/common.constants";
import Toaster from "../components/Toaster/toaster";
import {
  updateForecastChangesThunk,
  getForecastsThunk,
  getForecastsAggregateThunk,
  UPDATE_FORECAST_CHANGES_SUCCESS,
  clearForecastChange,
} from "../store/forecast.reducer";
import {
  MessageModal,
  DEFAULT_MSG_MODAL_CONFIG,
} from "../components/MessageModal/messageModal";
import { ACTIONS } from "../constants/action.constants";
import ProductDetails from "./Common/capacityConstraintContainer/ProductDetails";
import CapacityConstraintStatusContainer from "./Common/capacityConstraintContainer/CapacityConstraintStatusContainer";
import { RoverNavigationExtended } from "../components/NavigationExtended/navigationExtended";
import { HelpCircle } from "react-feather";
import cookie from "react-cookies";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../components/forms/Button/button";
import { Prompt } from "react-router";
import {
  getAccess,
  getFormattedUserId,
} from "../../../../../services/auth.services";
import { PCDM_ROUTES } from "../../../../app/Route/constants/pcdmRoutes.constants";
// import { getPcdmAccessThunk } from "../store/admin.reducer";
import axios from "axios";
import { getEmployeeDetailsThunk } from "../store/admin.reducer";
import { Row, Col, Tab, Nav } from "react-bootstrap";
import Divider from "@material-ui/core/Divider";
import "./PCDMContainer.scss";
import { formatLanId } from "../services/lanId.service";
import { PlusSquare } from "react-feather";
import { ERROR_MSG } from "../constants/message.contants";
import { addNotification, discardDisplayCommonError } from "../store/common.reducer";
import { ErrorMessageModal } from "../components/MessageModal/errorMessageModal";
import ProductEngineeringHome from "./../../../suite/views/Workforce/ProjectEngineering/projectEngineeringHome";
const WINDOW_OPEN_FEATURES = "scrollbars=yes, resizable=yes";
export class PCDMContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      navList: [
        {
          navKey: PCDM_TABS.TEAM_COMPOSITION,
          header: "Team Composition",
          floater: () => (
            <div
              className="howto-icon-container"
              onClick={() => this.showHowTo(PCDM_TABS.TEAM_COMPOSITION)}
            >
              <i
                className="fa fa-question-circle"
                title="Click to get walkaround in Team Composition tab"
              ></i>
            </div>
          ),
          content: this.getTeamCompositionView,
        },
        {
          navKey: PCDM_TABS.PRODUCT_ENGINEERING,
          header: "Product Engineering",
          floater: () => (
            <div
              className="howto-icon-container"
              onClick={() => this.showHowTo(PCDM_TABS.PRODUCT_ENGINEERING)}
            >
              <i
                className="fa fa-question-circle"
                title="Click to get walkaround in Product Engineering tab"
              ></i>
            </div>
          ),
          content: this.getProductEngineeringView,
        },
        {
          navKey: PCDM_TABS.PROJECT_ESTIMATES,
          header: "Project Estimates",
          floater: () => (
            <div
              className="howto-icon-container"
              onClick={() => this.showHowTo(PCDM_TABS.PROJECT_ESTIMATES)}
            >
              <i
                className="fa fa-question-circle"
                title="Click to get walkaround in Project Estimates tab"
              ></i>
            </div>
          ),
          content: this.getProjectEstimatesView,
        },
        {
          navKey: PCDM_TABS.SUMMARY,
          header: "Summary",
          floater: () => (
            <div
              className="howto-icon-container"
              onClick={() => this.showHowTo(PCDM_TABS.SUMMARY)}
            >
              <i
                className="fa fa-question-circle"
                title="Click to get walkaround in Summary tab"
              ></i>
            </div>
          ),
          content: this.getSummaryView,
        },
        {
          navKey: PCDM_TABS.FORECASTS,
          header: "Forecasts",
          content: this.getForecastView,
        },
      ],
      messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
      showProductForm: false,
    };
  }
  componentWillUnmount() {
    window.removeEventListener(
      "beforeunload",
      this.checkForecastChangeOnReload
    );
  }
  componentDidMount() {
    const { match, userParams } = this.props;
    document.title = "Rover PCDM - Team Composition";
    // window.addEventListener("beforeunload", this.checkForecastChangeOnReload);
    window.onbeforeunload = this.checkForecastChangeOnReload;
    // getPCDMAccess(match.params.productCode, getFormattedUserId(userParams));
    // this.props.getEmployeeDetails();
  }
  checkForecastChangeOnReload = (e) => {
    if (this.props.forecastTableHistory.length) {
      console.log("Refreshing..", e, this.props.forecastTableHistory);
      e.preventDefault();
      e.returnValue = "You have unsaved changes!!!";
      this.checkForecastChanges();
    } else {
      console.log("No forecast change..", e, this.props.forecastTableHistory);
    }
  };
  openDescriptionWindow = (url, title) => {
    const token = localStorage.getItem("token");
    axios({
      url: `${cookie.load("ROVER_PCD_API")}${url}`,
      headers: {
        Authorization: token ? `Bearer ${token}` : "",
      },
      method: "GET",
      responseType: "blob",
    }).then((response) => {
      const _url = window.URL.createObjectURL(
        new Blob([response.data], { type: "application/pdf" })
      );
      window.open(_url, title, WINDOW_OPEN_FEATURES);
    });
  };

  openDescriptionWindowforProductEngineering = (url, title) => {
    const token = localStorage.getItem("token");
    let  DOMAIN ='';
    let urlCheck=window.location.host;
  //   if(urlCheck=='rover-web-app-uat.cfaa.azr.hcsctest.net')
  //   {
  //     DOMAIN="https://rover-technical-delivery-api.cfaa.azr.hcsctest.net";
  //   } 
  //  else DOMAIN= "https://rover-technical-delivery-api-dev.cfaa.azr.hcsctest.net";
   DOMAIN = cookie.load('ROVER_TD_API');
    axios({
      url: `${DOMAIN}${url}`,
      headers: {
        Authorization: token ? `Bearer ${token}` : "",
      },
      method: "GET",
      responseType: "blob",
    }).then((response) => {
      const _url = window.URL.createObjectURL(
        new Blob([response.data], { type: "application/pdf" })
      );
      window.open(_url, title, WINDOW_OPEN_FEATURES);
    });
  };

  showHowTo = (tab) => {
    if (tab === PCDM_TABS.TEAM_COMPOSITION) {
      // window.open(
      //   `${cookie.load("ROVER_PCD_API")}/pcd/tool-tip/team-composition`,
      //   "How to - Team Composition",
      //   WINDOW_OPEN_FEATURES
      // );
      this.openDescriptionWindow( 
        "/pcd/tool-tip/team-composition",
        "How to - Team Composition"
      );
    } 
    else if (tab === PCDM_TABS.PRODUCT_ENGINEERING) {
     // window.open(
      //   `${cookie.load("ROVER_PCD_API")}/pcd/tool-tip/project-estimates`,
      //   "How to - Project Estimates",
      //   WINDOW_OPEN_FEATURES
      // );
      this.openDescriptionWindowforProductEngineering(
        //"/pcd/tool-tip/product-engineering",
        "/v1/td/tool-guide/product-engineering",
        "How to - Product Engineering"
      );
      
    }
    else if (tab === PCDM_TABS.PROJECT_ESTIMATES) {
      // window.open(
      //   `${cookie.load("ROVER_PCD_API")}/pcd/tool-tip/project-estimates`,
      //   "How to - Project Estimates",
      //   WINDOW_OPEN_FEATURES
      // );
      this.openDescriptionWindow(
        "/pcd/tool-tip/project-estimates",
        "How to - Project Estimates"
      );
    } else if (tab === PCDM_TABS.SUMMARY) {
      // window.open(
      //   `${cookie.load("ROVER_PCD_API")}/pcd/tool-tip/summary`,
      //   "How to - Summary",
      //   WINDOW_OPEN_FEATURES
      // );
      this.openDescriptionWindow("/pcd/tool-tip/summary", "How to - Summary");
    }
  };
  getTeamCompositionView = () => {
    const { productDetails, pcdmAccess } = this.props;
    return (
      <TeamComposition
        productDetails={productDetails}
        productCode={this.props.match.params.productCode}
        pcdmAccess={pcdmAccess.data}
        getProductManagerName={this.getProductManagerName}
      />
    );
  };
  getProductEngineeringView  = () => {
    const { productDetails, pcdmAccess } = this.props;
    return (
      <h1>123</h1>// <TeamComposition
      //   productDetails={productDetails}
      //   productCode={this.props.match.params.productCode}
      //   pcdmAccess={pcdmAccess.data}
      //   getProductManagerName={this.getProductManagerName}
      // />
    );
  };
  getProjectEstimatesView = () => {
    const { productDetails, pcdmAccess } = this.props;
    return (
      <ProjectEstimates
        productDetails={productDetails}
        productCode={this.props.match.params.productCode}
        pcdmAccess={pcdmAccess.data}
        getProductManagerName={this.getProductManagerName}
      />
    );
  };
  getSummaryView = () => {
    const { productDetails, pcdmAccess } = this.props;
    return (
      <Summary
        productDetails={productDetails}
        productCode={this.props.match.params.productCode}
        pcdmAccess={pcdmAccess.data}
        getProductManagerName={this.getProductManagerName}
      />
    );
  };
  getForecastView = () => {
    const { productDetails, pcdmAccess } = this.props;
    return (
      <Forecasts
        productDetails={productDetails}
        productCode={this.props.match.params.productCode}
        checkForecastChanges={this.checkForecastChanges}
        pcdmAccess={pcdmAccess.data}
        getProductManagerName={this.getProductManagerName}
      />
    );
  };
  setTitle = (activeTab) => {
    if (activeTab === PCDM_TABS.TEAM_COMPOSITION) {
      document.title = "Rover PCDM - Team Composition";
    } else if (activeTab === PCDM_TABS.PRODUCT_ENGINEERING) {
      document.title = "Rover PCDM - Project Engineering";
    } else if (activeTab === PCDM_TABS.PROJECT_ESTIMATES) {
      document.title = "Rover PCDM - Project Estimates";
    } else if (activeTab === PCDM_TABS.SUMMARY) {
      document.title = "Rover PCDM - Summary";
    } else if (activeTab === PCDM_TABS.FORECASTS) {
      document.title = "Rover PCDM - Forecasts";
    }
  };
  OnTabChange = (tab) => {
    if (this.props.forecastTableHistory.length) {
      this.checkForecastChanges(tab);
    } else {
      this.setTitle(tab);
      this.props.changePCDMTab(tab);
    }
  };
  discardNotification = () => {
    this.props.discardDisplayPrompt()
  }
  getForecastChangeFooter = (tab) => {
    return (
      <div className="pcdm-btn-wrapper pcdm-btn-wrapper--inline">
        <CustomButton
          variant={BUTTON_VARIANTS.SUCCESS}
          size="md"
          onClick={() => this.forecastChangeOnClose(ACTIONS.YES, "", tab)}
        >
          Save
        </CustomButton>
        <CustomButton
          key={2}
          variant={BUTTON_VARIANTS.LIGHT}
          size="md"
          onClick={() => this.forecastChangeOnClose(ACTIONS.NO, "", tab)}
        >
          Clear
        </CustomButton>
      </div>
    );
  };
  forecastChangeOnClose = (button, data, tab = "") => {
    if (button === ACTIONS.YES) {
      this.updateForecastChanges();
    } else if (button === ACTIONS.NO) {
      this.props.clearForecastChange();
    }
    this.setState({ messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG } });
    if (tab && button !== ACTIONS.CLOSE) {
      this.setTitle(tab);
      this.props.changePCDMTab(tab);
    }
  };
  checkForecastChanges = (tab) => {
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        variant: ACTIONS.YES_NO,
        customFooter: () => this.getForecastChangeFooter(tab),
        title: "Save Changes",
        visible: true,
        onClose: (button, data) =>
          this.forecastChangeOnClose(button, data, tab),
        dialogClassName: "forecast-prompt-modal",
        message:
          "You have unsaved forecasts, do you want to save them now or clear them?",
      },
    });
  };
  updateForecastChanges = () => {
    const {
      match,
      updateForecastChanges,
      getForecasts,
      forecastTableHistory,
    } = this.props;
    let payload = forecastTableHistory.map((change) => {
      return {
        pcode: change.pcode,
        projectEstimateId: change.projectEstimateId,
        month: change.month,
        forecastPoints: Number(change.forecast.points),
      };
    });
    updateForecastChanges(match.params.productCode, payload, (status, data) => {
      if (status === UPDATE_FORECAST_CHANGES_SUCCESS) {
        sessionStorage.clear();
        sessionStorage.setItem("token", localStorage.getItem("token"));
        getForecasts(match.params.productCode);
      } else {
        console.log("error", data);
      }
    });
  };
  
  managePMDelegates = () => {
    this.setState({showProductForm:true})
  }
  getProductManagerName = () => {
    const { productDetails, userParams, iiqRole } = this.props
    const username = formatLanId(userParams)
    if ((username === productDetails.lanId && iiqRole.PCDM.EDIT) || iiqRole.ADMIN ){
      return (<span>{productDetails.manager} 
      <CustomButton
        onClick={this.managePMDelegates}
        title={"Manage Delegates"}
        className="switch-product-link"
        borderless={true}
        size="sm"
        variant={BUTTON_VARIANTS.ICON}
      >
        <PlusSquare size={15} strokeWidth={3} />
      </CustomButton></span>)
    }else{
      return (<span>{productDetails.manager}</span>)
    }

  }
  onModalClose = async (status, data, keepModal = false) => {
    if (status === ACTIONS.SUCCESS) {
      this.props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      this.setState({showProductForm:false})
    } else if (status === ACTIONS.ERROR) {
      this.props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
      this.setState({showProductForm:false})
    } else {
      this.setState({showProductForm:false})
    }
  };
  render() {
    const {
      activeTab,
      forecastTableHistory,
      pcdmAccess,
      productDetails,iiqRole
    } = this.props;
    const { messageModalConfig, navList, showProductForm } = this.state;
    if (
      this.props.history &&
      (!this.props.productDetails || !this.props.productDetails.portfolio)
    ) {
      this.props.history.push(PCDM_ROUTES.ROUTE);
    }
    return (
      <div style={{ backgroundColor: "F5F6FA" }}>
        <div>
          <ProductDetails
            productInfo={productDetails}
            history={this.props.history}
            checkForecastChanges={this.checkForecastChanges}
            shouldRedirectToProductLine = {true}
          />
          <CapacityConstraintStatusContainer
            pcdmAccess={pcdmAccess.data}
            checkForecastChanges={this.checkForecastChanges}
          />
        </div>
        <br/>
        <br/>
        <div className="pcdm-nav-tab-container pcdm-tabs-new">
          {/* <RoverNavigationExtended
            className="pcdm-nav-tab"
            navList={navList}
            activeKey={activeTab}
            onTabChange={(tab) => this.OnTabChange(tab)}
          /> */}
          <Tab.Container 
          // defaultActiveKey={PCDM_TABS.TEAM_COMPOSITION} 
          activeKey = {activeTab}
          onSelect = {(k)=>{this.OnTabChange(k)}}
          transition={false}>
            <Nav variant="pills">
              <div className="product-tabs-header col-md-10 col-sm-12 ">
                <div  className="product-tab col-xl-2 col-lg-3">
                  <Nav.Item>
                    <Nav.Link eventKey={PCDM_TABS.TEAM_COMPOSITION}>
                      <span className="tab-header"   >TEAM COMPOSITION&nbsp;&nbsp;<HelpCircle size={13} strokeWidth={2} onClick={() => this.showHowTo(PCDM_TABS.TEAM_COMPOSITION)} /> </span>
                    </Nav.Link>
                  </Nav.Item>
                </div>
                {/* <div  className="product-tab col-xl-2 col-lg-3">
                  <Nav.Item>
                    <Nav.Link eventKey={PCDM_TABS.PRODUCT_ENGINEERING}>
                      <span className="tab-header"   >PRODUCT&nbsp;ENGINEERING&nbsp;<HelpCircle size={13} strokeWidth={2} onClick={() => this.showHowTo(PCDM_TABS.PRODUCT_ENGINEERING)} /> </span>
                    </Nav.Link>
                  </Nav.Item>
                </div> */}
                
                {/* // This is product Engineering Tab hide --Shiva */}
                {((iiqRole && Object.keys(iiqRole).length && iiqRole.ADMIN)||(iiqRole && Object.keys(iiqRole).length && iiqRole.RESOURCE_MANAGER)) && <div  className="product-tab col-xl-2 col-lg-3">
                  <Nav.Item>
                    <Nav.Link eventKey={PCDM_TABS.PRODUCT_ENGINEERING}>
                    <span className="tab-header"  >ENGINEERING ROADMAP&nbsp;&nbsp;<HelpCircle size={13} strokeWidth={2} onClick={() => this.showHowTo(PCDM_TABS.PRODUCT_ENGINEERING)} /> </span>
                      {/* <span className="tab-header"  >PRODUCT ENGINEERING&nbsp;&nbsp;<HelpCircle size={13} strokeWidth={2} onClick={() => this.showHowTo(PCDM_TABS.PRODUCT_ENGINEERING)} /> </span> */}
                    </Nav.Link>
                  </Nav.Item>
                </div>}
                <div  className="product-tab col-xl-2 col-lg-3">
                  <Nav.Item>
                    <Nav.Link eventKey={PCDM_TABS.PROJECT_ESTIMATES}>
                      <span className="tab-header"  >PROJECT ESTIMATES&nbsp;&nbsp;<HelpCircle size={13} strokeWidth={2} onClick={() => this.showHowTo(PCDM_TABS.PROJECT_ESTIMATES)} /> </span>
                    </Nav.Link>
                  </Nav.Item>
                </div>
                <div  className="product-tab col-xl-2 col-lg-3">
                  <Nav.Item>
                    <Nav.Link eventKey={PCDM_TABS.SUMMARY}>
                      <span className="tab-header" >SUMMARY&nbsp;&nbsp;<HelpCircle size={13} strokeWidth={2} onClick={() => this.showHowTo(PCDM_TABS.SUMMARY)} /> </span>
                    </Nav.Link>
                  </Nav.Item>
                </div>
                <div className="product-tab col-xl-2 col-lg-3">
                  <Nav.Item>
                    <Nav.Link eventKey={PCDM_TABS.FORECASTS}>
                      <span className="tab-header" >FORECASTS</span>
                    </Nav.Link>
                  </Nav.Item>
                </div>
              </div>
            </Nav>
            <Divider />
            <div className="pcdm-product-pages">
              <Tab.Content>
                <Tab.Pane eventKey={PCDM_TABS.TEAM_COMPOSITION}>
                  <TeamComposition
                    productDetails={productDetails}
                    productCode={this.props.match.params.productCode}
                    pcdmAccess={pcdmAccess.data}
                  />
                </Tab.Pane>
                <Tab.Pane eventKey={PCDM_TABS.PRODUCT_ENGINEERING}>
                  <ProductEngineeringHome productDetails={productDetails}  />
                 
                </Tab.Pane>
                <Tab.Pane eventKey={PCDM_TABS.PROJECT_ESTIMATES}>
                  <ProjectEstimates
                    productDetails={productDetails}
                    productCode={this.props.match.params.productCode}
                    pcdmAccess={pcdmAccess.data}
                  />
                </Tab.Pane>
                <Tab.Pane eventKey={PCDM_TABS.SUMMARY}>
                  <Summary
                    productDetails={productDetails}
                    productCode={this.props.match.params.productCode}
                    pcdmAccess={pcdmAccess.data}
                  />
                </Tab.Pane>
                <Tab.Pane eventKey={PCDM_TABS.FORECASTS}>
                  <Forecasts
                    productDetails={productDetails}
                    productCode={this.props.match.params.productCode}
                    checkForecastChanges={this.checkForecastChanges}
                    pcdmAccess={pcdmAccess.data}
                  />
                </Tab.Pane>
              </Tab.Content>
            </div>
          </Tab.Container>
        </div>
        <Toaster />
        <MessageModal {...messageModalConfig} />
        <Prompt
          when={forecastTableHistory.length}
          message={(location) => {
            if (forecastTableHistory.length) {
              this.checkForecastChanges();
              return false;
            }
            return true;
          }}
        />
        {/* {showProductForm ? 
          <ManageProductsForm 
            formVisible={showProductForm}
            selectedProduct={productDetails}
            formMode={PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW}
            closeModal={(status, data, keepModal) => this.onModalClose(status, data, keepModal)}
          /> 
        : null} */}
        <ErrorMessageModal  errorNotification = {this.props.errorNotification}
                 discardNotification = {this.discardNotification} />
      </div>
    );
  }
}
export const mapStateToProps = (state, ownProps) => {
  let productCode = ownProps.match.params.productCode;
  let productDetails = state.ProductsReducer.productsByOwner.data
    .productsResponses
    ? state.ProductsReducer.productsByOwner.data.productsResponses.find(
        (pd) => pd.productCode == productCode
      )
    : null;
  let productLines = [...state.ProductsReducer.productLines.data];
  let portfolio = {};
  if (productLines && productLines.length) {
    portfolio = productLines.find(
      (el) => el.portfolioId === productDetails.portfolioId
    );
  }
  productDetails = {
    ...productDetails,
    portfolio:
      portfolio && portfolio.portfolioName ? portfolio.portfolioName : "",
  };
  return {
    productDetails: productDetails,
    user: state.AuthReducer.user,
    permissions: state.AuthReducer.permissions,
    activeTab: state.CommonPCDMReducer.selectedTab,
    forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
    pcdmAccess: state.PCDMAdminReducer.pcdmAccess,
    userParams: state.AuthReducer.user,
    productLines: state.ProductsReducer.productLines.data,
    iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
    errorNotification: state.CommonPCDMReducer.errorNotification,
  };
};

export const mapDispatchToProps = (dispatch) => ({
  changePCDMTab: (tab) => dispatch(changeTab(tab)),
  updateForecastChanges: (productCode, payload, callback) =>
    dispatch(updateForecastChangesThunk(productCode, payload, callback)),
  getForecasts: (productCode) => dispatch(getForecastsThunk(productCode)),
  clearForecastChange: () => dispatch(clearForecastChange()),
  getForecastsAggregate: (productCode) =>
    dispatch(getForecastsAggregateThunk(productCode)),
  // getPCDMAccess: (productCode, lanId) => dispatch(getPcdmAccessThunk(productCode, lanId)),
  // getEmployeeDetails: ()=> dispatch(getEmployeeDetailsThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
  discardDisplayPrompt: () => dispatch(discardDisplayCommonError()),
});

export default connect(mapStateToProps, mapDispatchToProps)(PCDMContainer);