import React, { useState, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import { connect } from "react-redux";
import cookie from "react-cookies";
import axios from 'axios';
import moment from "moment";
import FileDownloader from 'js-file-download';
import { searchPcode } from '../admin.service';
import { FORM_CONTROL_DEFAULT } from "../../../constants/form.constants";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import CustomCheckBox from '../../../components/forms/CheckBoxSubBoxes/subCheckBox';

function AvgCostPerPointReport(props) {

  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    selectedProducts: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
  });
  const [progress, setProgress] = useState(false)
  const AVG_COST_REPORT_FILE_NAME = "avgCostPerPoint";

  const download = (url) => {
    const token = localStorage.getItem("token")
    setProgress(true)
    axios({
      url: `${cookie.load("ROVER_PCD_API")}${url}`,
      method: 'GET',
      headers : {
        Authorization : token ? `Bearer ${token}` : ''
      },
      onDownloadProgress(progressEvent){
        // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
        setProgress(true);
      },
      responseType: 'blob',
    }).then(response => {
      setProgress(false)
      // const url = window.URL.createObjectURL(new Blob([response.data]));
      // const link = document.createElement('a');
      // link.href = url;
      // link.target = "_blank";
      // link.setAttribute('download', `PCDM Avg Cost Per Point ${moment().format("YYYY.MM.DD")}.xlsx`);
      // document.body.appendChild(link);
      // link.click()
      // window.open(url, "_blank").focus()
      FileDownloader(response.data, `PCDM Avg Cost Per Point ${moment().format("YYYY.MM.DD")}.xlsx`)
    }).catch(error => {
      console.log(error)
      setProgress(false)
    })
  }

  const onSubmit = () => {
    if (noOfProd !== 0) {
      let noOfSelectedProducts = selectedFilters ? selectedFilters.map(
        (prod) => prod.children).flat().length : 0;
      let noOfActiveProducts = props.products && props.products.data &&
        props.products.data.productsResponses ? props.products.data.productsResponses.filter(
          (prod) => prod.active === true).length : 0;
      if (noOfSelectedProducts === noOfActiveProducts && noOfActiveProducts) {
        // window.open(
        //   `${cookie.load(
        //     "ROVER_PCD_API"
        //   )}/pcd/products/download/${AVG_COST_REPORT_FILE_NAME}`);
          download(`/pcd/products/download/${AVG_COST_REPORT_FILE_NAME}`)
      } else if (noOfActiveProducts > noOfSelectedProducts && noOfActiveProducts) {
        let filteredProducts = searchPcode(props.products && props.products.data
          && props.products.data.productsResponses ?
          props.products.data.productsResponses : [], selectedFilters)
        // window.open(
        //   `${cookie.load(
        //     "ROVER_PCD_API"
        //   )}/pcd/products/download/${AVG_COST_REPORT_FILE_NAME}?${filteredProducts}`);
          download(`/pcd/products/download/${AVG_COST_REPORT_FILE_NAME}?${filteredProducts}`)
      }
    } else {
      setFormControls({
        ...formControls,
        selectedProducts: {
          ...formControls.selectedProducts,
          error: noOfProd !== 0 ? false : true,
          errorMsg: noOfProd !== 0 ? "" : "Please select atleast one Product",
        },
      });
    }
  };

  //#region 

  // Filter functionalities
  const CHECK = {
    SELECTED: "SELECTED",
    NOT_SELECTED: "NOT_SELECTED",
    PARTIALLY_SELECTED: "PARTIALLY_SELECTED",
  };

  // Setting list for dropdown
  const [noOfProd, setNoOfProd] = useState(0);
  const [productList, setProductList] = useState({});

  useEffect(() => {
    if (formControls.selectedProducts.error) {
      setFormControls({
        ...formControls,
        selectedProducts: {
          ...formControls.selectedProducts,
          error: noOfProd !== 0 ? false : true,
          errorMsg: noOfProd !== 0 ? "" : "Please select atleast one Product",
        },
      });
    }
  }, [noOfProd])

  useEffect(() => {
    if (props.products && props.products.data && props.products.data.productsResponses) {
      const productList = props.products.data.productsResponses;
      let list = {};
      productList.forEach((el) => {
        if (el.active && !el.testProduct) {
          if (!list[el.portfolio]) {
            list[el.portfolio] = { portfolioId: el.portfolioId, children: [el.name] }
          } else {
            list[el.portfolio] = { ...list[el.portfolio], children: [...list[el.portfolio].children, el.name] }
          }
        }
      })
      setProductList(list);
    }
  }, [props.products])

  useEffect(() => {
    if (productList) {
      selectOrDeselectAll()
    }
  }, [productList])

  //#region // Check and Onclick Function for Select All
  const [selectedFilters, setSelectedFilter] = useState([]);
  const checkAllSelected = () => {
    let allSelected = [...selectedFilters];
    let countA = 0; let countB = 0
    Object.keys(productList).forEach((el) => {
      countA += productList[el].children.length
    })
    allSelected.forEach((el) => {
      countB += el.children.length
    })
    return allSelected.length === 0
      ? CHECK.NOT_SELECTED
      : countA === countB
        ? CHECK.SELECTED
        : CHECK.PARTIALLY_SELECTED;
  }
  const selectOrDeselectAll = () => {
    if (selectedFilters.length !== Object.keys(productList).length) {
      let tempSelected = []
      Object.keys(productList).forEach((el) => {
        let obj = { id: el, children: productList[el].children }
        tempSelected.push(obj);
      })
      setSelectedFilter(tempSelected);
    } else {
      setSelectedFilter([]);
    }
  }
  //#endregion

  // Function for selecting sub Options
  const updateFilters = (element, parent) => {
    let tempFilter = [...selectedFilters];
    let flag = false;
    tempFilter.forEach((el, index) => {
      if (el.id === parent) {
        flag = true;
        if (el.children.includes(element)) {
          let newFilter = el.children.filter((prod) => prod !== element)
          tempFilter[index].children = newFilter;
          setSelectedFilter(tempFilter);
        } else {
          tempFilter[index].children.push(element);
          setSelectedFilter(tempFilter);
        }
      }
    })
    if (!flag) {
      let obj = { id: parent, children: [element] }
      tempFilter.push(obj);
      setSelectedFilter(tempFilter);
    }
  }

  useEffect(() => {
    if (selectedFilters) {
      let count = 0;
      selectedFilters.forEach((el) => {
        count += el.children.length;
      });
      setNoOfProd(count);
    }
  }, [selectedFilters])

  const closeDropdown = () => {
    document.getElementById("dropdown").classList.remove("on");
  }
  //#endregion
  return (
    <div className="pcdm-avgCostPerPoint-report">
      <Row>
        <Col sm={4} md={4} lg={4} xl={4}>
          <form className="pcdm-form">
            <div className="pcdm-form__form-group">
              <div className="pcdm-form__form-group-field">
                <label className='required text-cap'>Selected Products</label>
                <CustomCheckBox
                  title={'Products'}
                  list={productList}
                  key={'portfolioId'}
                  value={'children'}
                  componentName={'avgcost-report'}
                  valuesSelected={noOfProd}
                  checkAllSelected={checkAllSelected}
                  selectedFilters={selectedFilters}
                  updateFilters={updateFilters}
                  selectOrDeselectAll={selectOrDeselectAll}
                  setSelectedFilter={setSelectedFilter}
                />
                <div class="error-message-container"><div class="error-message">{formControls.selectedProducts.errorMsg}</div></div>
              </div>
            </div>
          </form>
          <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
            <CustomButton
              variant={BUTTON_VARIANTS.BLUE_GOLD}
              size="md"
              onClick={onSubmit}
              disable={false}
              loading={progress}
              fluid={true}
            >
              Download Avg Cost Per Point Report
            </CustomButton>
          </div>
        </Col>
        <Col sm={{offset:1, span:5}} md={{ offset:1, span:5}} lg={{ offset:1, span:5}} xl={{ offset:1, span:5}}>
          <div className='avg-cost-report-description'>This report will show the Avg Cost per Point (based on the Team Composition page) for all selected products at the time the report is generated.</div>
        </Col>
      </Row>
    </div>
  );
}

export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner
});

export default connect(mapStateToProps, null)(AvgCostPerPointReport);

