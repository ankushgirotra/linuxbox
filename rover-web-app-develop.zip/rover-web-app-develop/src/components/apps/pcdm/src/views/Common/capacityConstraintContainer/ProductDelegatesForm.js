import React, { Component } from "react";
import { FORM_CONTROL_DEFAULT } from "../../../constants/form.constants";
import { FormModal } from "../../../components/FormModal/formModal";
import { PCDM_ADMIN_ACTIONS, ACTIONS, PRODUCT_ACTIONS } from "../../../constants/action.constants";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import TextField from "../../../components/forms/textField/textField";
import ErrorMsg from "../../../components/forms/errorMsg/errorMsg";
// import "../../admin.scss";
import { PlusCircle, MinusCircle, Trash2, PlusSquare } from "react-feather";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import {
  validateManageProductForm,
  handleProductAPIResponse,
  handleSoftDeleteAPIResponse,
  handleAddProductAPIResponse
} from "../../../services/Admin/admin.product.service";
import { saveProductThunk, addProductThunk, getDelegatesByProductThunk } from "../../../store/products.reducer";
import { DATA_STATUS } from "../../../constants/service.constant";
import { connect } from "react-redux";
import { check } from "../../../services/validation";
import { ADMIN_MANAGE_PRODUCT } from "../../../constants/message.contants";
import AsyncCustomSelect from "../../../components/forms/SelectDropdown/AsyncSelect";
import {
  MessageModal,
  DEFAULT_MSG_MODAL_CONFIG,
} from "../../../components/MessageModal/messageModal";
import { ProductDetails } from "./ProductDetails";
import { Tab, Nav } from "react-bootstrap";
import Divider from "@material-ui/core/Divider";
import { getProductFollowersThunk } from "../../../store/RMFollow.reducer";

const DELEGATE_FORM_ATTR = {
  delegateLanId: {
    ...FORM_CONTROL_DEFAULT,
    required: true,
    alreadyExist: false,
    addDelegate: false,
    editDelegate: false,
    active: true,
  },
  delegateName: {  
    ...FORM_CONTROL_DEFAULT,
    required: true,
    alreadyExist: false,
    addDelegate: false,
    editDelegate: false,
    active: true,
  },
  selectedDelegateName : {
    ...FORM_CONTROL_DEFAULT,
    required: true,
    alreadyExist: false,
    addDelegate: false,
    editDelegate: false,
    active: true,
  },
  delegateEmail: {
    ...FORM_CONTROL_DEFAULT,
    required: true,
    alreadyExist: false,
    addDelegate: false,
    editDelegate: false,
    active: true,
  },
};
const MANAGE_PRODUCTS_INITIAL_STATE = {
    activeTab:"delegates",
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    testProduct:false,
    productCode: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    productName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    productLine: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    itpmLanId: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    itpmName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    selectedItpmName : {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    itpmEmail: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    active: {
      ...FORM_CONTROL_DEFAULT,
      value: true,
    },
    delegateList: [],
  },
};
export class ManageProductsForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ...MANAGE_PRODUCTS_INITIAL_STATE,
    };
  }
  componentDidMount = async () => {
    const { selectedProduct, formMode, getDelegates, getProductFollowers } = this.props;
    getProductFollowers(selectedProduct.productCode)
    if (
      formMode === PCDM_ADMIN_ACTIONS.EDIT_PRODUCT ||
      formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW
    ) {
      await getDelegates(selectedProduct.productCode);
      this.populateProductForm();
    }
  };
  populateProductForm = () => {
    const { formControls } = this.state;
    const { selectedProduct, delegates, formMode } = this.props;
    this.setState({
      formControls: {
        ...formControls,
        testProduct: selectedProduct.testProduct,
        productCode: {
          ...formControls.productCode,
          value: selectedProduct.productCode,
          readOnly: true,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        productName: {
          ...formControls.productName,
          value: selectedProduct.name,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        productLine: {
          ...formControls.productLine,
          value: selectedProduct.portfolioId,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        itpmLanId: {
          ...formControls.itpmLanId,
          value: selectedProduct.lanId,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        itpmName: {
          ...formControls.itpmName,
          value: selectedProduct.lanId,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        selectedItpmName: {
          ...formControls.itpmName,
          value: selectedProduct.manager,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        itpmEmail: {
          ...formControls.itpmEmail,
          value: selectedProduct.email,
          disabled:
            formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
        },
        active: {
          ...formControls.active,
          value: selectedProduct.active,
        },
        delegateList: delegates.data
          .filter((del) => del.active)
          .map((delegate, index) => ({
            ...DELEGATE_FORM_ATTR,
            delegateLanId: {
              ...DELEGATE_FORM_ATTR.delegateLanId,
              value: delegate.delegatedLanId,
              alreadyExist: true,
              // disabled:formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
            },
            delegateName: {
              ...DELEGATE_FORM_ATTR.delegateName,
              value: delegate.delegatedLanId,
              alreadyExist: true,
              // disabled:formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
            },
            selectedDelegateName: {
              ...DELEGATE_FORM_ATTR.delegateName,
              value: delegate.delegateName,
              alreadyExist: true,
              // disabled:formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
            },
            delegateEmail: {
              ...DELEGATE_FORM_ATTR.delegateEmail,
              value: delegate.delegateEmail,
              alreadyExist: true,
              // disabled:formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW ? true : false,
            },
          })),
      },
    });
  };
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };
  onITPMNameInputChange = (newValue) => {
    const { formControls } = this.state;
    const selected = this.props.employeeDetails.data.find(
      (el) => el.employeeId === newValue.value
    );
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        itpmName: {
          ...formControls.itpmName,
          error: false,
          value: newValue.value,
        },
        itpmLanId: {
          ...formControls.itpmLanId,
          error: false,
          value: selected.employeeId,
        },
        selectedItpmName: {
          ...formControls.selectedItpmName,
          error: false,
          value: selected.name,
        },
        itpmEmail: {
          ...formControls.itpmEmail,
          error: false,
          value: selected.email,
        },
      },
    });
  };
  onDelegateNameChange = (newValue, index) => {
    const { formControls } = this.state;
    const selected = this.props.employeeDetails.data.find(
      (el) => el.employeeId === newValue.value
    );
    let tempDeleList = formControls.delegateList.slice();
    tempDeleList[index] = {
      ...tempDeleList[index],
      delegateLanId: {
        ...tempDeleList[index].delegateLanId,
        error: false,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
    };
    tempDeleList[index] = {
      ...tempDeleList[index],
      delegateName: {
        ...tempDeleList[index].delegateName,
        error: false,
        value: newValue.value,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
      selectedDelegateName: {
        ...tempDeleList[index].selectedDelegateName,
        error: false,
        value: selected.name,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
      delegateLanId: {
        ...tempDeleList[index].delegateLanId,
        error: false,
        value: selected.employeeId,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
      delegateEmail: {
        ...tempDeleList[index].delegateEmail,
        error: false,
        value: selected.email,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
    };
    this.setState({
      formControls: {
        ...formControls,
        error: false,
        delegateList: [...tempDeleList],
      },
    });
  };
  onDelegateChange = (event, index) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    let tempDeleList = formControls.delegateList.slice();
    tempDeleList[index] = {
      ...tempDeleList[index],
      delegateLanId: {
        ...tempDeleList[index].delegateLanId,
        error: false,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
    };
    tempDeleList[index] = {
      ...tempDeleList[index],
      [name]: {
        ...tempDeleList[index][name],
        error: false,
        value: value,
        readOnly: false,
        edited: true,
        editDelegate: true,
        active: true,
      },
    };
    this.setState({
      formControls: {
        ...formControls,
        error: false,
        delegateList: [...tempDeleList],
      },
    });
  };
  onAddOrDeleteDelegate = (mode, index) => {
    const { formControls } = this.state;
    if (mode === "ADD") {
      let updatedDelegateList = formControls.delegateList.slice();
      updatedDelegateList.unshift({ ...DELEGATE_FORM_ATTR });
      updatedDelegateList[0] = {
        ...updatedDelegateList[0],
        delegateLanId: {
          ...updatedDelegateList[0].delegateLanId,
          addDelegate: true,
          editDelegate: false,
          deleteDelegate: false,
        },
      };
      this.setState({
        formControls: {
          ...formControls,
          delegateList: updatedDelegateList,
          readOnly: true,
        },
      });
    } else if (mode === "DELETE") {
      let updatedDelegateList = formControls.delegateList.slice();
      updatedDelegateList.splice(index, 1);

      this.setState({
        formControls: {
          ...formControls,
          delegateList: updatedDelegateList,
        },
      });
    } else if (mode === "DISABLE") {
      let updatedDelegateList = formControls.delegateList.slice();
      updatedDelegateList[index] = {
        ...updatedDelegateList[index],
        delegateLanId: {
          ...updatedDelegateList[index].delegateLanId,
          readOnly: true,
          edited: true,
          addDelegate: false,
          editDelegate: false,
          deleteDelegate: true,
          active: false,
        },
        delegateName: {
          ...updatedDelegateList[index].delegateName,
          readOnly: true,
        }
      };

      this.setState({
        formControls: {
          ...formControls,
          delegateList: updatedDelegateList,
        },
      });
    } else if (mode === "ENABLE") {
      let updatedDelegateList = formControls.delegateList.slice();
      updatedDelegateList[index] = {
        ...updatedDelegateList[index],
        delegateLanId: {
          ...updatedDelegateList[index].delegateLanId,
          readOnly: false,
          edited: true,
          addDelegate: false,
          editDelegate: false,
          deleteDelegate: false,
          active: true,
        },
        delegateName: {
          ...updatedDelegateList[index].delegateName,
          readOnly: false,
        }
      };
      this.setState({
        formControls: {
          ...formControls,
          delegateList: updatedDelegateList,
        },
      });
    }
  };
  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode } = this.props;
    let validation = validateManageProductForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === PCDM_ADMIN_ACTIONS.ADD_PRODUCT) {
        await this.props.addProduct(payload, this.handleAddResponse);
      } else if (formMode === PCDM_ADMIN_ACTIONS.EDIT_PRODUCT) {
        await this.props.saveProduct(payload, this.handleResponse);
      } else if (formMode === PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW) {
        let added = 0;
        let deleted = 0;
        formControls.delegateList.forEach((del) => {
          if (del.delegateLanId.addDelegate || del.delegateEmail.editDelegate ||
             del.delegateLanId.editDelegate || del.delegateName.editDelegate) {
            added = added + 1;
          } else if (del.delegateLanId.deleteDelegate) {
            deleted = deleted + 1;
          }
        });
        if(added>0 && deleted>0){
          this.showPopUp(1)
        }
        else if (added > 0) {
          this.showPopUp(3);
        } else if (deleted > 0) {
          this.showPopUp(4);
        }
      }
    }
  };
  getAddPromptMessage = () => {
    return (
      <>
        Adding this person as a delegate will give them full product manager
        access to this product once they submit an IIQ request for the{" "}
        <b>RoverPCDM Delegate</b> role in the <b>Web Role - Prod</b>{" "}
        environment. Are you sure you want to add this person as a delegate?
      </>
    );
  };
  getDeletePromptMessage = () => {
    return (
      <>
        Removing this person as a delegate will revoke their edit access to this
        product. Are you sure you want to remove this person as a delegate?
      </>
    );
  };
  firstAction = (action, data) => {
    if(action === ACTIONS.YES){
      this.setState({approveAdd : true})
    }else{
      this.setState({approveAdd : false})
    }
    this.showPopUp(2)
  }
  secondAction = (action, data) => {
    if(action === ACTIONS.YES){
      this.setState({approvedelete : true}, ()=> this.handleDoubleAction() )
    }else{
      this.setState({approvedelete : false}, ()=> this.handleDoubleAction())
    }
    this.setState({
      messageModalConfig : {
        visible : false
      }
    })
  }
  handleDoubleAction = () => {
    const { approveAdd, approvedelete } = this.state
    let payload = this.reqPayload();
    if(approveAdd && approvedelete ){
      this.props.saveProduct(payload, this.handleResponse);
    }else if(!approveAdd && approvedelete){
      const arr = payload.delegateRequests.filter(del => !(del.addDelegate ? true : false))
      payload.delegateRequests = [...arr]
      this.props.saveProduct(payload, this.handleResponse);
    }else if(approveAdd && !approvedelete){
      const remArr = payload.delegateRequests.filter(del => (del.active ? true : false))
      const delArr = payload.delegateRequests.filter(del => !(del.active ? true : false))
      const newArr = [];
      delArr.forEach(del=> {
        del.active = true;
        del.deleteDelegate = false;
        newArr.push(del)
      })
      payload.delegateRequests = [...remArr, ...newArr]
      this.props.saveProduct(payload, this.handleResponse);
    }
  }
  showPopUp = (val) => {
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: val === 1 || val === 3 ? "ADD DELEGATE" : "DELETE DELEGATE",
        customContent:
          val === 1 || val === 3 ? this.getAddPromptMessage : this.getDeletePromptMessage,
        visible: true,
        onClose: val === 1 ? this.firstAction : val === 2 ? this.secondAction :  this.handleAction,
        variant: ACTIONS.YES_NO,
      },
    });
  };
  handleAction = async (action, data) => {
    if (action === ACTIONS.YES) {
      let payload = this.reqPayload();
      this.props.saveProduct(payload, this.handleResponse);
    } 
      this.setState({
        messageModalConfig : {
          visible : false
        }
      })
  };
  onActivateOrDeactivate = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formMode } = this.props;
    const { formControls } = this.state;
    let validation = validateManageProductForm(formControls);
    if (validation.error && formControls.edited) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload(ADMIN_MANAGE_PRODUCT.SOFTDELETE);
      if (formMode === PCDM_ADMIN_ACTIONS.EDIT_PRODUCT) {
        await this.props.saveProduct(payload, this.handleSoftDeleteResponse);
      }
    }
  };

  reqPayload = (defaultRequest = ADMIN_MANAGE_PRODUCT.SUBMIT) => {
    const { formControls } = this.state;
    const { productLines } = this.props;
    const productLinesCheck = check({
      original: productLines,
      path: "data",
      checkEmpty: true,
      defaultReturnValue: [],
    });
    // const employeeDetailsCheck = check({
    //   original: employeeDetails,
    //   path: "data",
    //   checkEmpty: true,
    //   defaultReturnValue: [],
    // });
    let payload = {
      productCode: formControls.productCode.value,
      productName: formControls.productName.value,
      productLineId: formControls.productLine.value,
      productLine:
        productLinesCheck.value.find(
          (el) => el.portfolioId === formControls.productLine.value
        ).portfolioName || "",
      addProduct: formControls.edited,
      itpmLanId: formControls.itpmLanId.value,
      // itpmName: employeeDetailsCheck.value.find((el)=> el.employeeId === formControls.itpmName.value).name || "",
      itpmName: formControls.selectedItpmName.value,
      itpmEmail: formControls.itpmEmail.value,
      testProduct: formControls.testProduct,
      active:
        defaultRequest === ADMIN_MANAGE_PRODUCT.SUBMIT
          ? formControls.active.value
          : !formControls.active.value,
      delegateRequests: formControls.delegateList.map((delegate, index) => {
        return {
          productCode: formControls.productCode.value,
          delegatedLanId: delegate.delegateLanId.value,
          // delegateName: employeeDetailsCheck.value.find((el)=> el.employeeId === delegate.delegateName.value).name || "",
          delegateName: delegate.selectedDelegateName.value,
          delegateEmail: delegate.delegateEmail.value,
          editDelegate: delegate.delegateLanId.active
            ? !delegate.delegateLanId.addDelegate &&
              delegate.delegateLanId.editDelegate 
              ? true
              : false
            : true,
          active: delegate.delegateLanId.active,
          addDelegate:
            delegate.delegateLanId.addDelegate &&
            delegate.delegateLanId.editDelegate &&
            delegate.delegateLanId.active
              ? true
              : false,
          deleteDelegate : delegate.delegateLanId.deleteDelegate ? true : false
        };
      }),
    };

    return payload;
  };
  handleResponse = (responseType, responseData) => {
    let { returnState, modal } = handleProductAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData
    );
    if (modal) {
      this.props.closeModal(modal.action, modal.props);
    } else if (returnState) {
      this.setState({ ...returnState });
    }
  };

  handleAddResponse = (responseType, responseData) => {
    let { returnState, modal } = handleAddProductAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData
    );
    if (modal) {
      this.props.closeModal(modal.action, modal.props);
    } else if (returnState) {
      this.setState({ ...returnState });
    }
  };

  handleSoftDeleteResponse = (responseType, responseData) => {
    let requestType =
      responseData && responseData.active
        ? ADMIN_MANAGE_PRODUCT.REACTIVATE
        : ADMIN_MANAGE_PRODUCT.DEACTIVATE;
    let { returnState, modal } = handleSoftDeleteAPIResponse(
      this.props,
      this.state,
      responseType,
      responseData,
      requestType
    );
    if (modal) {
      this.props.closeModal(modal.action, modal.props);
    } else if (returnState) {
      this.setState({ ...returnState });
    }
  };
  OnTabChange = (tab) => {
    
      this.setState({activeTab:tab});
  };
  getFormTabs = () => {
    const { formControls } = this.state;
    const { ProductFollowersList } = this.props;
    return (
      <div className="pcdm-tabs-new">
        <Tab.Container
        //   defaultActiveKey="delegates"
          activeKey = {this.state.activeTab}
          onSelect = {(k)=>{this.OnTabChange(k)}}
          transition={false}
        >
          <Nav variant="pills">
            <div className="product-tabs-header ">
              <div className="product-tab ">
                <Nav.Item>
                  <Nav.Link eventKey="delegates">
                    <span className="tab-header">DELEGATES </span>
                  </Nav.Link>
                </Nav.Item>
              </div>
              <div className="product-tab ">
                <Nav.Item>
                  <Nav.Link eventKey="followers">
                    <span className="tab-header">FOLLOWERS </span>
                  </Nav.Link>
                </Nav.Item>
              </div>
            </div>
          </Nav>
          <Divider />
          <div className="pcdm-product-pages pcdm-scroll-vertical">
            <Tab.Content>
              <Tab.Pane eventKey="delegates">
                <form className="pcdm-form">
                  <div className="pcdm-form__form-group">
                    <span>
                      Delegates are users with full access to specific products
                      in Rover PCDM. You can give Delegate access to any HCSC
                      employee who you trust with the ability to edit data for
                      your product in PCDM. Users must have the{" "}
                      <b>RoverPCDM Delegate</b> IIQ entitlement and must appear
                      in the table below in order for them to have full Delegate
                      access to this product.
                    </span>
                    <br />
                    <br />
                    {this.state.formControls.delegateList.length === 0 ? 
                    <div><p><b>This product currently has no Delegates.</b></p> 
                    <br />
                    </div> : null}
                    {this.getDelegateForm()}
                  </div>
                  {formControls.error ? (
                    <ErrorMsg
                      message={formControls.errorMessage}
                      errorDetail={formControls.errorDetail}
                    />
                  ) : null}
                </form>
              </Tab.Pane>
              <Tab.Pane eventKey="followers">
              <form className="pcdm-form">
                  <div className="pcdm-form__form-group">
                    <span>
                    Followers are Resource Managers who have chosen to follow this product so they get updates on upcoming capacity constraints detected in Rover PCDM.
                    </span>
                    <br />
                    <br />
                    {ProductFollowersList.data.length === 0 ?
                    <div><b>No Resource Managers are currently Followers of this product.</b> </div>
                    : <div>
                        <p><b>Followers:</b></p>
                        <ul>
                            {ProductFollowersList.data.map(follower=>{
                                return <li>{follower.name}</li>
                            })}
                        </ul>
                      </div>
                    }
                  </div>
                </form>
              </Tab.Pane>
            </Tab.Content>
          </div>
        </Tab.Container>
      </div>
    );
  };
  getDelegateForm = () => {
    const { formControls } = this.state;
    const { employeeDetails } = this.props;
    const employeeDetailsCheck = check({
      original: employeeDetails,
      path: "data",
      checkEmpty: true,
      defaultReturnValue: [],
    });
    console.log(formControls.delegateList)
    return (
      <>
        {/* <h5 className="pcdm-head">Delegate Details:</h5> */}
        <LinkExtended
          onClick={() => this.onAddOrDeleteDelegate("ADD")}
          className="add-delegate-link"
        >
          <PlusCircle size="12" strokeWidth={3} /> Add Delegate
        </LinkExtended>
        <br/>
        <div className="">
          {formControls.delegateList.map((delegate, index) => {
            let disableDelegate = delegate.delegateLanId.readOnly
              ? "disable-delegate"
              : "";
            return (
              <div className={`delegates-wrapper ${disableDelegate}`}>
                <div
                  className={`pcdm-form__form-group-field form-group-field--inline-3`}
                >
                  {/* <TextField
                    name="delegateName"
                    label={"Delegate Name"}
                    formObj={delegate.delegateName}
                    isRequired={delegate.delegateName.required}
                    onChange={(e) => this.onDelegateChange(e, index)}
                  /> */}
                  <AsyncCustomSelect
                    name="delegateName"
                    label={"Delegate Name"}
                    placeholder="Select a delegate name"
                    formObj={delegate.delegateName}
                    config={{
                      options: employeeDetailsCheck.value,
                      value: "name",
                      id: "employeeId",
                      id2: "lanId",
                    }}
                    doubleIds={true}
                    employeeName={delegate.selectedDelegateName.value}
                    formatOptionLabel={(prd) => `${prd.label}`}
                    isRequired={delegate.delegateName.required}
                    onChange={(newValue) => {
                      this.onDelegateNameChange(newValue, index);
                    }}
                    showDefaultValues={true}
                  />
                  <TextField
                    name={`delegateLanId`}
                    label={"Delegate Lan ID(6 digits)"}
                    formObj={delegate.delegateLanId}
                    isRequired={delegate.delegateLanId.required}
                    onChange={(e) => this.onDelegateChange(e, index)}
                  />
                  <TextField
                    name="delegateEmail"
                    label={"Delegate Email"}
                    formObj={delegate.delegateEmail}
                    isRequired={delegate.delegateEmail.required}
                    onChange={(e) => this.onDelegateChange(e, index)}
                  />
                </div>
                {delegate.delegateLanId.alreadyExist ? (
                  delegate.delegateLanId.readOnly ? (
                    <PlusSquare
                      size="14"
                      strokeWidth={3}
                      color="green"
                      onClick={() =>
                        this.onAddOrDeleteDelegate("ENABLE", index)
                      }
                    />
                  ) : (
                    <MinusCircle
                      size="14"
                      strokeWidth={3}
                      color="orange"
                      onClick={() =>
                        this.onAddOrDeleteDelegate("DISABLE", index)
                      }
                    />
                  )
                ) : (
                  <Trash2
                    size="14"
                    strokeWidth={3}
                    color="red"
                    onClick={() => this.onAddOrDeleteDelegate("DELETE", index)}
                  />
                )}
              </div>
            );
          })}
        </div>
        
      </>
    );
  };
  getFooter = () => {
    const { formMode } = this.props;
    const { formControls } = this.state;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          onClick={() => {
            this.onSubmit();
          }}
          disable={
            !(
              formControls.edited ||
              formControls.delegateList.filter(
                (del) =>
                  del.delegateLanId.edited ||
                  del.delegateName.edited ||
                  del.delegateEmail.edited ||
                  del.delegateLanId.deleteDelegate
              ).length
            )
          }
        >
          Save
        </CustomButton>
        {formMode === PCDM_ADMIN_ACTIONS.EDIT_PRODUCT ? (
          <CustomButton
            variant={
              formControls.active.value
                ? BUTTON_VARIANTS.ERROR
                : BUTTON_VARIANTS.SUCCESS
            }
            onClick={() => this.onActivateOrDeactivate()}
            size="md"
            disable={false}
          >
            {formControls.active.value
              ? ADMIN_MANAGE_PRODUCT.DEACTIVATE
              : ADMIN_MANAGE_PRODUCT.REACTIVATE}
          </CustomButton>
        ) : null}
      </div>
    );
  };
  getHeader = () =>{
      return(<ProductDetails
        productInfo={this.props.selectedProduct}
        history={this.props.history}
        fromProductForm = {true}
        /> )
  }
  render() {
    const {
      formVisible,
      closeModal,
      saveProductStatus,
      delegates,
      ProductFollowersList,
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          isLoading={
            saveProductStatus.status === DATA_STATUS.LOADING ||
            delegates.status === DATA_STATUS.LOADING || ProductFollowersList.status === DATA_STATUS.LOADING
          }
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={this.getFormTabs()}
          footer={this.state.formControls.delegateList.length > 0 && this.state.activeTab === "delegates" ? this.getFooter() : null}
          isSCForm={true}
          className="product-delegate-form pcdm-form-new"
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

export const mapStateToProps = (state) => ({
  saveProductStatus: state.ProductsReducer.saveProductStatus,
  delegates: state.ProductsReducer.delegatesByProduct,
  productLines: state.ProductsReducer.productLines,
  // employeeDetails : state.PCDMAdminReducer.employeeDetails,
  employeeDetails : state.TeamCalculationsReducer.scrumMasterData,
  ProductFollowersList : state.RMFollowReducer.ProductFollowersList
});

export const mapDispatchToProps = (dispatch) => ({
  saveProduct: (productFormData, callback) => dispatch(saveProductThunk(productFormData, callback)),
  getDelegates: (prdCode) => dispatch(getDelegatesByProductThunk(prdCode)),
  addProduct: (productFormData, callback) => dispatch(addProductThunk(productFormData, callback)),
  getProductFollowers : (productCode) => dispatch(getProductFollowersThunk(productCode))
});
export default connect(mapStateToProps, mapDispatchToProps)(ManageProductsForm);