import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import { Container, Row, Col } from "react-bootstrap";
import CustomButton from "../../components/forms/Button/button";
import AssessmentHome from "../../../../TD360/views/Assessment/assessmentHome";
import Score from '../../../../TD360/views/Assessment/score';
import RoadMapHome from '../../../../TD360/views/RoadMap/RoadMapHome';

const Home=()=>{
  const [OpenAssessment, SetOpenAssessment]= useState(false);
  const [OpenRoadMap, setOpenRoadmap]= useState(false);

  // useEffect(() => {
  //  return(SetOpenAssessment(false)) 
  // },[]);

  const BtnOnChange=(from)=>{
    if(from =='Roadmap'){
      SetOpenAssessment(false);
      setOpenRoadmap(true);
    }else if(from =='Assessment'){
      SetOpenAssessment(true);
      setOpenRoadmap(false);
    }
  }

  return( <>
<Container fluid>
        <Row className="pcdm-team_comp-container">
          <Col sm={12} md={12} lg={12} xl={3} className="pcdm-tc_panel"> 
            <div className="product-info">
             
                <div className="export-team-btn" style={{width:'172px'}}>
                  <CustomButton
                  
                 //onClick={()=>SetOpenAssessment(true)}
                 onClick={()=>{BtnOnChange('Roadmap')}}
                    title={"RoadMap"}
                    className="export-team-button"
                  >
                   
                    <span>RoadMap</span>
                  </CustomButton>
                 
                </div>
                
            </div>
           
          </Col>
          <Col > 
          {OpenAssessment&&(<><AssessmentHome/></>)}
          {OpenRoadMap&&(<><RoadMapHome/></>)}   
          </Col>
          
        </Row>
        
        <Row className="pcdm-team_comp-container">
          <Col sm={12} md={12} lg={12} xl={3} className="pcdm-tc_panel"> 
            <div className="product-info">
             
                <div className="export-team-btn" style={{width:'172px'}}>
                  <CustomButton
                   onClick={()=>{BtnOnChange('Assessment')}}
                    title={"Assessment"}
                    className="export-team-button"
                  >
                   
                    <span>Assessment </span>
                  </CustomButton>
                </div>
                
              
            </div>
           
            
          </Col>

          <Col >
          
          </Col>
        </Row>

        <Row className="pcdm-team_comp-container">
          <Col sm={12} md={12} lg={12} xl={3} className="pcdm-tc_panel"> 
          <div className="product-info">
             
             <div className="export-team-btn" style={{width:'172px'}}>
             
          
          {/* {OpenAssessment?
                      <><Score/></>
                       : ""
                    }
                
                 */}
              </div>
            </div>
           
            
          </Col>

          <Col >
          
          </Col>
        </Row>
      
      </Container>
</>)};
export default Home;