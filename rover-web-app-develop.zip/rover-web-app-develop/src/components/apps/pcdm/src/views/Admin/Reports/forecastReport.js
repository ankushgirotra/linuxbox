import React, { useState, useEffect } from "react";
import Datepicker from "../../../components/Datepicker/datepicker";
import {
  FORM_CONTROL_DEFAULT,
  MONTH_YEAR_FORMAT,
  FORM_DATE_FORMAT,
} from "../../../constants/form.constants";
import { Row, Col } from "react-bootstrap";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import moment from "moment";
import { getFormattedDate, getUTCFormattedDate } from "../../../services/form.service";
import cookie from "react-cookies";
import CustomCheckBox from '../../../components/forms/CheckBoxSubBoxes/subCheckBox';
import CustomCheckBox2, { CustomCheck } from "../../../../../../shared/CustomCheckBox/customCheckBox";
import { CHECK } from "../../../../../timesheet/constants/timesheet.constants";
import { connect } from "react-redux";
import FileDownloader from 'js-file-download';
import { searchPcode, selectedProjectCodes } from '../admin.service';
import { getForecastDueDatesThunk } from "../../../store/products.reducer";
import { getUsedProjectCodesThunk } from "../../../store/admin.reducer"
import axios from 'axios';
import CustomSelect from "../../../components/forms/SelectDropdown/selectDropdown";
import { check } from "../../../services/validation";

function ForecastReport(props) {
  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    startMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    endMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
    selectedProducts: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
    selectedProjects: {
      ...FORM_CONTROL_DEFAULT,
      // required: true,
    },
  });
  const [progress, setProgress] = useState(false)
  const manageMonthSelection = (type, date) => {
    const { endMonth } = formControls;
    let valueInMoment = moment(date, FORM_DATE_FORMAT);
    let validatedEndMonth = endMonth.value;

    if (type === "startMonth") {

      if (endMonth.value && valueInMoment.isAfter(moment(endMonth.value, FORM_DATE_FORMAT))) {
        validatedEndMonth = "";
      }
      setFormControls({
        ...formControls,
        edited: true,
        startMonth: {
          ...formControls.startMonth,
          value: date,
          error: false,
        },
        endMonth: {
          ...formControls.endMonth,
          disabled: false,
          value: validatedEndMonth,
          min: date,
          error: false,
        },
      });
    } else if (type === "endMonth") {
      setFormControls({
        ...formControls,
        edited: true,
        startMonth: {
          ...formControls.startMonth,
          error: false,
        },
        endMonth: {
          ...formControls.endMonth,
          value: date,
          error: false,
        },
      });
    }
  };
  const populateDateRange = (mode) => {
    let stMonth, edMonth;
    if (mode === "THIS_MONTH") {
      stMonth = edMonth = moment()
        .startOf("month")
        .hour(0)
        .minute(0)
        .second(0)
        .millisecond(0)
        .format(FORM_DATE_FORMAT);
      edMonth = moment()
        .endOf("month")
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format(FORM_DATE_FORMAT);
    } else if (mode === "NEXT_2_MONTHS") {
      stMonth = moment()
        // .subtract(1, "months")
        .startOf("month")
        .hour(0)
        .minute(0)
        .second(0)
        .millisecond(0)
        .format(FORM_DATE_FORMAT);
      edMonth = moment()
        .add(2, "months")
        .endOf("month")
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format(FORM_DATE_FORMAT);
    } else if (mode === "NEXT_12_MONTHS") {
      stMonth = moment()
        .startOf("month")
        .hour(0)
        .minute(0)
        .second(0)
        .millisecond(0)
        .format(FORM_DATE_FORMAT);
      edMonth = moment()
        .add(12, "months")
        .endOf("month")
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format(FORM_DATE_FORMAT);
    }
    setFormControls({
      ...formControls,
      edited: true,
      startMonth: {
        ...formControls.startMonth,
        value: new Date(getFormattedDate(stMonth)),
        error: false,
      },
      endMonth: {
        ...formControls.endMonth,
        value: new Date(getFormattedDate(edMonth)),
        error: false,
        min: new Date(getFormattedDate(stMonth)),
        disabled: false,
      },
    });
  };
  const onSubmit = () => {
    const { startMonth, endMonth } = formControls;
    if (startMonth.value && endMonth.value && noOfProd !== 0) {
      let st = moment(startMonth.value)
        .startOf("month")
        .hour(0)
        .minute(0)
        .second(0)
        .millisecond(0)
        .format("YYYY-MM-DD");
      let ed = moment(endMonth.value)
        .endOf("month")
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format("YYYY-MM-DD");
      let filteredProducts = searchPcode(props.products && props.products.data && props.products.data.productsResponses ? props.products.data.productsResponses : [],selectedFilters)
      let filteredProjects = selectedProjectCodes(formControls.selectedProjects.value);
      // window.open(
      //   `${cookie.load(
      //     "ROVER_PCD_API"
      //   )}/pcd/products/download/forecastDetails?startMonth=${st}&endMonth=${ed}${filteredProducts}`);
      const token = localStorage.getItem("token");
      setProgress(true)
      axios({
        url: `${cookie.load("ROVER_PCD_API")}/pcd/products/download/forecastDetails?startMonth=${st}&endMonth=${ed}&includeCompleted=${includeCompleted}${filteredProducts}${filteredProjects}`,
        // url: `https://api-gateway-ssl-svc.dev.hcscint.net/rover/pcdm/pcd/products/download/forecastDetails?startMonth=${st}&endMonth=${ed}&includeCompleted=${includeCompleted}${filteredProducts}${filteredProjects}`,
        method: 'GET',
        headers : {
          Authorization : token ? `Bearer ${token}` : ''
        },
        onDownloadProgress(progressEvent){
          // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
          setProgress(true);
        },
        responseType: 'blob',
      }).then(response => {
        setProgress(false)
        // const url = window.URL.createObjectURL(new Blob([response.data]));
        // const link = document.createElement('a');
        // link.href = url;
        // link.target = "_blank";
        // link.setAttribute('download', `Forecast_details_from_${st}_to_${ed}.xlsx`);
        // document.body.appendChild(link);
        // link.click()
        // // window.open(url, "_blank").focus()
        FileDownloader(response.data, `Forecast_details_from_${st}_to_${ed}.xlsx`)
      }).catch(error => {
        console.log(error)
        setProgress(false)
      })
    } else {
      setFormControls({
        ...formControls,
        startMonth: {
          ...formControls.startMonth,
          error: startMonth.value ? false : true,
          errorMsg: startMonth.value ? "" : "Please select End Month",
        },
        endMonth: {
          ...formControls.endMonth,
          error: endMonth.value ? false : true,
          errorMsg: endMonth.value ? "" : "Please select End Month",
        },
        selectedProducts: {
          ...formControls.selectedProducts,
          error: noOfProd !== 0 ? false : true,
          errorMsg: noOfProd !== 0 ? "" : "Please select atleast one Product",
        },
      });
    }
  };
  //#region 

  // Filter functionalities

  const CHECK = {
    SELECTED: "SELECTED",
    NOT_SELECTED: "NOT_SELECTED",
    PARTIALLY_SELECTED: "PARTIALLY_SELECTED",
  };

  // Setting list for dropdown
  const [noOfProd, setNoOfProd] = useState(0);
  const [productList, setProductList] = useState({});

  useEffect(() => {
    if (formControls.selectedProducts.error) {
      setFormControls({
        ...formControls,
        selectedProducts: {
          ...formControls.selectedProducts,
          error: noOfProd !== 0 ? false : true,
          errorMsg: noOfProd !== 0 ? "" : "Please select atleast one Product",
        },
      });
    }
  }, [noOfProd])

  useEffect(() => {
    if (props.products && props.products.data && props.products.data.productsResponses) {
      const productList = props.products.data.productsResponses;
      let list = {};
      productList.forEach((el) => {
        if (el.active && !el.testProduct) {
          if (!list[el.portfolio]) {
            list[el.portfolio] = { portfolioId: el.portfolioId, children: [el.name] }
          } else {
            list[el.portfolio] = { ...list[el.portfolio], children: [...list[el.portfolio].children, el.name] }
          }
        }
      })
      setProductList(list);
    }
  }, [props.products])
  useEffect(() => {
    if (productList) {
      selectOrDeselectAll()
    }
  }, [productList])

  useEffect(()=>{
    props.getForecastDueDtes();
    props.getUsedProjectCodes();
  },[])

  //#region // Check and Onclick Function for Select All
  const [selectedFilters, setSelectedFilter] = useState([]);
  const checkAllSelected = () => {
    let allSelected = [...selectedFilters];
    let countA = 0; let countB = 0
    Object.keys(productList).forEach((el) => {
      countA += productList[el].children.length
    })
    allSelected.forEach((el) => {
      countB += el.children.length
    })
    return allSelected.length === 0
      ? CHECK.NOT_SELECTED
      : countA === countB
        ? CHECK.SELECTED
        : CHECK.PARTIALLY_SELECTED;
  }
  const selectOrDeselectAll = () => {
    if (selectedFilters.length !== Object.keys(productList).length) {
      let tempSelected = []
      Object.keys(productList).forEach((el) => {
        let obj = { id: el, children: productList[el].children }
        tempSelected.push(obj);
      })
      setSelectedFilter(tempSelected);
    } else {
      setSelectedFilter([]);
    }
  }
  //#endregion

  // Function for selecting sub Options
  const updateFilters = (element, parent) => {
    let tempFilter = [...selectedFilters];
    let flag = false;
    tempFilter.forEach((el, index) => {
      if (el.id === parent) {
        flag = true;
        if (el.children.includes(element)) {
          let newFilter = el.children.filter((prod) => prod !== element)
          tempFilter[index].children = newFilter;
          setSelectedFilter(tempFilter);
        } else {
          tempFilter[index].children.push(element);
          setSelectedFilter(tempFilter);
        }
      }
    })
    if (!flag) {
      let obj = { id: parent, children: [element] }
      tempFilter.push(obj);
      setSelectedFilter(tempFilter);
    }
  }

  useEffect(() => {
    if (selectedFilters) {
      let count = 0;
      selectedFilters.forEach((el) => {
        count += el.children.length;
      });
      setNoOfProd(count);
    }
  }, [selectedFilters])

  const closeDropdown = () => {
    document.getElementById("dropdown").classList.remove("on");
  }
  //#endregion
  const [includeCompleted, setIncludeCompleted] = useState(false)
  const onSelectCheckbox = () => {
    setIncludeCompleted(!includeCompleted)
  }
  const checkSelected = () => {
    return includeCompleted ? CHECK.SELECTED : CHECK.NOT_SELECTED
  }
  const onInputChange = (event) => {
    // const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    setFormControls({
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
    });
  };
  const getToolTipMessage = () => {
    return (<div>
      <p>
        <b>This filter contains all projects that Product Managers have created estimates for in PCDM.
           If you are not getting any results when searching for the P-Code you want to choose,
           please confirm that the Product Manager(s) have added this project to their Project Estimates page and that it is in Execution.</b>
      </p>
      <br/>
      <p>
        <b>By default, all projects that have been estimated will be included in this report.
           If you select any projects in this filter, then the report will only include data for the selected projects.</b>
      </p>
    </div>)
  }
  const projectCodesCheck = check({
    original: props.projectCodesUsed,
    path: "data",
    checkEmpty: true,
    defaultReturnValue: [],
  });
  return (
    <React.Fragment>
      <div>
        <Row className="forecast-scroll-margin">
          <Col sm={12} md={12} lg={12} xl={12}>
            <h5 className="forecast-due-dates pcdm-head">
              Last Publish Due Date:{" "}
              {props.forecastDueDates.lastpublishDuedate
                ? getUTCFormattedDate(
                    props.forecastDueDates.lastpublishDuedate,
                    "MM/DD/YYYY"
                  )
                : "--"}
            </h5>
            <h5 className="forecast-due-dates pcdm-head">
              Upcoming Publish Due Date:{" "}
              {props.forecastDueDates.nextPublishduedate
                ? getUTCFormattedDate(
                    props.forecastDueDates.nextPublishduedate,
                    "MM/DD/YYYY"
                  )
                : "--"}
            </h5>
          </Col>

          {/* <p className="forecast-due-dates forecast-due-dates2">
      <span >  </span>
      </p> */}
        </Row>
      </div>
      <div className="forecast-report-container">
        <Row>
          <Col sm={4} md={4} lg={4} xl={4}>
            <form className="pcdm-form">
              <div className="pcdm-form__form-group">
                <div className="pcdm-form__form-group-field">
                  <Datepicker
                    name="startMonth"
                    label={"Start Month"}
                    formObj={formControls.startMonth}
                    isRequired={formControls.startMonth.required}
                    onChange={manageMonthSelection}
                    placeholderText={"Ex: Jan, 2020"}
                    dateFormat={MONTH_YEAR_FORMAT}
                    showMonthYearPicker={true}
                  />
                </div>
                <div className="pcdm-form__form-group-field">
                  <Datepicker
                    name="endMonth"
                    label={"End Month"}
                    formObj={formControls.endMonth}
                    isRequired={formControls.endMonth.required}
                    onChange={manageMonthSelection}
                    dateFormat={MONTH_YEAR_FORMAT}
                    placeholderText={"Ex: Apr, 2021"}
                    showMonthYearPicker={true}
                  />
                </div>
                <div className="pcdm-form__form-group-field">
                  <label className="required text-cap">Selected Products</label>
                  <CustomCheckBox
                    title={"Products"}
                    list={productList}
                    key={"portfolioId"}
                    value={"children"}
                    componentName={"forecast-report"}
                    valuesSelected={noOfProd}
                    checkAllSelected={checkAllSelected}
                    selectedFilters={selectedFilters}
                    updateFilters={updateFilters}
                    selectOrDeselectAll={selectOrDeselectAll}
                    setSelectedFilter={setSelectedFilter}
                  />
                  <div class="error-message-container">
                    <div class="error-message">
                      {formControls.selectedProducts.errorMsg}
                    </div>
                  </div>
                </div>
                <div className="pcdm-form__form-group-field">
                  <CustomSelect
                    name="selectedProjects"
                    label={"Selected Projects"}
                    placeholder="Select Projects"
                    formObj={formControls.selectedProjects}
                    config={{
                      options: projectCodesCheck.value,
                      value: "projectName",
                      id: "pcode",
                    }}
                    isMulti={true}
                    formatOptionLabel={(prd) => `${prd.label} (${prd.value})`}
                    isRequired={formControls.selectedProjects.required}
                    onChange={(e) =>
                      onInputChange({
                        target: { name: e.name, value: e.value },
                      })
                    }
                    hasToolTip = {true}
                    toolTipMessage = {getToolTipMessage()}
                    toolTipTitle = {""}
                  />
                </div>
              </div>
            </form>
            <CustomCheckBox2
              list={[{ key: 1, value: "Include Completed Projects" }]}
              key={"key"}
              value={"value"}
              onCheckboxClick={(filter) => onSelectCheckbox()}
              isSelected={checkSelected}
            />
            <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
              <CustomButton
                variant={BUTTON_VARIANTS.BLUE_GOLD}
                size="md"
                onClick={onSubmit}
                disable={!formControls.edited}
                loading={progress}
                fluid={true}
              >
                {/* {progress == 0 || progress == 100 ? "Download Forecasts Report" : progress } */}
                Download Forecasts Report
              </CustomButton>
            </div>
          </Col>
          <Col sm={2} md={2} lg={2} xl={2}>
            <LinkExtended onClick={() => populateDateRange("THIS_MONTH")}>
              This Month
            </LinkExtended>
            <LinkExtended onClick={() => populateDateRange("NEXT_2_MONTHS")}>
              Next 3 Months
            </LinkExtended>
            <LinkExtended onClick={() => populateDateRange("NEXT_12_MONTHS")}>
              Next 12 Months
            </LinkExtended>
          </Col>
          <Col sm={5} md={5} lg={5} xl={5}>
            <div className="forecast-report-description">
              This report will pull all project forecasts entered for the
              selected products over the selected time period.
            </div>
          </Col>
        </Row>
      </div>
    </React.Fragment>
  );
}


export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner,
  forecastDueDates: state.ProductsReducer.forecastDueDates.data,
  projectCodesUsed: state.PCDMAdminReducer.projectCodesUsed,
});

export const mapDispatchToProps = (dispatch) => ({
  getForecastDueDtes : () => dispatch(getForecastDueDatesThunk()),
  getUsedProjectCodes : () => dispatch(getUsedProjectCodesThunk()),
})

export default connect(mapStateToProps, mapDispatchToProps)(ForecastReport);
