import React, { Component } from "react";
import "./productSelection.scss";
import "../../../utilities/pcdm_form.scss";
import {
  setProductsByOwnerThunk,
  setProductLinesThunk,
} from "../../store/products.reducer";
import { changeTab, discardDisplayCommonError } from "../../store/common.reducer";
import { connect } from "react-redux";
import DataHandler from "../../components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../constants/service.constant";
import { PRODUCT_ALL } from "../../constants/access.constants";
import SelectDropdown from "../../components/forms/select/select";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../components/forms/Button/button";
import { ERROR_MSG, TOOL_TIP_MESSAGE } from "../../constants/message.contants";
import { PCDM_TABS } from "../../constants/common.constants";
import { check } from "../../services/validation";
import {
  getAccess,
  getFormattedUserId,
} from "../../../../../../services/auth.services";
import { getPCodesThunk } from "../../store/projects.reducer";
import { PRODUCT_ACTIONS } from "../../constants/action.constants";
import LinkExtended from "../../../../../shared/Link/linkExtended";
import CustomSelect from "../../components/forms/SelectDropdown/selectDropdown";
import ToolTip from "../../components/ToolTip/ToolTip";
import { PCDM_ROUTES } from "../../../../../app/Route/constants/pcdmRoutes.constants";
import { getPcdmAccess } from "../../store/admin.reducer";
import { formatLanId } from "../../services/lanId.service";
import { getScrumMasterThunk } from "../../store/teamCalculations.reducer"
import { ErrorMessageModal } from "../../components/MessageModal/errorMessageModal";
import sortBy from "../../../../../../services/helper.service";
export class ProductSelection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formMode: PRODUCT_ACTIONS.PRODUCT_VIEW,
      formControls: {
        selectedProduct: {
          value: null,
          error: false,
          errorMsg: "",
          required: true,
        },
        selectedProductLine: {
          value: null,
          error: false,
          errorMsg: "",
          required: true,
        },
      },
      dropDownTitle: "Select Product Code",
      delegateAccess: {
        delegateLanId: null,
        productCode: null,
        writeAccess: false,
      },
    };
  }

  componentDidMount = async () => {
    document.title = "Rover PCDM - Product Selection";
    sessionStorage.clear();
    sessionStorage.setItem("token",localStorage.getItem("token"))
    const { loggedInUser, userParams, setPcdmAccess } = this.props;
    let lanId = loggedInUser.isAuthenticated
      ? formatLanId(userParams)
      : "";
    await this.props.setProductsByOwner(lanId);
    await this.props.setProductLines();
    this.props.scrumMasterList();
    this.props.getPCodes();
    this.props.changePCDMTab(PCDM_TABS.TEAM_COMPOSITION);
  };
  onInputChange = (event) => {
    const { formControls, formMode } = this.state;
    const { loggedInUser, userParams } = this.props;
    let lanId = loggedInUser.isAuthenticated
      ? formatLanId(userParams)
      : "";
    const name = event.target.name;
    const value = event.target.value;
    let selectedProductDetails = this.props.products.data.productsResponses.find(
      (pd) => pd.productCode == value
    );
    this.setState({
      formControls: {
        ...formControls,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
      delegateAccess: {
        delegateLanId: lanId,
        productCode:
          formMode === PRODUCT_ACTIONS.PRODUCT_VIEW
            ? selectedProductDetails.productCode
            : "",
        writeAccess:
          formMode === PRODUCT_ACTIONS.PRODUCT_VIEW
            ? selectedProductDetails.writeAccess
            : false,
      },
    });
  };

  onProductSubmit = (e) => {
    const { formControls, formMode } = this.state;
    e.preventDefault();
    if (formMode === PRODUCT_ACTIONS.PRODUCT_VIEW) {
      if (formControls.selectedProduct.value === "") {
        this.setState({
          formControls: {
            ...formControls,
            selectedProduct: {
              ...formControls.selectedProduct,
              error: true,
              errorMsg: ERROR_MSG.REQUIRED_FIELD,
            },
          },
        });
      } else {
        localStorage.setItem("productCode", formControls.selectedProduct.value);
        this.props.setPcdmAccess(this.state.delegateAccess);
        this.props.history.push(
          PCDM_ROUTES.getProdutRoute(formControls.selectedProduct.value)
        );
      }
    } else if (formMode === PRODUCT_ACTIONS.PRODUCT_LINE_VIEW) {
      if (formControls.selectedProductLine.value === "") {
        this.setState({
          formControls: {
            ...formControls,
            selectedProductLine: {
              ...formControls.selectedProductLine,
              error: true,
              errorMsg: ERROR_MSG.REQUIRED_FIELD,
            },
          },
        });
      } else {
        this.props.history.push(
          PCDM_ROUTES.getProdutLineRoute(formControls.selectedProductLine.value)
        );
      }
    }
  };
  onFormViewChange = (formMode) => {
    if(formMode === PRODUCT_ACTIONS.PRODUCT_LINE_VIEW){
      document.title = "Rover PCDM - Product Line View"
    }else{
      document.title = "Rover PCDM - Product Selection"
    }
    this.setState({ formMode: formMode });
  };
  formatGroupLabel = (data) => {
    return <span className="custom-label"> {data.label} </span>;
  };
  discardNotification = () => {
    this.props.discardDisplayPrompt()
  }
  render() {
    const { formControls, formMode } = this.state;
    const { products, productLines, accessParams, userParams } = this.props;
    const ACC = getAccess(accessParams, userParams);
    // added
    const ACCESS = this.props.iiqRole;
    const productCheck = check({
      original: products,
      path: "data.productsResponses",
      checkEmpty: true,
      defaultReturnValue: [],
    });
    const productLinesCheck = check({
      original: productLines,
      path: "data",
      checkEmpty: true,
      defaultReturnValue: [],
    });
    const activeProductLineList = productLinesCheck.value.filter(
      (opt) => opt.allProductLines === true      
    );
    const productsList = productCheck.value.filter(
      (opt) => opt.active === true      
    );
    const manageProdList = productsList.filter(
      (opt) => {
        if(opt.testProduct && opt.writeAccess){
          return true
        }else if(!opt.testProduct && opt.writeAccess){
          return true
        }else{
          return false
        } 
      }      
    );
    const manageOptions = manageProdList.map((opt) => ({
      label: opt.name,
      value: opt.productCode,
    }));
    const viewProdList = productsList.filter(
      (opt) => opt.writeAccess !== true && opt.testProduct !== true
    );
    const viewOptions = viewProdList.map((opt) => ({
      label: opt.name,
      value: opt.productCode,
    }));
    const followProdList = productsList.filter(
      (opt) => opt.follow === true && opt.testProduct !== true
    )
    const followOptions = followProdList.map((opt)=>({
      label: opt.name,
      value: opt.productCode,
    }))
    const otherProdList = productsList.filter(
      (opt) => opt.follow !== true && opt.testProduct !== true
    )
    const otherProductsOptions = otherProdList.map((opt)=>({
      label: opt.name,
      value: opt.productCode,
    }))
    const options1 = [
      {
        label: "Manage",
        options: manageOptions,
      },
      {
        label: "View",
        options: viewOptions,
      },
    ];
    const options2 = [
      {
        label: "Following",
        options: followOptions,
      },
      {
        label: "Other Products",
        options: otherProductsOptions,
      },
    ];
    const productOptions = ACCESS.RESOURCE_MANAGER && followOptions.length > 0 ? options2 : options1;
    return (
      <div className="container-fluid product-container">
        <div className="pcdm-view">
          <div className="pcdm-view__wrapper">
            <DataHandler
              loader={{
                state:
                  products.status === DATA_STATUS.LOADING ||
                  productLines.status === DATA_STATUS.LOADING,
                show: true,
              }}
              showData={productCheck.flag}
              emptyDataMessage="No Products found"
            >
              <div className="product-form-link-container">
                {formMode === PRODUCT_ACTIONS.PRODUCT_VIEW ? (
                  [
                    <LinkExtended
                      className="product-form-link"
                      onClick={() =>
                        this.onFormViewChange(PRODUCT_ACTIONS.PRODUCT_LINE_VIEW)
                      }
                    >
                      Product Line View
                    </LinkExtended>,
                    <ToolTip
                      toolTipTitle={"Product Line"}
                      toolTipMessage={TOOL_TIP_MESSAGE.PRODUCT_LINE_VIEW}
                    ></ToolTip>,
                  ]
                ) : (
                  <LinkExtended
                    className="product-form-link"
                    onClick={() =>
                      this.onFormViewChange(PRODUCT_ACTIONS.PRODUCT_VIEW)
                    }
                  >
                    Product View
                  </LinkExtended>
                )}
              </div>
              <div className="pcdm-view__card">
                <div className="pcdm-view__head">
                  <h4 className="pcdm-view__title">
                    {formMode === PRODUCT_ACTIONS.PRODUCT_VIEW
                      ? "Product"
                      : "Product Line"}
                  </h4>
                </div>
                <div className="pcdm-view__body">
                  <div className="pcdm-tag">
                    
                    {
                    /* removed
                    /* <b>
                      {ACC.PCDM_ADMIN
                        ? "ADMIN"
                        : ACC.PCDM_VIEW
                        ? "VIEWER"
                        : "Product Manager"}
                    </b> */}
                    {/* {productCheck.flag && ACC.PCDM_EDIT && !ACC.PCDM_ADMIN
                      ? manageProdList.length
                        ? manageProdList[0].manager
                        : viewProdList.length
                        ? viewProdList[0].manager
                        : ""
                      : ""} */}
                                          {/* added */}

                                          <b> {ACCESS.TITLE}</b>

                  </div>
                  <form className="pcdm-form">
                    <div className="pcdm-form__form-group">
                      <div className="pcdm-form__form-group-field">
                        {formMode === PRODUCT_ACTIONS.PRODUCT_VIEW ? (
                          <CustomSelect
                            name="selectedProduct"
                            formatGroupLabel={(prd) =>
                              this.formatGroupLabel(prd)
                            }
                            isOptionsMultiList={true}
                            label={""}
                            placeholder="Select a product"
                            formObj={formControls.selectedProduct}
                            config={{
                              options: productOptions,
                              //   id: "productCode",
                              //   value: "name",
                            }}
                            formatOptionLabel={(prd) =>
                              `${prd.value} - ${prd.label}`
                            }
                            isRequired={formControls.selectedProduct.required}
                            onChange={(e) =>
                              this.onInputChange({
                                target: { name: e.name, value: e.value },
                              })
                            }
                          />
                        ) : (
                          <CustomSelect
                            name="selectedProductLine"
                            label={""}
                            placeholder="Select a product line"
                            formObj={formControls.selectedProductLine}
                            config={{
                              options: [...sortBy(activeProductLineList, "portfolioName")],
                              value: "portfolioName",
                              id: "portfolioId",
                            }}
                            formatOptionLabel={(prd) => `${prd.label}`}
                            isRequired={
                              formControls.selectedProductLine.required
                            }
                            onChange={(e) =>
                              this.onInputChange({
                                target: { name: e.name, value: e.value },
                              })
                            }
                          />
                        )}
                      </div>
                    </div>
                    <div
                      className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}
                    >
                      <CustomButton
                        variant={BUTTON_VARIANTS.PRIMARY}
                        size="md"
                        onClick={this.onProductSubmit}
                      >
                        Proceed
                      </CustomButton>
                    </div>
                  </form>
                </div>
              </div>
            </DataHandler>
            <ErrorMessageModal  errorNotification = {this.props.errorNotification}
                 discardNotification = {this.discardNotification} />
          </div>
        </div>
      </div>
    );
  }
}

export const mapStateToProps = (state) => ({
  products: state.ProductsReducer.productsByOwner,
  productLines: state.ProductsReducer.productLines,
  loggedInUser: state.AuthReducer,
  activeTab: state.CommonPCDMReducer.selectedTab,
  accessParams: state.ProductsReducer.productsByOwner.data,
  userParams: state.AuthReducer.user,
  iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
  errorNotification: state.CommonPCDMReducer.errorNotification,
});

export const mapDispatchToProps = (dispatch) => ({
  setProductsByOwner: (id) => dispatch(setProductsByOwnerThunk(id)),
  setProductLines: () => dispatch(setProductLinesThunk()),
  changePCDMTab: (tab) => dispatch(changeTab(tab)),
  setPcdmAccess: (delegateAccess) => dispatch(getPcdmAccess(delegateAccess)),
  scrumMasterList: () => dispatch(getScrumMasterThunk()),
  getPCodes: () => dispatch(getPCodesThunk()),
  discardDisplayPrompt: () => dispatch(discardDisplayCommonError()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProductSelection);

