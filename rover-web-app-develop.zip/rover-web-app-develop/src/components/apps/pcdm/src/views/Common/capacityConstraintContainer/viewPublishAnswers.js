import React, { useState, useEffect } from "react";
import {
  TOOL_TIP_MESSAGE,
  PROJECT_MESSAGES,
  CONSTRAINT_CAPACITY_VALUE,
  CONSTRAINT_CAPACITY_ICON_COLOR,
  CONSTRAINT_CAPACITY_STATUS
} from "../../../constants/message.contants";
import { getFormattedDate,  } from "../../../services/form.service";
import moment from "moment";
import "../../../templates/projects.template.scss";
import {ArrowLeft, ArrowRight} from 'react-feather';
import LinkExtended from "../../../../../../shared/Link/linkExtended";

export default  function PublishViewersHistory(props){
  const [showPublishDates, setShowPublishDates] = useState()
  const [answersData, setAnswersData] = useState([])
  const [QAData, setQAData] = useState({})
  const {publishAnswers} = props;
    const getDCValueStatus = (maxcapacityConstraint)=>{
      if (maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.LOW) {
        return "LOW";
      } else if (
        maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.LOW &&
        maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.MED_LOW
      ) {
        return "MED_LOW";
      } else if (
        maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.MED_LOW &&
        maxcapacityConstraint < CONSTRAINT_CAPACITY_VALUE.HIGH
      ) {
        return "MEDIUM";
      } else if (maxcapacityConstraint >= CONSTRAINT_CAPACITY_VALUE.HIGH) {
        return "HIGH";
      }
    }
    const getStatusIdentifier = (status) => {
      if (status === 1 ) return "LOW";
      if (status === 2 ) return "MED_LOW";
      if (status === 3 ) return "MEDIUM";
      if (status === 4 ) return "HIGH";
    };
    const setViewersData = (data) =>{
      setShowPublishDates(false)
      setQAData(data)
    }
    const goBack = () => {
      setShowPublishDates(true);
    }
    useEffect(() => {
      setShowPublishDates(true)
      let answers = publishAnswers
      for(let i=0; i<answers.length; i++){
        for(let j=0; j<answers.length; j++){
          if(new Date(answers[i].createdDate) > new Date(answers[j].createdDate) ){
            let temp = answers[i];
            answers[i]=answers[j];
            answers[j]=temp;
          }
        }
      }
      setAnswersData(answers)
    },[])

    return(
      <React.Fragment>
        {showPublishDates ? 
        <div className="view-publish-answers">
        <tbody>
          {answersData.map((data, key) => {
            let publishData = {...data};
            // let status = getDCValueStatus(data.maxcapacityConstraint)
            let status = getStatusIdentifier(data.overallConstraint)
            publishData.status = status;
            return (
              <tr key={key} >
                <td>
                  {data.createdDate ? getFormattedDate(data.createdDate, "MM/DD/YYYY") : "--"}
                </td>
                <td className=" capacity-constraint-tooltip-container" >
                  {/* <span className="capacity-constraint-status">{data.maxcapacityConstraint}%</span> */}
                </td>
                <td className=" capacity-constraint-tooltip-container" >
                  <span className="capacity-constraint-avatar" style={{
                    backgroundColor: CONSTRAINT_CAPACITY_ICON_COLOR[status],
                  }} />
                </td>
                {data.question1 && data.question2 ? <td  >
                  <LinkExtended onClick = {()=>{setViewersData(publishData)}} >
                    <ArrowRight size={15} strokeWidth={5}  />
                  </LinkExtended>
                </td> : null}
              </tr>
            )
          })}
        </tbody>
        </div> 

        : <> 
        <div className='publishQA1' >
          <LinkExtended onClick={() => { goBack() }} >
              <ArrowLeft size={15} strokeWidth={5} />
            </LinkExtended>
            <div className='paddingClass'>
            {QAData.createdDate ? getFormattedDate(QAData.createdDate, "MM/DD/YYYY") : "--"}
            </div>
        </div>
            
            <div className="publishQA2 capacity-constraint-tooltip-container" >
              {/* <div className="capacity-constraint-status">{QAData.maxcapacityConstraint}%</div> */}
              <div className="capacity-constraint-avatar" style={{
                backgroundColor: CONSTRAINT_CAPACITY_ICON_COLOR[QAData.status],
              }} />
            </div>

              <div className="PublishAnswers">
                <p><b>1. Please detail any mitigation plans to address upcoming capacity constraints here:</b></p>
                <p>{QAData.q2Plan}</p>
              </div>
              <div className="PublishAnswers">
                <p><b>2. Please identify any other factor that may impact your current capacity constraint status here:</b></p>
                <p> {QAData.question3} </p>
              </div>

        </> }
      </React.Fragment>
    )
  }