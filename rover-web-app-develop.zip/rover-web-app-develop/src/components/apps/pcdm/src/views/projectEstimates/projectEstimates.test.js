import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import mockAxios from "axios";
import { products } from "../../../test_fixtures/product.mock";
import { ADMIN_PERMISSIONS } from "../../constants/access.constants";
import { ProjectEstimates } from "./projectEstimates";
import { projectsEstimatesData } from "../../../test_fixtures/projectsEstimatesData.mock";
import { PROJECT_ACTIONS, ACTIONS } from "../../constants/action.constants";

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());

const baseProps = {
  getProjects: jest.fn(),
  getPCodes: jest.fn(),
  getPortfolios: jest.fn(),
  getSummaryChart: jest.fn(),
  getForecasts: jest.fn(),
  showNotification: jest.fn(),
  getForecastsCapacity: jest.fn(),
  getProductManagerName: jest.fn(),
  refreshProduct: jest.fn(),
  projectsBudgetRefresh: jest.fn(),
  productDetails: { ...products[0] },
  productCode: products[0].productCode,
  estimateTypes: [
    { id: 1, desc: "Intake" },
    { id: 2, desc: "Execution" },
  ],
  projectType: [
    { id: 1, desc: "Transform" },
    { id: 2, desc: "Core Enablement (Grow)" },
    { id: 3, desc: "Planned Sustain" },
  ],
  estimationTimings: [
    { id: 1, desc: "During Intake (ROM)" },
    { id: 2, desc: "During PPP" },
  ],
  fundings: [
    { id: 1, desc: "Funded" },
    { id: 2, desc: "Unfunded" },
  ],
  investmentPortfolios: [
    { id: 1, desc: "TD&S" },
    { id: 2, desc: "Retail" },
    { id: 3, desc: "Provider" },
  ],
  deliveryPortfolios: [
    { id: 1, desc: "ADC" },
    { id: 2, desc: "Mandates" },
    { id: 3, desc: "Provider" },
  ],
  projects: projectsEstimatesData,
  completedProjectsList: projectsEstimatesData,
  loggedInUser: { user: { id: "ADMIN" }, permissions: [...ADMIN_PERMISSIONS] },
  pcdmAccess: { productCode: "", delegateLanId: "", writeAccess: false },
};

let component = null;
const getWrapper = () => shallow(<ProjectEstimates {...baseProps} />);
fdescribe("add PCDMContainer component", () => {
  beforeEach(() => {
    component = getWrapper();
  });
  describe("Component initate properly", () => {
    it("TeamComposition renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("On selecting project", () => {
    it("should update stae value ", async () => {
      const wrapper = getWrapper();
      let callback = () => {
        wrapper.setState({ openProjectForm: true, formMode: PROJECT_ACTIONS.EDIT_PROJECT });
      };
      wrapper.instance().onProjectSelection(41, callback);
      /*  let mockMethod=jest.fn();
            mockMethod.mockReturnValue('==============================Returned===========================');
            console.log(mockMethod()); */
      expect(wrapper.state().formMode).toEqual(PROJECT_ACTIONS.EDIT_PROJECT);
      expect(wrapper.state().selectedProjectId).toEqual(41);
    });
  });
  describe("On closing modal", () => {
    it("should update state openProjectForm value to false if status is SUCCESS", async () => {
      const wrapper = getWrapper();
      wrapper.instance().onModalClose(ACTIONS.SUCCESS, { message: "Project Added successfully " });
      expect(wrapper.state().openProjectForm).toEqual(false);
    });
    it("should update state openProjectForm value to true if status is ERROR", async () => {
      const wrapper = getWrapper();
      wrapper.instance().onModalClose(ACTIONS.ERROR, { message: "" });
      expect(wrapper.state().openProjectForm).toEqual(false);
    });
    it("should update state openProjectForm value to false if status is some other value", async () => {
      const wrapper = getWrapper();
      wrapper.instance().onModalClose(ACTIONS.CUSTOM, { message: "" });
    });
  });
  describe("OnAdd or edit project", () => {
    it("should update state formmode value to ADD_PROJECT if mode  isADD_PROJECT", async () => {
      const wrapper = getWrapper();
      wrapper.instance().onAddOrEditProjectClick(PROJECT_ACTIONS.ADD_PROJECT, {});
      expect(wrapper.state().openProjectForm).toEqual(true);
      expect(wrapper.state().formMode).toEqual(PROJECT_ACTIONS.ADD_PROJECT);
    });
    it("should update state formmode value to EDIT_PROJECT if mode  is EDIT_PROJECT", async () => {
      const wrapper = getWrapper();
      wrapper
        .instance()
        .onAddOrEditProjectClick(PROJECT_ACTIONS.EDIT_PROJECT, { projectEstimateId: 41 });
      expect(wrapper.state().openProjectForm).toEqual(true);
      expect(wrapper.state().formMode).toEqual(PROJECT_ACTIONS.EDIT_PROJECT);
    });
  });
  describe("On sending project Id to getSelectedProjectDetails ", () => {
    it("should return project details from the props if available", async () => {
      const wrapper = getWrapper();
      const actualValue = wrapper.instance().getSelectedProjectDetails(50);
      const expectedValue = projectsEstimatesData.data.projectEstimatesList.filter(
        (prj) => prj.projectEstimateId === 50
      );
      // expect(actualValue.projectEstimateId).toEqual(expectedValue.projectEstimateId);
    });
    it("should return undefined if project not available", async () => {
      const wrapper = getWrapper();
      const actualValue = wrapper.instance().getSelectedProjectDetails(999);
      expect(actualValue).toEqual(undefined);
    });
  });
  describe("On hitting  sendOptions ", () => {
    it("should return data required", async () => {
      const wrapper = getWrapper();
      const actualValue = wrapper.instance().sendOptions();
      const expectedValue = {
        estimateTypes: baseProps.estimateTypes,
        projectType: baseProps.projectType,
        estimationTimings: baseProps.estimationTimings,
        fundings: baseProps.fundings,
        investmentPortfolios: baseProps.investmentPortfolios,
        deliveryPortfolios: baseProps.deliveryPortfolios,
      };
      expect(actualValue).toEqual(expectedValue);
    });
  });
  describe("n hitting onHeaderChange", () => {
    it("should set state formmode and openProjectForm ", async () => {
      const wrapper = getWrapper();
      wrapper.instance().onHeaderChange(PROJECT_ACTIONS.EDIT_PROJECT);
      expect(wrapper.state().openProjectForm).toEqual(true);
      expect(wrapper.state().formMode).toEqual(PROJECT_ACTIONS.EDIT_PROJECT);
    });
  });
});
