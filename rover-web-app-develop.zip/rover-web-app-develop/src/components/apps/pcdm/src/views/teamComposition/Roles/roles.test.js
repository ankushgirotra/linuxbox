import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Roles } from "./roles";
import { teamCalculation } from "../../../../test_fixtures/teamCalculation.mock";
import { teams } from "../../../../test_fixtures/teams.mock";
import { ACTIONS, TEAM_ACTIONS } from "../../../constants/action.constants";
import { DEFAULT_MODAL_STATE } from "../../../components/modal/PCDMmodal";
import { Function } from "core-js";

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());
const baseProps = {
  setRoleOptions: jest.fn(),
  getTeams: jest.fn(),
  getProductCalc: jest.fn(),
  getProjects: jest.fn(),
  getSummaryChart: jest.fn(),
  getResourceForecast: jest.fn(),
  showNotification: jest.fn(),
  getTeamsRoles: jest.fn(),
  refreshProduct: jest.fn(),
  refreshProductMonthly: jest.fn(),
  roleCalculation: 100,
  team: teams[0],
  canEditRole: true,
};

let component = null;
const getWrapper = () => shallow(<Roles {...baseProps} />);

fdescribe("add Team Details", () => {
  beforeEach(() => {
    component = getWrapper();
  });
  describe("Component initate properly", () => {
    it("Roles renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("on closing modal", () => {
    it("Should changes state after error", () => {
      const wrapper = getWrapper();
      var data = { teamId: 53, message: "Some error Occurred" };
      var status = ACTIONS.ERROR;
      wrapper.instance().onModalClose(status, data);
    });
    it("Should  changing state for Action success ", () => {
      const wrapper = getWrapper();
      var data = { teamId: 53, message: "Role added to the team successfully" };
      var status = ACTIONS.SUCCESS;
      wrapper.instance().onModalClose(status, data);
      expect(wrapper.state().showRoleForm).toEqual(false);
    });
    it("Should changes stateModal visible to false , if entered other value", () => {
      const wrapper = getWrapper();
      var data = {};
      var status = ACTIONS.CUSTOM;
      wrapper.instance().onModalClose(status, data);
      expect(wrapper.state().showRoleForm).toEqual(false);
    });
  });
  describe("On clicking add or edit", () => {
    it("Should Change the stae on click add", () => {
      const wrapper = getWrapper();
      var data = {};
      var mode = TEAM_ACTIONS.ADD_ROLE;

      wrapper.instance().onAddOrEditRoleClick(mode, data);
      expect(wrapper.state().showRoleForm).toEqual(true);
      expect(wrapper.state().formMode).toEqual(mode);
      expect(wrapper.state().selectedRole).toEqual(data);
    });
    it("Should Change the stae on click Edit", () => {
      const wrapper = getWrapper();
      var data = teams[0].teamRole[0];
      var mode = TEAM_ACTIONS.EDIT_ROLE;

      wrapper.instance().onAddOrEditRoleClick(mode, data);
      expect(wrapper.state().showRoleForm).toEqual(true);
      expect(wrapper.state().formMode).toEqual(mode);
      expect(wrapper.state().selectedRole).toEqual(data);
    });
  });
});
