import React, { useState, useMemo, useEffect, useCallback } from "react";
import "./forecastTable.scss";
import { check } from "../../../services/validation";
import { connect } from "react-redux";
import {
  getForecastDollarThunk,
  GET_FORECAST_DOLLAR_SUCCESS,
  logForecastChange,
} from "../../../store/forecast.reducer";
import moment from "moment";
import { Row, Col, Container, Tab, Nav } from "react-bootstrap";
import List from "../../../components/List/forecastsList";
import RenderForecastTable from "./RenderForecastTable";
import { Search } from "react-feather";
import Divider from "@material-ui/core/Divider";

function ForecastsNewTable(props) {
  const {
    forecastsAggregate,
    forecastsIndividual,
    activeTab,
    forecastTableHistory,
    logChange,
    productCode,
    forecastDollar,
    updateForecastChangesStatus,
    hasEditAccess,
    isShowCompletedProjectChecked = "false",
    isAggregate = false,
    tableID = 'individual',
    startMonth,
    endMonth
  } = props;
  
  const [projectFundedList, setProjectFundedList] = useState([]);
  const [productCoreList, setProductCoreList] = useState([]);
  const [selectedForecastProjectFunded, setSelectedForecastProjectFunded] = useState();
  const [selectedForecastProductCore, setSelectedForecastProductCore] = useState();
  const [searchValueProjectFunded, setSearchValueProjectFunded] = useState("");
  const [searchValueProductCore, setSearchValueProductCore] = useState("");
  const [searchValue, setSearchValue] = useState("");
  const [finalProductCoreList, setFinalProductCoreList] = useState([]);
  const [finalProjectFundedList, setFinalProjectFundedList] = useState([]);
  const [forecastType, setForecastType] = useState("projectFunded");
  useEffect(()=>{
    const forecastsIndividualFiltered = check({
        path: "data.matchedProjects",
        original: forecastsIndividual,
        checkEmpty: true,
        defaultReturnValue: [],   
      });
      forecastsIndividualFiltered.value.sort(function (project1, project2) {
        return Number(project1.pcode.slice(1,)) - Number(project2.pcode.slice(1,))
      });
      const forecastsAggregateFiltered = check({
        path: "data.matchedProjects",
        original: forecastsAggregate,
        checkEmpty: true,
        defaultReturnValue: [],   
      });
      let productCoreForecasts = []
      let projectFundedForecasts = []
      forecastsAggregateFiltered.value.forEach((ele)=>{
        if(ele.projectType == "Project Funded"){
            ele = {...ele, projectName:"Project Funded - Aggregate", projectEstimateId:"pf"}
            projectFundedForecasts.push(ele)
        }
        else{
            ele = {...ele, projectName:"Product Core - Aggregate", projectEstimateId:"pc"}
            productCoreForecasts.push(ele)
        }
      }) 
      forecastsIndividualFiltered.value.forEach((ele)=>{
        if(ele.projectType == "Project Funded")
            projectFundedForecasts.push(ele)
        else
            productCoreForecasts.push(ele)
      }) 
      projectFundedForecasts.sort(function (project1, project2) {
        return Number(project1.pcode.slice(1,)) - Number(project2.pcode.slice(1,))
      });
      if(selectedForecastProjectFunded){
          const index = projectFundedForecasts.findIndex(el => el.projectEstimateId == selectedForecastProjectFunded.projectEstimateId)
          setSelectedForecastProjectFunded(projectFundedForecasts[index])
      }
      else{
        const index = projectFundedForecasts.findIndex(el => el.projectEstimateId == "pf")
        setSelectedForecastProjectFunded(projectFundedForecasts[index]);
      }
      if (selectedForecastProductCore) {
        const index = productCoreForecasts.findIndex(
          (el) => el.projectEstimateId == selectedForecastProductCore.projectEstimateId
        );
        setSelectedForecastProductCore(productCoreForecasts[index]);
      } else {
        const index = productCoreForecasts.findIndex(
          (el) => el.projectEstimateId == "pc"
        );
        setSelectedForecastProductCore(productCoreForecasts[index]);
      }
      setProjectFundedList(projectFundedForecasts);
      setProductCoreList(productCoreForecasts); 
      setFinalProductCoreList(productCoreForecasts);
      setFinalProjectFundedList(projectFundedForecasts);
  },[forecastsIndividual,forecastsAggregate])

  const onProductCoreSelect = (projectEstimateId) => {
      const selected = productCoreList.findIndex(el => el.projectEstimateId == projectEstimateId)
      setSelectedForecastProductCore(productCoreList[selected])
  }

  const onProjectFundedSelect = (projectEstimateId) => {
    const selected = projectFundedList.findIndex(el => el.projectEstimateId == projectEstimateId)
    setSelectedForecastProjectFunded(projectFundedList[selected])
  }
  
  const searchedList = (e,type) => {
    setSearchValue(e.target.value)
    if(searchValue == ""){
      setFinalProductCoreList(productCoreList);
      setFinalProjectFundedList(projectFundedList)
    }else{
      if(type == "productCore"){
        const productCore = productCoreList.filter(el => 
          el.projectName.toLowerCase().includes(searchValue.toLowerCase()) ||
          el.pcode.toLowerCase().includes(searchValue.toLowerCase()) )
        setFinalProductCoreList(productCore)
      }else{
        const projectFunded = projectFundedList.filter(el => 
          el.projectName.toLowerCase().includes(searchValue.toLowerCase()) ||
          el.pcode.toLowerCase().includes(searchValue.toLowerCase()) )
        setFinalProjectFundedList(projectFunded)
      }
    }
  }
  const getForecastsList = (type) => {
    return (
      <>
      <div className="search-bar-wrapper">
            <span className="search-icon">
                <Search size="15" strokeWidth={2} />
            </span>
            <input className="search-bar" type="text" placeholder="Search" value={searchValue} onChange = {(e)=>searchedList(e,type)} />
      </div>
      <List
        className={"forecast-lists"}
        listArray={type == "productCore" ? finalProductCoreList : finalProjectFundedList}
        title={() => {}}
        onClick={(t) =>
          type == "productCore"
            ? onProductCoreSelect(t.projectEstimateId)
            : onProjectFundedSelect(t.projectEstimateId)
        }
        selected={{
          teamId: type == "productCore" ?
           selectedForecastProductCore ? selectedForecastProductCore.projectEstimateId : null 
           :selectedForecastProjectFunded ? selectedForecastProjectFunded.projectEstimateId : null,
        }}
        id="projectEstimateId"
        displayKey="projectName"
      />
      </>
    );
  };

  // const [activeTab, setActiveTab] = useState("projectFunded")
  const onTabChange = (k) => {
    setForecastType(k)
  }

return (
  <React.Fragment>
    <Container fluid className="forecasts-table-v2">
      <Row>
        <Col sm={4} md={4} lg={4} xl={4} className="no-right-padding">
          <Tab.Container
            activeKey={forecastType}
            onSelect={(k) => {
              onTabChange(k);
            }}
            transition={false}
          >
            <Nav variant="pills">
              <Row className="forecasts-tabs-header">
                <div className="forecasts-tab">
                  <Nav.Item>
                    <Nav.Link eventKey="projectFunded">Project Funded</Nav.Link>
                  </Nav.Item>
                </div>
                <div className="forecasts-tab">
                  <Nav.Item>
                    <Nav.Link eventKey="productCore">Product Core</Nav.Link>
                  </Nav.Item>
                </div>
              </Row>
            </Nav>
            <Divider />
            <Row className="forecasts-tab-content-details-wrapper">
              <Tab.Content>
                <Tab.Pane eventKey="projectFunded">
                  {getForecastsList("projectFunded")}
                </Tab.Pane>
                <Tab.Pane eventKey="productCore">
                  {getForecastsList("productCore")}
                </Tab.Pane>
              </Tab.Content>
            </Row>
          </Tab.Container>
        </Col>
        <Col sm={8} md={8} lg={8} xl={8} className="no-left-padding">
          {forecastType == "projectFunded" && selectedForecastProjectFunded ? (
            <div id="projectFunded" className="forecast-table-class">
              <RenderForecastTable
                selectedForecast={selectedForecastProjectFunded}
                forecastsAggregate={forecastsAggregate}
                forecastsIndividual={forecastsIndividual}
                productCode={productCode}
                hasEditAccess={hasEditAccess}
                isShowCompletedProjectChecked={isShowCompletedProjectChecked}
              />
            </div>
          ) : null}
          {forecastType == "productCore" && selectedForecastProductCore ? (
            <div id="projectFunded" className="forecast-table-class">
              <RenderForecastTable
                selectedForecast={selectedForecastProductCore}
                forecastsAggregate={forecastsAggregate}
                forecastsIndividual={forecastsIndividual}
                productCode={productCode}
                hasEditAccess={hasEditAccess}
                isShowCompletedProjectChecked={isShowCompletedProjectChecked}
              />
            </div>
          ) : null}
        </Col>
      </Row>
    </Container>
  </React.Fragment>
);

}
export const mapStateToProps = (state) => ({
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
  forecastDollar: state.ForecastsReducer.forecastDollar,
  updateForecastChangesStatus: state.ForecastsReducer.updateForecastChangesStatus,
});
export const mapDispatchToProps = (dispatch) => ({
  getForecastDollar: (productCode, projectEstimateId, forecastPoints, month, callback) =>
    dispatch(
      getForecastDollarThunk(productCode, projectEstimateId, forecastPoints, month, callback)
    ),
  logChange: (change) => dispatch(logForecastChange(change)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ForecastsNewTable);

