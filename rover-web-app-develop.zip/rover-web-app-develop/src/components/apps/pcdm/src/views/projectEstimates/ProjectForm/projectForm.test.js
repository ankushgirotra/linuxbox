import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import mockAxios from "axios";
import { ProjectForm } from "./projectForm";
import { products } from "../../../../test_fixtures/product.mock";
import {
  projectFormCommons,
  defaultProjectFormState,
  editedProjectFormState,
} from "../../../../test_fixtures/projectFormCommonData.mock";
import { projectsEstimatesData } from "../../../../test_fixtures/projectsEstimatesData.mock";
import { PROJECT_ACTIONS } from "../../../constants/action.constants";
import { DEFAULT_MSG_MODAL_CONFIG } from "../../../components/MessageModal/messageModal";
import {
  FORM_CONTROL_DEFAULT,
  STORY_PTS_MIN,
  STORY_PTS_MAX,
  MONTH_DATE_YEAR_FORMAT,
  EST_TYPE_PCODE,
} from "../../../constants/form.constants";
import { getFormattedDate } from "../../../services/form.service";
import { modifyFormForPCode } from "../../../services/project.service";

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());
const baseProps = {
  saveProject: jest.fn(),
  editProject: jest.fn(),
  deleteProject: jest.fn(),
  completeProject: jest.fn(),
  getProjectDefaults: jest.fn(),
  getBaselineEstimate: jest.fn(),

  productDetails: { ...products[0] },
  manager: products[0].manager,
  lanID: "ADMIN",
  formVisible: true,
  header: "Add Project",
  selectedProject: projectsEstimatesData.data.projectEstimatesList[0],
  closeModal: jest.fn(),
  formMode: PROJECT_ACTIONS.ADD_PROJECT,
  productCode: products[0].productCode,

  saveProjectStatus: projectFormCommons.saveProjectStatus,
  editProjectStatus: projectFormCommons.editProjectStatus,
  deleteProjectStatus: projectFormCommons.deleteProjectStatus,
  completeProjectStatus: projectFormCommons.completeProjectStatus,
  projectDefaults: projectFormCommons.projectDefaults,
  pCodeOptions: projectFormCommons.pCodeOptions,
  usedPCodes: projectFormCommons.pCodeOptions,
  baseLineBudgetStatus: projectFormCommons.baseLineBudget,
  estimateTypes: projectFormCommons.estimateTypeOptions,
  fundings: projectFormCommons.fundingOptions,
  projectType: projectFormCommons.projectTypeOptions,
  investmentPortfolios: projectFormCommons.investmentPortfolioOptions,
  deliveryPortfolios: projectFormCommons.deliveryPortfolioOptions,
  baseLineBudget: 0,
};

const defaultState = defaultProjectFormState;
const stateWithValues = editedProjectFormState;

let component = null;
const getWrapper = () => shallow(<ProjectForm {...baseProps} />);
fdescribe("add PCDMContainer component", () => {
  beforeEach(() => {
    component = getWrapper();
  });
  describe("Component initate properly", () => {
    it("TeamComposition renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("On hitting populate form method", () => {
    it("should update state", () => {
      const wrapper = getWrapper();
      wrapper.instance().populateFileds(projectsEstimatesData.data.projectEstimatesList[0]);
      expect(wrapper.state().formControls.pCode.value).toEqual(
        projectsEstimatesData.data.projectEstimatesList[0].pcode
      );
    });
  });
  describe("On Changing input value", () => {
    it("update state based on input value ,here input value is Pcode", () => {
      const wrapper = getWrapper();
      let event = {
        target: {
          name: "pCode",
          value: "P000000012",
        },
      };
      wrapper.instance().onInputChange(event);
      expect(wrapper.state().formControls.pCode.value).toEqual("P000000012");
    });
    it("update state based on input value", () => {
      const wrapper = getWrapper();
      let event = {
        target: {
          name: "funding",
          value: "Funded",
        },
      };
      wrapper.instance().onInputChange(event);
      expect(wrapper.state().formControls.funding.value).toEqual("Funded");
    });
  });
  describe("On Changing estimateType value", () => {
    it("update state based on estimateType value ", () => {
      const wrapper = getWrapper();
      wrapper.instance().onEstimateTypeChange(EST_TYPE_PCODE);
      expect(wrapper.state().formControls.estimateType.value).toEqual(EST_TYPE_PCODE);
    });
  });
  describe("On Changing points value", () => {
    it("update state based on points value ", () => {
      const wrapper = getWrapper();
      const event = {
        value: "160",
        error: "",
      };
      wrapper.instance().onPointsChange(event);
      expect(wrapper.state().formControls.points.value).toEqual("160");
    });
  });
  describe("On Changing Start or end date value", () => {
    it("update state start date based on start date value ", () => {
      const wrapper = getWrapper();
      let startDate = new Date("Mon Aug 17 2020 00:00:00 GMT+0530");
      wrapper.instance().manageMonthSelection("plannedStart", startDate);
      expect(wrapper.state().formControls.plannedStart.value).toEqual(startDate);
    });
    it("update state end date based on end date value ", () => {
      const wrapper = getWrapper();
      let endDate = new Date("Mon Aug 17 2020 00:00:00 GMT+0530");
      wrapper.instance().manageMonthSelection("plannedEnd", endDate);
      expect(wrapper.state().formControls.plannedEnd.value).toEqual(endDate);
    });
  });
  describe("On delete click", () => {
    it("it shoudl update sate on valid request", () => {
      const wrapper = getWrapper();
      wrapper.setState({ ...stateWithValues });
      wrapper.instance().onDeleteClick();
      expect(wrapper.state().messageModalConfig.title).toEqual("Delete");
    });
    it("it shoudl update sate on valid request", () => {
      const wrapper = getWrapper();
      wrapper.setState({ ...defaultState });
      wrapper.instance().onDeleteClick();
      expect(wrapper.state().formControls.error).toEqual(true);
    });
  });
});
