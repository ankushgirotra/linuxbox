import React, { Component } from "react";
import moment from "moment";
import { connect } from "react-redux";
import { Container, Row, Col } from "react-bootstrap";
import { Edit3, Calendar, Copy, AlertCircle} from "react-feather";
import { getTeamsRolesThunk, getTeamsSprintVelocityThunk } from "../../../store/teamCalculations.reducer";
import { roundOff, stringToCurrency, getFormattedDate, formatNumberWithCommaSeprated } from "../../../services/form.service";
import { getTeamsEndDateTooltipMsg } from "../../../constants/tooltip.messages";
import { TOOL_TIP_MESSAGE } from "../../../constants/message.contants";
import ToolTip from "../../../components/ToolTip/ToolTip";
// import estimateHistory from "../../../../../../../shared/img/icon-img/history.PNG";
import copyIcon from "../../../../../../../assets/images/svg/copy.icon.svg";
import editPencilIcon from "../../../../../../../assets/images/svg/editPencil.icon.svg";
import estimateHistory from "../../../../../../../assets/images/svg/estimateHistory.icon.svg";
import { getSprintVelocityHistory } from "../../../templates/projects.template";
import Roles from "../Roles/roles";
import "./team.scss";

export class Team extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount = async () => {
    const productCode = localStorage.getItem("productCode")
    await this.props.getTeamsRoles(productCode);
    this.props.getTeamsSprintVelocity(productCode)
  };

  getEndDateTooltip = () => {
    return (
      <span className="teams-list-enddate-tooltip">
        <ToolTip
          toolTipMessage={getTeamsEndDateTooltipMsg()}
          toolTipTitle={""}
          content={() => (
            <span className="custom-tool-tip" title="Click to get info">
              <AlertCircle
                size="15"
                color="#d50000"
                strokeWidth={2.5}
              />
            </span>
          )}
          toolTipPlacement="auto" > </ToolTip>
      </span>
    )
  };

  checkTeamsEndDate = (endMonth) => {
    var endDate = moment(endMonth).utc().format();
    var currentDate = moment().utc().format();
    var futureDate = moment(currentDate).add(14 , "days");
    var diffInDates = moment(endDate).isAfter(futureDate);
    return !diffInDates; 
  };

  getFormattedEndDate = (endMonth) => {
    return this.checkTeamsEndDate(endMonth) ? <>
      {getFormattedDate(endMonth)} {this.getEndDateTooltip()}
    </> : getFormattedDate(endMonth);
  };

  getSprintVelocity = (sprintVelocity, teamId) => {
    const sprintVelocityHistory = this.props.teamsSprintVelocity.length ?
      this.props.teamsSprintVelocity.filter((team) => team.teamId === teamId) : [];
    const velocity = sprintVelocity + " points";
    return (
      <span>
        {velocity}
        {sprintVelocityHistory.length > 0 ? <ToolTip
          toolTipTitle={"Velocity History"}
          toolTipMessage={getSprintVelocityHistory(sprintVelocityHistory)}
          content={() => (
            <img src={estimateHistory} className="velocityHistory-icon" /> // className="velocityHistory-icon"
          )}
          toolTipPlacement="right"
        ></ToolTip> : null}
      </span>
    )
  };

  showCost = (costVal) => {
    const roundOffVal = roundOff(parseFloat(costVal), 2);
    return stringToCurrency(String(roundOffVal), "blur", 2);
  };

  checkTitleContent = (property) => {   
    return property && property.props && property.props.children ? property.props.children[0] : "";
  }

  showInfo = (key, value) => {
    return (
      <div className="teams_info-key_n_value">
        <p className={"teams_info-key"}>{key} </p>
        <p className={"teams_info-value"} title={value}> {value} </p>
      </div>
    )
  };

  showKeys = (keys) => {
    return (
      <ul>
        {keys.map((key,index) => <li>{key}</li> )}
      </ul>
    )
  };

  showValues = (values) => {
    return (
      <ul>
        {values.map((value, index) =>
          <li title={typeof value !== "string" ? this.checkTitleContent(value) : value}>
            {value ? value : <span> &#8211; </span>} </li>)}
      </ul>
    )
  };

  /*
  getRoleCalc = () => {
    const { teamCalculation } = this.props;
    if (
      teamCalculation &&
      teamCalculation.rolesCalculation &&
      teamCalculation.rolesCalculation.length
    ) {
      return teamCalculation.rolesCalculation;
    } else {
      return [];
    }
  }; */

  
  getScrumMaster = () => {  
    return (
      <span className="scrum_master_new-tooltip">Scrum Master NEW
        <ToolTip
          toolTipMessage={TOOL_TIP_MESSAGE.SCRUM_MASTER_NEW}
          toolTipTitle={""}
          content={() => (
            <span className="custom-tool-tip" title="Click to get info">
              <AlertCircle
                size="15"
                color="#d50000"
                strokeWidth={2.5}
              />
            </span>
          )}
          toolTipPlacement="right" ></ToolTip>
      </span>
    )
  };

  formatResourceName = (team) => {
    let resourceName = team.scrumMasterNewId === "000000" ? "N/A" : team.scrumMasterNew;
    return resourceName;
  };

  render() {

    const { selectedTeam, editTeam, copyTeam, extendTeam, haveEditTeamPermission,
      haveEditRolePermission, isRolledOff, isEligibleForExtend } = this.props;
    
    return (
      <div className="pcdm-team_composition">
        <Container>
          <Row >
            <Col sm={12} md={12} lg={12} xl={12}>
              <div className="team-title">
                <h3 className=""> {selectedTeam ? selectedTeam.name : ""}
                {haveEditTeamPermission ? (
                  <>
                    {isRolledOff() ? (
                      isEligibleForExtend() ? (
                        <span onClick={extendTeam} title={"Click to extend team's end date"} className="tc_cal-img">
                          <Calendar strokeWidth={2} stroke="#3b77fe" />
                        </span>
                      ) : null
                    ) : (
                        <span onClick={editTeam} title={"Click to edit/delete the team"}>
                          {/* <Edit3 size="20" strokeWidth={2} stroke="#3b77fe" /> */}
                          <img src={editPencilIcon} className="tc_copy-img" />
                        </span>
                    )}
                      <span onClick={copyTeam} title={"Click to copy the team"}>
                        {/* <Copy size="20" strokeWidth={2} stroke="#3b77fe" /> */}
                        <img src={copyIcon} className="tc_copy-img" />
                      </span>
                  </>
                ) : null}
                </h3>
              </div>
            </Col>

            <Col sm={12} md={12} lg={12} xl={12} className="pcdm-tc-team_info-container">
              <div className="pcdm-tc-team_info">
                <p className="teams_info-date"> {this.showInfo("Last Updated On", selectedTeam ?
                  getFormattedDate(selectedTeam.lastModifiedDate, "MM/DD/YYYY hh:mm A") : "")} </p>
                <p className="teams_info-hr_per_sprint"> {this.showInfo("Hours/Sprint", selectedTeam ?
                  formatNumberWithCommaSeprated(roundOff(parseFloat(selectedTeam.hoursPerSprint || 0), 1, true))
                  : roundOff(parseFloat(0), 1, true))} </p>
                <p className="teams_info-cost_per_sprint"> {this.showInfo("Cost/Sprint", selectedTeam ?
                  this.showCost(selectedTeam.costPerSprint) : this.showCost(0))} </p>
                <p className="teams_info-hr_per_pt"> {this.showInfo("Hours/Point", selectedTeam ?
                  formatNumberWithCommaSeprated(roundOff(parseFloat(selectedTeam.hoursPerPoint || 0), 1, true))
                  : roundOff(parseFloat(0), 1, true))} </p>
                <p className="teams_info-cost_per_pt"> {this.showInfo("Cost/Point", selectedTeam ?
                  this.showCost(selectedTeam.costPerPoint) : this.showCost(0))} </p>
              </div>
            </Col>

          </Row>

          {/* <div className="pcdm-tc-team_summary">
            <Row >
              <Col sm={4} md={4} lg={4} xl={4}>
                {this.showInfo("Methodology", selectedTeam ? selectedTeam.methodology : "")}
                {this.showInfo("Scrum Master", selectedTeam ? selectedTeam.scrumMaster : "-")}
                {this.showInfo(this.getScrumMaster(), selectedTeam ? selectedTeam.scrumMasterNew : "-")}
              </Col>
              <Col sm={4} md={4} lg={4} xl={4}>
                {this.showInfo("Sprint Velocity", selectedTeam ? this.getSprintVelocity(selectedTeam.sprintVelocity, selectedTeam.teamId) : "")}
                {this.showInfo("Sprint Length", selectedTeam ? selectedTeam.sprintLength : "")}
              </Col>
              <Col sm={4} md={4} lg={4} xl={4}>
                {this.showInfo("Team Start Date", selectedTeam ? getFormattedDate(selectedTeam.startMonth) : "")}
                {this.showInfo("Team End Date", selectedTeam ? isRolledOff() ?
                  getFormattedDate(selectedTeam.endMonth) : this.getFormattedEndDate(selectedTeam.endMonth) : "")}
              </Col>
            </Row>
          </div>             
          */}

          <div className="pcdm-tc-team_summary">
            <Row>
              <Col sm={4} md={4} lg={4} xl={4}>
                <div className="teams_info-key_n_value">
                  <div className="teams_info-key">{this.showKeys(["Methodology", "Scrum Master"])}</div>
                  <div className="teams_info-value">{this.showValues([selectedTeam ? selectedTeam.methodology : "",
                  selectedTeam && selectedTeam.scrumMasterNewId ? this.formatResourceName(selectedTeam) : "N/A"])}</div>
                </div>
              </Col>
              <Col sm={4} md={4} lg={4} xl={4}>
                <div className="teams_info-key_n_value">
                  <div className="teams_info-key">{this.showKeys(["Sprint Velocity", "Sprint Length"])}</div>
                  <div className="teams_info-value">{this.showValues([selectedTeam ? this.getSprintVelocity(selectedTeam.sprintVelocity, selectedTeam.teamId) : "",
                  selectedTeam ? selectedTeam.sprintLength : ""])}</div>
                </div>
              </Col>
              <Col sm={4} md={4} lg={4} xl={4}>
                <div className="teams_info-key_n_value">
                  <div className="teams_info-key">{this.showKeys(["Team Start Date", "Team End Date"])}</div>
                  <div className="teams_info-value">{this.showValues([selectedTeam ? getFormattedDate(selectedTeam.startMonth) : "",
                  selectedTeam ? isRolledOff() ?
                    getFormattedDate(selectedTeam.endMonth) : this.getFormattedEndDate(selectedTeam.endMonth) : ""])}</div>
                </div>
              </Col>
            </Row>
          </div>

          <Row classname="pcdm-tc-roles_table">
            <Col sm={12} md={12} lg={12} xl={12}>
              <Roles
                team={selectedTeam ? selectedTeam : {}}               
                canEditRole={!isRolledOff() && haveEditRolePermission}
                // roleCalculation={this.getRoleCalc()}
              />
            </Col>
          </Row>

        </Container>
      </div>
    );
  }
}
export const mapStateToProps = (state) => ({
  teamsSprintVelocity: state.TeamCalculationsReducer.teamsSprintVelocity.data,
});

export const mapDispatchToProps = (dispatch) => ({
  getTeamsRoles: (productCode) => dispatch(getTeamsRolesThunk(productCode)),
  getTeamsSprintVelocity: (productCode) => dispatch(getTeamsSprintVelocityThunk(productCode)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Team);