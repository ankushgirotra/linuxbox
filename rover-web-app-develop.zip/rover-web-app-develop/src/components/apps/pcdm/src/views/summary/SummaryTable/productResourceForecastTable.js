import React, { useMemo } from "react";
import DataGrid from "../../../components/DataGrid/dataGrid";
import "./productResourceForecast.scss";
import { FORM_DATE_FORMAT } from "../../../constants/form.constants";
import moment from "moment";
import RowColHeaderTable from "../../../components/Table/table";
import { getFormattedDate } from "../../../services/form.service";
import { DATA_STATUS } from "../../../constants/service.constant";
import DataHandler from "../../../components/DataHandler/dataHandler";
import ToolTip from "../../../components/ToolTip/ToolTip";

export function ProductResourceForecastTable({ resourceForecast: { data, status }, roles }) {

  const columns = useMemo(() => {
    return data.length
      ? data.reduce((acc, curr, index, arr) => {
        acc.push({
          head: getFormattedDate(curr.forecastDate, "MMM YYYY", FORM_DATE_FORMAT),
          accessor: curr.forecastDate,
        });
        return acc;
      }, [])
      : [];
  }, [data]);

  const rows = useMemo(() => {
    return data.length
      ? data.reduce(
        (acc, curr, index, arr) => {
          for (let i = 0; i < curr.summaryResourcesCountVo.length; i++) {
            let index = acc.findIndex(
              (el) => el.roleId === curr.summaryResourcesCountVo[i].roleId
            );
            if (index >= 0) {
              acc[index][curr.forecastDate] = curr.summaryResourcesCountVo[i].noOfResources;
            }

          }
          return acc;
        },
        roles.length
          ? [
            ...roles.map((role) => {
              return { ...role, head: role.roleName };
            }),
          ]
          : []
      )
      : [];
  }, [data]);
  
  return (
    <div className="resource-forecast-table-container">
      <h5 className="pcdm-head">
        Product Resource Forecast
        <ToolTip
          toolTipTitle={"Product Resource Forecast"}
          toolTipMessage={
            "This table shows the quantity of each role your product needs to support the composition of your teams."
          }
        ></ToolTip>
      </h5>
      <DataHandler
        loader={{
          state: status === DATA_STATUS.LOADING,
          show: false,
        }}
        showData={data.length && roles.length}
        emptyDataMessage="Add team details to view Resource forecast"
      >
        <RowColHeaderTable
          columns={[...columns]}
          colWidths={["190px", ...columns.map((head) => "100px")]}
          rows={[...rows]}
          className={"resource-forecast-table pcdm-scroll-vertical"}
          customRowColHead={"Role"}
          defaultValue={0}
          isStriped={false}
        />
      </DataHandler>
    </div>
  );
}
