import React, { useState, useRef } from "react";
import RoverDropzone from "../../../../../../shared/Dropzone/dropzone";
import "./PCDMReports.scss";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import { MONTH_YEAR_FORMAT, FORM_CONTROL_DEFAULT } from "../../../constants/form.constants";
import Datepicker from "../../../components/Datepicker/datepicker";
import moment from "moment";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import ToolTip from "../../../components/ToolTip/ToolTip";
import { connect } from "react-redux";
import { uploadActulasThunk, UPLOAD_ACTUALS_SUCCESS } from "../../../store/admin.reducer";
import { DATA_STATUS } from "../../../constants/service.constant";
import { ACTIONS } from "../../../constants/action.constants";
import { addNotification } from "../../../store/common.reducer";
import { check } from "../../../services/validation";

export function UploadActuals(props) {
  const dropzoneRef = useRef();
  const [files, setFiles] = useState([]);
  const [error, setError] = useState([]);
  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    actualsMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
  });

  const manageMonthSelection = (type, date) => {
    const { actualsMonth } = formControls;
    setFormControls({
      ...formControls,
      edited: true,
      actualsMonth: {
        ...actualsMonth,
        value: date,
        error: false,
        errorMsg: "",
      },
    });
    setError([]);
  };
  const resetForm = () => {
    setFormControls({
      edited: false,
      error: false,
      errorMessage: "",
      actualsMonth: {
        ...FORM_CONTROL_DEFAULT,
        required: true,
      },
    });
    dropzoneRef.current.removeAll();
  };
  const onSubmit = () => {
    const { actualsMonth } = formControls;
    if (actualsMonth.value) {
      if (files.length) {
        let month = moment(actualsMonth.value)
          .startOf("month")
          .hour(0)
          .minute(0)
          .second(0)
          .millisecond(0)
          .format("M");
        let year = moment(actualsMonth.value)
          .startOf("month")
          .hour(0)
          .minute(0)
          .second(0)
          .millisecond(0)
          .format("YYYY");
        let bodyFormData = new FormData();
        bodyFormData.append("file", files[0]);
        props.uploadActuals(month, year, bodyFormData, (status, response) => {
          if (status === UPLOAD_ACTUALS_SUCCESS) {
            resetForm();
            props.showNotification({
              title: "Success",
              variant: ACTIONS.SUCCESS,
              content: "Actuals uploaded successfully",
            });
          } else {
            const { flag, value } = check({
              path: "response.data",
              original: response,
              checkEmpty: true,
            });
            if (flag) setError(value);
            props.showNotification({
              title: "Error",
              variant: ACTIONS.ERROR,
              content: "Error in uploading Actuals",
            });
          }
        });
      }
    } else {
      setFormControls({
        ...formControls,
        actualsMonth: {
          ...formControls.actualsMonth,
          error: actualsMonth.value ? false : true,
          errorMsg: actualsMonth.value ? "" : "Please select a Month",
        },
      });
    }
  };
  const getTooltipContent = () => {
    return (
      <div className="file-format-conditions">
        <p>
          The .xlsx file you upload must have 7 columns in the following order with these headers:
        </p>
        <ol>
          <li>Product ID</li> <li>Product Name</li> <li>Pcode</li> <li>Project Name</li>
          <li>Period</li> <li>Cost</li> <li>Story Points</li>
        </ol>
      </div>
    );
  };
  return (
    <div className="actual-upload-container">
      <h5 className="pcdm-head center">
        Select an Actuals file
        <ToolTip
          toolTipMessage={getTooltipContent()}
          toolTipTitle={"Actuals File format"}
        ></ToolTip>
      </h5>
      <RoverDropzone
        ref={dropzoneRef}
        placeholder="(Only .xlsx file will be accepted)"
        config={{
          noClick: true,
          noKeyboard: true,
          maxFiles: 1,
          accept: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }}
        onDropFiles={(files) => {
          setFiles(files);
          setError([]);
        }}
      />
      <div className={`upload-actuals-form-container`}>
        <Datepicker
          containerClassName="upload-actuals-date-picker"
          name="actualsMonth"
          label={"Actuals Month:"}
          formObj={formControls.actualsMonth}
          isRequired={formControls.actualsMonth.required}
          onChange={manageMonthSelection}
          placeholderText={"Ex: Jan, 2020"}
          dateFormat={MONTH_YEAR_FORMAT}
          showMonthYearPicker={true}
        />
        <div className="upload-actuals-form-footer">
          <CustomButton
            variant={BUTTON_VARIANTS.PRIMARY}
            size="md"
            onClick={onSubmit}
            loading={props.actualsUploadStatus.status === DATA_STATUS.LOADING}
          >
            Upload Actuals
          </CustomButton>
        </div>
      </div>
      <div className="error-container-upload-actuals">
        {error.length ? (
          <ol>
            {error.map((err) => (
              <li>{err.message}</li>
            ))}
          </ol>
        ) : null}
      </div>
    </div>
  );
}
export const mapStateToProps = (state) => ({
  actualsUploadStatus: state.PCDMAdminReducer.actualsUploadStatus,
});

export const mapDispatchToProps = (dispatch) => ({
  uploadActuals: (month, year, formData, callback) =>
    dispatch(uploadActulasThunk(month, year, formData, callback)),
  showNotification: (notification) => dispatch(addNotification(notification)),
});
export default connect(mapStateToProps, mapDispatchToProps)(UploadActuals);
