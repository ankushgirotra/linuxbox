import React, { useState } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import "./forecastActions.scss";
import { Badge } from "react-bootstrap";
import { check } from "../../../services/validation";
import { clearForecastChange, getForecastsThunk } from "../../../store/forecast.reducer";
import { FormModal } from "../../../components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import { DATA_STATUS } from "../../../constants/service.constant";
import { AlertTriangle, PlusCircle } from "react-feather";
import { RoverNavigationExtended } from "../../../components/NavigationExtended/navigationExtended";

export function ForecastActions(props) {

  const [showModal, setShowModal] = useState(false);
  const [selectedTab, setSelectedTab] = useState(1);
  const { forecasts, hasEditAccess ,addMissingEst } = props;

  const missedEst = check({
    path: "data.missingEstimates",
    checkEmpty: true,
    defaultReturnValue: [],
    original: forecasts,
  });
  const missedAct = check({
    path: "data.missingActuals",
    checkEmpty: true,
    defaultReturnValue: [],
    original: forecasts,
  });
  const getContent = () => (
    <RoverNavigationExtended
      navList={[
        {
          navKey: 1,
          header: () => (
            <>
              Missing Estimates
              <Badge style={{ marginLeft: "3px" }} variant="danger">
                {missedEst.value.length}
              </Badge>
            </>
          ),
          content: () => getMissingDetails("ESTIMATE", missedEst.value),
        },
        {
          navKey: 2,
          header: () => (
            <>
              Missing Actuals
              <Badge style={{ marginLeft: "3px" }} variant="danger">
                {missedAct.value.length}
              </Badge>
            </>
          ),
          content: () => getMissingDetails("ACTUAL", missedAct.value),
        },
      ]}
      activeKey={selectedTab}
      onTabChange={(tab) => setSelectedTab(tab)}
    />
  );
  const getMissingDetails = (key, list) => (
    <div>
      {key === "ESTIMATE" ? (
        <>
          <p className="missing-projects-info">
            The Project Actuals from Spark indicate that your product worked on the following
            projects that are missing from your Project Estimates page.
          </p>
          <p className="missing-projects-info">
            Please review the list below and add these projects to your Project Estimates page.
          </p>
        </>
      ) : (
          <>
            <p className="missing-projects-info">
              The Project Actuals from Spark did not show that work was completed for the following
              projects that appeared on your Project Estimates page.
          </p>
            <p className="missing-projects-info">
              Please review the list below and determine why they were missing from your Project
              Actuals.
          </p>
          </>
        )}
      <ul className="missing-projects-list pcdm-scroll-vertical">
        {list.map((list) => {
          return (
            <li>
              <p className="add-icon" title={`Add Project`}>
                {key === "ESTIMATE" && hasEditAccess ? <PlusCircle size={18}
                  strokeWidth={3} onClick={() => addMissingEst(list)} /> : null}
              </p>
              <p className="pcode">{list.pcode}</p>
              <p className="project">{list.projectName}</p>
            </li>
          );
        })}
      </ul>
    </div>
  );

  const getFooter = () => null;
  return (
    <div className="forecast-actions">
      {missedEst.value.length || missedAct.value.length ? (
        <CustomButton
          onClick={() => setShowModal(!showModal)}
          title={"Click here to see missing projects"}
          className="forecast-link inline missing_proj_btn"
          variant={BUTTON_VARIANTS.WARNING}
        >
          <AlertTriangle size={11} strokeWidth={3} />
          <span>Missing Projects</span>
        </CustomButton>
      ) : null}
      {props.forecastTableHistory.length && hasEditAccess
        ? [
          <CustomButton
            key={1}
            onClick={props.updateForecastChanges}
            title={"Click to save forecast changes"}
            className="forecast-link inline"
            loading={props.updateForecastChangesStatus.status === DATA_STATUS.LOADING}
            disable={props.updateForecastChangesStatus.status === DATA_STATUS.LOADING}
          >
            <span>Save changes</span>
          </CustomButton>,
          <a className="forecast-clear" onClick={() => props.clearForecastChange()} key={2}>
            Clear changes
            </a>,
        ]
        : null}
      {showModal ? (
        <FormModal
          visible={showModal}
          closeModal={(status, data) => setShowModal(false)}
          header={"Missing Projects"}
          content={() => getContent()}
          footer={() => getFooter()}
          className="missing-project"
        />
      ) : null}
    </div>
  );
}

export const mapStateToProps = (state) => ({
  forecasts: state.ForecastsReducer.forecasts,
  activeTab: state.CommonPCDMReducer.selectedTab,
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
  updateForecastChangesStatus: state.ForecastsReducer.updateForecastChangesStatus,
});
export const mapDispatchToProps = (dispatch) => ({
  getForecasts: (productCode) => dispatch(getForecastsThunk(productCode)),
  clearForecastChange: () => dispatch(clearForecastChange()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ForecastActions));
