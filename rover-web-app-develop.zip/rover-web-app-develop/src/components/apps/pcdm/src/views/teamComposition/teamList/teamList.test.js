import React from "react";
import Enzyme, { shallow } from "enzyme";
import EnzymeAdapter from "enzyme-adapter-react-16";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import mockAxios from "axios";
import { teams } from "../../../../test_fixtures/teams.mock";
import TeamList from "./teamList.js";
import List from "../../../components/List/list";

Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => (store = mockStore());

const baseProps = {
  selectedTeamId: teams[0].teamId,
  addTeam: jest.fn(),
  activeTeams: teams,
  canEdit: true,
  rolledOffTeams: teams,
};

let component = null;
const getWrapper = () => shallow(<TeamList {...baseProps} />);
fdescribe("add PCDMContainer component", () => {
  beforeEach(() => {
    component = getWrapper();
  });
  describe("Component initate properly", () => {
    it("TeamComposition renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe("Child Component event", () => {
    it("TeamComposition renders in UI without crashing", async () => {
      const wrapper = getWrapper();
      wrapper.find(List).last().prop("title")();
    });
  });
});
