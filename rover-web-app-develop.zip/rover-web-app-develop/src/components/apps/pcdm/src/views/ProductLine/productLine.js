import React, { useEffect, useState, useMemo } from "react";
import "./productLine.scss";
import Info from "../../components/info/info";
import { useParams, useHistory } from "react-router";
import { Container, Row, Col } from "react-bootstrap";
import { getProductLineSummaryThunk, productLineSummaryReset, getProductLineSummaryConstraintsThunk } from "../../store/productLine.reducer";
import { setProductsByOwnerThunk, setProductLinesThunk } from "../../store/products.reducer";
import Switch from "../../components/forms/Switch/switch";
import { connect } from "react-redux";
import { getFormattedDate } from "../../services/form.service";
import { FORM_DATE_FORMAT, MONTH_YEAR_FORMAT, FORM_CONTROL_DEFAULT } from "../../constants/form.constants";
import DataHandler, { OverlayLoader } from "../../components/DataHandler/dataHandler";
import InitialEstimatesTable from "../summary/SummaryTable/initialEstimatesTable";
import { DATA_STATUS } from "../../constants/service.constant";
import moment from "moment";
import { RefreshCw } from "react-feather";
import PCDMComposedChart from "../../components/ComposedChart/composedChart";
import { filterList, FUNDED, EXTRA_CAPACITY, UNFUNDED, CAPACITY } from "../summary/summary";
import List from "../../components/List/list";
import { check } from "./../../services/validation";
import Datepicker from "../../components/Datepicker/datepicker";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../components/forms/Button/button";
import { PCDM_ROUTES } from "../../../../../app/Route/constants/pcdmRoutes.constants";
import CapacityTable from "./CapacityTable"

export function ProductLine(props) {
  const {
    chartData,
    pCodeList,
    getProductLineSummary,
    isDataLoading,
    productLines,
    setProductLines,
    getSummaryConstraints,
    capacityConstraintsList,
  } = props;
  const { productLine } = useParams();
  const { productLineName, setProductLineName } = useState("");
  const [isPcodeFilterAltered, setIsPcodeFilterAltered] = useState(false);
  const [currentFilter, setCurrentFilter] = useState(filterList[0]);
  const [actualChartData, setActualChartData] = useState([])
  const [chartDataInstance, setChartDataInstance] = useState()
  const [currentPcodesList, setCurrentPcodesList] = useState([])
  useEffect(()=>{
    const prdCodesList = pCodeList.filter((opt)=> opt.testProduct !== true)
    setCurrentPcodesList(prdCodesList)
  },[pCodeList])
  useEffect(() => {
    setChartDataInstance(chartData)
  }, [chartData])
  useEffect(() => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    let filteredArray = []
    let endDate = new Date(currentYear, 11, 31)
    if (currentMonth > 5) {
      let startDate = new Date(currentYear, 0, 1)
      filteredArray = chartData.filter((el) => new Date(el.month) >= startDate && new Date(el.month) <= endDate)
    } else {
      let startDate2 = new Date()
      startDate2.setMonth(currentMonth - 6)
      startDate2.setDate(1)
      filteredArray = chartData.filter((el) => new Date(el.month) >= startDate2 && new Date(el.month) <= endDate)
    }
    let data = chartData;
    let minStartDate;
    if (chartData.length) {
      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j < data.length; j++) {
          if (new Date(data[i].month) < new Date(data[j].month)) {
            let temp = data[i];
            data[i] = data[j];
            data[j] = temp;
          }
        }
      }
      minStartDate = new Date(data[0].month)
    }
    if (filteredArray.length) {
      let endMonthFirstDate = new Date(filteredArray[filteredArray.length - 1].month);
      let endMonthLastDate = new Date(moment(endMonthFirstDate).endOf("month"));
      let maxEndDate = new Date(data[data.length - 1].month)
      let maxEndLastDate = new Date(moment(maxEndDate).endOf("month"));
      setActualChartData(filteredArray)
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          value: new Date(filteredArray[0].month),
          min: minStartDate,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          disabled: false,
          value: endMonthLastDate,
          min: new Date(filteredArray[0].month),
          max: maxEndLastDate,
          error: false,
          // value: new Date(filteredArray[filteredArray.length - 1].month),
          // max: new Date(data[data.length - 1].month),        
        },
      })
    }

  }, [chartData])
  const chartTableLow = useMemo(() => {
    return actualChartData.length && actualChartData.map((el) => {
      const newEl = {
        capacity: el.capacity,
        extraCapacity: el.extraCapacity,
        month: el.month,
        productCore: el.productCore,
        projectFunded: el.projectFunded,
        unfunded: el.unfunded,
      }
      return newEl;
    })
  }
    , [actualChartData]);
  const chartTableHigh = useMemo(() => {
    return actualChartData.length && actualChartData.map((el) => {
      const newEl = {
        capacity: el.capacity,
        extraCapacity: el.maxRangeExtraCapacity,
        month: el.month,
        productCore: el.maxRangeProductCore,
        projectFunded: el.maxRangeProjectFunded,
        unfunded: el.maxRangeUnfunded,
      }
      return newEl;
    })
  }
    , [actualChartData]);
  const [formControls, setFormControls] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    storyPointMode: {
      ...FORM_CONTROL_DEFAULT,
      value: 2,
      required: false,
    },
  });
  const onStoryPointModeChange = (value) => {
    setFormControls({
      ...formControls,
      edited: true,
      storyPointMode: {
        ...formControls.storyPointMode,
        value: value,
      },
    });
  }
  const [chartDataCalc, setChartData] = useState(chartTableLow ? chartTableLow : []);
  useEffect(() => {
    if (formControls.storyPointMode.value === 1) {
      setChartData(chartTableLow)
    } else {
      setChartData(chartTableHigh);
    }
  }, [formControls.storyPointMode.value, chartTableLow, chartTableHigh])
  const [chartConfig, setChartConfig] = useState({
    loading: false,
    xAxisKey: "month",
    barConfig: {
      required: true,
      stack: [...FUNDED, ...UNFUNDED, ...EXTRA_CAPACITY],
      barSize: 30,
    },
    lineConfig: [{ ...CAPACITY }],
  });
  const [brushIndex, setBrushIndex] = useState({
    startIndex: 0,
    endIndex: 0,
  });
  const [selectedPcodes, setSelectedPcodes] = useState([]);

  if (!selectedPcodes.length && pCodeList.length && !isPcodeFilterAltered) {
    setSelectedPcodes(pCodeList.map((item, index) => ({ id: item.productCode, name: item.name })));
  }
  useEffect(() => {
    if (productLine){
      getProductLineSummary(
        productLine,
        selectedPcodes.map((pcode) => pcode.id)
      );
    getSummaryConstraints(productLine);
    }
    setProductLines();
  }, []);

  useEffect(() => {
    if (selectedPcodes.length && isPcodeFilterAltered)
      getProductLineSummary(
        productLine,
        selectedPcodes.map((pcode) => pcode.id)
      );
  }, [selectedPcodes]);

  const defaultPosition = useMemo(() => {
    if (
      actualChartData.length
      // (brushIndex.endIndex > chartData.length - 1 || brushIndex.endIndex === 0)
    ) {
      let start = actualChartData.findIndex((el) => el.month === moment().format("MMM YYYY")),
        end = 0;
      /* If there is current month and 3 months from current month is exist in chart period 
      then set 3 months from current month as end index */
      if (start < 0) {
        start = 0;
      }
      if (start + 3 <= actualChartData.length - 1) {
        end = start + 3;
      } else {
        end = actualChartData.length - 1;
      }
      if (start != -1 && start - 3 > 0) {
        start = start - 3;
      } else {
        start = 0;
      }
      setBrushIndex({
        startIndex: start,
        endIndex: end,
      });
    }
  }, [actualChartData]);

  const customToolTip = (payload) => {
    let list =
      currentFilter.id == 1
        ? ["capacity", "projectFunded", "productCore", "unfunded", "extraCapacity"]
        : currentFilter.id == 2
          ? ["capacity", "projectFunded", "productCore", "extraCapacity"]
          : ["unfunded"];
    let forecastTooltip = list.map((el, index) => {
      let obj = payload.filter((item) => item.dataKey === el)[0];
      return (
        <div className="custom-tooltip" key={index}>
          <span style={{ color: `${obj.color}` }}>{obj.name.toLowerCase()}</span>
          <span>-</span>
          <span>{obj.value.toLocaleString()}</span>
        </div>
      );
    });
    return forecastTooltip;
  };
  const onFilterChange = (item) => {
    let isFunded = item.id === 2;
    let isAll = item.id === 1;
    setChartConfig({
      ...chartConfig,
      barConfig: {
        ...chartConfig.barConfig,
        stack: isAll
          ? [...FUNDED, ...UNFUNDED, ...EXTRA_CAPACITY]
          : isFunded
            ? [...FUNDED, ...EXTRA_CAPACITY]
            : [...UNFUNDED],
      },
      lineConfig: isFunded || isAll ? [{ ...CAPACITY }] : [],
    });
    setCurrentFilter(item);
  };
  const onPcodeFilterChange = (item) => {
    setIsPcodeFilterAltered(true);
    let checkExist = selectedPcodes.findIndex((el) => el.id === item.id);
    let temp = selectedPcodes.slice();
    if (checkExist >= 0) {
      temp.splice(checkExist, 1);
      setSelectedPcodes(temp);
      // if (temp.length === 1 && checkExist === 0) {
      //   setSelectedPcodes(pCodeList.map((item, index) => ({ id: index, name: item })));
      // } else {
      //   temp.splice(checkExist, 1);
      //   setSelectedPcodes(temp);
      // }
    } else {
      temp.push(item);
      setSelectedPcodes(temp);
    }
  };
  const getProductLineName = () => {
    const productLinesCheck = check({
      original: productLines,
      path: "data",
      checkEmpty: true,
      defaultReturnValue: [],
    });

    var portfolio = productLinesCheck.value.filter(
      (opt) => opt.portfolioId == (productLine) && opt.testProduct !== true
    );
    return portfolio.length ? portfolio[0].portfolioName : "";
  };
  const [formControlsDate, setFormControlsDate] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    startMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    endMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
  });
  const manageMonthSelection = (type, date) => {
    const { endMonth } = formControlsDate;
    let valueInMoment = moment(date, FORM_DATE_FORMAT);
    let validatedEndMonth = endMonth.value;

    if (type === "startMonth") {

      if (endMonth.value && valueInMoment.isAfter(moment(endMonth.value, FORM_DATE_FORMAT))) {
        validatedEndMonth = "";
      }
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          value: date,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          disabled: false,
          value: validatedEndMonth,
          min: date,
          error: false,
        },
      });
    } else if (type === "endMonth") {
      let lastDate = new Date(moment(date).endOf("month"));
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          value: date ? lastDate : null,
          error: false,
        },
      });
    }
  };
  const onSubmit = () => {
    const filteredArray = chartDataInstance.length ? chartDataInstance.filter((el) =>
      new Date(el.month) >= new Date(formControlsDate.startMonth.value) &&
      new Date(el.month) <= new Date(formControlsDate.endMonth.value)) : []
    setActualChartData(filteredArray);
  }

  const chartHeader = () => {
    return <div className="chart-header"> <p>PRODUCTS</p></div>
  };

  const getTimeRangeHeader = () => {
    return (
      <>
        <p className="withAddButton"> Time range </p>
        <CustomButton
          onClick={() => { onSubmit() }}
          className="time_range-btn"
        >
          <RefreshCw size={13} strokeWidth={3} />
          <span>Refresh</span>
        </CustomButton>
      </>
    )
  };

  const history = useHistory();

  const onExitIconClick = () => {
    props.resetProductLineStore();
    history.push(PCDM_ROUTES.ROUTE);
  };

  const getClassName = () => {
    if (selectedPcodes && selectedPcodes.length && chartDataCalc && chartDataCalc.length) {
      return "product-line-chart-container_v2";
    }
    else {
      return "product-line-chart-container";
    }
  };

  return (
    <div className="product-line-container">
      <Container fluid>
        <Row>
          <Col sm={12} md={12} lg={12} xl={12}>
            <div className="product-line-info">
              <span className="productLine_key">Product Line:</span>
              <span className="productLine_value">&nbsp;{getProductLineName()}</span>
              <CustomButton
                onClick={onExitIconClick}
                title={"Switch Product"}
                className="switch-product-link"
                borderless={true}
                size="sm"
                variant={BUTTON_VARIANTS.ICON}
              >
                <span className="lnr lnr-exit"></span>
              </CustomButton>
            </div>
          </Col>
        </Row>
        <div style={{ position: "relative", minHeight: "300px" }}>
          <OverlayLoader loading={isDataLoading === DATA_STATUS.LOADING ||
             capacityConstraintsList.status == DATA_STATUS.LOADING } />
          <DataHandler
            showData={chartDataCalc.length || isDataLoading === DATA_STATUS.INITIAL || pCodeList.length}
            emptyDataMessage="Add Teams and Projects to view Capacity & Demand Estimates"
          >
            <Row className="product-line-filter_Graph_N_Table-Container">
              <Col sm={3} md={3} lg={3} xl={3} className="product-line_filter-container">
                <div className="sticky-top fixedit">
                  <div className="product-line--chart-filter-container">
                    <div className="list-select-container product_line-time-range" >
                    <div className="teams-head pcdm-time_range-header"> {getTimeRangeHeader()} </div>
                    <div className="time-range-product_line-dates">
                      <form className="pcdm-form">
                        <div className="pcdm-form__form-group">
                          <div className="pcdm-form__form-group-field">
                            <Datepicker
                              name="startMonth"
                              label={"Start Month"}
                              formObj={formControlsDate.startMonth}
                              isRequired={formControlsDate.startMonth.required}
                              onChange={manageMonthSelection}
                              placeholderText={"Ex: Jan, 2020"}
                              dateFormat={MONTH_YEAR_FORMAT}
                              showMonthYearPicker={true}
                              customInput={true}
                            />
                          </div>
                          <div className="pcdm-form__form-group-field">
                            <Datepicker
                              name="endMonth"
                              label={"End Month"}
                              formObj={formControlsDate.endMonth}
                              isRequired={formControlsDate.endMonth.required}
                              onChange={manageMonthSelection}
                              dateFormat={MONTH_YEAR_FORMAT}
                              placeholderText={"Ex: Apr, 2021"}
                              showMonthYearPicker={true}
                              customInput={true}
                            />
                          </div>
                          {/* <div className="float-right" >
                            <CustomButton
                              variant={BUTTON_VARIANTS.PRIMARY}
                              size="md"
                              onClick={() => {
                                onSubmit();
                              }}
                              fluid={true}
                            >
                              Refresh
                          </CustomButton>
                          </div> */}
                        </div>
                      </form>

                    </div>
                  </div>
                    {/* <List
                      className={"chart-type-filter-list"}
                      list={[...filterList]}
                      title={() => chartHeader()}
                      onChange={onFilterChange}
                      selected={currentFilter}
                      id="id"
                      value="name"
                      groupName="chart-type-filter-list"
                      hideRadioButton={true}
                    /> */}
                    <List
                      className={"product-filter-list"}
                      list={currentPcodesList.map((item, index) => ({
                        id: item.productCode,
                        name: item.name,
                      }))}
                      title={() => chartHeader()}
                      onClick={onPcodeFilterChange}
                      onChange={onPcodeFilterChange}
                      selected={selectedPcodes}
                      id="id"
                      value="name"
                      groupName="product-filter-list"
                      showCheckbox={true}
                      hideRadioButton={true}
                    />
                  </div>
                </div>
              </Col>

              <Col sm={9} md={9} lg={9} xl={9} className="pcdm-product-line-graph_N_table">
                <Row>
                  <Col sm={12} md={12} lg={12} xl={12}>
                    <div className={getClassName()}>
                      <h4 className="pcdm-head center">
                        <span>Capacity & Demand Estimates</span>
                        {isDataLoading === DATA_STATUS.LOADING ? null : (
                          <span
                            title="click to refresh Capacity & Demand Estimates"
                            className="summary-refresh"
                            onClick={() =>
                              getProductLineSummary(
                                productLine,
                                selectedPcodes.map((pcode) => pcode.id)
                              )
                            }
                          >
                            <RefreshCw size={13} strokeWidth={3} />
                          </span>
                        )}
                      </h4>
                      <DataHandler showData={selectedPcodes.length} emptyDataMessage="No Products">
                        <PCDMComposedChart
                          chartLoading={false}
                          {...chartConfig}
                          points={chartDataCalc}
                          brushConfig={{
                            dataKey: "month",
                            startIndex: brushIndex.startIndex,
                            endIndex: brushIndex.endIndex,
                            onChange: (points) =>
                              setBrushIndex({
                                startIndex: points.startIndex,
                                endIndex: points.endIndex,
                              }),
                          }}
                          customToolTip={customToolTip}
                        />
                      </DataHandler>
                    </div>
                  </Col>
                </Row>

                {chartDataCalc.length && selectedPcodes.length ? (
                  <Row className="product-line--demand-capacity-table">
                    <Col sm={12} md={12} lg={12} xl={12}>
                      <div className="product-line-switch-option">
                        <Switch
                          name={"storyPointMode"}
                          config={{
                            options: [
                              { id: 1, value: "Use low-end Intake estimates" },
                              { id: 2, value: "Use high-end Intake estimates" },
                            ],
                            id: "id",
                            value: "value",
                          }}
                          className="ts-mode-slider"
                          formObj={formControls.storyPointMode}
                          onChange={onStoryPointModeChange}
                        />
                      </div>
                      <InitialEstimatesTable
                        initialEstimates={chartDataCalc.slice(
                          brushIndex.startIndex,
                          brushIndex.endIndex + 1
                        )}
                      />
                      <CapacityTable capacityConstraintsList = {capacityConstraintsList.data}
                       currentPcodesList = {currentPcodesList} />
                    </Col>
                  </Row>
                ) : null}
              </Col>
            </Row>

          </DataHandler>
        </div>
      </Container>
    </div>
  );
}

const mapStateToProps = (state) => {
  const chartData = [...(state.ProductLinesReducer.productLineSummary.data.summaryReportVo || [])];
  let props = {
    chartData: [
      ...chartData.map((el) => {
        let temp = {
          ...el,
          month: getFormattedDate(el.month, "MMM YYYY", FORM_DATE_FORMAT),
        };
        return temp;
      }),
    ],
    pCodeList: state.ProductLinesReducer.productLineSummary.data.productLineProductResponse || [],
    isDataLoading: state.ProductLinesReducer.productLineSummary.status,
    productLines: state.ProductsReducer.productLines,
    capacityConstraintsList: state.ProductLinesReducer.productLineSummaryConstraints,
  };
  return props;
};

const mapDispatchToProps = (dispatch) => ({
  getProductLineSummary: (productLine, pCodes) =>
    dispatch(getProductLineSummaryThunk(productLine, pCodes)),
  setProductLines: () => dispatch(setProductLinesThunk()),
  resetProductLineStore: () => dispatch(productLineSummaryReset()),
  getSummaryConstraints: (productLineId) => dispatch(getProductLineSummaryConstraintsThunk(productLineId))
});
export default connect(mapStateToProps, mapDispatchToProps)(ProductLine);
