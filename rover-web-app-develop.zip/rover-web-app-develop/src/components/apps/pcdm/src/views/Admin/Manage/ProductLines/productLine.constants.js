export const DUPLICATE_RECORD = 'No Product Line duplicate names are allowed.';
export const PROD_LINE_NAME_REQ = 'Product Line Name is required.';
