import React, { useState } from "react";
import {
  MONTH_DATE_YEAR_FORMAT,
  TEAM_END_DATE_MAX,
  TEAM_END_DATE_MIN,
  DB_DATE_FORMAT,
} from "../../../constants/form.constants";
import moment from "moment";
import Datepicker from "../../../components/Datepicker/datepicker";
import { DATA_STATUS } from "../../../constants/service.constant";
import ErrorMsg from "../../../components/forms/errorMsg/errorMsg";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import { connect } from "react-redux";
import { editTeamThunk } from "../../../store/teams.reducer";
import { TEAM_MESSAGES, ERROR_MSG } from "../../../constants/message.contants";
import { FormModal } from "../../../components/FormModal/formModal";
import "./extendTeamForm.scss";
import { TEAM_ACTIONS } from "../../../constants/action.constants";

function ExtendTeamForm({
  extendTeam,
  productCode,
  teamDetails,
  closeModal,
  formVisible,
  header,
  editTeamStatus,
  teamsRoles
}) {
  const [formControls, setFormControls] = useState({
    error: false,
    errorMessage: "",
    errorDetail: "",
    endMonth: {
      value: moment(teamDetails.endMonth).toDate(),
      error: false,
      errorMsg: "",
      min: TEAM_END_DATE_MIN,
      max: null,
      disabled: true,
    },
    extendedEndDate: {
      value: null,
      error: false,
      errorMsg: "",
      min: moment(teamDetails.endMonth).add(1, "day").toDate(),
      max: null,
      disabled: false,
    },
  });

  const manageMonthSelection = (type, date) => {
    setFormControls({
      ...formControls,
      error: false,
      extendedEndDate: {
        ...formControls.extendedEndDate,
        value: date,
      },
    });
  };
  const reqPayload = () => {
    const payload = {
      name: teamDetails.name,
      methodology: teamDetails.methodology,
      sprintLength: teamDetails.sprintLength,
      sprintVelocity: teamDetails.sprintVelocity,
      scrumMaster: teamDetails.scrumMaster,
      startMonth: teamDetails.startMonth,
      scrumMasterNew: teamDetails.scrumMasterNew,
      scrumMasterNewId: teamDetails.scrumMasterNewId,
      endMonth: moment(formControls.extendedEndDate.value)
        .hour(23)
        .minute(59)
        .second(59)
        .millisecond(999)
        .format(DB_DATE_FORMAT),
      active: teamDetails.active,
    };
    return payload;
  };
  const handleResponse = (responseType, responseData) => {
    const roles = teamsRoles && teamsRoles.length ? teamsRoles.filter(role => role.roleId === teamDetails.teamId) : []
    if (responseType === DATA_STATUS.SUCCESS)
      closeModal(DATA_STATUS.SUCCESS, {
        teamId: teamDetails.teamId,
        message: TEAM_MESSAGES.EXTEND_TEAM_SUCCESS,
        actionType : TEAM_ACTIONS.EDIT_TEAM,
        endMonthFlag: true,
        startMonthFlag: false,
      },  false, roles );
    else {
      closeModal(DATA_STATUS.SUCCESS, {
        teamId: teamDetails.teamId,
        message: TEAM_MESSAGES.EXTEND_TEAM_SUCCESS,
        actionType : TEAM_ACTIONS.EDIT_TEAM,
        endMonthFlag: true,
        startMonthFlag: false,
      },  false, roles );
    }
  };
  const onSubmit = () => {
    if (formControls.extendedEndDate.value === "" || formControls.extendedEndDate.value === null) {
      setFormControls({
        ...formControls,
        errror: true,
        extendedEndDate: {
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      });
    } else {
      let payload = reqPayload();
      console.log(payload)
      extendTeam(payload, productCode, teamDetails.teamId, handleResponse);
    }
  };
  const getExtendForm = () => (
    <form className="pcdm-form">
      <div className="pcdm-form__form-group">
        <div className="pcdm-form__form-group-field">
          <Datepicker
            name="endMonth"
            label={"Current End Date"}
            formObj={formControls.endMonth}
            isRequired={true}
            disabled={true}
            dateFormat={MONTH_DATE_YEAR_FORMAT}
          />
        </div>
        <div className="pcdm-form__form-group-field">
          <Datepicker
            name="extendedEndDate"
            label={"Extended End Date"}
            formObj={formControls.extendedEndDate}
            isRequired={true}
            onChange={manageMonthSelection}
            dateFormat={MONTH_DATE_YEAR_FORMAT}
          />
        </div>
        {formControls.error ? (
          <ErrorMsg message={formControls.errorMessage} errorDetail={formControls.errorDetail} />
        ) : null}
      </div>
    </form>
  );
  const getFooter = () => (
    <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
      <CustomButton variant={BUTTON_VARIANTS.PRIMARY} size="md" type={"submit"} onClick={onSubmit}>
        Extend
      </CustomButton>
      <CustomButton
        disable={false}
        loading={false}
        variant={BUTTON_VARIANTS.LIGHT}
        onClick={closeModal}
        size="md"
        type={"button"}
      >
        Cancel
      </CustomButton>
    </div>
  );
  return (
    <FormModal
      isLoading={editTeamStatus.status === DATA_STATUS.LOADING}
      visible={formVisible}
      closeModal={closeModal}
      header={header}
      content={getExtendForm()}
      footer={getFooter()}
      className="extend-team-form"
    />
  );
}
export const mapStateToProps = (state) => ({
  editTeamStatus: state.TeamsReducer.editTeamStatus,
  teamsRoles: state.TeamCalculationsReducer.teamsRoles.data,
});
export const mapDispatchToProps = (dispatch) => ({
  extendTeam: (payload, productCode, teamId, callback) =>
    dispatch(editTeamThunk(payload, productCode, teamId, callback)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ExtendTeamForm);
