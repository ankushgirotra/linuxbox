import React, { Component, useState, useEffect } from "react";
import { FormModal } from "../../../../components/FormModal/formModal";
import TextField from "../../../../components/forms/textField/textField";
import CustomButton, { BUTTON_VARIANTS } from "../../../../components/forms/Button/button";
import { connect } from "react-redux";
import { FORM_CONTROL_DEFAULT  } from "../../../../constants/form.constants";
import { validateDueDateForm } from "../../../../services/Admin/admin.product.service";
import ErrorMsg from "../../../../components/forms/errorMsg/errorMsg";
import { modifyPublishDueDateThunk } from "../../../../store/admin.reducer";

export function DueDateFormModal(props){

    const { dueDate, formOpen, closePopupModel ,savePublishDueDate } = props;

    const [formControls, setFormControls] = useState({
        edited: false,
        error: false,
        errorMessage: "",
        dueDate: {
          ...FORM_CONTROL_DEFAULT,
          required: true,
          value: props.dueDate,
        },
      });

    useEffect(() => {
        setFormControls({
            ...formControls,
            edited: false,
            error: false,
            errorMessage: "",
            dueDate: {
                ...formControls.dueDate,
                value: props.dueDate,
                error: false,
            }
        })
    },[formOpen ,dueDate])

    const onInputChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setFormControls({
            ...formControls,
            edited: true,
            error: false,
            [name]: {
                ...formControls[name],
                value: value,
                error: false,
            },
        });
    };

    const getProjectForm = () => {
        return (
            <fieldset>
                <form className="pcdm-form">
                    <div className="pcdm-form__form-group">
                        <div className="pcdm-form__form-group-field form-group-field--inline-4 ">
                            <TextField
                                name="dueDate"
                                name={"dueDate"}
                                label={"Publish Due Date"}
                                placeholder = {"# business day of the month for the publish due date"}
                                formObj={formControls.dueDate}
                                isRequired={formControls.dueDate.required}
                                type="text"
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.target.name, value: e.target.value },
                                    })
                                }
                            />
                        </div>
                    </div>
                    {formControls.errorMessage ? <p>{formControls.errorMessage}</p> : null}
                    {/* {formControls.error ? (
                        <ErrorMsg message={formControls.errorMessage} errorDetail={formControls.errorDetail} />
                    ) : null} */}
                </form>
            </fieldset>
        );
    };

    const onSubmit = (e) => {
        if (e) {
            e.preventDefault();
        }
        const validate = validateDueDateForm(formControls);
        if (validate.error) {
            setFormControls(validate)
        } else {
            let dateEntered = parseInt(formControls.dueDate.value)
            savePublishDueDate(dateEntered, closePopupModel);
        }
    };


    const getProjectFooter = () => {
        return (
          <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
            <CustomButton
              variant={BUTTON_VARIANTS.PRIMARY}
              size="md"
              onClick={(e) =>  onSubmit(e) }
            >
              Save
            </CustomButton>
          </div>
        );
    };
    return (
        <>
            <FormModal
                isLoading={false}
                visible={formOpen}
                closeModal={(status, data, keepModal) => closePopupModel(status, data, keepModal)}
                header={"EDIT PUBLISH DUE DATE"}
                content={() => getProjectForm()}
                footer={() => getProjectFooter()}
                className="project-form"
            />
        </>
    );
    
}
export const mapStateToProps = (state) => ({
    publishDueDate : state.PCDMAdminReducer.getPublishDueDate,
    modifiedPublishDueDate : state.PCDMAdminReducer.modifyPublishDueDate,
});

export const mapDispatchToProps = (dispatch) => ({
    savePublishDueDate: (date ,callback) => dispatch(modifyPublishDueDateThunk(date ,callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(DueDateFormModal);