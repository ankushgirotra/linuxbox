import React, { useState } from "react";
import { connect } from "react-redux";
import { FormModal } from "../../../components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import TextArea from "../../../components/forms/TextArea/textArea";
import { PUBLISH_REPORT } from "../../../constants/access.constants";
import {
  CONSTRAINT_CAPACITY_ICON_COLOR,
  CONSTRAINT_CAPACITY_STATUS,
  ERROR_MSG,
} from "../../../constants/message.contants";
import { DATA_STATUS } from "../../../constants/service.constant";
import {
  publishReportThunk,
  PUBLISH_REPORT_SUCCESS,
  getSummaryChartThunk,
  getPublishAnswersThunk,
} from "../../../store/summary.reducer";
import "./CapacityConstraintStatusContainer.scss";
import { Upload } from "react-feather";


export function PublishReport(props) {
  const { dcStatus, loggedInUser, publish, publishReport, getSummaryChart, getPublishAnswers } = props;
  const { permissions, ROVER_IIQ_ROLES } = loggedInUser;
  const [showModal, setShowModal] = useState(false);
  const [formControls, setFormControl] = useState({
    error: false,
    question1: {
      value: "",
      required: true,
      error: false,
      errorMsg: "",
    },
    question2: {
      value: "",
      required: true,
      error: false,
      errorMsg: "",
    },
  });
  const onChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setFormControl({
      ...formControls,
      error: false,
      [name]: {
        ...formControls[name],
        error: false,
        value: value,
      },
    });
  };

  const validatePublishForm = () => {
    let formState = {
      ...formControls,
      error: false,
      errorMessage: "",
    };
    for (const [key, valueObj] of Object.entries(formControls)) {
      if (
        valueObj.required &&
        (valueObj.value === null ||
          valueObj.value === undefined ||
          (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
      ) {
        formState = {
          ...formState,
          error: true,
          [key]: {
            ...formState[key],
            error: true,
            errorMsg: ERROR_MSG.REQUIRED_FIELD,
          },
        };
      }
    }
    return formState;
  };
  const getStatusIdentifier = () => {
    if (dcStatus.status === CONSTRAINT_CAPACITY_STATUS.LOW) return 1;
    if (dcStatus.status === CONSTRAINT_CAPACITY_STATUS.MED_LOW) return 2;
    if (dcStatus.status === CONSTRAINT_CAPACITY_STATUS.MEDIUM) return 3;
    if (dcStatus.status === CONSTRAINT_CAPACITY_STATUS.HIGH) return 4;
  };
  const closeModal = () => {
    setFormControl({
      error: false,
      question1: {
        value: "",
        required: true,
        error: false,
        errorMsg: "",
      },
      question2: {
        value: "",
        required: true,
        error: false,
        errorMsg: "",
      },
    });
    setShowModal(false);
  };
  const preparePublish = () => {
    let payload = {
      summaryConstraint: getStatusIdentifier(),
      overallConstraint: getStatusIdentifier(),
      question1: showModal,
      question2: showModal,
      q2Plan: formControls.question1.value,
      question3: formControls.question2.value,
    };

    publishReport(localStorage.getItem("productCode"), payload, (status, data) => {
      if (status === PUBLISH_REPORT_SUCCESS) {
        console.log("inside publish")
        closeModal();
        getSummaryChart(localStorage.getItem("productCode"));
        getPublishAnswers(localStorage.getItem("productCode"));
      }
    });
  };
  const decidePublishReport = () => {
    if (props.forecastTableHistory.length) {
      props.checkForecastChanges();
    } else if (
      dcStatus.status === CONSTRAINT_CAPACITY_STATUS.LOW ||
      dcStatus.status === CONSTRAINT_CAPACITY_STATUS.MED_LOW
    ) {
      preparePublish();
    } else if (
      (dcStatus.status === CONSTRAINT_CAPACITY_STATUS.HIGH ||
        dcStatus.status === CONSTRAINT_CAPACITY_STATUS.MEDIUM) &&
      !showModal
    ) {
      setShowModal(true);
    } else {
      let validation = validatePublishForm();
      if (validation.error) {
        setFormControl({ ...validation });
      } else {
        preparePublish();
      }
    }
  };

  const getContent = () => {
    return (
      <div className="publish-report-popup">
        <div className="capacity-constraint-status-container">
          <p>Capacity Constraint Status = </p>
          <div className="capacity-constraint-avatar" style={dcStatus.style} />
          <span className="capacity-constraint-status">{dcStatus.status}</span>
        </div>
        <form className="pcdm-form">
          <div className="pcdm-form__form-group">
            <div className="pcdm-form__form-group-field">
              <TextArea
                className="publish-questions"
                rows={3}
                cols={5}
                name="question1"
                label="1. Please detail any mitigation plans to address upcoming capacity constraints here:"
                onChange={onChange}
                placeholder="Type answer here..."
                isRequired={formControls.question1.required}
                formObj={formControls.question1}
              />
            </div>
          </div>
          <div className="pcdm-form__form-group">
            <div className="pcdm-form__form-group-field">
              <TextArea
                className="publish-questions"
                rows={3}
                cols={5}
                name="question2"
                label="2. Please identify any other factor that may impact your current capacity constraint status here:"
                onChange={onChange}
                placeholder="Type answer here..."
                isRequired={formControls.question2.required}
                formObj={formControls.question2}
              />
            </div>
          </div>
        </form>
      </div>
    );
  };
  const getFooter = (fluid, variant) =>
    // permissions.includes(PUBLISH_REPORT) ? (
      ROVER_IIQ_ROLES.PCDM.EDIT || ROVER_IIQ_ROLES.PCDM.DELEGATE || ROVER_IIQ_ROLES.PCDM.ADMIN ? (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          disable={publish.status === DATA_STATUS.LOADING}
          loading={publish.status === DATA_STATUS.LOADING}
          fluid={fluid}
          variant={variant}
          onClick={decidePublishReport}
          title={"Click to Publish the report"}
          className="publish-button"
        >
          <Upload size="13" strokeWidth={3} />
          <span>&nbsp;Publish Report</span>
        </CustomButton>
      </div>
    ) : null;
  return (
    <div className="publish-report-container">
      {getFooter(true, BUTTON_VARIANTS.LINK)}
      {showModal ? (
        <FormModal
          visible={showModal}
          closeModal={(status, data) => closeModal()}
          header={"Publish report"}
          content={getContent()}
          footer={getFooter(false, BUTTON_VARIANTS.SUCCESS)}
          className="missing-project"
        />
      ) : null}
    </div>
  );
}

export const mapStateToProps = (state) => ({
  summary: state.SummaryReducer.summaryData.data,
  loggedInUser: state.AuthReducer,
  publish: state.SummaryReducer.publish,
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
});
export const mapDispatchToProps = (dispatch) => ({
  publishReport: (productCode, payload, callback) =>
    dispatch(publishReportThunk(productCode, payload, callback)),
  getSummaryChart: (productCode) => dispatch(getSummaryChartThunk(productCode)),
  getPublishAnswers: (productCode)=> dispatch(getPublishAnswersThunk(productCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PublishReport);
