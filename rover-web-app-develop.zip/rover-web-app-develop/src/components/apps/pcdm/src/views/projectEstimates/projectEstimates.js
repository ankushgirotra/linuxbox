import React, { Component } from "react";
import Info from "../../components/info/info";
import "./projectEstimates.scss";
import { Container, Row, Col, Badge } from "react-bootstrap";
import { ProjectTable } from "./ProjectTable/projectTable";
import Checkbox from "../../components/forms/Checkbox/checkbox";
import { getSummaryChartThunk } from "../../store/summary.reducer";
import { PROJECT_ACTIONS, ACTIONS, PRODUCT_ACTIONS } from "../../constants/action.constants";
import ProjectForm from "./ProjectForm/projectForm";
import { connect } from "react-redux";
import {
  getProjectsThunk,
  getPCodesThunk,
  getPortfoliosThunk,
  getCompletedProjectsThunk,
} from "../../store/projects.reducer";
import moment from "moment";
import { PROJECT_EDIT } from "../../constants/access.constants";
import { withRouter } from "react-router";
import CustomButton from "../../components/forms/Button/button";
import ProjectComments from "./ProjectForm/ProjectComments/projectComments";
import ProjectFormHeader from "./ProjectForm/ProjectFormHeader/projectFormHeader";
import {
  getForecastsThunk,
  getForecastsAggregateThunk,
  getForecastsCapacityThunk,
} from "../../store/forecast.reducer";
import { refreshProductThunk, projectsBudgetRefreshThunk } from "../../store/teamCalculations.reducer";
import { addNotification } from "../../store/common.reducer";
import { ERROR_MSG } from "../../constants/message.contants";
import { Plus, Download } from "react-feather";
import { check } from "../../services/validation";
import { OverlayLoader } from "../../components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../constants/service.constant";
import {
  getAccess,
  getFormattedUserId,
} from "../../../../../../services/auth.services";
import cookie from "react-cookies";
import ForecastActions from "../forecasts/ForecastActions/forecastActions";
import axios from 'axios';

export class ProjectEstimates extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openProjectForm: false,
      showCompletedProjects: false,
      formMode: PROJECT_ACTIONS.ADD_PROJECT,
      selectedProjectId: null,
      progress: false,
      completedProjectsFlag:0, 
    };
  }
  componentDidMount = async () => {
    this.props.getProjects(this.props.productCode);
    // this.props.getPCodes();
    // await this.props.getPortfolios();
  };

  onProjectSelection = (projectId, callback) => {
    this.setState({ selectedProjectId: projectId }, () =>
      callback ? callback() : null
    );
  };
  
  onModalClose = async (status, data, keepModal = false, completeReload = true ) => {
    if (status === ACTIONS.SUCCESS) {
      this.props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      if (!keepModal) {
        this.setState({ openProjectForm: false });
      }
      // if(data.actionType && data.actionType === PROJECT_ACTIONS.EDIT_PROJECT && !completeReload ){
      //   const { projects } = this.props;
      //   if(projects.data && projects.data.projectEstimatesList && projects.data.projectEstimatesList.length){
      //     const index = projects.data.projectEstimatesList.
      //       findIndex(el=>el.projectEstimateId === data.payload.projectEstimateId )
      //     projects.data.projectEstimatesList[index]=data.payload
      //   }
      // }else{
        this.props.getProjects(this.props.productCode);
        if(this.props.completedProjectsList.data && this.props.completedProjectsList.data.projectEstimatesList &&
            this.props.completedProjectsList.data.projectEstimatesList.length){
              this.props.getCompletedProjects(this.props.productCode)
            }
        this.props.refreshProduct(this.props.productCode, ()=>{
          this.props.getSummaryChart(this.props.productCode);
        })
        console.log(data.actionType === PROJECT_ACTIONS.ADD_PROJECT && data.estimateType =="Execution", data)
        if((data.actionType === PROJECT_ACTIONS.ADD_PROJECT && data.estimateType =="Execution") 
        || (data.actionType === PROJECT_ACTIONS.EDIT_PROJECT && data.addMode )){
          this.props.projectsBudgetRefresh(data.projectestimateId, "add", ()=>{
            this.props.getForecasts(this.props.productCode);
            this.props.getForecastsAggregate(this.props.productCode);
            this.props.getForecastsCapacity(this.props.productCode);
          })
        }else if(completeReload){
          this.props.projectsBudgetRefresh(data.projectestimateId, "edit", ()=>{
            this.props.getForecasts(this.props.productCode);
            this.props.getForecastsAggregate(this.props.productCode);
            this.props.getForecastsCapacity(this.props.productCode);
          })
        }else if(data.actionType === PROJECT_ACTIONS.DELETE_PROJECT){
          this.props.getForecasts(this.props.productCode);
          this.props.getForecastsAggregate(this.props.productCode);
          this.props.getForecastsCapacity(this.props.productCode);
        }
      // }
      // if(completeReload){
      //   this.props.getSummaryChart(this.props.productCode);
      //   this.props.getForecasts(this.props.productCode);
      //   this.props.getForecastsAggregate(this.props.productCode);
      //   this.props.getForecastsCapacity(this.props.productCode);
      // }
    } else if (status === ACTIONS.ERROR) {
      this.props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_FORM_ERR,
      });
    } else if (!keepModal) {
      this.setState({ openProjectForm: false });
    }
  };

  onAddOrEditProjectClick = (mode, data) => {
    if (mode === PROJECT_ACTIONS.ADD_PROJECT) {
      this.setState({ openProjectForm: true, formMode: mode });
    } else if (mode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES) {
      this.onProjectSelection(data.pcode, () => { 
        this.setState({ openProjectForm: true, formMode: mode });
      });
    } else {
      this.onProjectSelection(data.projectEstimateId, () => {
        this.setState({ openProjectForm: true, formMode: mode });
      });
    }
  };
  getSelectedProjectDetails = (projectId) => {
    const { formMode } = this.state;
    const { projects, completedProjectsList } = this.props;
    if (formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES){
      return this.getMissedEstProjectDetails(projectId);
    }
    if (
      projects.data &&
      projects.data.projectEstimatesList &&
      projects.data.projectEstimatesList.length &&
      completedProjectsList.data &&
      completedProjectsList.data.projectEstimatesList &&
      completedProjectsList.data.projectEstimatesList.length
    ) {
      const arr = [...projects.data.projectEstimatesList, ...completedProjectsList.data.projectEstimatesList]
      return arr.filter(
        (project) =>
          project.projectEstimateId && project.projectEstimateId === projectId
      )[0];
    } else if (
      projects.data &&
      projects.data.projectEstimatesList &&
      projects.data.projectEstimatesList.length
    ) {
      return projects.data.projectEstimatesList.filter(
        (project) => 
        project.projectEstimateId && project.projectEstimateId === projectId
      )[0];
    } else {
      return {};
    }
  };
  /* Missing Estimates */
  getMissedEstProjectDetails = (projectId) => {
    const { forecasts } = this.props;
    if (
      forecasts.data &&
      forecasts.data.missingEstimates &&
      forecasts.data.missingEstimates.length
    ) {
      return forecasts.data.missingEstimates.filter(
        (project) =>
          project.pcode && project.pcode === projectId
      )[0];
    } else {
      return {};
    }
  }; 

  sendOptions = () => {
    return {
      estimateTypes: this.props.estimateTypes,
      projectType: this.props.projectType,
      estimationTimings: this.props.estimationTimings,
      fundings: this.props.fundings,
      investmentPortfolios: this.props.investmentPortfolios,
      deliveryPortfolios: this.props.deliveryPortfolios,
    };
  };
  onHeaderChange = (formMode) => {
    this.setState({
      openProjectForm: true,
      formMode: formMode,
    });
  };
  getHeader = () => {
    const { formMode } = this.state;
    if (formMode === PROJECT_ACTIONS.ADD_PROJECT) {
      return "Add Project";
    } else if (
      formMode === PROJECT_ACTIONS.EDIT_PROJECT ||
      formMode === PROJECT_ACTIONS.PROJECT_COMMENT
    ) {
      return () => (
        <ProjectFormHeader
          formMode={formMode}
          onHeaderChange={this.onHeaderChange}
        />
      );
    } else if (formMode === PROJECT_ACTIONS.REOPEN_PROJECT) {
      return "Re-Open Project";
    }
    else if (formMode === PROJECT_ACTIONS.ADD_MISSING_ESTIMATES) {
      return "Add Missing Estimates";
    }
  };
  getLabel = (noOfCompletedProjects, show) => (
    <>
      Show Completed Projects
      {show ? (
        <Badge style={{ marginLeft: "3px" }} variant="success">
          {noOfCompletedProjects}
        </Badge>
      ) : null}
    </>
  );

  exportProjectEstimatesTable = (productCode) => {
    // window.open(
    //   `${cookie.load(
    //     "ROVER_PCD_API"
    //   )}/pcd/products/${productCode}/export-project-estimates`
    // );
    const token = localStorage.getItem("token")
    this.setState({progress:true})
    axios({
      url: `${cookie.load("ROVER_PCD_API")}/pcd/products/${productCode}/export-project-estimates`,
      method: 'GET',
      headers: {
        Authorization: token ? `Bearer ${token}` : ''
      },
      onDownloadProgress(progressEvent) {
        // const progressValue = Math.round((progressEvent.loaded / progressEvent.total) * 100);
        // this.setState({progress:true})
      },
      responseType: 'blob',
    }).then(response => {
      this.setState({progress:false})
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.target = "_blank";
      link.setAttribute('download', `ProjectEstimates ${productCode} ${moment().format("YYYY.MM.DD")}.xlsx`);
      document.body.appendChild(link);
      link.click()
      // window.open(url, "_blank").focus()
    }).catch(error => {
      console.log(error)
      this.setState({progress:false})
    })
  };

  showCompletedProjects = () => {
    if(this.state.completedProjectsFlag === 0){
      this.props.getCompletedProjects(this.props.productCode)
    }
    this.setState({
      showCompletedProjects: !this.state.showCompletedProjects,
      completedProjectsFlag : this.state.completedProjectsFlag + 1,
    })
  }
  render() {
    const {
      productDetails,
      projects,
      loggedInUser,
      pcdmAccess,
      userParams,
      completedProjectsList,
    } = this.props;
    let lanId = loggedInUser.isAuthenticated
      ? getFormattedUserId(userParams)
      : "";
    const {
      showCompletedProjects,
      openProjectForm,
      formMode,
      selectedProjectId,
      progress
    } = this.state;
    const projectList = check({
      original: projects,
      path: "data.projectEstimatesList",
      defaultReturnValue: [],
    }).value;
    const completedList = check({
      original: completedProjectsList,
      path: "data.projectEstimatesList",
      defaultReturnValue: [],
    }).value;
    // const info = {
    //   "Product Manager": productDetails ? this.props.getProductManagerName() : null,
    //   "Product Line": productDetails && productDetails.portfolio,
    //   Product: productDetails && productDetails.name,
    //   "PRD Code": productDetails && productDetails.productCode,
    //   "Last Updated":
    //     projects.data && projects.data.lastModifiedDate
    //       ? moment(projects.data.lastModifiedDate).format("MM/DD/YYYY hh:mm A")
    //       : "",
    // };
    let filteredProjects = projectList.length
      ? showCompletedProjects
        ? [...completedList, ...projectList] 
        : projectList
      : [];
    filteredProjects.sort(function (project1, project2) {
      var date1 = moment(project1.modifiedDate);
      var date2 = moment(project2.modifiedDate);
      return date2.diff(date1);
    });
    let noOfCompletedProjects = completedList
      ? completedList.length
      : 0;
    return (
      <div className="pcdm-container pcdm-proj_est-container" style={{ position: "relative" }}>
        <OverlayLoader loading={projects.status === DATA_STATUS.LOADING || completedProjectsList.status === DATA_STATUS.LOADING} />
        <Container fluid>
          {/* <Row>
            <Col sm={12} md={3} lg={3} xl={3}>
              <div className="project-estimate-info">
                <Info info={info} history={this.props.history} />
              </div>
            </Col>
          </Row> */}
          <Row>
            <Col>
              <div className="project-table-actions">
                <div className="left-align">
                  {pcdmAccess.writeAccess ? (
                    <CustomButton
                      onClick={() =>
                        this.onAddOrEditProjectClick(
                          PROJECT_ACTIONS.ADD_PROJECT,
                          null
                        )
                      }
                      title={"Click to add a project"}
                      className="project-link inline add_project_btn"
                    >
                      <Plus size={13} strokeWidth={3} color={"#fff"} />
                      <span>Add Project </span>
                    </CustomButton>
                  ) : null}

                  <div style={{ display: "inline-block", marginLeft: "1px" }}>
                    <ForecastActions
                      hasEditAccess={pcdmAccess.writeAccess}
                      addMissingEst={(selectedPcode) =>
                        this.onAddOrEditProjectClick(PROJECT_ACTIONS.ADD_MISSING_ESTIMATES,
                          selectedPcode)}
                    />
                  </div>

                  <Checkbox
                    label={this.getLabel(
                      noOfCompletedProjects,
                      showCompletedProjects
                    )}
                    checked={showCompletedProjects}
                    className={"proj_est-checkbox"}
                    onChange={() =>
                      this.showCompletedProjects()
                    }
                  />
                </div>
                <div className="right-align">
                  {pcdmAccess.writeAccess ? (
                    <CustomButton
                      onClick={() =>
                        this.exportProjectEstimatesTable(
                          productDetails.productCode
                        )
                      }
                      title={"Click to Download Project Estimates"}
                      className="project-export-link inline"
                      loading = {progress}
                      fluid = {true}
                    >
                      <Download size={15} strokeWidth={3} />
                      <span>Export Project Estimates</span>
                    </CustomButton>
                  ) : null}
                </div>
              </div>
            </Col>
          </Row>
          <Row>
            <Col>
              <ProjectTable
                onAddOrEditProject={this.onAddOrEditProjectClick}
                {...this.sendOptions()}
                projects={filteredProjects}
                showCompletedProjects={showCompletedProjects}
                canEdit={pcdmAccess.writeAccess}
              />
            </Col>
          </Row>
        </Container>
        {openProjectForm ? (
          <ProjectForm
            manager={productDetails ? productDetails.manager : null}
            lanId={lanId}
            formVisible={openProjectForm}
            header={this.getHeader()}
            selectedProject={this.getSelectedProjectDetails(selectedProjectId)}
            closeModal={(status, data, keepModal,completeReload) =>
              this.onModalClose(status, data, keepModal, completeReload)
            }
            formMode={formMode}
            {...this.sendOptions()}
          />
        ) : null}
      </div>
    );
  }
}

export const mapStateToProps = (state) => ({
  estimateTypes: state.ProjectsReducer.estimateTypeOptions,
  projectType: state.ProjectsReducer.projectTypeOptions,
  estimationTimings: state.ProjectsReducer.estimationTimingOptions,
  fundings: state.ProjectsReducer.fundingOptions,
  investmentPortfolios: state.ProjectsReducer.investmentPortfolioOptions,
  deliveryPortfolios: state.ProjectsReducer.deliveryPortfolioOptions,
  projects: state.ProjectsReducer.projects,
  completedProjectsList: state.ProjectsReducer.completedProjectsList,
  loggedInUser: state.AuthReducer,
  userParams: state.AuthReducer.user,
  forecasts: state.ForecastsReducer.forecasts,
  // projectDefaults: state.ProjectsReducer.projectDefaults,
});

export const mapDispatchToProps = (dispatch) => ({
  getProjects: (productCode) => dispatch(getProjectsThunk(productCode)),
  getCompletedProjects : (productCode) => dispatch(getCompletedProjectsThunk(productCode)),
  // getPCodes: () => dispatch(getPCodesThunk()),
  // getPortfolios: () => dispatch(getPortfoliosThunk()),
  getSummaryChart: (productCode) => dispatch(getSummaryChartThunk(productCode)),
  refreshProduct: (productCode, callback) => dispatch(refreshProductThunk(productCode, callback)),
  projectsBudgetRefresh: (projectEstimateId, type, callback) => dispatch(projectsBudgetRefreshThunk(projectEstimateId, type, callback)),
  getForecasts: (productCode) => dispatch(getForecastsThunk(productCode)),
  getForecastsAggregate: (productCode) => dispatch(getForecastsAggregateThunk(productCode)),
  showNotification: (notification) => dispatch(addNotification(notification)),
  getForecastsCapacity: (productCode) =>
    dispatch(getForecastsCapacityThunk(productCode)),
});
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(ProjectEstimates)
);
