import React, { useState, useEffect } from "react";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../../components/forms/Button/button";
import { CheckCircle } from "react-feather";
import { connect } from "react-redux";
import {
  getFollowProductThunk,
  SET_FOLLOWING,
  setFollowingThunk,
  setUnFollowThunk,
  SET_UNFOLLOW,
} from "../../../store/RMFollow.reducer";
import { formatLanId } from "../../../services/lanId.service";
import { DATA_STATUS } from "../../../constants/service.constant";
import { PRODUCT_FOLLOW_ACTIONS } from "../../../constants/action.constants";
function RMFOllowProduct(props) {
  const {
    userParams,
    getFollowProduct,
    setFollowing,
    RMProductStatus,
    setUnfollow,
    RMFollowStatus,
    RMUnFollowStatus,
  } = props;
  useEffect(() => {
    const productCode = localStorage.getItem("productCode");
    const employeeId = formatLanId(userParams);
    getFollowProduct(productCode, employeeId);
  }, []);

  const setFollow = (mode) => {
    const productCode = localStorage.getItem("productCode");
    const employeeId = formatLanId(userParams);
    if (mode === PRODUCT_FOLLOW_ACTIONS.FOLLOW_PRODUCT) {
      setFollowing(productCode, employeeId, (status, data) => {
        if (status === SET_FOLLOWING) {
          getFollowProduct(productCode, employeeId);
        }
      });
    } else if (mode === PRODUCT_FOLLOW_ACTIONS.UNFOLLOW) {
      setUnfollow(productCode, employeeId, (status, data) => {
        if (status === SET_UNFOLLOW) {
          getFollowProduct(productCode, employeeId);
        }
      });
    }
  };
  return (
    <div className="publish-report-container following-button">
      {RMProductStatus.status == DATA_STATUS.SUCCESS ? (
        <>
          <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
            <CustomButton
              fluid={true}
              variant={BUTTON_VARIANTS.SUCCESS}
              disable={true}
              // onClick={() => setFollow(false)}
              loading={RMUnFollowStatus.status === DATA_STATUS.LOADING}
              title={"Follow this product to see it on your Rover dashboard"}
              className="publish-button"
            >
              <CheckCircle size="13" strokeWidth="3" /> <span> FOLLOWING </span>
            </CustomButton>
          </div>
          {/* <span title='Click here to Unfollow product' style = {{color:"blue"}} onClick = {()=> setFollow(false)} ><u>Unfollow</u></span> */}
          <div id="unfollow_button">
            <a
              role="button"
              className="collapse-link"
              aria-expanded="false"
              title='Click here to Unfollow product'
              onClick={() => setFollow(PRODUCT_FOLLOW_ACTIONS.UNFOLLOW)}
            >
              Unfollow
            </a>
          </div>
        </>
      ) : (
        <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
          <CustomButton
            fluid={true}
            variant={BUTTON_VARIANTS.LINK}
            onClick={() => setFollow(PRODUCT_FOLLOW_ACTIONS.FOLLOW_PRODUCT)}
            loading={RMFollowStatus.status === DATA_STATUS.LOADING}
            title={"Follow this product to see it on your Rover dashboard"}
            className="publish-button"
          >
            <span>FOLLOW PRODUCT</span>
          </CustomButton>
        </div>
      )}
    </div>
  );
}

export const mapStateToProps = (state) => ({
  RMProductStatus: state.RMFollowReducer.RMProductStatus,
  RMFollowStatus: state.RMFollowReducer.RMFollowStatus,
  RMUnFollowStatus: state.RMFollowReducer.RMUnFollowStatus,
  userParams: state.AuthReducer.user,
});
export const mapDispatchToProps = (dispatch) => ({
  getFollowProduct: (productCode, employeeId) =>
    dispatch(getFollowProductThunk(productCode, employeeId)),
  setFollowing: (productCode, employeeId, callback) =>
    dispatch(setFollowingThunk(productCode, employeeId, callback)),
  setUnfollow: (productCode, employeeId, callback) =>
    dispatch(setUnFollowThunk(productCode, employeeId, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RMFOllowProduct);
