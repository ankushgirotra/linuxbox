import React, { useState, useMemo } from "react";
import { connect } from "react-redux";
import { Popover, OverlayTrigger } from "react-bootstrap";
import { getAllocationDetailsThunk } from "../../../../store/roles.reducer";
import { OverlayLoader } from "../../../../components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../../../constants/service.constant";

function AllocationPopOver({resourceName,resourceId,getAllocationDetails,allocationDetails,allocationStatus}) {

  const [allocDetails, setAllocDetails] = useState([]);
  const [totalAlloc, setTotalAlloc] = useState(0);
  const [popoverWidth, setPopoverWidth] = useState("300px");

  const getMaxLength = (gvnArr) => {
    let maxProductNameLength = Math.max(...gvnArr.map((prod) => prod.productName.length));
    let maxTeamNameLength = Math.max(...gvnArr.map((prod) => prod.teamName.length));
    let maxLength = Math.max(maxProductNameLength, maxTeamNameLength);
    if (maxLength > 40) {
      return maxLength > 50 ? maxLength - 3 : maxLength - 1;
    } else {
      return maxLength + 5;
    }
  }

  useMemo(() => {
    if (allocationDetails.length) {
      let sortedTeamArr = allocationDetails.map((prod) => prod.teams.sort(function (team1, team2) {
        if (team1.allocation > team2.allocation) return -1;
        if (team2.allocation > team1.allocation) return 1;
        return 0;
      }))
      let maxLength = getMaxLength(sortedTeamArr.flat());
      let sortedArr = allocationDetails.sort(function (prod1, prod2) {
        if (prod1.allocation > prod2.allocation) return -1;
        if (prod2.allocation > prod1.allocation) return 1;
        return 0;
      })
      let totalAllocation = 0;
      allocationDetails.forEach(prod => totalAllocation += prod.allocation)
      setTotalAlloc(totalAllocation)
      setAllocDetails(sortedArr)
      setPopoverWidth(`${maxLength*8}px`)
    }
  }, [allocationDetails]);

  const displayAllocationToolTip = () => {
    return (
      <Popover className="pcdm-allocation_popover"
        style={{ marginLeft: "20px", maxWidth: popoverWidth }}>
        <Popover.Title className="allocation_popover-header">
          {resourceName}
        </Popover.Title>
        <Popover.Content className="allocation_popover-content">
          <table>
            {totalAlloc>100 ? <span className="redText">Total allocation > 100%, please correct.</span> : null }
            <tbody>
              {allocationDetails.length && allocDetails.length ? allocDetails.map((prod) => {
                return <tr>
                  <p className="product-details">
                    <td> <b> {prod.productName} </b></td>
                    <td> <b> {`${prod.allocation}%`} </b></td>
                  </p>
                  {
                    prod.teams.length ? prod.teams.map((team) => {
                      return <p className="teams-details">
                        <td> {team.teamName} </td>
                        <td> {`${team.allocation}%`} </td>
                      </p>
                    }) : ""
                  }
                </tr>
              }) : ""}
            </tbody>
          </table>
        </Popover.Content>
      </Popover>
    );
  }

  return (
    <>
      <OverlayLoader
        loading={allocationStatus.status === DATA_STATUS.LOADING}
      />
      <OverlayTrigger
        trigger="click"
        rootClose
        placement={"right"}
        overlay={displayAllocationToolTip()}
      >
        <span
          title={"click to view resource allocation"}
          onClick={() => getAllocationDetails(resourceId)}
          style={{ cursor: "pointer" }}
        >
          {resourceName}
        </span>
      </OverlayTrigger>
    </>
  );
}

const mapStateToProps = (state) => ({
  allocationDetails: state.RolesReducer.allocationDetails.data,
  allocationStatus: state.RolesReducer.allocationDetails.status,
});

const mapDispatchToProps = (dispatch) => ({
  getAllocationDetails: (lanId,callback) => dispatch(getAllocationDetailsThunk(lanId,callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AllocationPopOver);
