import React, { useState, useEffect, useMemo } from "react";
import Info from "../../components/info/info";
import Collapsible from "../../components/Collapsible/collapsible";
import { Row, Col, Container, Badge } from "react-bootstrap";
import moment from "moment";
import List from "../../components/List/list";
import Checkbox from "../../components/forms/Checkbox/checkbox";
import "./forecasts.scss";
import ForecastsNewTable from "./ForecastTable/forecastsNewTable";
import ActualsAndForecastsChart from "./ActualsAndForecastsChart/actualsAndForecastsChart";
import {
  clearForecastChange,
  getForecastsCapacityThunk,
  getForecastsThunk,
  getForecastsAggregateThunk,
  updateForecastChangesThunk,
  UPDATE_FORECAST_CHANGES_SUCCESS,
  getCompletedForecastsThunk,
  getCompletedForecastsAggregateThunk,
} from "../../store/forecast.reducer";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { check } from "../../services/validation";
import ForecastActions from "./ForecastActions/forecastActions";
import ForecastTable from "./ForecastTable/forecastTable";
import { getMatchedProjectList } from "../../services/forecast.chart.service";
import DataHandler, { OverlayLoader } from "../../components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../constants/service.constant";
import { RefreshCw } from "react-feather";
import { getAccess } from "../../../../../../services/auth.services";
import { NO_DATA_MSG } from "../../constants/message.contants";
import CustomButton from "../../components/forms/Button/button";
import { ArrowRightCircle } from "react-feather";
import goToCurrentMonth from "../../templates/forecast.template";
import { PROJECT_ACTIONS, ACTIONS } from "../../constants/action.constants";
import ProjectForm from "../projectEstimates/ProjectForm/projectForm";
import { ERROR_MSG } from "../../constants/message.contants";
import { Download } from "react-feather";
import {
  getProjectsThunk,
  getPCodesThunk,
  getPortfoliosThunk,
} from "../../store/projects.reducer";
import { getSummaryChartThunk } from "../../store/summary.reducer";
import { addNotification } from "../../store/common.reducer";
import Switch from "../../components/forms/Switch/switch";
import { getFormattedDate } from "../../services/form.service";
import {
  DEFAULT_MSG_MODAL_CONFIG,
  MessageModal,
} from "../../components/MessageModal/messageModal";
import Datepicker from "../../components/Datepicker/datepicker";
import {
  FORM_CONTROL_DEFAULT,
  MONTH_YEAR_FORMAT,
  FORM_DATE_FORMAT,
} from "../../constants/form.constants";
import  {
  BUTTON_VARIANTS,
} from "../../components/forms/Button/button";
import ProjectForecastsForm from "./forecastReportForm";
import {
  matchedProjectTooltipMsg,
  totalBudgetTooltipMsg,
} from "../../templates/forecast.template";
import ToolTip from "../../components/ToolTip/ToolTip";

export function Forecasts(props) {
  const {
    productDetails,
    productCode,
    getForecasts,
    getForecastsCompleted,
    getForecastsAggregateCompleted,
    forecasts,
    forecastAggregate,
    completedForecasts,
    completedForecastAggregate,
    activeTab,
    getForecastsCapacity,
    forecastsCapacity,
    updateForecastChangesStatus,
    forecastDollar,
    pcdmAccess,
    projects,
    getForecastsAggregate,
    summary,
    clearForecastChange,
  } = props;
  
  useEffect(() => {
    getForecasts(productCode);
    getForecastsAggregate(productCode);
    getForecastsCapacity(productCode);
  }, []);

  const [showCompletedProjects, setShowCompletedProjects] = useState(false);
  const [showCompletedProjectsFlag, setShowCompletedProjectsFlag] = useState(0);
  const [forecastsFiltered, setForecastsFiltered] = useState(forecasts);
  const [completedForecastsFiltered, setCompletedForecastsFiltered] = useState(completedForecasts)
  const [activeProj, setActiveProj] = useState(forecasts);
  const [didSelectAllChecked, setDidSelectAllChecked] = useState(false);
  const [openProjectForm, setOpenProjectForm] = useState(false);
  const [selectedPcode, setSelectedPcode] = useState("");

  const filterList = useMemo(() => {
    let filterArr = []
    if(showCompletedProjects){
      filterArr = getMatchedProjectList(completedForecastsFiltered)
      filterArr.sort((a,b)=>{
        let name1=a.name;
        let name2=b.name;
        if(name1<name2)
          return -1;
        if(name1>name2)
          return 1;
        return 0;
      })
      const index = filterArr.findIndex((el)=>el.id==='pc')
      const element = filterArr.filter((el)=>el.id==='pc')[0]
      if(index >= 0){
        filterArr.splice(index,1)
        filterArr.unshift(element)
      }
      return filterArr
    }else{
      filterArr = getMatchedProjectList(forecasts)
      filterArr.sort((a,b)=>{
        let name1=a.name;
        let name2=b.name;
        if(name1<name2)
          return -1;
        if(name1>name2)
          return 1;
        return 0;
      })
      const index = filterArr.findIndex((el)=>el.id==='pc')
      const element = filterArr.filter((el)=>el.id==='pc')[0]
      if(index >= 0){
        filterArr.splice(index,1)
        filterArr.unshift(element)
      }
      return filterArr
    }
  }, [forecasts, completedForecastsFiltered, showCompletedProjects]);
  const [currentFilter, setCurrentFilter] = useState(filterList);
  const [productCoreAggregate, setProductCoreAggregate] = useState(null)
  const [forecastCapacityData, setForecastCapacityData] = useState(null)
  
  if (!currentFilter.length && filterList.length) {
    setCurrentFilter(filterList);
  }
  useEffect(()=>{
    setCurrentFilter(filterList)
  },[filterList, forecasts,showCompletedProjects, completedForecastsFiltered ])
  useEffect(() => {
    if (forecasts && forecasts.data && forecasts.data.matchedProjects) {
      const filterActive = forecasts && forecasts.data && forecasts.data.matchedProjects ?
        forecasts.data.matchedProjects.filter((prj) => prj.completed === false) : [];
      const forecastData = JSON.parse(JSON.stringify(forecasts));
      forecastData.data.matchedProjects = filterActive;
      setActiveProj(forecastData);
      setForecastsFiltered(forecastData);
    }
  }, [forecasts, completedForecasts])
  
  useEffect(()=>{
    if(showCompletedProjects){
      if( completedForecastAggregate && completedForecastAggregate.data && completedForecastAggregate.data.matchedProjects ){
        const productCore = completedForecastAggregate && completedForecastAggregate.data && completedForecastAggregate.data.matchedProjects ?
        completedForecastAggregate.data.matchedProjects.filter((prj)=> prj.projectType === "Product Core")[0] : null;
        setProductCoreAggregate(productCore)
      }
    }else{
      if( forecastAggregate && forecastAggregate.data && forecastAggregate.data.matchedProjects ){
        const productCore = forecastAggregate && forecastAggregate.data && forecastAggregate.data.matchedProjects ?
        forecastAggregate.data.matchedProjects.filter((prj)=> prj.projectType === "Product Core")[0] : null;
        setProductCoreAggregate(productCore)
      }
    }
  },[forecastAggregate, completedForecastAggregate])
  useEffect(()=>{
    if(forecastsCapacity && forecastsCapacity.data){
      setForecastCapacityData(forecastsCapacity.data)
    }
  },[forecastsCapacity])
  // useEffect(()=>{
  //   if( forecastsCapacity && forecastsCapacity.data ){
  //     const currentMonth = new Date().getMonth();
  //     const currentYear = new Date().getFullYear();
  //   let filteredArray = []
  //   let endDate = new Date(currentYear+1, 2, 31)
  //   let startDate = new Date(currentYear, 9, 1)
  //   // if (currentMonth > 5) {
  //   //   let startDate = new Date(currentYear, 0, 1)
  //   //   filteredArray = forecastsCapacity.data.filter((el) => new Date(el.month) >= startDate && new Date(el.month) <= endDate)
  //   // } else {
  //   //   let startDate2 = new Date()
  //   //   startDate2.setMonth(currentMonth - 6)
  //   //   startDate2.setDate(1)
  //   //   filteredArray = forecastsCapacity.data.filter((el) => new Date(el.month) >= startDate2 && new Date(el.month) <= endDate)
  //   // }
  //   filteredArray = forecastsCapacity.data.filter((el) => new Date(el.month) >= startDate && new Date(el.month) <= endDate)
  //   let data = forecastsCapacity.data;
  //   let minStartDate;
  //   if (forecastsCapacity.data.length) {
  //     for (let i = 0; i < data.length; i++) {
  //       for (let j = 0; j < data.length; j++) {
  //         if (new Date(data[i].month) < new Date(data[j].month)) {
  //           let temp = data[i];
  //           data[i] = data[j];
  //           data[j] = temp;
  //         }
  //       }
  //     }
  //     minStartDate = new Date(data[0].month)
  //   }
  //   if (filteredArray.length) {
  //     let endMonthFirstDate = new Date(filteredArray[filteredArray.length - 1].month);
  //     let endMonthLastDate = new Date (moment(endMonthFirstDate).endOf("month"));
  //     let maxEndDate = new Date(data[data.length - 1].month);
  //     let maxEndLastDate= new Date (moment(maxEndDate).endOf("month"));
  //     setForecastCapacityData(filteredArray);
  //     setStartMonth(new Date(filteredArray[0].month));
  //     setEndMonth(endMonthLastDate);
  //     // setEndMonth(new Date(filteredArray[filteredArray.length - 1].month))
  //     setFormControlsDate({
  //       ...formControlsDate,
  //       edited: true,
  //       startMonth: {
  //         ...formControlsDate.startMonth,
  //         value: new Date(filteredArray[0].month),
  //         min: minStartDate,
  //         error: false,
  //       },
  //       endMonth: {
  //         ...formControlsDate.endMonth,
  //         disabled: false,
  //         value: endMonthLastDate,
  //         min: new Date(filteredArray[0].month),
  //         max: maxEndLastDate,
  //         error: false,
  //         // value: new Date(filteredArray[filteredArray.length - 1].month),
  //         // max: new Date(data[data.length - 1].month),       
  //       },
  //     })
  //   }

  //   }
  // },[forecastsCapacity])

  useEffect(() => {
    if (!showCompletedProjects) {
      if (forecasts) {
        setForecastsFiltered(activeProj);
      }
    } else {
      if(completedForecasts.status === DATA_STATUS.SUCCESS)
      // const fullForecastData = {forecasts}
      forecastsFiltered.data.matchedProjects = [...forecastsFiltered.data.matchedProjects, ...completedForecasts.data.matchedProjects]
      setCompletedForecastsFiltered(forecastsFiltered);
    }
  }, [showCompletedProjects,completedForecasts])

  const onSubmit = () => {
    setStartMonth(formControlsDate.startMonth.value)
    setEndMonth(formControlsDate.endMonth.value)
    const filteredArray = forecastsCapacity.data.length ? forecastsCapacity.data.filter((el) =>
      new Date(el.month) >= new Date(formControlsDate.startMonth.value) &&
      new Date(el.month) <= new Date(formControlsDate.endMonth.value)) : []
    setForecastCapacityData(filteredArray);  
  }

  const [brushIndex, setBrushIndex] = useState({
    startIndex: 0,
    endIndex: 0,
  });
  useEffect(() => {
    if (
      forecastCapacityData
    ) {
      let start = forecastCapacityData.findIndex((el) => el.month === moment().startOf("month").format("M/DD/YYYY")),
        end = 0;
      /* If there is current month and 3 months from current month is exist in chart period 
      then set 3 months from current month as end index */
      if (start < 0) {
        start = 0;
      }
      if (start + 3 <= forecastCapacityData.length - 1) {
        end = start + 3;
      } else {
        end = forecastCapacityData.length - 1;
      }
      if (start != -1 && start - 3 > 0) {
        start = start - 3;
      } else {
        start = 0;
      }
      setBrushIndex({
        startIndex: start,
        endIndex: end,
      });
    }
  }, [forecastCapacityData]);

  /*
  const info = {
    "Product Manager": productDetails ? props.getProductManagerName() : null,
    "Product Line": productDetails && productDetails.portfolio,
    Product: productDetails && productDetails.name,
    "PRD Code": productDetails && productDetails.productCode,
    "Last Updated":
      productDetails && productDetails.lastModifiedDate
        ? moment(productDetails.lastModifiedDate).format("MM/DD/YYYY hh:mm A")
        : "",
  };
  */

  const onFilterChange = (item) => {
    let checkExist = currentFilter.findIndex((el) => el.id === item.id);
    let temp = currentFilter.slice();
    if (checkExist >= 0) {
      temp.splice(checkExist, 1);
      setCurrentFilter(temp);
    } else {
      temp.push(item);
      setCurrentFilter(temp);
    }
  };

  const [formControlsDate, setFormControlsDate] = useState({
    edited: false,
    error: false,
    errorMessage: "",
    startMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    endMonth: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      disabled: true,
    },
  });

  const [startMonth, setStartMonth] = useState(null)
  const [endMonth, setEndMonth] = useState(null);
  const manageMonthSelection = (type, date) => {
    const { endMonth } = formControlsDate;
    let valueInMoment = moment(date, FORM_DATE_FORMAT);
    let validatedEndMonth = endMonth.value;

    if (type === "startMonth") {

      if (endMonth.value && valueInMoment.isAfter(moment(endMonth.value, FORM_DATE_FORMAT))) {
        validatedEndMonth = "";
      }
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          value: date,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          disabled: false,
          value: validatedEndMonth,
          min: date,
          error: false,
        },
      });
    } else if (type === "endMonth") {
      let lastDate= new Date (moment(date).endOf("month"));
      setFormControlsDate({
        ...formControlsDate,
        edited: true,
        startMonth: {
          ...formControlsDate.startMonth,
          error: false,
        },
        endMonth: {
          ...formControlsDate.endMonth,
          value: date ? lastDate : null,
          error: false,
        },
      });
    }
  };

  const onSelectAllChange = () => {
    setDidSelectAllChecked(!didSelectAllChecked);
    setCurrentFilter(filterList);
  }

  const sendOptions = () => {
    return {
      estimateTypes: props.estimateTypes,
      projectType: props.projectType,
      estimationTimings: props.estimationTimings,
      fundings: props.fundings,
      investmentPortfolios: props.investmentPortfolios,
      deliveryPortfolios: props.deliveryPortfolios,
    };
  };

  const onAddOrEditProjectClick = (data) => {
    setSelectedPcode(data.pcode);
    setOpenProjectForm(true);
  };

  const onModalClose = async (status, data, keepModal = false) => {
    if (status === ACTIONS.SUCCESS) {
      props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      if (!keepModal) {
        setOpenProjectForm(false);
      }
      props.getProjects(props.productCode);
      props.getSummaryChart(props.productCode);
      props.getForecasts(props.productCode);
      props.getForecastsAggregate(props.productCode);
      props.getForecastsCapacity(props.productCode);
      if(showCompletedProjectsFlag > 1) {
        getForecastsAggregateCompleted(productCode)
        getForecastsCompleted(productCode)
      }
    } else if (status === ACTIONS.ERROR) {
      props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_FORM_ERR,
      });
    } else if (!keepModal) {
      setOpenProjectForm(false);
    }
  };

  const getSelectedProjectDetails = (projectId) => {
    if (
      forecasts.data &&
      forecasts.data.missingEstimates &&
      forecasts.data.missingEstimates.length
    ) {
      return forecasts.data.missingEstimates.filter(
        (project) =>
          project.pcode && project.pcode === projectId
      )[0];
    } else {
      return {};
    }
  };

  const updateForecastChanges = () => {
    if (props.forecastTableHistory.length) {
      let payload = props.forecastTableHistory.map((change) => {
        return {
          pcode: change.pcode,
          month: change.month,
          forecastPoints: Number(change.forecast.points),
          projectEstimateId: change.projectEstimateId,
        };
      });
      props.updateForecastChanges(productCode, payload, (status, data) => {
        if (status === UPDATE_FORECAST_CHANGES_SUCCESS) {
          sessionStorage.clear();
          sessionStorage.setItem("token",localStorage.getItem("token"))
          getForecasts(productCode);
          getForecastsAggregate(productCode);
          getForecastsCapacity(productCode);
          if(showCompletedProjectsFlag > 1) {
            getForecastsAggregateCompleted(productCode)
            getForecastsCompleted(productCode)
          }
        } else {
          console.log("error", data);
        }
      });
    }
  };
  const { flag, value } = check({
    path: "data.matchedProjects",
    checkEmpty: true,
    defaultReturnValue: [],
    original: forecasts,
  });
  //Show Completed Projects Label
  const getLabel = (noOfCompletedProjects, show) => (
    <>
      Show Completed Projects
      {show ? (
        <Badge style={{ marginLeft: "3px" }} variant="success">
          {noOfCompletedProjects}
        </Badge>
      ) : null}
    </>
  );
  let noOfCompletedProjects = completedForecasts && completedForecasts.data && completedForecasts.data.matchedProjects
    ? completedForecasts.data.matchedProjects.filter((prj) => prj.completed === true).length
    : 0;
  const [tableMode, setTableMode] = useState({
    value: 1,
    required: false,
  });
  const [messageModalConfig, setMessageModelConfig] = useState({ ...DEFAULT_MSG_MODAL_CONFIG })
  const [showForecastReport, setShowForecastReport] = useState(false)
  const setShowReportForm = (flag) => {
    setShowForecastReport(flag)
  }
  const handleModel = (action, data) => {
    if (action === 'SAVE') {
      updateForecastChanges();
      setMessageModelConfig({
        visible: false,
      })
      setTableMode({ ...tableMode, value: tableMode.value === 1 ? 2 : 1 });
    } else if (action === 'CLEAR') {
      clearForecastChange();
      setMessageModelConfig({
        visible: false,
      })
      setTableMode({ ...tableMode, value: tableMode.value === 1 ? 2 : 1 });
    } else {
      setTableMode({ ...tableMode, value: 1 })
      setMessageModelConfig({
        visible: false,
      })
    }
  }

  const filterHeader = () => {
    return <div className="filter-header"> <p>GRAPH FILTER</p></div>
  };

  const getTimeRangeHeader = () => {
    return (
      <>
        <p className="withAddButton"> Time range </p>
        <CustomButton
          onClick={() => onSubmit()}
          className="time_range-btn"
        >
          <RefreshCw size={13} strokeWidth={3} />
          <span>Refresh</span>
        </CustomButton>
      </>
    )
  };

  const showCompletedForecasts = () => {
    if(showCompletedProjectsFlag === 0){
      getForecastsCompleted(productCode)
      getForecastsAggregateCompleted(productCode)
    }
    setShowCompletedProjects(!showCompletedProjects)
    setShowCompletedProjectsFlag(showCompletedProjectsFlag+1)
  }
  return (
    <div className="pcdm-container" style={{ position: "relative" }}>
      <OverlayLoader
        loading={
          forecasts.status === DATA_STATUS.LOADING ||
          forecastsCapacity.status === DATA_STATUS.LOADING ||
          completedForecastAggregate.status === DATA_STATUS.LOADING ||
          completedForecasts.status === DATA_STATUS.LOADING
        }
      />
      <Container fluid className="forecast-container">
        {/* <Collapsible>
          <Row>
            <Col sm={6} md={3} lg={3} xl={3}>
              <div className="summary-info">
                <Info
                  info={info}
                  history={props.history}
                  checkForecastChanges={props.checkForecastChanges}
                />
              </div>
            </Col>
          </Row>
        </Collapsible> */}
        <DataHandler
          showData={flag && forecastsCapacity.data.length}
          emptyDataMessage={NO_DATA_MSG.NO_FORECAST}
        >
          <Row className="pcdm-forecast_container">
            <Col
              sm={3}
              md={3}
              lg={3}
              xl={3}
              className="forecast-filter_N_timerange-container"
            >
              <div className="sticky-top fixedit">
                <div className="forecast-chart-filter-container">
                  <CustomButton
                    onClick={() => {
                      setShowForecastReport(true);
                    }}
                    title={"Click to Download Project Estimates"}
                    className="forecast-export-link inline"
                    fluid={true}
                  >
                    <Download size={15} strokeWidth={3} />
                    <span> &nbsp;Export Project Forecasts</span>
                  </CustomButton>
                  <List
                    className={"forecast-chart-filter-list"}
                    list={filterList}
                    title={() => filterHeader()}
                    onClick={onFilterChange}
                    onChange={onFilterChange}
                    selected={currentFilter}
                    id="id"
                    value="name"
                    // multiSelect={true}
                    groupName="forecast-chart-filter-list"
                    showSelectAll={
                      filterList.length === currentFilter.length ? false : true
                    }
                    onSelectAllClick={onSelectAllChange}
                    showCheckbox={true}
                    hideRadioButton={true}
                  />
                </div>
                {/* <div className="list-select-container time-range-summary" >
                  <div className="teams-head pcdm-time_range-header"> {getTimeRangeHeader()} </div>
                  <div className="time-range-summary-dates">
                    <form className="pcdm-form">
                      <div className="pcdm-form__form-group">
                        <div className="pcdm-form__form-group-field">
                          <Datepicker
                            name="startMonth"
                            label={"Start Month"}
                            formObj={formControlsDate.startMonth}
                            isRequired={formControlsDate.startMonth.required}
                            onChange={manageMonthSelection}
                            placeholderText={"Ex: Jan, 2020"}
                            dateFormat={MONTH_YEAR_FORMAT}
                            showMonthYearPicker={true}
                            customInput={true}
                            portalId={"root-potal-pcdm"}
                          />
                        </div>
                        <div className="pcdm-form__form-group-field">
                          <Datepicker
                            name="endMonth"
                            label={"End Month"}
                            formObj={formControlsDate.endMonth}
                            isRequired={formControlsDate.endMonth.required}
                            onChange={manageMonthSelection}
                            dateFormat={MONTH_YEAR_FORMAT}
                            placeholderText={"Ex: Apr, 2021"}
                            showMonthYearPicker={true}
                            customInput={true}
                            portalId={"root-potal-pcdm"}
                          />
                        </div>
                      </div>
                    </form>
                  </div>
                </div> */}
              </div>
            </Col>
            <Col
              sm={9}
              md={9}
              lg={9}
              xl={9}
              className="pcdm-forecast-chart_N_table"
            >
              <Row>
                <Col
                  sm={12}
                  md={12}
                  lg={12}
                  xl={12}
                  className="forecasts-chart-container"
                >
                  <h5 className="pcdm-head center">
                    <span>Project Actuals & Forecasts</span>
                    <span
                      title="click to refresh Project Actuals & Forecasts"
                      className="forecast-refresh"
                      onClick={() => {
                        getForecasts(productCode);
                        getForecastsAggregate(productCode);
                        getForecastsCapacity(productCode);
                        if (showCompletedProjectsFlag > 1) {
                          getForecastsAggregateCompleted(productCode);
                          getForecastsCompleted(productCode);
                        }
                      }}
                    >
                      <RefreshCw size={13} strokeWidth={3} />
                    </span>
                  </h5>
                  <p className="text-center">
                    <span>
                      Actuals Last Updated:{" "}
                      {summary.actualsUploadDate
                        ? getFormattedDate(
                            summary.actualsUploadDate,
                            "MM/DD/YYYY"
                          )
                        : "--"}{" "}
                    </span>
                  </p>
                  <ActualsAndForecastsChart
                    forecasts={
                      showCompletedProjects
                        ? completedForecastsFiltered
                        : forecasts
                    }
                    forecastsCapacity={forecastCapacityData}
                    selectedPcodes={currentFilter}
                    productCoreAggregate={productCoreAggregate}
                    startIndex={brushIndex.startIndex}
                    endIndex={brushIndex.endIndex}
                  />
                </Col>
              </Row>

              <Row className="forecasts-table-container">
                <Col
                  sm={12}
                  md={12}
                  lg={12}
                  xl={12}
                  style={{ position: "relative" }}
                >
                  <OverlayLoader
                    loading={
                      updateForecastChangesStatus.status ===
                        DATA_STATUS.LOADING ||
                      forecastDollar.status === DATA_STATUS.LOADING
                    }
                  />
                  <Row>
                    <div>
                      <div className="forecast-left-align">
                        {/* {tableMode.value === 1 ? */}
                        <span className="forecast-projects-heading">
                          Projects
                          <ToolTip
                            toolTipTitle={"Projects"}
                            toolTipMessage={matchedProjectTooltipMsg()}
                          ></ToolTip>
                        </span>
                        <div className="forecast_btn">
                          <Checkbox
                            label={getLabel(
                              noOfCompletedProjects,
                              showCompletedProjects
                            )}
                            // label={'Show Completed Projects'}
                            checked={showCompletedProjects}
                            className={"forecasts-checkbox"}
                            onChange={() => showCompletedForecasts()}
                          />
                          {/* : null} */}
                          {/* <div style={{ display: "inline-block", marginLeft: "10px" }}>
                            {tableMode.value === 1 ?
                              <CustomButton
                                title={"Click to go to Current month"}
                                onClick={() => goToCurrentMonth('individual')}
                                className="project-link inline"
                              >
                                <span>Go to Current Month</span>
                                <ArrowRightCircle size="14" strokeWidth={2} />
                              </CustomButton> :
                              <CustomButton
                                title={"Click to go to Current month"}
                                onClick={() => goToCurrentMonth('aggregate')}
                                className="project-link inline"
                              >
                                <span>Go to Current Month</span>
                                <ArrowRightCircle size="14" strokeWidth={2} />
                              </CustomButton>
                            }
                          </div> */}
                        </div>
                        {/* <Switch
                          name={"tableMode"}
                          config={{
                            options: [
                              { id: 1, value: "Individual" },
                              { id: 2, value: "Aggregate" },
                            ],
                            id: "id",
                            value: "value",
                          }}
                          className="forecasts-table-switch ml-2"
                          formObj={tableMode}
                          onChange={(e) => {
                            if (props.forecastTableHistory.length) {
                              setMessageModelConfig({
                                ...messageModalConfig, title: "",
                                title: "Save Changes",
                                message: "You have unsaved forecasts, do you want to save them now or clear them?",
                                variant: ACTIONS.SAVE_CLEAR,
                                visible: true,
                                onClose: handleModel,
                                dialogClassName: 'save-changes-model'
                              })
                            } else {
                              setTableMode({ ...tableMode, value: tableMode.value === 1 ? 2 : 1 });
                            }
                          }}
                        /> */}
                      </div>
                    </div>
                    <Col>
                      <div className="right-align forecast_buttons_align">
                        <ForecastActions
                          hasEditAccess={pcdmAccess.writeAccess}
                          updateForecastChanges={updateForecastChanges}
                          addMissingEst={(selectedPcode) =>
                            onAddOrEditProjectClick(selectedPcode)
                          }
                        />
                      </div>
                    </Col>
                  </Row>

                  {/* {tableMode.value === 1 ?
                    <ForecastTable
                      hasEditAccess={pcdmAccess.writeAccess}
                      forecasts={showCompletedProjects ? completedForecastsFiltered : forecastsFiltered}
                      activeTab={activeTab}
                      productCode={productCode}
                      isShowCompletedProjectChecked={showCompletedProjects}
                      isAggregate={false}
                      tableID={'individual'}
                      startMonth={startMonth}
                      endMonth={endMonth}
                    />
                    :
                    <ForecastTable
                      hasEditAccess={pcdmAccess.writeAccess}
                      forecasts={showCompletedProjects ? completedForecastAggregate : forecastAggregate}
                      activeTab={activeTab}
                      productCode={productCode}
                      isShowCompletedProjectChecked={showCompletedProjects}
                      isAggregate={true}
                      tableID={'aggregate'}
                      startMonth={startMonth}
                      endMonth={endMonth}
                    />
                  } */}
                  <ForecastsNewTable
                    hasEditAccess={pcdmAccess.writeAccess}
                    forecastsAggregate={
                      showCompletedProjects
                        ? completedForecastAggregate
                        : forecastAggregate
                    }
                    forecastsIndividual={
                      showCompletedProjects
                        ? completedForecastsFiltered
                        : forecastsFiltered
                    }
                    activeTab={activeTab}
                    productCode={productCode}
                    isShowCompletedProjectChecked={showCompletedProjects}
                    // isAggregate={true}
                    // tableID={'aggregate'}
                    startMonth={startMonth}
                    endMonth={endMonth}
                  />
                </Col>
              </Row>
            </Col>
          </Row>
        </DataHandler>
      </Container>
      <MessageModal {...messageModalConfig} />
      {openProjectForm ? (
        <ProjectForm
          formVisible={openProjectForm}
          header={"Add Missing Estimates"}
          selectedProject={getSelectedProjectDetails(selectedPcode)}
          closeModal={(status, data, keepModal) =>
            onModalClose(status, data, keepModal)
          }
          formMode={PROJECT_ACTIONS.ADD_MISSING_ESTIMATES}
          {...sendOptions()}
        />
      ) : null}
      {showForecastReport ? (
        <ProjectForecastsForm
          showForecastReport={showForecastReport}
          setShowReportForm={setShowReportForm}
        />
      ) : null}
    </div>
  );
}

export const mapStateToProps = (state) => ({
  forecasts: state.ForecastsReducer.forecasts,
  forecastAggregate: state.ForecastsReducer.forecastAggregate,
  completedForecasts: state.ForecastsReducer.completedForecasts,
  completedForecastAggregate: state.ForecastsReducer.completedForecastAggregate,
  activeTab: state.CommonPCDMReducer.selectedTab,
  updateForecastChangesStatus: state.ForecastsReducer.updateForecastChangesStatus,
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
  forecastsCapacity: state.ForecastsReducer.forecastsCapacity,
  forecastDollar: state.ForecastsReducer.forecastDollar,
  // Add missing proj estimates
  estimateTypes: state.ProjectsReducer.estimateTypeOptions,
  projectType: state.ProjectsReducer.projectTypeOptions,
  estimationTimings: state.ProjectsReducer.estimationTimingOptions,
  fundings: state.ProjectsReducer.fundingOptions,
  investmentPortfolios: state.ProjectsReducer.investmentPortfolioOptions,
  deliveryPortfolios: state.ProjectsReducer.deliveryPortfolioOptions,
  projects: state.ProjectsReducer.projects,
  summary: state.SummaryReducer.summaryData.data,
});

export const mapDispatchToProps = (dispatch) => ({
  getForecasts: (productCode) => dispatch(getForecastsThunk(productCode)),
  getForecastsAggregate: (productCode) => dispatch(getForecastsAggregateThunk(productCode)),
  getForecastsCompleted: (productCode) => dispatch(getCompletedForecastsThunk(productCode)),
  getForecastsAggregateCompleted: (productCode) => dispatch(getCompletedForecastsAggregateThunk(productCode)),
  updateForecastChanges: (productCode, payload, callback) =>
    dispatch(updateForecastChangesThunk(productCode, payload, callback)),
  getForecastsCapacity: (productCode) => dispatch(getForecastsCapacityThunk(productCode)),
  // Add missing proj estimates
  getProjects: (productCode) => dispatch(getProjectsThunk(productCode)),
  getPCodes: () => dispatch(getPCodesThunk()),
  // getPortfolios: () => dispatch(getPortfoliosThunk()),
  getSummaryChart: (productCode) => dispatch(getSummaryChartThunk(productCode)),
  showNotification: (notification) => dispatch(addNotification(notification)),
  clearForecastChange: () => dispatch(clearForecastChange()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Forecasts));
