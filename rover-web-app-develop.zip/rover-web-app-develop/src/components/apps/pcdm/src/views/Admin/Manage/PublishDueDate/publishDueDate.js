import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import CustomButton from "../../../../components/forms/Button/button";
import { Edit } from "react-feather";
import DueDateFormModal from "../PublishDueDate/publishDueDateFormModal"
import "./publishdueDate.scss";
import { ACTIONS, MANAGE_PUBLISH_DUE_DATE } from "../../../../constants/action.constants";
import { addNotification } from "../../../../store/common.reducer";
import { ERROR_MSG } from "../../../../constants/message.contants";
import { getPublishDueDateThunk } from "../../../../store/admin.reducer";

export function PublishDueNote(props) {

  const { initialPublishDueDate, showNotification, updatedPublishDueDate, getPublishDueDate } = props;

  const [actualDueDate, setActualDueDate] = useState(6);
  const [superScriptText, setSuperScriptText] = useState("th");
  const [formOpen, setFormOpen] = useState(false);

  const editDueDate = () => {
    setFormOpen(true);
  };


  const onModalClose = (status, data, keepModal = false) => {
    if (status === MANAGE_PUBLISH_DUE_DATE.MODIFY_PUBLISH_DUE_DATE_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: MANAGE_PUBLISH_DUE_DATE.MODIFY_PUBLISH_DUE_DATE_SUCCESS_MSG,
      });
    } else if (status === MANAGE_PUBLISH_DUE_DATE.MODIFY_PUBLISH_DUE_DATE_ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
    }
    getPublishDueDate();
    setFormOpen(false);
  };

  useEffect(() => {
    if (initialPublishDueDate && initialPublishDueDate.data
      && initialPublishDueDate.data.workingDays) {
      setActualDueDate(initialPublishDueDate.data.workingDays)
    };
  }, [initialPublishDueDate, updatedPublishDueDate, formOpen]);

  useEffect(() => {
    if (parseInt(actualDueDate) === 1) {
      setSuperScriptText("st");
    } else if (parseInt(actualDueDate) === 2) {
      setSuperScriptText("nd");
    } else if (parseInt(actualDueDate) === 3) {
      setSuperScriptText("rd");
    } else {
      setSuperScriptText("th");
    }
  }, [actualDueDate]);

  return (
    <>
      <p className="custom-publish_duedate-msg"> ITPMs must publish on the
          <b className="custom-publish_duedate-date"> {actualDueDate}<sup>{superScriptText}</sup></b> business day of each month.
            <span>
          <CustomButton
            onClick={() => editDueDate()}
            title={"Click to edit publish due date"}
            className="team-link inline"
          >
            <span>EDIT</span>
            <Edit size="12" strokeWidth={3} />
          </CustomButton>
        </span>
      </p>
      <DueDateFormModal
        formOpen={formOpen}
        closePopupModel={onModalClose}
        dueDate={actualDueDate} />
    </>
  );
}
export const mapStateToProps = (state) => ({
  initialPublishDueDate: state.PCDMAdminReducer.getPublishDueDate,
  updatedPublishDueDate: state.PCDMAdminReducer.modifyPublishDueDate,
});

export const mapDispatchToProps = (dispatch) => ({
  getPublishDueDate: () => dispatch(getPublishDueDateThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PublishDueNote);
