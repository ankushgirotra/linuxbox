import React, { useState } from "react";
import { Row, Col } from "react-bootstrap";
import cookie from "react-cookies";
import axios from 'axios';
import moment from 'moment';
import FileDownloader from 'js-file-download';
import CustomButton, { BUTTON_VARIANTS } from "../../../components/forms/Button/button";
import "./PCDMReports.scss";


export default function AllocationReport() {
  const [progress, setProgress] = useState(false)
  const onSubmit = () => {
    const token = localStorage.getItem("token")
    setProgress(true)
    axios({
      // url: `https://rover-web-api-pcd-test.cfaa.azr.hcsctest.net/pcd/products/download/allocationReport`,
      url: `${cookie.load("ROVER_PCD_API")}/pcd/products/download/allocationReport`,
      method: 'GET',
      headers : {
        Authorization : token ? `Bearer ${token}` : ''
      },
      onDownloadProgress(progressEvent){
        // const progressValue = Math.round((progressEvent.loaded/progressEvent.total)*100);
        setProgress(true);
      },
      responseType: 'blob',
    }).then(response => {
      setProgress(false)
      // const url = window.URL.createObjectURL(new Blob([response.data]));
      // const link = document.createElement('a');
      // link.href = url;
      // link.target = "_blank";
      // link.setAttribute('download', `Allocation Report ${moment().format("YYYY.MM.DD")}.xlsx`);
      // document.body.appendChild(link);
      // link.click()
      // window.open(url, "_blank").focus()
      FileDownloader(response.data, `Allocation Report ${moment().format("YYYY.MM.DD")}.xlsx`)
    }).catch(error => {
      console.log(error)
      setProgress(false)
    })
  };
  return (
    <div className="pcdm-allocation-report">
      <Row>
        <Col sm={4} md={4} lg={4} xl={4}>
          <div className={`pcdm-btn-wrapper`}>
            <CustomButton variant={BUTTON_VARIANTS.BLUE_GOLD} size="md" loading = {progress} fluid={true} onClick={onSubmit}>
              Download Report
            </CustomButton>
          </div>
        </Col>
        <Col sm={{ offset: 1, span: 5 }} md={{ offset: 1, span: 5 }} lg={{ offset: 1, span: 5 }} xl={{ offset: 1, span: 5 }}>
          <div className={`pcdm-btn-wrapper`}>
            <div className='allocation-report-description'>This report will detail all resources who have a total allocation across PCDM that is greater than 100%</div>
          </div>
        </Col>
      </Row>
    </div>
  );
}
