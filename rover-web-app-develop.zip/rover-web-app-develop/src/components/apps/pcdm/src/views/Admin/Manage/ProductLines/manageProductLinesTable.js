import React, { useMemo, useEffect, useState } from "react";
import { connect } from "react-redux";
import DataGrid from "../../../../components/DataGrid/dataGrid";
import { PlusCircle } from "react-feather";
import CustomButton from "../../../../components/forms/Button/button";
import { check } from "../../../../services/validation";
import ProductLineFormModel from './productLineFormModel';
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import { PCDM_ADMIN_ACTIONS } from "../../../../constants/action.constants";
import '../../admin.scss';

export function ManageProductLines(props) {
  const { productLines } = props;
  const columns = useMemo(() => [
    {
      Header: (props) => productLineHead(),
      accessor: "portfolioName",
      Cell: ({ row: { original } }) => showProduct(original, "portfolioName"),
      disableFilters: true,
      disableSortBy: true,
    },
  ]);
  const showProduct = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() => onRowClickAddEdit(PCDM_ADMIN_ACTIONS.EDIT_PRODUCT_LINE, row)}
      >
        {row.portfolioName}
      </LinkExtended>
    );
  };
  const productLinesCheck = check({
    original: productLines,
    path: "data",
    checkEmpty: true,
    defaultReturnValue: [],
  });
  const [productLineData,setProductLineData] = useState([])
  useEffect(()=>{
    const productLineArray = productLines && productLines.data  ? productLines.data : null;
    if(productLineArray && typeof productLineArray === 'object') {
      productLineArray.sort((a,b)=>{
        let name1=a.portfolioName;
        let name2=b.portfolioName;
        if(name1<name2)
          return -1;
        if(name1>name2)
          return 1;
        return 0;
      });
      setProductLineData(productLineArray);
    } 
  },[productLines])

  const productLineHead = () => (
    <div className="add-product-line-head">
      <p>Product Line</p>
      <CustomButton
        onClick={(event) => {
          event.stopPropagation();
          onRowClickAddEdit(PCDM_ADMIN_ACTIONS.ADD_PRODUCT_LINE, {})
        }}
        title={"Click to add Product Line"}
        className="product-line-add-link"
      >
        <span className='mr-1'>ADD</span>
        <PlusCircle size="15" strokeWidth={3} />
      </CustomButton>
    </div>
  );
 
  const [formOpen, setFormOpen] = useState(false);
  const [currentRow, setCurrentRow] = useState(null);
  const [formMode, setFormMode] = useState(null);

  const onRowClickAddEdit = (editFlag, row) => {
    setFormMode(editFlag)
    setFormOpen(true)
    setCurrentRow(row);
  }
  const closeModel = (status, data, keepModal) => {
    setFormOpen(false);
    setCurrentRow(null);
  }
  return (
    <div className="manage-product-lines-container pcdm-scroll-vertical">
      <DataGrid
         onCellClick={(row, cell) => {
          onRowClickAddEdit(PCDM_ADMIN_ACTIONS.EDIT_PRODUCT_LINE, row);
        }}
        data={productLineData}
        columns={columns}
        noRowText={"Click + icon to start adding Product Line "}
        getRowClassName={(row) =>  "table-text-align"}
        getCellClassName={(cell) =>
          "table-text-align"
        }
      />
      <ProductLineFormModel 
        formOpen={formOpen}
        closePopupModel={closeModel}
        closeModal={props.closeModal}
        currentRow={currentRow}
        tableData={productLineData}
        setTableData={setProductLineData}
        formMode={formMode}
      />
    </div>
  );
}
export const mapStateToProps = (state) => ({
  productLines: state.ProductsReducer.productLines,
});

export const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(ManageProductLines);
