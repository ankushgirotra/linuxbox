import React, {  useState } from "react";
import { connect } from "react-redux";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../../components/forms/Button/button";
import { resetForecast } from "../../../store/forecast.reducer";
import { resetTeam } from "../../../store/teams.reducer";
import { resetProject } from "../../../store/projects.reducer";
import { resetSummary } from "../../../store/summary.reducer";
import { productLineSummaryReset } from "../../../store/productLine.reducer";
import { PCDM_ROUTES } from "../../../../../../app/Route/constants/pcdmRoutes.constants";
import { formatLanId } from "../../../services/lanId.service";
import { PlusSquare } from "react-feather";
import {
  PRODUCT_ACTIONS,
  PCDM_ADMIN_ACTIONS,
} from "../../../constants/action.constants";
import ManageProductsForm from "./ProductDelegatesForm";
import { addNotification } from "../../../store/common.reducer";
import { ACTIONS } from "../../../constants/action.constants";
import { ERROR_MSG } from "../../../constants/message.contants";
import "./Productdetails.scss";

export function ProductDetails(props) {
  const { productInfo, iiqRole, userParams, fromProductForm = false, shouldRedirectToProductLine = false } = props;
  const [showProductForm, setShowProductForm] = useState(false)
  const onExitIconClick = () => {
    if (props.forecastTableHistory.length && props.checkForecastChanges) {
      props.checkForecastChanges();
    } else {
      props.resetTeamStore();
      props.resetProjectStore();
      props.resetSummaryStore();
      props.resetForecastStore();
      props.resetProductLineStore();
      props.history.push(PCDM_ROUTES.ROUTE);
    }
  };
  const getFormattedLastModifiedDate = () => {
    const newDate = new Date(productInfo.lastModifiedDate)
    const time = newDate.toLocaleTimeString([],{hour:'2-digit', minute:'2-digit'});
    const date = newDate.toLocaleDateString();
    return date+" "+time;
  }
  const managePMDelegates = () => {
    setShowProductForm(true)
  };
  const getProductManagerName = () => {
    const username = formatLanId(userParams);
    if(fromProductForm){
      return <span>{productInfo.manager}</span>;
    }
    else if ((username === productInfo.lanId && iiqRole.PCDM.EDIT) || iiqRole.ADMIN) {
      return (
        <span>
          {productInfo.manager}
          <CustomButton
            onClick={managePMDelegates}
            title={"Manage Delegates"}
            className="manage-product-delegates"
            borderless={true}
            size="sm"
            variant={BUTTON_VARIANTS.ICON}
          >
            <PlusSquare size={15} strokeWidth={2} />
          </CustomButton>
        </span>
      );
    } else {
      return <span>{productInfo.manager}</span>;
    }
  };

  const redirectToProductLine = (e) => {
    if (e) {
      e.preventDefault();
    }
    props.resetTeamStore();
    props.resetProjectStore();
    props.resetSummaryStore();
    props.resetForecastStore();
    props.resetProductLineStore();
    props.history.replace(PCDM_ROUTES.getProdutLineRoute(props.productInfo.portfolioId));
  };

  const onModalClose = async (status, data, keepModal = false) => {
    if (status === ACTIONS.SUCCESS) {
      props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      setShowProductForm(false)
    } else if (status === ACTIONS.ERROR) {
      props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
      setShowProductForm(false)
    } else {
      setShowProductForm(false)
    }
  };
  return (
    <div className="product-information col-sm-12 col-md-12 col-lg-10">
      <div className="productName">
        <span className="name">{productInfo.name}</span>
        <span className="productCode">|&nbsp;{productInfo.productCode}</span>
        {/* <span className="icon"> */}
          {/* {( props.history &&
                  props.history.location.pathname.includes("pcdm")) ||
                (props.history && props.history.location.pathname.includes("product-line")) ? ( */}
          {!fromProductForm ? <CustomButton
            onClick={onExitIconClick}
            title={"Switch Product"}
            className="switch-product-link"
            borderless={true}
            size="sm"
            variant={BUTTON_VARIANTS.ICON}
          >
            <span className="lnr lnr-exit"></span>
          </CustomButton> : null}
          {/* ) : null} */}
        {/* </span> */}
      </div>
      <div className="info-part2">
        <div className="productLine">
          <span className="info-label">Product Line:&nbsp;</span>
          {shouldRedirectToProductLine ?
            <span
              className="info-value productLine-hyperlink"
              title={"Click to visit Product Line view"}
              onClick={redirectToProductLine}>
              {productInfo.portfolio}
            </span> :
            <span className="info-value">{productInfo.portfolio}</span>
          }
        </div>
        <div className="productManager">
          <span className="info-label">Product Manager:&nbsp;</span>
          <span className="info-value">{getProductManagerName()}</span>
        </div>
        {/* <div className="lastModified">
          <span className="info-label">Last Updated&nbsp;&nbsp;:&nbsp;</span>
                <span className="info-value">{getFormattedLastModifiedDate()}</span>
        </div> */}
      </div>
      {showProductForm ? (
          <ManageProductsForm
            formVisible={showProductForm}
            selectedProduct={productInfo}
            formMode={PRODUCT_ACTIONS.PRODUCT_MANAGER_VIEW}
            closeModal={(status, data, keepModal) =>
              onModalClose(status, data, keepModal)
            }
          />
        ) : null}
    </div>
  );
}

export const mapStateToProps = (state) => ({
  forecastTableHistory: state.ForecastsReducer.forecastTableHistory,
  iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
  userParams: state.AuthReducer.user,
});
export const mapDispatchToProps = (dispatch) => ({
  resetTeamStore: () => dispatch(resetTeam()),
  resetProjectStore: () => dispatch(resetProject()),
  resetSummaryStore: () => dispatch(resetSummary()),
  resetForecastStore: () => dispatch(resetForecast()),
  resetProductLineStore: () => dispatch(productLineSummaryReset()),
  showNotification: (notification) => dispatch(addNotification(notification)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProductDetails);
