export const searchPcode = (list, valueList, keyToMatch, keyToUse) => {
    let filterPayload = '';
    let selectedlist = [];
    valueList.forEach((el) => {
        el.children.forEach((value) => {
            let prod = list.find((el1) => el1.name === value && el.id === el1.portfolio && el1.active && !el1.testProduct)
            filterPayload += `&productCode=${prod.productCode}`
            selectedlist.push(prod)
        })
    })
    const newList = list.filter(el => el.active)
    if(selectedlist.length === newList.length){
        return ""
    }
    return filterPayload;
}

export const selectedProjectCodes = (list) => {
    console.log(list)
    let selectedPcodes = '';
    if(!list){
        return ""
    }
    else if( list.length === 0){
        return ""
    }else{
        list.forEach(el => {
            selectedPcodes +=`&pcode=${el.value}`
        })
        return selectedPcodes;
    }
}