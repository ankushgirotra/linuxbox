import React from "react";
import { PROJECT_ACTIONS } from "../../../../constants/action.constants";
import NavBarCapsule from "../../../../components/Navigation/navBars";
import "./projectFormHeader.scss";

export default function ProjectFormHeader({ onHeaderChange, formMode }) {

  return formMode === PROJECT_ACTIONS.ADD_PROJECT ? (
    <h4 className={`text-custom`}>Add Project</h4>
  ) : (
    <NavBarCapsule
      onClick={onHeaderChange}
      customContainerClassName="edit-project-form-header"
      selected={formMode}
      navOptions={[
        { key: PROJECT_ACTIONS.EDIT_PROJECT, value: "Edit Project" },
        { key: PROJECT_ACTIONS.PROJECT_COMMENT, value: "Comments" },
      ]}
    />
  );
}
