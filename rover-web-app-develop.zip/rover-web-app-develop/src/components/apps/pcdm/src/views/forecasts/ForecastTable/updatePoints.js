import React, { useState, useRef } from "react";
import { Popover, OverlayTrigger } from "react-bootstrap";
import TextField from "../../../components/forms/textField/textField";
import CustomButton from "../../../components/forms/Button/button";
import { ERROR_MSG } from "../../../constants/message.contants";
import { X } from "react-feather";

export default function UpdatePoints({
  content,
  point,
  updatePoints,
  payload,
}) {
  const [formControls, setFormControls] = useState({
    points: {
      value: point,
      error: false,
      errorMsg: "",
      disabled: false,
    },
  });
  const popoverRef = useRef();
  const onPointsChange = (event) => {
    setFormControls({
      ...formControls,
      points: {
        ...formControls.points,
        error: event.error,
        value: event.value,
        errorMsg: event.errorMessage,
      },
    });
  };
  const prepareOverlay = () => {
    setFormControls({
      points: {
        value: point,
        error: false,
        errorMsg: "",
        disabled: false,
      },
    });
  };
  const checkField = () => {
    if (
      formControls.points.value !== null &&
      formControls.points.value !== undefined
    ) {
      if (Number(formControls.points.value) === Number(point)) {
        setFormControls({
          ...formControls,
          points: {
            ...formControls.points,
            error: true,
            errorMsg: "Please change the value",
          },
        });
      } else {
        updatePoints({ old: point, new: formControls.points }, payload);
        popoverRef.current.handleHide();
      }
    } else {
      setFormControls({
        ...formControls,
        points: {
          ...formControls.points,
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      });
    }
  };
  const popover = (
    <Popover id="forecast-points-update">
      <Popover.Title as="h4" style={{ textAlign: "center" }}>
        Enter Forecast
        <X
          size={17}
          strokeWidth={3}
          onClick={() => popoverRef.current.handleHide()}
          className="forecast-update--close-icon"
        />
      </Popover.Title>
      <Popover.Content>
        <TextField
          name="points"
          label={"Points"}
          formObj={formControls.points}
          isRequired={formControls.points.required}
          type="number"
          onFocus={(e) => e.target.select()}
          onChange={onPointsChange}
        />
        <CustomButton
          key={1}
          onClick={checkField}
          title={"Click to see the changes"}
          className="forecast-update-link inline"
        >
          <span>Calculate Cost</span>
        </CustomButton>
      </Popover.Content>
    </Popover>
  );
  return (
    <OverlayTrigger
      ref={popoverRef}
      trigger="click"
      placement="auto"
      overlay={popover}
    >
      <div onClick={() => prepareOverlay()}>{content}</div>
    </OverlayTrigger>
  );
}
