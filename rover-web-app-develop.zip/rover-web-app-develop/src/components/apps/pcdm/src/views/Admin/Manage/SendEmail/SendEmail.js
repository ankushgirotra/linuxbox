import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import CustomButton, { BUTTON_VARIANTS } from "../../../../components/forms/Button/button";
import Checkbox from "../../../../components/forms/Checkbox/checkbox";
import TextField from "../../../../components/forms/textField/textField";
import TextArea from "../../../../components/forms/TextArea/textArea";
import { ACTIONS } from "../../../../constants/action.constants";
import { addNotification } from "../../../../store/common.reducer";
import { ERROR_MSG } from "../../../../constants/message.contants";
import { sendEmailThunk } from "../../../../store/admin.reducer";
import ErrorMsg from "../../../../components/forms/errorMsg/errorMsg";
import "./sendEmail.scss";
import { DATA_STATUS } from "../../../../constants/service.constant";

const INITIAL_STATE = {
  edited: false,
  error: false,
  errorMessage: "",
  errorDetail: "",
  subject: {
    value: "",
    error: false,
    errorMsg: "",
    required: true,
  },
  body: {
    value: "",
    error: false,
    errorMsg: "",
    required: true,
  },
  checkboxes: {
    error: false,
    errorMsg: "",
  },
};
export function SendEmail(props) {
  const [productManagersFlag, setProductMangersFlag] = useState(false);
  const [delegatesFlag, setDelegatesFlag] = useState(false);
  const [formControls, setFormControls] = useState({...INITIAL_STATE});

  useEffect(()=>{
    if(props.selectedTab != 7){
      setFormControls({...INITIAL_STATE})
      setProductMangersFlag(false)
      setDelegatesFlag(false)
    }
  },[props.selectedTab])
  const onInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setFormControls({
      ...formControls,
      edited: true,
      error: false,
      [name]: {
        ...formControls[name],
        error: false,
        value: value,
      },
    });
  };
  const onSendEmail = (action, data) => {
    if(action == "SEND_EMAIL_SUCCESS"){
      props.showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Email sent Successfully",
      });
      setFormControls({...INITIAL_STATE})
      setProductMangersFlag(false)
      setDelegatesFlag(false)
    }else {
      props.showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: ERROR_MSG.COMMON_ERR,
      });
      setFormControls({...INITIAL_STATE})
      setProductMangersFlag(false)
      setDelegatesFlag(false)
    }
  }
  const onSubmit = (e) => {
    e.preventDefault();
    if((productManagersFlag || delegatesFlag) && formControls.subject!="" && formControls.body!=""){
      let payload = {
        subject : formControls.subject.value,
        body : formControls.body.value,
        emailProductManager : productManagersFlag,
        emailDelegate : delegatesFlag,
      }
      props.sendEmail(payload, onSendEmail)
    }else{
      setFormControls({
        ...formControls,
        subject: {
          ...formControls.subject,
          error: formControls.subject.value ? false : true,
          errorMsg: formControls.subject.value ? "" : "Please fill out this field",
        },
        body: {
          ...formControls.body,
          error: formControls.body.value ? false : true,
          errorMsg: formControls.body.value ? "" : "Please fill out this field",
        },
        checkboxes: {
          ...formControls.checkboxes,
          error: productManagersFlag || delegatesFlag ? false : true,
          errorMsg: productManagersFlag || delegatesFlag ? "" : "Please select atleast 1 Recipient",
        },
      });
    }
  }
  return (
    <React.Fragment>
      <div className="send-email-form pcdm-form-new">
        <div className="custom-modal__header">
          <h4>Send Email</h4>
        </div>
        <div className="custom-modal__body">
          <form className="pcdm-form">
            <div className="pcdm-form__form-group ">
              <div className="pcdm-form__form-group-field checkboxes_class  ">
                <label className="pcdm-head required">Recipients: </label>
                <div className="email-checkboxes">
                  <Checkbox
                    label={"Product Managers"}
                    checked={productManagersFlag}
                    className={"email_checkbox"}
                    onChange={() => {
                      setProductMangersFlag(!productManagersFlag)
                      setFormControls({
                        ...formControls,
                        checkboxes:{
                          error:false,
                          errorMsg:""
                        }
                      })
                    }}
                  />
                </div>
                <div className="email-checkboxes">
                  <Checkbox
                    label={"Delegates"}
                    checked={delegatesFlag}
                    className={"email_checkbox"}
                    onChange={() => {
                      setDelegatesFlag(!delegatesFlag)
                      setFormControls({
                        ...formControls,
                        checkboxes:{
                          error:false,
                          errorMsg:""
                        }
                      })
                    }}
                  />
                </div>
              </div>
              {formControls.checkboxes.error ? <ErrorMsg message={formControls.checkboxes.errorMsg} /> : null}
              <div className="pcdm-form__form-group-field">
                <TextField
                  name="subject"
                  label={"Subject"}
                  formObj={formControls.subject}
                  isRequired={formControls.subject.required}
                  type="text"
                  onChange={onInputChange}
                />
              </div>
              <div className="pcdm-form__form-group-field">
                <TextArea
                  name="body"
                  label={"Body"}
                  formObj={formControls.body}
                  isRequired={formControls.body.required}
                  type="text"
                  rows={5}
                  onChange={onInputChange}
                />
              </div>
            </div>
          </form>
        </div>
        <div className="custom-modal__footer custom-modal__footer-top-border">
          <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
            <CustomButton
              variant={BUTTON_VARIANTS.PRIMARY}
              size="md"
              onClick={onSubmit}
            >
              Send
            </CustomButton>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}
export const mapStateToProps = (state) => ({
  sendEmailStatus : state.PCDMAdminReducer.sendEmailStatus,
});

export const mapDispatchToProps = (dispatch) => ({
  sendEmail: (payload, callback) => dispatch(sendEmailThunk(payload, callback)),
  showNotification: (notification) => dispatch(addNotification(notification)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SendEmail);
