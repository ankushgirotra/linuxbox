import React from "react";
import { MONTHS } from "../../../timesheet/constants/timesheet.constants";

export const getStartDateTooltipMsg = (month, year) => {
  return (
    <div>
      This new start date does not account for actuals that were already
      received for{" "}
      <b>
        {month} {year}
      </b>
      &nbsp;for this project. Please keep the start date in accordance with the
      actual work performed on the project. The start date should be set within
      or before{" "}
      <b>
        {month} {year}
      </b>
      .
    </div>
  );
};

export const getEndDateTooltipMsg = (month, year) => {
  return (
    <div>
      This new end date does not account for actuals that were already received
      for{" "}
      <b>
        {month} {year}
      </b>
      &nbsp;for this project. Please keep the end date in accordance with the
      actual work performed on the project. The end date should be set within or
      after{" "}
      <b>
        {month} {year}
      </b>
      .
    </div>
  );
};

export const getStartEndDateTooltipMsg = (month, year, month1, year1) => {
  return (
    <div className="startdate_enddate_tooltip">
      <div className="text-justify">
        This new start date does not account for actuals that were already
        received for{" "}
        <b>
          {month} {year}
        </b>
        &nbsp;for this project. Please keep the start date in accordance with
        the actual work performed on the project. The start date should be set
        within or before{" "}
        <b>
          {month} {year}
        </b>
        .
      </div>
      <br />
      <div className="text-justify">
        This new end date does not account for actuals that were already
        received for{" "}
        <b>
          {month1} {year1}
        </b>
        &nbsp;for this project. Please keep the end date in accordance with the
        actual work performed on the project. The end date should be set within
        or after{" "}
        <b>
          {month1} {year1}
        </b>
        .
      </div>
    </div>
  );
};

export const getDeleteTooltipMsg = (month, year) => {
  return (
    <div>
      This project already received actuals for{" "}
      <b>
        {month} {year}
      </b>, it cannot be deleted since work has been completed. If the
      project ended early, please edit the end date and click Complete Project.
    </div>
  );
};

export const getactualStartDateTooltipMsg = (month, year) => {
  return (
    <div>
      This new start date does not account for actuals that were already
      received for{" "}
      <b>
        {month} {year}{" "}
      </b>
      &nbsp;for this project. Please keep the start date in accordance with the
      actual work performed on the project. The start date should be set within
      or before{" "}
      <b>
        {month} {year}{" "}
      </b>
      .<p>Do you wish to continue?</p>
    </div>
  );
};

export const getactualEndDateTooltipMsg = (month, year) => {
  return (
    <div>
      This new end date does not account for actuals that were already received
      for{" "}
      <b>
        {month} {year}{" "}
      </b>
      &nbsp;for this project. Please keep the end date in accordance with the
      actual work performed on the project. The end date should be set within or
      after{" "}
      <b>
        {month} {year}{" "}
      </b>
      .<p>Do you wish to continue?</p>
    </div>
  );
};

export const getTeamsEndDateTooltipMsg = () => {
  return (
    <div style={{textAlign : "justify"}}>
      This team's end date is approaching. Once the end date passes, the team will move 
      to the <b> ROLLED OFF TEAMS </b> list and you will have one month to extend the team's end date 
      before it is permanently archived. Please edit the end date if necessary.
    </div>
  )
}
export const getactualStartEndDateTooltipMsg = (
  startmonth,
  startyear,
  endmonth,
  endyear
) => {
  return (
    <div>
      <h5>Start Date:</h5>
      This new start date does not account for actuals that were already
      received for{" "}
      <b>
        {startmonth} {startyear}{" "}
      </b>
      &nbsp;for this project. Please keep the start date in accordance with the
      actual work performed on the project. The start date should be set within
      or before{" "}
      <b>
        {startmonth} {startyear}{" "}
      </b>
      .<p> </p>
      <h5>End Date:</h5>
      This new end date does not account for actuals that were already received
      for{" "}
      <b>
        {endmonth} {endyear}{" "}
      </b>
      &nbsp;for this project. Please keep the end date in accordance with the
      actual work performed on the project. The end date should be set within or
      after{" "}
      <b>
        {endmonth} {endyear}{" "}
      </b>
      .<p>Do you wish to continue?</p>
    </div>
  );
};

export const getEstimateTypeTooltipMessage = () => {
  return (
    <div className="text-justify">
      <b>Intake</b> estimates occur before project planning and before the effort has a P-Code.{" "}
      <b> Execution</b>{" "}estimates happen after project planning and requires a P-Code for 
      project funded efforts. This field must be set to{" "}<b>Execution</b>{" "}in order for the 
      project to appear on the Forecasts table.
    </div>
  );
};


