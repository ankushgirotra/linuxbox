export const ERR_CODES = {
  ALREADY_EXIST: "ALREADY_EXIST",
  LESS_THAN: "LESS_THAN",
  GREATER_THAN: "GREATER_THAN",
};
export const ERROR_MSG = {
  ROLE_RATE_EXCEED_LENGTH: "Rate must be a max of 10 char",
  RESOURCE_NAME_ALLOW_CHAR: "Must begin and end with alphabets. May contain hyphens and spaces.",
  ROLE_NAME_ALLOW_CHAR: "Only alphanumerics, spaces, hyphens, and slashes are allowed",
  P_CODE_ALLOW_CHAR: "Please enter alphanumeric characters only. May include hyphens",
  ALREADY_EXIST: "An estimate for this project already exists, please edit the existing project",
  PROJECT_END_DATE_ERROR: "Planned End date should be after the Planned Start date ",
  REQUIRED_FIELD: "Please fill out this field",
  COMMON_ERR: "Please check this field",
  COMMON_FORM_ERR: "Error in submitting the form",
  PRODUCT_NAME_ERROR: "Allowed only alphabets",
  PUBLISH_DUE_DATE: "Allowed only Numbers",
  PUBLISH_DUE_DATE_RANGE: "Numbers must not exceed 15",
  HOLIDAY_NAME_ALLOW_CHAR: "Only alphanumerics, spaces, hyphens, dots and slashes are allowed",
  HOLIDAY_NAME_ALREADY_EXIST: " Holiday Name Already Exists",
  DOWNLOAD_ERROR: "Unable to download. Please try Later"
  // PRODUCT_NAME_ERROR: 'Allowed only alphabets. Should start with "PRODUCT"',
};

export const TECHNOLOGY_MESSAGES = {
  SAVE_TECHNOLOGY_SUCCESS: "Technology saved successfully",
  UPDATE_TECHNOLOGY_SUCCESS: "Technology updated successfully",
  SAVE_TECHNOLOGY_ERROR: "Error in saving technology",
  DELETE_TECHNOLOGY_SUCCESS: "Technology deleted successfully",
  DELETE_TEAM_PROMPT_NO: "Are you sure you want to delete the team?",
};

export const TEAM_MESSAGES = {
  SAVE_TEAM_SUCCESS: "Team saved successfully",
  COPY_TEAM_SUCCESS: "Team copied successfully",
  UPDATE_TEAM_SUCCESS: "Team updated successfully",
  SAVE_TEAM_ERROR: "Error in saving team",
  DELETE_TEAM_SUCCESS: "Team deleted successfully",
  SAVE_ROLE_SUCCESS: "Role added to the team successfully",
  UPDATE_ROLE_SUCCESS: "Role updated successfully",
  SAVE_ROLE_ERROR: "Error in saving role",
  DELETE_ROLE_SUCCESS: "Role deleted successfully",
  EXTEND_TEAM_SUCCESS: "Team's End date extended successfully",
  DELETE_TEAM_PROMPT_MESSAGE: "Did this team complete at least one sprint?",
  DELETE_TEAM_PROMPT_YES: [
    "Since this team completed work, please do not delete the team so PCDM can track historical capacity.",
    "Please edit the end date to reflect the team’s last day of work so the team can be archived in the “Rolled-Off Teams” list for historical data.",
  ],
  DELETE_TEAM_PROMPT_NO: [
    "Deleting this team means it never performed work and will remove it from your capacity on the Summary page.",
    "Are you sure you want to delete the team?",
  ],
};

export const PROJECT_MESSAGES = {
  SAVE_PROJECT_SUCCESS: "Project saved successfully",
  UPDATE_PROJECT_SUCCESS: "Project updated successfully",
  SAVE_PROJECT_ERROR: "Error in saving Project",
  DELETE_PROJECT_SUCCESS: "Project deleted successfully",
  SAVE_PROJECT_COMMENT_SUCCESS: "Comment added successfully",
  COMPLETE_PROJECT_SUCCESS: "Project marked as complete successfully",
  COMPLETE_PROJECT_ED_DT_FUTURE:
    "Project cannot be completed until end date. Please edit the end date and story points if necessary",
  COMPLETE_PROJECT_ST_DT_FUTURE: "A project that has not yet started cannot be marked completed",
  COMPLETE_PROJECT_CONFIRM: "Has your product's work on this project been completed?",
  DELETE_PROJECT_PROMPT: [
    "Deleting this project means no work was completed for the project and historical demand data can be removed from the summary page.",
    "Are you sure you want to delete the project?",
  ],
  SAVING_PROJECT_PROMPT: [
    "When a project moves to Execution, you are establishing a baseline budget estimate for the project.",
  ],

  EDITING_POINTS_PROMPT: [
    "Editing the story points for a project in execution will change your baseline budget estimate",
  ],
  EXECUTION_TYPE_LOCKED_ERROR: "Projects in Execution cannot revert back to Intake",
  EXECUTION_TYPE_PCODE_ERROR: "P-code cannot be edited once a project is in Execution",
  EXECUTION_TYPE_PROJECT_NAME_ERROR: "Project Name cannot be edited once a project is in Execution",
  REOPEN_PROJECT_MESSAGE:
    "Completed Projects can be Re-Opened. Please click below button to Re-open this Project",
};

export const TOOL_TIP_MESSAGE = {
  PRODUCT_LINE_VIEW:
    "Click here to view the aggregated capacity & demand summary for a full Product Line",
  NO_TOOL_TIP: "",
  SPRINT_HOURS:
    "This calculation assumes a 45-hour work week for offshore contractors and a 40-hour work week for all other resource types.",
  AVG_COST_PER_POINT:
    "This calculation includes all active teams (that have not yet rolled off) with at least one saved role.",
  ROLLED_OFF_TEAMS:
    "All teams with end dates that have already passed will appear in this list. If a team appears in this list because the end date needs to be extended, you have 30 days after the end date of the team to extend it and reactivate the team.",
  //Roles Tool Tip Messages
  SCRUM_MASTER_NEW:
    "This field will now be connected to real PeopleSoft records so we can track scrum master allocation across product teams. Please edit this team and select the scrum master / process lead from the new field.",
  RESOURCE_TYPE: [
    "Employee = 40 hours per week",
    "Near-shore Contractor = 40 hours per week",
    "Onshore Contractor = 40 hours per week",
    "Offshore Contractor = 45 hours per week",
  ],
  ALLOCATION:
    "Though allocations may vary, a fully allocated employee is typically allocated at 80%, whereas a fully allocated contractor is typically allocated at 100%.",

  //ProjectEstimate Tool tip message
  FUNDING: 'When the estimate moves to Execution, this field will default to "Funded"',
  BASELINE_ESTIMATES: [
    "The Baseline Budget for this project reflects the estimated cost at the time this project estimate moved to ",
    "Execution",
    " status. It will only change if the scope of the project is changed and if story points are edited.",
  ],
  ESTIMATE_TYPE: [
    {
      title: "Intake Estimates",
      points: [
        "Happen before project planning",
        "Allow for a +/-50% margin of error",
        "No P-code is required",
      ],
    },
    {
      title: "Execution Estimates",
      points: [
        "Happen after project planning",
        "Allow for a +/- 20% margin of error",
        'Spark P-Code is required for work that is not Product Core (select "Product Core" from the P-Code/Core dropdown if the estimate is for Product Core work)',
        "Baseline Budget Estimate (used on Forecast page) is established",
      ],
    },
    {
      note: {
        title: "NOTE",
        points: [
          "Projects in Execution cannot revert back to Intake, and the P-Code & Project Name can no longer be edited",
        ],
      },
    },
  ],
  PROJECT_TYPE:"All efforts with a P-Code (formerly labeled Transform or Grow) are considered Project Funded, and all efforts without a P-Code (formerly labeled Sustain) are considered Product Core.",

  EST_HRS:
    "This field estimates the approximate number of hours it will take to complete your scope for each project. This calculation is dynamic and will update as project details are edited or as any variables on the Team Composition page change.",
  EST_COST:
    "This field estimates the approximate cost of the scope for each project. This calculation is dynamic and will update as project details are edited or as any variables on the Team Composition page change.",
};
export const CONSTRAINT_CAPACITY_STATUS = {
  LOW: "Low",
  MED_LOW: "Med/Low",
  MEDIUM: "Medium",
  HIGH: "High",
  DEFAULT: "DEFAULT",
};

export const CONSTRAINT_CAPACITY_ICON_COLOR = {
  LOW: "rgb(0, 175, 80)",
  MED_LOW: "rgb(141, 212, 74)",
  MEDIUM: "rgb(255, 254, 0)",
  HIGH: "rgb(255, 192, 0)",
  DEFAULT: "rgb(0, 0, 0)",
};

export const CONSTRAINT_CAPACITY_VALUE = {
  LOW: 10,
  MED_LOW: 20,
  MEDIUM: 30,
  HIGH: 40,
  DEFAULT: 0,
};
export const INFO_MESSAGES={
  ROLE:'(only add roles who will charge to the PRD Code)'
}

export const NO_DATA_MSG = {
  NO_FORECAST:
    "There are no projects currently in Execution. Please set the Estimate Type to Execution for a project estimate in order for it to appear here on the Forecasts page.",
};

export const ADMIN_MANAGE_PRODUCT ={
  SUBMIT : "Submit",
  SOFTDELETE: "softDelete",
  DEACTIVATE : "Deactivate",
  REACTIVATE : "Activate",
  ACTIVATE_MESSAGE: "Product Activated successfully",
  DEACTIVATE_MESSAGE : "Product Deactivated successfully"
};

export const ADMIN_MANAGE_HOLIDAYS = {
  ADD_HOLIDAY_SUCCESS_MSG: "Holiday Added Successfully",
  ADD_HOLIDAY_ERROR_MSG: "Error in Adding the Holiday",
  EDIT_HOLIDAY_SUCCESS_MSG: "Holiday Updated Successfully",
  DELETE_HOLIDAY_SUCCESS_MSG: "Holiday Deleted Successfully",
  DELETE_HOLIDAY_ERROR_MSG: "Error in Deleting the Holiday",
}
