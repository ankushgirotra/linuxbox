export const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export const PCDM_TABS = {
  TEAM_COMPOSITION: "TEAM_COMPOSITION",
  PRODUCT_ENGINEERING: "PRODUCT_ENGINEERING",
  PROJECT_ESTIMATES: "PROJECT_ESTIMATES",
  SUMMARY: "SUMMARY",
  FORECASTS: "FORECASTS",
};
export const TITLE = {
  PCDM: "Product Capacity & Demand Management",
  RRC: "Requests",
  SOG: "Supplier Operational Governance",
  SUITE: "Suite",
  RM_SUITE: "Resource Management Analytics",
  SKILLS_CENTRAL: "Skills Central",
  TIMESHEET: "Timesheet",
  VENDOR_PORTAL: "Vendor Resource Management",
  TD360: "Technical Delivery 360"
};
export const LOCALE = {
  US: "en-US",
};
export const CURRENCY = {
  USD: "USD",
};