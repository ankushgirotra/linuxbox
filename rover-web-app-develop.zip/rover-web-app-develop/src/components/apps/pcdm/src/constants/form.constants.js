import moment from "moment";
export const PRODUCT_LINE_FORM_DEFAULT = {
  value: "",
  error: false,
  errorMsg: "",
  disabled: false,
  readOnly: false,
  required: false,
  edited: false,
}
export const FORM_CONTROL_DEFAULT = {
  value: "",
  error: false,
  errorMsg: "",
  disabled: false,
  readOnly: false,
  required: false,
  min: "",
  max: "",
  edited: false,
};
export const TEAM_FORM_CONST = {
  id: 0,
  name: "",
  methodology: "",
  sprintLength: "",
  sprintVelocity: 0,
  scrumMaster: "",
  startMonth: "",
  endMonth: "",
  hoursPerSprint: "",
  costPerSprint: "",
  hoursPerPoint: "",
  costPerPoint: "",
  lastUpdated: "",
  productId: "",
};
export const SPRINT_OPTIONS = [
  {
    id: 1,
    desc: "1 week",
  },
  {
    id: 2,
    desc: "2 weeks",
  },
  {
    id: 3,
    desc: "3 weeks",
  },
  {
    id: 4,
    desc: "4 weeks",
  },
];
export const RESOURCE_OPTIONS = [
  {
    id: 1,
    desc: "Employee",
    value: "Employee",
  },
  {
    id: 2,
    desc: "Onshore Contractor",
    value: "Onshore"
  },
  {
    id: 3,
    desc: "Offshore Contractor",
    value: "Offshore"
  },
  {
    id: 4,
    desc: "Near-shore Contractor",
    value: "Near-Shore"
  },
];

export const RESOURCE_TYPE ={
  EMPLOYEE:"Employee" ,
  ONSHORE_CONTRACTOR :"Onshore Contractor",
  OFFSHORE_CONTRACTOR :"Offshore Contractor",
  NEARSHORE_CONTRACTOR : "Near-shore Contractor",
}
export const MIN_SPRINT_VELOCITY = 0;
export const MAX_SPRINT_VELOCITY = 999999;
export const PROD_NAME_REG = /[a-zA-Z]{1,}[-/,.()& a-zA-Z0-9]*$/;
export const ROLE_NAME_REG = /^[a-z][a-z]*(?:[-\s]{1,10}[a-z]+)*$/i;
export const AD_ROLE_REG = /^[A-Za-z0-9-/\\–\s]*$/; // Allow alphanumeric, space, slashes, hyphen
export const P_CODE_REGEX = /^[a-z0-9][a-z0-9]*(?:[-]{1,10}[a-z0-9]+)*$/i;
export const DEFAULT_SPRINT_OPTION_ID = "2 weeks";
export const DEFAUL_RATE_FOR_DAS = { roleIds: [7, 8], value: 97 };
export const DEFAULT_RATE_FOR_NON_DAS = 75;
export const MONTH_DATE_YEAR_FORMAT = "MM/DD/YYYY";
export const MONTH_YEAR_FORMAT = "MMM, yyyy";
export const PUBLISH_DUE_DATE = "^[0-9]+$";
export const PUBLISH_DUE_DATE_RANGE = "^(0[1-9]|[1-9]|1[0-5])$";
export const HOLIDAY_NAME_REG = /^[A-Za-z0-9-/,.()& \\–\s]*$/; 

export const TEAM_START_DATE_MIN = moment().subtract(10, "years").toDate(); /*  moment().subtract(6, "month").toDate(); */
export const TEAM_START_DATE_MAX = moment().add(10, "years").toDate();
export const TEAM_END_DATE_MIN = moment().subtract(10, "years").toDate();
export const TEAM_END_DATE_MAX = moment().add(10, "years").toDate();

export const DB_DATE_FORMAT = "YYYY-MM-DD HH:mm:ss.SSS";
export const FORM_DATE_FORMAT = "MM/DD/YYYY";
export const MIN_DATE_PRJ = moment().subtract(5, "month").format(FORM_DATE_FORMAT);
export const MAX_DATE_PRJ = moment().add(11, "month").format(FORM_DATE_FORMAT);
export const EST_TYPE_PCODE = "Execution";
export const STORY_PTS_MIN = 1;
export const STORY_PTS_MAX = 2147483647;
export const DOLLAR_DEFAULT = 0.0;

//Project Constants

export const PRODUCT_CORE="Product Core";
export const PROJECT_FUNDED="Project Funded";
export const PROJECT_TYPE_FUNDED = "Funded";

export const PROJECT_OPTIONS = [
  {
    id: 1,
    desc: "Project Funded",
    value: "Project",
  },
  {
    id: 2,
    desc: "Product Core",
    value: "Core"
  },
];

