import moment from "moment";

export const DEFAULT_HEIGHT = 400;
export const DEFAULT_WIDTH = 750;
export const CARTESIAN_GRID_COLOR = "#f5f5f5";
export const DEFAULT_LINE_STROKE_COLOR = "#162955";
export const DEFAULT_BAR_FILL_COLOR = "#ff7300";
export const CAPACITY_DEMAND_MIN_DATE = moment().subtract(5, 'month').startOf("month").format("MMM YYYY");
export const CAPACITY_DEMAND_MAX_DATE = moment().add(6, 'month').startOf("month").format("MMM YYYY");