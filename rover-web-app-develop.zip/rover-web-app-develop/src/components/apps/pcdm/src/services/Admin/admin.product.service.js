import { SAVE_PRODUCT_SUCCESS, SAVE_PRODUCT_ERROR, ADD_PRODUCT_SUCCESS, ADD_PRODUCT_ERROR } from "../../store/products.reducer";
import { ACTIONS } from "../../constants/action.constants";
import { check } from "../validation";
import { ERROR_MSG, ERR_CODES } from "../../constants/message.contants";
import {
  PROD_NAME_REG, PUBLISH_DUE_DATE,
  PUBLISH_DUE_DATE_RANGE,
  HOLIDAY_NAME_REG,
} from "../../constants/form.constants";
import { checkLanIdFormat } from "../../../../../../services/auth.services";
import { ADMIN_MANAGE_PRODUCT } from "../../constants/message.contants";

export const handleProductAPIResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_PRODUCT_SUCCESS || responseType === SAVE_PRODUCT_ERROR) {
    return handleSaveResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_PRODUCT_SUCCESS) {
    const propsToParent = {
      message: "Product Updated successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleAddProductAPIResponse = (props, state, responseType, responseData) => {
  if (responseType === ADD_PRODUCT_SUCCESS || responseType === ADD_PRODUCT_ERROR) {
    return handleAddResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleAddResponse = (props, state, responseType, responseData) => {
  if (responseType === ADD_PRODUCT_SUCCESS) {
    const propsToParent = {
      message: "Product Added successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleSoftDeleteAPIResponse = (props, state, responseType, responseData, requestType) => {
  if (responseType === SAVE_PRODUCT_SUCCESS || responseType === SAVE_PRODUCT_ERROR) {
    return handleSoftDeleteResponse(props, state, responseType, responseData, requestType);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleSoftDeleteResponse = (props, state, responseType, responseData, requestType) => {
  if (responseType === SAVE_PRODUCT_SUCCESS) {
    const propsToParent = {
      message: requestType === ADMIN_MANAGE_PRODUCT.REACTIVATE ?
        ADMIN_MANAGE_PRODUCT.ACTIVATE_MESSAGE : ADMIN_MANAGE_PRODUCT.DEACTIVATE_MESSAGE
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

const checkErrorPath = (response) => {
  const { flag, value } = check({
    path: "data.errors",
    original: response,
    checkEmpty: true,
  });
  if (flag) {
    return true;
  } 
  return false;
}
export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const checkPath = checkErrorPath(response);
  const { flag, value } = check({
    path: "data.errors",
    original: response,
    checkEmpty: true,
  });
  if ((response.status === 400 || response.status === 422)) {
    const errors  = checkPath ? response.data.errors : response.data;
    for (let i = 0; i < errors.length; i++) {
      if (errors[i].code === "Add Delegate" && errors[i].field === "Duplicate Delegate") {
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            errorMessage: errors[i].message,
          },
        };
      } else if (errors[i].code === "Add Delegate" && errors[i].field === "Delegate") {
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            errorMessage: errors[i].message,
          },
        };
      } else {
        const field = errors[i].field === 'ProductCode' ? 'productCode' : errors[i].field === 'ProductName' ? 'productName':errors[i].field
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            [field]: {
              ...errState.formControls[field],
              error: true,
              errorMsg: errors[i].message ? errors[i].message :ERROR_MSG.COMMON_ERR,
            },
          },
        };
      }
    }
  } 
  return errState;
};
export const validateManageProductForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (Array.isArray(valueObj) && key === "delegateList") {
      let tempDeleList = valueObj.slice();
      valueObj.forEach((delegate, index) => {
        for (const [keyDele, delegateObj] of Object.entries(delegate)) {
          if (
            delegateObj.required &&
            (delegateObj.value === null ||
              delegateObj.value === undefined ||
              (typeof delegateObj.value === "string" && delegateObj.value.trim() === ""))
          ) {
            tempDeleList[index] = {
              ...tempDeleList[index],
              [keyDele]: {
                ...tempDeleList[index][keyDele],
                error: true,
                errorMsg: ERROR_MSG.REQUIRED_FIELD,
              },
            };
            formState = {
              ...formState,
              error: true,
              delegateList: [...tempDeleList],
            };
          } else if (keyDele === "delegateLanId") {
            let flag = checkLanIdFormat(tempDeleList[index][keyDele].value);
            if (!flag) {
              tempDeleList[index] = {
                ...tempDeleList[index],
                [keyDele]: {
                  ...tempDeleList[index][keyDele],
                  error: true,
                  errorMsg: "Invalid Lan Id",
                },
              };
              formState = {
                ...formState,
                error: true,
                delegateList: [...tempDeleList],
              };
            }
          }
        }
      });
    } else if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "itpmLanId") {
      let flag = checkLanIdFormat(valueObj.value);
      if (!flag) {
        formState = {
          ...formState,
          error: true,
          itpmLanId: {
            ...formState.itpmLanId,
            error: true,
            errorMsg: "Invalid Lan Id",
          },
        };
      }
    } else if (key === "productName") {
      if (!new RegExp(PROD_NAME_REG).test(valueObj.value.trim())) {
        formState = {
          ...formState,
          error: true,
          productName: {
            ...formState.productName,
            error: true,
            errorMsg: ERROR_MSG.PRODUCT_NAME_ERROR,
          },
        };
      }
    }
  }
  return formState;
};

export const validateDueDateForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    // console.log(valueObj)
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined || valueObj.value === "")
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "dueDate") {
      let flag = !new RegExp(PUBLISH_DUE_DATE).test(valueObj.value);
      let rangeFlag = new RegExp(PUBLISH_DUE_DATE_RANGE).test(valueObj.value);
      if (flag) {
        formState = {
          ...formState,
          error: true,
          dueDate: {
            ...formState.dueDate,
            error: true,
            errorMsg: ERROR_MSG.PUBLISH_DUE_DATE,
          },
        };
      }
      else if (!rangeFlag) {
        formState = {
          ...formState,
          error: true,
          dueDate: {
            ...formState.dueDate,
            error: true,
            errorMsg: ERROR_MSG.PUBLISH_DUE_DATE_RANGE,
          },
        };
      }
    }
  }
  return formState;
};

export const validateHolidayForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined || valueObj.value === "")
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "holidayName") {
      let flag = new RegExp(HOLIDAY_NAME_REG).test(valueObj.value.trim());
      if (!flag) {
        formState = {
          ...formState,
          error: true,
          holidayName: {
            ...formState.holidayName,
            error: true,
            errorMsg: ERROR_MSG.HOLIDAY_NAME_ALLOW_CHAR,
          },
        };
      }
    }
  }
  return formState;
};


