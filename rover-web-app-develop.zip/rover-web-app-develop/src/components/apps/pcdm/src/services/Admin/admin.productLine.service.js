import { 
  SAVE_PRODUCT_LINE_SUCCESS, 
  SAVE_PRODUCT_LINE_ERROR,
  ADD_PRODUCT_LINES,
  ADD_PRODUCT_LINES_ERROR
} from "../../store/productLine.reducer";
import { ACTIONS } from "../../constants/action.constants";
import { check } from "../validation";
import { ERROR_MSG, ERR_CODES } from "../../constants/message.contants";
import { PROD_NAME_REG } from "../../constants/form.constants";
import { checkLanIdFormat } from "../../../../../../services/auth.services";

export const handleProductLineAPIResponse = (props, state, responseType, responseData) => {
    if (responseType === ADD_PRODUCT_LINES || responseType === ADD_PRODUCT_LINES_ERROR) {
      return handleAddAPLResponse(props, state, responseType, responseData);
    }else if (responseType === SAVE_PRODUCT_LINE_SUCCESS || responseType === SAVE_PRODUCT_LINE_ERROR) {
      return handleSavePLResponse(props, state, responseType, responseData);
    } else {
      return { returnState: null, modal: null };
    }
  };

  export const handleAddAPLResponse = (props, state, responseType, responseData) => {
    if (responseType === ADD_PRODUCT_LINES) {
      const propsToParent = {
        message: "Product Line Added successfully",
      };
      return {
        modal: { action: ACTIONS.SUCCESS, props: propsToParent },
      };
    } else {
      console.log(responseData);
      return {
        returnState: { ...errorState(responseData, state) },
      };
    }
  };

  export const handleSavePLResponse = (props, state, responseType, responseData) => {
    if (responseType === SAVE_PRODUCT_LINE_SUCCESS) {
      const propsToParent = {
        message: "Product Line Updated successfully",
      };
      return {
        modal: { action: ACTIONS.SUCCESS, props: propsToParent },
      };
    } else {
      console.log(responseData);
      return {
        returnState: { ...errorState(responseData, state) },
      };
    }
  };

  export const errorState = (errorResponse, state) => {
    const { response } = errorResponse;
    let errState = { formControls: { ...state.formControls } };
    const { flag, value } = check({
      path: "data.errors",
      original: response,
      checkEmpty: true,
    });
    if (response.status === 400 && flag) {
      const { errors } = response.data;
      for (let i = 0; i < errors.length; i++) {
        if (errors[i].code === "Add Delegate" && errors[i].field === "Duplicate Delegate") {
          errState = {
            ...errState,
            formControls: {
              ...errState.formControls,
              error: true,
              errorMessage: errors[i].message,
            },
          };
        } else if (errors[i].code === "Add Delegate" && errors[i].field === "Delegate") {
          errState = {
            ...errState,
            formControls: {
              ...errState.formControls,
              error: true,
              errorMessage: errors[i].message,
            },
          };
        } else {
          errState = {
            ...errState,
            formControls: {
              ...errState.formControls,
              error: true,
              [errors[i].field]: {
                ...errState.formControls[errors[i].field],
                error: true,
                errorMsg: ERROR_MSG.COMMON_ERR,
              },
            },
          };
        }
      }
    }
  
    return errState;
  };