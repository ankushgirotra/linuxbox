import { check } from "./validation";
import { DOLLAR_DEFAULT, FORM_DATE_FORMAT } from "../constants/form.constants";
import { getFormattedDate, stringToCurrency } from "./form.service";
import moment from "moment";
import { CURRENCY, LOCALE } from "../constants/common.constants";
const repeatColWidth = [100, 100, 80, 80];


export const prepareForecastsData = (
  forecast,
  forecastTableHistory,
  selectedType,
  customCell,
  customRowHeader,
  customColHead,
  searchedKeyword,
  tableID,
  startMonth,
  endMonth,
) => {

  let filtered = forecast;
  // console.log(forecast ,selectedType, searchedKeyword);

  if (selectedType || searchedKeyword) {
    if (selectedType) {
      filtered = forecast.filter((proj) => proj.projectType === selectedType);
    };
    if (searchedKeyword) {
      filtered = filtered.filter((proj) => proj.pcode.toLowerCase().includes(searchedKeyword.toLowerCase())
        || proj.projectName.toLowerCase().includes(searchedKeyword.toLowerCase()));
    };
  };

  // console.log(filtered.length);

  let filteredProject = JSON.parse(JSON.stringify(filtered));
  // console.log("TABLE UPDATE", forecastTableHistory, forecast, selectedType);
  if (forecastTableHistory.length) {
    for (let i = 0; i < forecastTableHistory.length; i++) {
      let pCodeIndex = filteredProject.findIndex(
        (pCodeInfo) => pCodeInfo.projectEstimateId === forecastTableHistory[i].projectEstimateId
      );
      let newArr = [...filteredProject];
      if (newArr && newArr[pCodeIndex] && newArr[pCodeIndex].listOfForecastAndActualData) {
        newArr[pCodeIndex].listOfForecastAndActualData.map((monthly) => {
          if (
            monthly.month ===
            getFormattedDate(forecastTableHistory[i].month, "MM/DD/YYYY", "YYYY-MM-DD")
          ) {
            monthly.forecast.dollars = forecastTableHistory[i].forecast.dollars;
            monthly.forecast.points = forecastTableHistory[i].forecast.points;
            monthly.variance.dollars = forecastTableHistory[i].variance.dollars;
            monthly.variance.points = forecastTableHistory[i].variance.points;
            return monthly;
          } else {
            return monthly;
          }
        });
      }
      filteredProject = newArr;
    }
  }
  const repeatColHeaders = [
    { content: "Budget" },
    { content: "Forecast" },
    { content: "Actual" },
    { content: (params) => customColHead({ params, value: "Variance" }) },
  ];
  let finalArray = [];
  let columnPaths = [
    { accessor: "pCode", type: "th", rowSpan: "2", scope: "rowgroup", content: customRowHeader },
    { accessor: "budget", type: "th", content: customRowHeader },
    { accessor: "totalActuals", type: "th" },
  ];
  let headerConfig = [
    [
      {
        content: (params) => customColHead({ ...params, value: "" }),
        colSpan: 3,
        scope: "colgroup",
      },
    ],
    [
      { content: (params) => customColHead({ params, value: "Projects" }) },
      { content: (params) => customColHead({ params, value: "Total Budget" }) },
      { content: "Total Actuals" },
    ],
  ];
  let colWidths = [120, 100, 100];

  filteredProject.forEach((project, index) => {
    const { dollarsObj, pointsObj } = constructProjectObj(project, startMonth, endMonth);
    finalArray.push(dollarsObj, pointsObj);
  });
  if (finalArray.length) {
    for (const [key, value] of Object.entries(finalArray[0])) {
      if (key !== "pCode" && key !== "budget" && key !== "original" && key !== "totalActuals" && key !== 'actualsAfterEnd' && key !== 'actualsBeforeStart') {
        columnPaths.push(
          { accessor: `${key}.monthlyBudgets.budget`, content: customCell },
          { accessor: `${key}.monthlyBudgets.forecast`, content: customCell },
          { accessor: `${key}.monthlyBudgets.actual`, content: customCell },
          { accessor: `${key}.monthlyBudgets.variance`, content: customCell }
        );
        let formattedDate = getFormattedDate(key, "MMM YYYY", FORM_DATE_FORMAT);
        headerConfig[0].push({
          content: formattedDate,
          colSpan: 4,
          scope: "colgroup",
          id: formattedDate === moment().format("MMM YYYY") ? `forecast-current-month-${tableID}` : "",
        });
        headerConfig[1].push(...repeatColHeaders);
        colWidths.push(...repeatColWidth);
      }
    }
  }
  return { finalArray, columnPaths, headerConfig, colWidths };
};

export const constructProjectObj = (project, startMonth, endMonth) => {
  let { flag, value } = check({
    path: "listOfForecastAndActualData",
    original: project,
    defaultReturnValue: [],
    checkEmpty: true,
  });
  let dollarsObj = {
    pCode: project.pcode,
    budget: new Intl.NumberFormat(LOCALE.US, {
      style: "currency",
      currency: CURRENCY.USD,
    }).format(project.totalBudget),
    totalActuals: new Intl.NumberFormat(LOCALE.US, {
      style: "currency",
      currency: CURRENCY.USD,
    }).format(project.actualTotalBudget),
    original: project,
    actualsBeforeStart: false,
    actualsAfterEnd: false
  };
  let pointsObj = {
    budget: `${project.totalPoints} pts`,
    totalActuals: `${project.actualTotalPoints} pts`,
    original: project,
    actualsBeforeStart: false,
    actualsAfterEnd: false
  };
  if (flag) {
    const filteredArray = value.length ? value.filter((el) =>
      new Date(el.month) >= new Date(startMonth) &&
      new Date(el.month) <= new Date(endMonth)) : []
    filteredArray.map((forecastAndActuals) => {
      const tempDollarObj = constructDollarsObj(forecastAndActuals, project);
      const tempPointsObj = constructPointsObj(forecastAndActuals, project);
      dollarsObj[forecastAndActuals.month] = tempDollarObj;
      pointsObj[forecastAndActuals.month] = tempPointsObj;
      if (tempDollarObj.monthlyBudgets.actualsBeforeStart || tempPointsObj.monthlyBudgets.actualsBeforeStart) {
        dollarsObj.actualsBeforeStart = true;
        pointsObj.actualsBeforeStart = true;
      }
      if (tempDollarObj.monthlyBudgets.actualsAfterEnd || tempPointsObj.monthlyBudgets.actualsAfterEnd) {
        dollarsObj.actualsAfterEnd = true;
        pointsObj.actualsAfterEnd = true;
      }
    });
  }

  return { dollarsObj, pointsObj };
};
export const constructDollarsObj = (forecastAndActuals, project) => {
  let monthlyDollarsObj = {};
  monthlyDollarsObj.monthlyBudgets = getMonthlyDollarsValues(forecastAndActuals, project);
  return monthlyDollarsObj;
};

export const constructPointsObj = (forecastAndActuals, project) => {
  let monthlyPointsObj = {};
  monthlyPointsObj.monthlyBudgets = getMonthlyPointsValues(forecastAndActuals, project);
  return monthlyPointsObj;
};
export const checkActulasException = (forecastMonth, prjStMonth, prjEndMonth, actual) => {
  let flags = { actualsBeforeStart: false, actualsAfterEnd: false }
  if (moment(forecastMonth, "MM/DD/YYYY").isBefore(moment(prjStMonth).format("MM/DD/YYYY"), 'month') && actual) {
    flags = {
      ...flags,
      actualsBeforeStart: true
    };
  }
  if (moment(forecastMonth, "MM/DD/YYYY").isAfter(moment(prjEndMonth).format("MM/DD/YYYY"), 'month') && actual) {
    flags = {
      ...flags,
      actualsAfterEnd: true
    };
  }

  return flags;
}
export const getMonthlyDollarsValues = (forecastAndActuals, project) => {
  const actualsInDollar = check({
    path: "actual.dollars",
    original: forecastAndActuals,
    defaultReturnValue: null,
  }).value
  let monthlyBudgets = {
    variant: "DOLLAR",
    active: forecastAndActuals.active,
    editable: moment(forecastAndActuals.month, "MM/DD/YYYY")
      .startOf("month")
      .isSameOrAfter(moment().startOf("month")),
    ...checkActulasException(forecastAndActuals.month, project.plannedStart, project.plannedEnd, actualsInDollar)
  };
  if (forecastAndActuals.active || forecastAndActuals.actual.dollars) {
    monthlyBudgets = {
      ...monthlyBudgets,
      budget: check({
        path: "budget.dollars",
        original: forecastAndActuals,
        defaultReturnValue: null,
      }).value,
      forecast: check({
        path: "forecast.dollars",
        original: forecastAndActuals,
        defaultReturnValue: null,
      }).value,
      actual: actualsInDollar,
      variance: check({
        path: "variance.dollars",
        original: forecastAndActuals,
        defaultReturnValue: null,
      }).value,
    };
  }
  return monthlyBudgets;
};
export const getMonthlyPointsValues = (forecastAndActuals, project) => {
  const actualsInPoints = check({
    path: "actual.points",
    original: forecastAndActuals,
    defaultReturnValue: null,
  }).value
  let monthlyBudgets = {
    variant: "POINT",
    active: forecastAndActuals.active,
    editable: moment(forecastAndActuals.month, "MM/DD/YYYY")
      .startOf("month")
      .isSameOrAfter(moment().startOf("month")),
    ...checkActulasException(forecastAndActuals.month, project.plannedStart, project.plannedEnd, actualsInPoints)
  };
  if (forecastAndActuals.active || forecastAndActuals.actual.points) {
    monthlyBudgets = {
      ...monthlyBudgets,
      budget: check({
        path: "budget.points",
        original: forecastAndActuals,
        defaultReturnValue: null,
      }).value,
      forecast: check({
        path: "forecast.points",
        original: forecastAndActuals,
        defaultReturnValue: null,
      }).value,
      actual: actualsInPoints,
      variance: check({
        path: "variance.points",
        original: forecastAndActuals,
        defaultReturnValue: null,
      }).value,
    };
  }
  return monthlyBudgets;
};

export const prepareForecastTableData = (selectedForecast, forecastTableHistory) => {
  const data = JSON.parse(JSON.stringify(selectedForecast))
  let monthDataArray = []
  let selectedData = data.listOfForecastAndActualData.slice()
  let totalForecastBudget = 0;
  let totalForecastPoints = 0;
  let updatedPoints = [];
  let forecastDataNew = selectedData.slice()
  if(forecastTableHistory.length){
   updatedPoints = forecastTableHistory.filter(el => data.projectEstimateId === el.projectEstimateId)
   if(updatedPoints.length){
     updatedPoints.map(el => {
       forecastDataNew.map(monthly => {
         if(monthly.month == getFormattedDate(el.month, "MM/DD/YYYY", "YYYY-MM-DD")){
            monthly.forecast.dollars = el.forecast.dollars;
            monthly.forecast.points = el.forecast.points;
            monthly.variance.dollars = el.variance.dollars;
            monthly.variance.points = el.variance.points;
            return monthly;
         }else{
           return monthly;
         }
       })
     })
   }
  }
  const plannedStart = moment(data.plannedStart).startOf("month")
  const plannedEnd = moment(data.plannedEnd).endOf("month")
  const actualStart = moment(data.actualStart).startOf("month")
  const actualEnd = moment(data.actualEnd).endOf("month")
  forecastDataNew.forEach((el=>{
    if(data.projectEstimateId == "pc" ||
    data.projectEstimateId == "pf") {
      totalForecastBudget +=el.forecast.dollars;
      totalForecastPoints +=el.forecast.points;
      monthDataArray.push({...el})
    }else if( (moment(el.month) < plannedStart && moment(el.month) >= actualStart) ||
        (moment(el.month) > plannedEnd && moment(el.month) <= actualEnd) ){
          const actualsInDollar = check({
            path: "actual.dollars",
            original: el,
            defaultReturnValue: null,
          }).value
          const flags = checkActulasException(el.month, selectedForecast.plannedStart, selectedForecast.plannedEnd, actualsInDollar);
          const editable = moment(el.month, "MM/DD/YYYY").startOf("month").isSameOrAfter(moment().startOf("month"));
          // if(el.actual.dollars>0 || el.actual.points>0){
            monthDataArray.push({...el,onlyActuals:true,...flags})
          // }
    }
    else if((moment(el.month) >= plannedStart) && (moment(el.month) <= plannedEnd)){
          totalForecastBudget += Number(el.forecast.dollars);
          totalForecastPoints += Number(el.forecast.points);
          const editable = moment(el.month, "MM/DD/YYYY").startOf("month").isSameOrAfter(moment().startOf("month"));
          const actualsInDollar = check({
            path: "actual.dollars",
            original: el,
            defaultReturnValue: null,
          }).value
          const flags = checkActulasException(el.month, selectedForecast.plannedStart, selectedForecast.plannedEnd, actualsInDollar);
          monthDataArray.push({...el,editable, ...flags })
       }
  }))
  monthDataArray.sort((a,b)=> {
    var date1 = moment(a.month);
    var date2 = moment(b.month);
    return date2.diff(date1);
  })
  let footer = {
    month : "TOTAL",
    budget: { dollars: data.totalBudget, points: data.totalPoints },
    forecast: { dollars: totalForecastBudget, points: totalForecastPoints },
    actual: { dollars: data.actualTotalBudget, points: data.actualTotalPoints  },
    variance: { dollars: totalForecastBudget-data.totalBudget,
       points: totalForecastPoints-data.totalPoints },
    editable: false,
    footer: true,
  }
  monthDataArray.push({...footer})
  return monthDataArray;
}