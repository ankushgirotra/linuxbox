/**
 * Check the nested object's value
 * input => {path:"a.b.c.d", original:{a:b:{c:{d:"check me!!"}}}, defaultReturnValue=false}
 * output => {flag:true, value:"check me!!"}
 * comments => It will check the path, if it exist it will return {flag:false, value: <actualValue>}
 * or else {flag:false, value: <defaultReturnValue>}
 */
export const check = ({
  path = "",
  original,
  defaultReturnValue,
  checkEmpty = false,
  checkZero = false,
}) => {
  let paths;
  let finalValue = { flag: true, value: defaultReturnValue };
  if (path && path.length && original) {
    paths = path.split(".");
    if (paths.length) {
      paths.slice(0).reduce((acc, currNode, index, arr) => {
        if (acc[currNode] === null || acc[currNode] === undefined) {
          // console.log("null", acc[currNode]);
          finalValue = {
            flag: false,
            value: defaultReturnValue,
          };
          arr.splice(1);
        } else {
          if (checkEmpty) {
            if (
              acc[currNode] === "" ||
              Object.keys(acc[currNode]).length === 0
            ) {
              // console.log("empty", acc[currNode]);
              finalValue = {
                flag: false,
                value: defaultReturnValue,
              };
              arr.splice(1);
            }
          }
          if (checkZero) {
            if (acc[currNode] === 0) {
              // console.log("zero", acc[currNode]);
              finalValue = {
                flag: false,
                value: defaultReturnValue,
              };
              arr.splice(1);
            }
          }
          if (finalValue.flag) {
            finalValue = {
              flag: true,
              value: acc[currNode],
            };
            acc = acc[currNode];
            return acc;
          }
        }
      }, original);
      return finalValue;
    } else {
      return {
        flag: false,
        value: defaultReturnValue,
      };
    }
  } else {
    return {
      flag: false,
      value: defaultReturnValue,
    };
  }
};

export const moveArrayEl = (arr, fromIndex, toIndex) => {
  while (fromIndex < 0) {
    fromIndex += arr.length;
  }
  while (toIndex < 0) {
    toIndex += arr.length;
  }
  if (toIndex >= arr.length) {
    let i = toIndex - arr.length;
    while (i-- + 1) {
      arr.push(undefined);
    }
  }
  arr.splice(toIndex, 0, arr.splice(fromIndex, 1)[0]);
  return arr;
};
