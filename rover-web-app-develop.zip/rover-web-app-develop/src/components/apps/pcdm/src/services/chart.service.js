import React from "react";

export default function ExtraCapacityShape(props) {
  const { x: oX, y: oY, width: oWidth, height: oHeight, value, fill } = props;

  let x = oX;
  let y = oHeight < 0 ? oY + oHeight : oY;
  let width = oWidth;
  let height = Math.abs(oHeight);

  return (
    <svg>
      <rect
        fill={"#00000000"}
        stroke={"#923031"}
        x={x}
        y={y}
        width={width}
        height={height}
      />
    </svg>
  );
}
