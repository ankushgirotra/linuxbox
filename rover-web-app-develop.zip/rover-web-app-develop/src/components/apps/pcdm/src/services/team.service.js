import { TEAM_ACTIONS,ACTIONS } from "../constants/action.constants";
import { DATA_STATUS } from "../constants/service.constant";
import { TEAM_MESSAGES, ERROR_MSG, ERR_CODES } from "../constants/message.contants";
import { ROLE_NAME_REG } from "../constants/form.constants";
import { checkValueBetweenRange } from "./form.service";
import {
  SAVE_TEAM_SUCCESS,
  SAVE_TEAM_ERROR,
  EDIT_TEAM_SUCCESS,
  DELETE_TEAM_SUCCESS,
  EDIT_TEAM_ERROR,
  DELETE_TEAM_ERROR,
  COPY_TEAM_SUCCESS,
  COPY_TEAM_ERROR,
} from "../store/teams.reducer";
import { check } from "./validation";
import moment from "moment";

export const handleTeamAPIResponse = (props, state, responseType, responseData) => {
  if (
    responseType === SAVE_TEAM_SUCCESS ||
    responseType === SAVE_TEAM_ERROR ||
    responseType === COPY_TEAM_SUCCESS ||
    responseType === COPY_TEAM_ERROR
  ) {
    return handleSaveResponse(props, state, responseType, responseData);
  } else if (responseType === EDIT_TEAM_SUCCESS || responseType === EDIT_TEAM_ERROR) {
    return handleEditResponse(props, state, responseType, responseData);
  } else if (responseType === DELETE_TEAM_SUCCESS || responseType === DELETE_TEAM_ERROR) {
    return handleDeleteResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_TEAM_SUCCESS || responseType === COPY_TEAM_SUCCESS) {
    const roles = responseType === COPY_TEAM_SUCCESS && props.teamsRoles ? props.teamsRoles.filter((role)=> role.teamId === props.teamDetails.teamId ) : []
    const propsToParent = {
      teamId: responseData.teamId,
      message: TEAM_MESSAGES[responseType],
      endMonth: responseData.endMonth,
      actionType: TEAM_ACTIONS.ADD_TEAM,
      copyRoles: state.copyRoles,
      noOfRosters: roles.length,
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
  if (responseType === EDIT_TEAM_SUCCESS) {
    const propsToParent = {
      teamId: responseData.teamId,
      message: TEAM_MESSAGES.UPDATE_TEAM_SUCCESS,
      endMonth: responseData.endMonth,
      actionType: TEAM_ACTIONS.EDIT_TEAM,
      startMonthFlag: moment(responseData.startMonth).isBefore(moment(props.teamDetails.startMonth)),
      endMonthFlag: moment(props.teamDetails.endMonth).isBefore(moment(responseData.endMonth)),
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
  if (responseType === DELETE_TEAM_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: TEAM_MESSAGES.DELETE_TEAM_SUCCESS,
          actionType: TEAM_ACTIONS.DELETE_TEAM,
        },
      },
    };
  } else {
    console.log(responseData);
    return { returnState: { savingProject: false } };
  }
};

export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const { flag, value } = check({
    path: "data.errors",
    original: response,
    checkEmpty: true,
  });
  console.log(response)

  if (response.status === 400 && flag) {
    const { errors } = response.data;
    for (let i = 0; i < errors.length; i++) {
      errState = {
        ...errState,
        formControls: {
          ...errState.formControls,
          error: true,
          [errors[i].field]: {
            ...errState.formControls[errors[i].field],
            error: true,
            errorMsg: ERROR_MSG.COMMON_ERR,
          },
        },
      };
    }
  }
  return errState;
};
export const validateTeamForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "scrumMaster" && valueObj.value.trim() !== "") {
      if (new RegExp(ROLE_NAME_REG).test(valueObj.value.trim())) {
      } else {
        formState = {
          ...formState,
          error: true,
          scrumMaster: {
            ...formControls.scrumMaster,
            error: true,
            errorMsg: ERROR_MSG.RESOURCE_NAME_ALLOW_CHAR,
          },
        };
      }
    } else if (key === "sprintVelocity") {
      let { error, errorCode } = checkValueBetweenRange(valueObj.value, valueObj.min, valueObj.max);
      if (error) {
        formState = {
          ...formState,
          error: true,
          sprintVelocity: {
            ...formState.sprintVelocity,
            error: true,
            errorMsg:
              errorCode === ERR_CODES.LESS_THAN
                ? `Minimum value allowed is ${valueObj.min}`
                : errorCode === ERR_CODES.GREATER_THAN
                ? `Maximum value allowed is ${valueObj.max}`
                : "",
          },
        };
      }
    }
  }
  return formState;
};
