import {check} from "./validation"

export const formatLanId = (userParams) => {
    const { flag, value } = check({
        original: userParams,
        path: "id",
        defaultReturnValue: "",
      });
    let id = value.toUpperCase()
    if(id.toLowerCase() === "admin") {
        return "368389"
    }
    if(id.startsWith("MS") || id.startsWith("CN") || id.startsWith("CH") || id.startsWith("NA") ){
        return 0 + id.slice(2)
    }
    if(id.length == 6 && /^[A-Za-z]+$/.test(id.substr(0, 1))){
        return 0 + id.slice(1);
      }
    return id.replace(/[A-Z]/gi, "")
}
