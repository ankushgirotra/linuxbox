import { ACTIONS, PROJECT_ACTIONS } from "../constants/action.constants";
import { DATA_STATUS } from "../constants/service.constant";
import {
  PROJECT_NAME_REG,
  FORM_DATE_FORMAT,
  P_CODE_REGEX,
  EST_TYPE_PCODE,
  DB_DATE_FORMAT,
  PRODUCT_CORE,
  PROJECT_FUNDED,
  PROJECT_TYPE_FUNDED
} from "../constants/form.constants";
import { ERROR_MSG, ERR_CODES } from "../constants/message.contants";
import { PROJECT_MESSAGES } from "../constants/message.contants";
import moment from "moment";
import {
  SAVE_PROJECT_SUCCESS,
  SAVE_PROJECT_ERROR,
  EDIT_PROJECT_SUCCESS,
  EDIT_PROJECT_ERROR,
  DELETE_PROJECT_SUCCESS,
  DELETE_PROJECT_ERROR,
  COMPLETE_PROJECT_SUCCESS,
  COMPLETE_PROJECT_ERROR,
  SAVE_PROJECT_COMMENT_ERROR,
  SAVE_PROJECT_COMMENT_SUCCESS,
} from "../store/projects.reducer";
import { getFormattedDate, checkValueBetweenRange } from "./form.service";
import { check } from "./validation";

export const handleProjectAPIResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_PROJECT_SUCCESS || responseType === SAVE_PROJECT_ERROR) {
    return handleSaveResponse(props, state, responseType, responseData);
  } else if (responseType === EDIT_PROJECT_SUCCESS || responseType === EDIT_PROJECT_ERROR) {
    return handleEditResponse(props, state, responseType, responseData);
  } else if (responseType === DELETE_PROJECT_SUCCESS || responseType === DELETE_PROJECT_ERROR) {
    return handleDeleteResponse(props, state, responseType, responseData);
  } else if (
    responseType === SAVE_PROJECT_COMMENT_SUCCESS ||
    responseType === SAVE_PROJECT_COMMENT_ERROR
  ) {
    return handleSaveProjectCommentResponse(props, state, responseType, responseData);
  } else if (responseType === COMPLETE_PROJECT_SUCCESS || responseType === COMPLETE_PROJECT_ERROR) {
    return handleCompleteResponse(responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};
export const handleSaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_PROJECT_SUCCESS) {
    const propsToParent = {
      message: PROJECT_MESSAGES.SAVE_PROJECT_SUCCESS,
      actionType: PROJECT_ACTIONS.ADD_PROJECT,
      estimateType: responseData.estimateType,
      projectestimateId : responseData.projectEstimateId,
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { savingProject: false, ...errorState(responseData, state) },
      modal: { action: ACTIONS.ERROR },
    };
  }
};
export const handleSaveProjectCommentResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_PROJECT_COMMENT_SUCCESS) {
    const propsToParent = {
      message: PROJECT_MESSAGES.SAVE_PROJECT_COMMENT_SUCCESS,
      
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
      modal: { action: ACTIONS.ERROR },
    };
  }
};
export const handleEditResponse = (props, state, responseType, responseData) => {
  if (responseType === EDIT_PROJECT_SUCCESS) {
    const propsToParent = {
      message: PROJECT_MESSAGES.UPDATE_PROJECT_SUCCESS,
      payload: responseData,
      actionType: PROJECT_ACTIONS.EDIT_PROJECT,
      estimateType: responseData.estimateType,
      addMode: props.selectedProject.estimateType == state.formControls.estimateType.value ? false : true,
      projectestimateId : responseData.projectEstimateId,
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
      modal: { action: ACTIONS.ERROR },
    };
  }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
  if (responseType === DELETE_PROJECT_SUCCESS) {
    return {
      returnState: { deletingProject: false },
      modal: {
        action: ACTIONS.SUCCESS,
        actionType: PROJECT_ACTIONS.DELETE_PROJECT,
        props: {
          message: PROJECT_MESSAGES.DELETE_PROJECT_SUCCESS,
        },
      },
    };
  } else {
    console.log(responseData);
    return { returnState: { savingProject: false }, modal: { action: ACTIONS.ERROR } };
  }
};
export const handleCompleteResponse = (responseType, responseData) => {
  if (responseType === COMPLETE_PROJECT_SUCCESS) {
    return {
      returnState: { completingProject: false },
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: PROJECT_MESSAGES.COMPLETE_PROJECT_SUCCESS,
        },
      },
    };
  } else {
    console.log(responseData);
    return { returnState: { completingProject: false }, modal: { action: ACTIONS.ERROR } };
  }
};
export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const { flag, value } = check({
    path: "response.data",
    original: errorResponse,
    checkEmpty: true,
  });
  console.log(errorResponse.response);
  if (response.status === 400 && flag) {
    for (let i = 0; i < response.data.length; i++) {
      if (response.data[i].code === ERR_CODES.ALREADY_EXIST) {
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            pCode: {
              ...errState.formControls.pCode,
              error: true,
              errorMsg: ERROR_MSG.ALREADY_EXIST,
            },
          },
        };
      } else {
        let fieldName = response.data[i].field;
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            fieldName: {
              ...errState.formControls[fieldName],
              error: true,
              errorMsg: ERROR_MSG.COMMON_ERR,
            },
          },
        };
      }
    }
  } else {
    for (let i = 0; i < response.data.length; i++) {
        let fieldName = response.data[i].field;
        let errMsg = response.data[i].message;
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            errorResponse: {
              ...errState.formControls[fieldName],
              error: true,
              fieldName: fieldName,
              errorMsg: errMsg,
            },
          },
        };
    }
  }
  return errState;
};

export const validateCommentForm = (formControl) => {
  let formState = {
    ...formControl,
    error: false,
    savingComment: false,
  };
  if (formState.comment.value.trim() === "") {
    formState = {
      ...formState,
      savingComment: false,
      comment: {
        ...formState.comment,
        error: true,
        errorMsg: ERROR_MSG.REQUIRED_FIELD,
      },
      error: true,
    };
  }
  return formState;
};
export const validateProjectForm = (formControls , rangeStatus = false) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  let isExecution = formState.estimateType.value === EST_TYPE_PCODE ? true : false;
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formState[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "pCode" && valueObj.value.trim() !== "" && valueObj.value.trim() !== PRODUCT_CORE) {
      if (new RegExp(P_CODE_REGEX).test(valueObj.value.trim())) {
      } else {
        formState = {
          ...formState,
          error: true,
          [key]: {
            ...formState[key],
            error: true,
            errorMsg: ERROR_MSG.P_CODE_ALLOW_CHAR,
          },
        };
      }
    } else if (key === "plannedStart") {
      if (moment(formState.plannedStart.value).isSameOrAfter(moment(formState.plannedEnd.value))) {
        formState = {
          ...formState,
          error: true,
          plannedEnd: {
            ...formState.plannedEnd,
            error: true,
            errorMsg: ERROR_MSG.PROJECT_END_DATE_ERROR,
          },
        };
      }
    } else if (key === "points") {
      let { error, errorCode } = checkValueBetweenRange(valueObj.value, valueObj.min, valueObj.max);
      if (error) {
        formState = {
          ...formState,
          error: true,
          points: {
            ...formState.points,
            error: true,
            errorMsg:
              errorCode === ERR_CODES.LESS_THAN
                ? `Minimum value allowed is ${valueObj.min}`
                : errorCode === ERR_CODES.GREATER_THAN
                ? `Maximum value allowed is ${valueObj.max}`
                : "",
          },
        };
      }
    } else if (key === "highEndRangePoints" && !isExecution && rangeStatus) {
      let minValue = formState.points.value;
      let { error, errorCode } = checkValueBetweenRange(valueObj.value, Number(minValue)+1, valueObj.max);
      if (error) {
        formState = {
          ...formState,
          error: true,
          highEndRangePoints: {
            ...formState.highEndRangePoints,
            error: true,
            errorMsg:
              errorCode === ERR_CODES.LESS_THAN
                ? `Value must be greater than ${minValue}`
                : errorCode === ERR_CODES.GREATER_THAN
                  ? `Maximum value allowed is ${valueObj.max}`
                  : "",
          },
        };
      }
    }
  }
  return formState;
};

export const populateProjectForm = (formControl, project) => {
  // console.log(formControl, project)
  const {
    estimateType,
    icode,
    pcode,
    projectName,
    projectType,
    investmentPortfolio,
    deliveryPortfolio,
    storyPoints,
    plannedStart,
    plannedEnd,
    funding,
    baselineBudget,
    completed,
    actualStartDate,
    actualEndDate,
    range,
    maxStoryPoints,
  } = project;
  const isExecution = estimateType === EST_TYPE_PCODE;
  const isProductCore = String(pcode).toLowerCase() === PRODUCT_CORE.toLowerCase();
  return {
    ...formControl,
    estimateType: { ...formControl.estimateType, value: estimateType },
    pCode: { ...formControl.pCode, readOnly:completed,value: pcode },
    iCode: { ...formControl.pCode, value: icode },
    projectName: {
      ...formControl.projectName,
      value: projectName,
      // readOnly: isExecution && !isProductCore,
      required: true,
    },
    projectType: {
      ...formControl.projectType,
      value: projectType,
      readOnly: isExecution,
      required: !isExecution,
    },
    investmentPortfolio: {
      ...formControl.investmentPortfolio,
      value: investmentPortfolio,
      readOnly: isExecution,
    },
    deliveryPortfolio: {
      ...formControl.deliveryPortfolio,
      value: deliveryPortfolio,
      readOnly: isExecution,
    },
    points: { ...formControl.points, value: Number(storyPoints) },
    highEndRangePoints: { 
      ...formControl.highEndRangePoints, 
      value: !isExecution && range ? Number(maxStoryPoints) : "",
      required: range,
    },
    plannedStart: {
      ...formControl.plannedStart,
      value: getFormattedDate(plannedStart, "DATE"),
    },
    plannedEnd: {
      ...formControl.plannedEnd,
      value: getFormattedDate(plannedEnd, "DATE"),
      disabled: false,
      min: moment(plannedStart).add(1, "day").toDate(),
    },
    funding: {
      ...formControl.funding,
      value: funding,
      readOnly: isExecution,
    },
    baselineBudget: {
      ...formControl.baselineBudget,
      value: baselineBudget,
    },
    actualStartDate: {
      ...formControl.actualStartDate,
      value: actualStartDate,
    },
    actualEndDate: {
      ...formControl.actualEndDate,
      value: actualEndDate,
    },
  };
};

export const modifyFormForEstimateType = (formControls, estimateType) => {
  const isExecution = estimateType === EST_TYPE_PCODE;
  const isProductCore = String(formControls.pCode.value).toLowerCase() === PRODUCT_CORE.toLowerCase();
  if (isExecution) {
    return {
      formControls: {
        ...formControls,
        isEdited: true,
        estimateType: {
          ...formControls.estimateType,
          value: estimateType,
          error: false,
        },
        pCode: { ...formControls.pCode, required: true },
        projectName: {
          ...formControls.projectName,
          // readOnly: isExecution && !isProductCore,
          required: true,
        },
        projectType: {
          ...formControls.projectType,
          readOnly: true,
          error: false,
        },
        investmentPortfolio: {
          ...formControls.investmentPortfolio,
          readOnly: true,
          error: false,
        },
        deliveryPortfolio: {
          ...formControls.deliveryPortfolio,
          readOnly: true,
          error: false,
        },
        funding: {
          ...formControls.funding,
          value: "Funded",
          required: true,
          readOnly: true,
          error: false,
        },
        highEndRangePoints: {
          ...formControls.highEndRangePoints,
          value: "",
          required: false,
          error: false,
          errorMsg: ""
        },
      },
    };
  } else {
    return {
      formControls: {
        ...formControls,
        isEdited: true,
        estimateType: {
          ...formControls.estimateType,
          value: estimateType,
          error: false,
        },
        pCode: { ...formControls.pCode, required: false },
        projectName: {
          ...formControls.projectName,
          required: true,
          readOnly: false,
        },
        projectType: {
          ...formControls.projectType,
          required: true,
          readOnly: false,
        },
        investmentPortfolio: {
          ...formControls.investmentPortfolio,
          readOnly: false,
        },
        deliveryPortfolio: {
          ...formControls.deliveryPortfolio,
          readOnly: false,
        },
        funding: { ...formControls.funding, required: true, readOnly: false },
      },
    };
  }
};
export const modifyFormForPCode = (formControls, pCode, projectDefaults) => {
  const isPrjNameEmpty = check({
    path: "projectName",
    original: projectDefaults,
    checkEmpty: true,
  });
  let isPrjTypeEmpty = check({
    path: "projectType",
    original: projectDefaults,
    checkEmpty: true,
  });
 
  return {
    formControls: {
      ...formControls,
      isEdited: true,
      pCode: { ...formControls.pCode, value: pCode, error: false },
      projectName: {
        ...formControls.projectName,
        value: isPrjNameEmpty.flag ? isPrjNameEmpty.value : "",
        // readOnly: isPrjNameEmpty.flag,
        required: true,
        error: !isPrjNameEmpty.flag,
      },
      projectType: {
        ...formControls.projectType,
        value: (pCode==PRODUCT_CORE)?PRODUCT_CORE:PROJECT_FUNDED,//isPrjTypeEmpty.flag ? isPrjTypeEmpty.value : formControls.projectType.value,
        required: !isPrjTypeEmpty.flag,
        readOnly: isPrjTypeEmpty.flag,
        error: !isPrjTypeEmpty.flag,
      },
      investmentPortfolio: {
        ...formControls.investmentPortfolio,
        value: projectDefaults.investmentPortfolio,
      },
      deliveryPortfolio: {
        ...formControls.deliveryPortfolio,
        value: projectDefaults.deliveryPortfolio,
      },
    },
    selectedProjectDefaults: projectDefaults,
  };
};
export const getDeletePayload = (project) => {
  return {
    estimateType: project.estimateType,
    pcode: project.pcode,
    icode: project.icode,
    projectName: project.projectName,
    projectType: project.projectType,
    investmentPortfolio: project.investmentPortfolio,
    deliveryPortfolio: project.deliveryPortfolio,
    storyPoints: Number(project.storyPoints),
    baselineBudget: project.baselineBudget,
    plannedStart: moment(project.plannedStart)
      .hour(0)
      .minute(0)
      .second(0)
      .millisecond(0)
      .format(DB_DATE_FORMAT),
    plannedEnd: moment(project.plannedEnd)
      .hour(23)
      .minute(59)
      .second(59)
      .millisecond(999)
      .format(DB_DATE_FORMAT),
    funding: project.funding,
    completed: project.completed,
    active: false,
    actualStartDate : project.actualStartDate,
    actualEndDate: project.actualEndDate,
    range: project.range,
    maxStoryPoints: project.maxStoryPoints,
  };
};
export const getMarkCompletePayload = (project) => {
  return {
    estimateType: project.estimateType,
    pcode: project.pcode,
    icode: project.icode,
    projectName: project.projectName,
    projectType: project.projectType,
    investmentPortfolio: project.investmentPortfolio,
    deliveryPortfolio: project.deliveryPortfolio,
    storyPoints: Number(project.storyPoints),
    baselineBudget: project.baselineBudget,
    plannedStart: moment(project.plannedStart)
      .hour(0)
      .minute(0)
      .second(0)
      .millisecond(0)
      .format(DB_DATE_FORMAT),
    plannedEnd: moment(project.plannedEnd)
      .hour(23)
      .minute(59)
      .second(59)
      .millisecond(999)
      .format(DB_DATE_FORMAT),
    funding: project.funding,
    active: project.active,
    completed: true,
    actualStartDate : project.actualStartDate,
    actualEndDate: project.actualEndDate,
    range: project.range,
    maxStoryPoints: project.maxStoryPoints,
  };
};

export const saveCommentPayload = (formControl, manager, lanId) => {
  return {
    name: "User",
    lanId: lanId,
    comments: formControl.comment.value.trim(),
  };
};
export const getAddOrEditPayload = (mode, formControls, selectedProject ,rangeStatus) => {
  let isExecution = formControls.estimateType.value === EST_TYPE_PCODE ? true : false;
  let payload = {
    estimateType: formControls.estimateType.value,
    pcode: formControls.pCode.value.trimRight(),
    icode: formControls.iCode.value.trimRight(),
    projectName: formControls.projectName.value.trimRight(),
    projectType: formControls.projectType.value,
    investmentPortfolio: formControls.investmentPortfolio.value,
    deliveryPortfolio: formControls.deliveryPortfolio.value,
    storyPoints: Number(formControls.points.value),
    baselineBudget: formControls.baselineBudget.value,
    plannedStart: moment(formControls.plannedStart.value)
      .hour(0)
      .minute(0)
      .second(0)
      .millisecond(0)
      .format(DB_DATE_FORMAT),
    plannedEnd: moment(formControls.plannedEnd.value)
      .hour(23)
      .minute(59)
      .second(59)
      .millisecond(999)
      .format(DB_DATE_FORMAT),
    funding: formControls.funding.value,
    active: true,
    completed: false,
    pcodeCheck: false,
    actualStartDate : formControls.actualStartDate.value,
    actualEndDate: formControls.actualEndDate.value,
    range: isExecution ? false : rangeStatus,
    maxStoryPoints: isExecution || !rangeStatus ? 0 : formControls.highEndRangePoints.value,
  };
  if (
    mode === PROJECT_ACTIONS.EDIT_PROJECT &&
    payload.estimateType === EST_TYPE_PCODE &&
    payload.pcode !== PRODUCT_CORE
  ) {
    if (payload.pcode !== selectedProject.pcode) {
      payload = {
        ...payload,
        pcodeCheck: true,
      };
    } else if (payload.estimateType !== selectedProject.estimateType) {
      payload = {
        ...payload,
        pcodeCheck: true,
      };
    }
  } else if (
    mode === PROJECT_ACTIONS.ADD_PROJECT &&
    payload.estimateType === EST_TYPE_PCODE &&
    payload.pcode !== PRODUCT_CORE
  ) {
    payload = {
      ...payload,
      pcodeCheck: true,
    };
  }
  return payload;
};

export const populateAddMissingEstForm = (formControl, project) => {
  const {
    pcode,
    projectName,
    investmentPortfolio,
    deliveryPortfolio,
  } = project;
  const isProductCore = String(pcode).toLowerCase() === PRODUCT_CORE.toLowerCase();
  return {
    ...formControl,
    estimateType: {
      ...formControl.estimateType,
      value: EST_TYPE_PCODE,
      readOnly: false,
      required: true,
    },
    pCode: {
      ...formControl.pCode,
      value: pcode,
      readOnly: true,
      required: true,
    },
    projectName: {
      ...formControl.projectName,
      value: projectName,
      readOnly: true,
      required: true,
    },
    projectType: {
      ...formControl.projectType,
      value: isProductCore ? PRODUCT_CORE : PROJECT_FUNDED,
      readOnly: true,
    },
    funding: {
      ...formControl.funding,
      value: PROJECT_TYPE_FUNDED,
      readOnly: true, 
    },
    investmentPortfolio: {
      ...formControl.investmentPortfolio,
      value: investmentPortfolio,
      readOnly: true,
    },
    deliveryPortfolio: {
      ...formControl.deliveryPortfolio,
      value: deliveryPortfolio,
      readOnly: true,
    },
    plannedEnd: {
      ...formControl.plannedEnd,
      disabled: true,
    },
  };
};
