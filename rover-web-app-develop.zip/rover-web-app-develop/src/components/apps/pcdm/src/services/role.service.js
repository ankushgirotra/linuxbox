import { ACTIONS } from "../constants/action.constants";
import { ERROR_MSG, ERR_CODES } from "../constants/message.contants";
import { ROLE_NAME_REG } from "../constants/form.constants";
import { TEAM_MESSAGES } from "../constants/message.contants";
import { checkValueBetweenRange } from "./form.service";
import { check } from "./validation";
import {
  SAVE_ROLE_SUCCESS,
  EDIT_ROLE_SUCCESS,
  SAVE_ROLE_ERROR,
  EDIT_ROLE_ERROR,
  DELETE_ROLE_SUCCESS,
  DELETE_ROLE_ERROR,
} from "../store/roles.reducer";

export const handleRoleAPIResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_ROLE_SUCCESS || responseType === SAVE_ROLE_ERROR) {
    return handleSaveResponse(props, state, responseType, responseData);
  } else if (responseType === EDIT_ROLE_SUCCESS || responseType === EDIT_ROLE_ERROR) {
    return handleEditResponse(props, state, responseType, responseData);
  } else if (responseType === DELETE_ROLE_SUCCESS || responseType === DELETE_ROLE_ERROR) {
    return handleDeleteResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_ROLE_SUCCESS) {
    const propsToParent = {
      teamId: responseData.teamId,
      message: TEAM_MESSAGES.SAVE_ROLE_SUCCESS,
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
  if (responseType === EDIT_ROLE_SUCCESS) {
    const propsToParent = {
      teamId: responseData.teamId,
      message: TEAM_MESSAGES.UPDATE_ROLE_SUCCESS,
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
  if (responseType === DELETE_ROLE_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: TEAM_MESSAGES.DELETE_ROLE_SUCCESS,
        },
      },
    };
  } else {
    console.log(responseData);
    return { returnState: { savingProject: false } };
  }
};

export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const { flag, value } = check({
    path: "data.errors",
    original: response,
    checkEmpty: true,
  });
  if (response.status === 400 && flag) {
    const { errors } = response.data;
    for (let i = 0; i < errors.length; i++) {
      errState = {
        ...errState,
        formControls: {
          ...errState.formControls,
          error: true,
          [errors[i].field]: {
            ...errState.formControls[errors[i].field],
            error: true,
            errorMsg: ERROR_MSG.COMMON_ERR,
          },
        },
      };
    }
  }
  return errState;
};

export const validateRoleForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "rate") {
      if (valueObj.value.trim().replace("$", "").replace(/,/g, "").length >= 10) {
        formState = {
          ...formState,
          error: true,
          rate: {
            ...formState.rate,
            error: true,
            errorMsg: ERROR_MSG.ROLE_RATE_EXCEED_LENGTH,
          },
        };
      }
    } else if (key === "resourceName" && valueObj.value.trim() !== "") {
      if (new RegExp(ROLE_NAME_REG).test(valueObj.value.trim())) {
      } else {
        formState = {
          ...formState,
          error: true,
          resourceName: {
            ...formState.resourceName,
            error: true,
            errorMsg: ERROR_MSG.RESOURCE_NAME_ALLOW_CHAR,
          },
        };
      }
    } else if (key === "allocation") {
      let { error, errorCode } = checkValueBetweenRange(
        valueObj.value.replace(/[^0-9]/g, ""),
        valueObj.min,
        valueObj.max
      );
      if (error) {
        formState = {
          ...formState,
          error: true,
          allocation: {
            ...formState.allocation,
            error: true,
            errorMsg:
              errorCode === ERR_CODES.LESS_THAN
                ? `Minimum value allowed is ${valueObj.min}`
                : errorCode === ERR_CODES.GREATER_THAN
                ? `Maximum value allowed is ${valueObj.max}`
                : "",
          },
        };
      }
    }
  }
  return formState;
};
