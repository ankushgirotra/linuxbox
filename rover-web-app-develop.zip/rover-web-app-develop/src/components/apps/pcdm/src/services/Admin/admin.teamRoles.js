import { ACTIONS } from "../../constants/action.constants";
import { check } from "../validation";
import { ERROR_MSG, ERR_CODES } from "../../constants/message.contants";
import {
  MODIFY_TEAM_ROLE_RATE_ERROR,
  MODIFY_TEAM_ROLE_RATE_SUCCESS,
} from "../../store/admin.reducer";
import { AD_ROLE_REG } from "../../constants/form.constants";

export const handleTeamRoleAPIResponse = (props, state, responseType, responseData) => {
  if (
    responseType === MODIFY_TEAM_ROLE_RATE_SUCCESS ||
    responseType === MODIFY_TEAM_ROLE_RATE_ERROR
  ) {
    return handleEditResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
  if (responseType === MODIFY_TEAM_ROLE_RATE_SUCCESS) {
    const propsToParent = {
      message: "Role rate updated successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  console.log(response);
  const { flag, value } = check({
    path: "data.errors",
    original: response,
    checkEmpty: true,
  });
  const error2 = check({
    path: "data",
    original: response,
    checkEmpty: true,
  });
  if (response.status === 400 && flag) {
    const { errors } = response.data;
    for (let i = 0; i < errors.length; i++) {
      errState = {
        ...errState,
        formControls: {
          ...errState.formControls,
          error: true,
          [errors[i].field]: {
            ...errState.formControls[errors[i].field],
            error: true,
            errorMsg: ERROR_MSG.COMMON_ERR,
          },
        },
      };
    }
  } else if (response.status === 422 && error2.flag) {
    const { value } = error2;
    for (let i = 0; i < value.length; i++) {
      errState = {
        ...errState,
        formControls: {
          ...errState.formControls,
          error: true,
          [value[i].field]: {
            ...errState.formControls[value[i].field],
            error: true,
            errorMsg: value[i].message,
          },
        },
      };
    }
  } else {
    errState = {
      ...errState,
      formControls: {
        ...errState.formControls,
        error: true,
        errorMessage:
          response.data && typeof response.data === "string"
            ? response.data
            : ERROR_MSG.COMMON_FORM_ERR,
      },
    };
  }
  return errState;
};
export const validateManageTeamRolesForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    } else if (key === "roleName" && valueObj.value.trim() !== "") {
      if (new RegExp(AD_ROLE_REG).test(valueObj.value.trim())) {
      } else {
        formState = {
          ...formState,
          error: true,
          roleName: {
            ...formState.roleName,
            error: true,
            errorMsg: ERROR_MSG.ROLE_NAME_ALLOW_CHAR,
          },
        };
      }
    }
  }
  return formState;
};
