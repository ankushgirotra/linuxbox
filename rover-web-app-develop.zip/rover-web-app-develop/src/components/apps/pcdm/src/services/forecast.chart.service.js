import moment from "moment";
import { getFormattedDate } from "./form.service";
import { check } from "./validation";
export const getMatchedProjectList = (forecasts) => {
  let matchedProjectsList = [];
  if (forecasts.data.matchedProjects) {
    matchedProjectsList = [{ id: 'pc', name: 'Product Core (All Estimates)' }];
    forecasts.data.matchedProjects.map((project, index) => {
      if (project.projectType !== "Product Core") {
        matchedProjectsList.push({ id: project.projectEstimateId, name: project.pcode });
      }
    });
  }
  return matchedProjectsList;
};

export const getForecastchartData = (selectedPcodes, forecasts, forecastCapacity, productCoreAggregate) => {
  let chartDataList = [];
  if (
    selectedPcodes &&
    selectedPcodes.length &&
    forecasts &&
    forecasts.length &&
    forecastCapacity &&
    productCoreAggregate
  ) {
    forecastCapacity.forEach((chartMonthly) => {
      let monthlyObj = {
        month: getFormattedDate(chartMonthly.month, "M/D/YYYY", "M/DD/YYYY"),
        capacity: chartMonthly.allTeamCostPerMonth,
        forecast: 0,
        originalBudget: 0,
        forecastPC: 0,
        originalBudgetPC: 0,
        forecastTotal: 0,
        originalBudgetTotal: 0,
        actuals: 0,
        actualsPC: 0,
        actualsTotal: 0,
        forecastToActualChange: "",
      };
      selectedPcodes.forEach((pcode) => {
        // if (pcode.id === "pc") {
        //   const prodCore = forecasts.filter(
        //     (project) => project.projectType === "Product Core"
        //   );
        //   prodCore.forEach((projectDetails) => {
        //     if (projectDetails && projectDetails.listOfForecastAndActualData) {
        //       let projectMonthly = projectDetails.listOfForecastAndActualData.filter((monthly) => {
        //         if (
        //           getFormattedDate(monthly.month, "MM/DD/YYYY", "MM/DD/YYYY") ===
        //           getFormattedDate(chartMonthly.month, "MM/DD/YYYY", "M/DD/YYYY")
        //         ) {
        //           return true;
        //         }
        //         return false;
        //       });
        //       if (projectMonthly.length) {
        //         monthlyObj = appendMonthlyObj(monthlyObj, projectMonthly, true);
        //       }
        //     }
        //   });
        // } 
        if (pcode.id != "pc") {
          let projectDetails = forecasts.filter(
            (project) => project.projectEstimateId === pcode.id
          )[0];
          if (projectDetails && projectDetails.listOfForecastAndActualData) {
            let projectMonthly = projectDetails.listOfForecastAndActualData.filter((monthly) => {
              if (
                getFormattedDate(monthly.month, "MM/DD/YYYY", "MM/DD/YYYY") ===
                getFormattedDate(chartMonthly.month, "MM/DD/YYYY", "M/DD/YYYY")
              ) {
                return true;
              }
              return false;
            });
            if (projectMonthly.length) {
              monthlyObj = appendMonthlyObj(monthlyObj, projectMonthly, false);
            }
          }
        }
      });
      let flagCheck = selectedPcodes.filter(pcode => pcode.id==="pc");
      if(flagCheck.length > 0 ){
        let projectMonthly = productCoreAggregate ? productCoreAggregate.listOfForecastAndActualData.filter((monthly)=> {
          if( getFormattedDate(monthly.month, "MM/DD/YYYY", "MM/DD/YYYY") === 
              getFormattedDate(chartMonthly.month, "MM/DD/YYYY", "M/DD/YYYY") ){
              return true;
            }
            return false
        }) : null
        if(projectMonthly.length){
          monthlyObj = appendMonthlyObj(monthlyObj, projectMonthly, true);
        }
      }
      monthlyObj = {
        ...monthlyObj, forecastTotal: monthlyObj.forecast + monthlyObj.forecastPC,
        originalBudgetTotal: monthlyObj.originalBudget + monthlyObj.originalBudgetPC,
        actualsTotal: monthlyObj.actuals + monthlyObj.actualsPC
      }
      monthlyObj = {
        ...monthlyObj, 
        forecastToActualChange: forecastToActualChangePercent({
          actualsValue: monthlyObj.actuals,
          forecastValue: monthlyObj.forecast,
          defaultReturnValue: "",
        }),
      }
      chartDataList.push(monthlyObj);
    });
  }
  return chartDataList;
};

const appendMonthlyObj = (monthlyObj, projectMonthly, projectCore) => {
  const forecast = projectCore ? 'forecastPC' : 'forecast';
  const originalBudget = projectCore ? 'originalBudgetPC' : 'originalBudget';
  const actuals = projectCore ? "actualsPC" : "actuals" ;
  return {
    ...monthlyObj,
    [forecast]:
      monthlyObj[forecast] +
      check({
        path: "forecast.dollars",
        original: projectMonthly[0],
        defaultReturnValue: 0,
      }).value,
    [originalBudget]:
      monthlyObj[originalBudget] +
      check({
        path: "budget.dollars",
        original: projectMonthly[0],
        defaultReturnValue: 0,
      }).value,
    [actuals]:
      monthlyObj[actuals] +
      check({
        path: "actual.dollars",
        original: projectMonthly[0],
        defaultReturnValue: 0,
      }).value,
    
  };
}

export const forecastToActualChangePercent = ({
  actualsValue = 0,
  forecastValue = 0,
  defaultReturnValue,
}) => {
  var percentageChange = 0;
  if (forecastValue > 0) {
    percentageChange = ((actualsValue - forecastValue) / forecastValue) * 100;
  } else {
    return "";
  }
  return Math.round(percentageChange) + "%";
};
export const convertToCurrency = (value, locale, _currency) => {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: _currency,
  }).format(value);
};
