import moment from "moment";
import { MONTH_DATE_YEAR_FORMAT } from "../constants/form.constants";
import { ERR_CODES } from "../constants/message.contants";

export const formatAsCommaSeperated = (value, removePreceedingZero = false) => {
  const removeNondigit = value.replace(/\D/g, "");
  let formatIt = "";
  if (removePreceedingZero) {
    formatIt = String(Number(removeNondigit)).replace(
      /\B(?=(\d{3})+(?!\d))/g,
      ","
    );
  } else {
    formatIt = removeNondigit.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
  return formatIt;
};
export const stringToCurrency = (
  input,
  event,
  decimalPt,
  showEmptyDecimal = true
) => {
  let inputVal = input.trim();
  let defaulDecimal = new Array(decimalPt).fill(0).join("");
  let defaultCurrency = `$0.${defaulDecimal}`;

  if (inputVal === "" && event == "blur") {
    return defaultCurrency;
  }
  if (inputVal.indexOf(".") >= 0) {
    let decimalIndex = inputVal.indexOf(".");
    let number = inputVal.substring(0, decimalIndex);
    let decimal = inputVal.substring(decimalIndex);
    number = formatAsCommaSeperated(number, event == "blur");
    decimal = decimal.replace(/\D/g, "");
    if (event == "blur") {
      decimal += "00";
    }
    decimal = decimal.substring(0, decimalPt || 2);
    inputVal = `$${number}.${decimal}`;
  } else {
    inputVal = formatAsCommaSeperated(inputVal, event == "blur");
    if (inputVal.length === 0 && event == "blur") {
      inputVal += "0";
    }
    if (event == "blur") {
      inputVal += ".00";
    }
    inputVal = `$${inputVal}`;
  }
  return inputVal;
};
export const formatNumberWithCommaSeprated = (number) => {
  if (String(number).includes(".")) {
    const [digit, decimal] = String(number).split(".");
    return `${formatAsCommaSeperated(digit)}.${decimal}`;
  } else {
    return formatAsCommaSeperated(String(number));
  }
};
export const roundOff = (value, decimalPoint, showEmptyDecimal) => {
  let multiplier = Math.pow(10, decimalPoint || 0);
  const rounded = Math.round(value * multiplier) / multiplier;
  if (showEmptyDecimal) {
    return rounded.toFixed(decimalPoint);
  } else {
    return rounded;
  }
};

export const stringToPercentage = (inputVal) => {
  return `${inputVal}%`;
};

export const appendPointsToValue=(sprintVelocity)=>{
  return `${sprintVelocity} points`;
};

export const checkValueBetweenRange = (inputVal, min, max) => {
  if (min && !isNaN(min)) {
    if (Number(inputVal) < Number(min)) {
      return {
        error: true,
        errorCode: ERR_CODES.LESS_THAN,
      };
    }
  }
  if (max && !isNaN(max)) {
    if (Number(inputVal) > Number(max)) {
      return {
        error: true,
        errorCode: ERR_CODES.GREATER_THAN,
      };
    }
  }
  return {
    error: false,
    errorCode: "",
  };
};

export const getFormattedDate = (
  dateStr,
  resFormat = MONTH_DATE_YEAR_FORMAT,
  reqFormat = ""
) => {
  if (resFormat === "DATE") {
    return moment(dateStr, reqFormat).toDate();
  } else {
    return moment(dateStr, reqFormat).format(resFormat);
  }
};

export const getUTCFormattedDate = (
  dateStr,
  resFormat = MONTH_DATE_YEAR_FORMAT,
  reqFormat = ""
) => {
  if (resFormat === "DATE") {
    return moment(dateStr, reqFormat).toDate();
  } else {
    return moment(dateStr, reqFormat).utc().format(resFormat);
  }
};
