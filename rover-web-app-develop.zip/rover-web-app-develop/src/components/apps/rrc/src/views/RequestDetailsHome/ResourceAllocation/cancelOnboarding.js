import React, { Component, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Row, Col, Container, Form } from "react-bootstrap";
import Button from '../../../../../../shared/components/forms/Button/button';
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import ModalFooter from "react-bootstrap/ModalFooter";
import "bootstrap/dist/css/bootstrap.min.css";
import { Radio } from '@material-ui/core'
import TextField from '../../../../../../shared/components/forms/TextField/textField';
import { validateRequestForm } from '../../../services/requestForm.service';
import { FormControlLabel, RadioGroup } from '@material-ui/core';
import Select from 'react-select'
import SelectDropdown from '../../../../../../shared/components/forms/SelectDropdown/selectDropdown';
import { useDropzone } from "react-dropzone";
import { Trash2, XCircle } from "react-feather";
import { connect } from "react-redux";

const INITIAL_FORM_STATE = {
    formControls: {
        resourceName: {
            value: "",
            error: false,
            errorMsg: "",
            disable: true,
        },
        comments: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
    },
};

const CancelOnboarding = (props) => {

    const [requestFormState, setRequestFormState] = useState(INITIAL_FORM_STATE);

    const { cancelOnboardingId, cancelOnboardingStatus, resourceName, resourceType } = props;
    const [checked, setChecked] = useState(false)



    useEffect(() => {
        let requestStatus = ""
        if (cancelOnboardingStatus === 1) {
            requestStatus = "Identifying Resource";
        } else if (cancelOnboardingStatus === 2) {
            requestStatus = "Resource Reserved";
        } else if (cancelOnboardingStatus === 3) {
            requestStatus = "Completed";
        } else if (cancelOnboardingStatus === 4) {
            requestStatus = "Cancelled";
        } else if (cancelOnboardingStatus === 5) {
            requestStatus = "External Blocker";
        }

    }, [])

    const onCloseCancelOnboardingModal = () => {
        setRequestFormState(INITIAL_FORM_STATE);
        setChecked(false);
        props.onCloseCancelOnboardingModal(true);
    }

    const unCheckedOnboarding = {
        marginLeft: " -30px",
        width: "auto",
        height: "2.4rem",
        borderRadius: "8px",
        marginBottom: "2rem",
        color: "#C72B31",
        border: "1px solid #C72B31",
        backgroundColor: "white",
        padding: "7px 15px 5px 15px",
        boxShadow: "0px 3px 6px #00000029",
        opacity: 1,
        cursor: "not-allowed"
    };

    const checkedOnboarding = {
        marginLeft: " -30px",
        width: "auto",
        height: "2.4rem",
        borderRadius: "8px",
        marginBottom: "2rem",
        color: "#C72B31",
        border: "1px solid #C72B31",
        backgroundColor: "white",
        padding: "7px 15px 5px 15px",
        boxShadow: "0px 3px 6px #00000029",
        opacity: 1,
    };


    const onInputChange = (event) => {
        const { formControls } = requestFormState;
        const name = event.target.name;
        const value = event.target.value;

        setRequestFormState({
            formControls: {
                ...formControls,
                error: false,
                [name]: {
                    ...formControls[name],
                    error: false,
                    value: value,
                },
            },
        });
    };

    const onCancelOnboarding = () => {
        const { formControls } = requestFormState;
        if (formControls.comments.value === '') {
            setRequestFormState({
                ...requestFormState,
                formControls: {
                    ...formControls,
                    comments: {
                        ...formControls.comments,
                        error: true,
                        errorMsg: 'Comment field is required',
                    },
                },
            });
        } else {
            const payload = {
                request_id: cancelOnboardingId,
                cancel_comments: requestFormState.formControls.comments.value
            };
            props.cancelOnboarding(payload);
            onCloseCancelOnboardingModal();
        }
    }

    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            backdrop="static"
            keyboard={false}
            fullscreen={true | 'sm-down'}
        >
            <ModalHeader style={{ border: "none", fontSize: "22px !important" }} >
                <span className={"rrc-details-title"}>

                    <p id="title" style={{ color: "black", marginLeft: "10px" }}>
                        <b>Cancel Reservation - Request ID  {cancelOnboardingId && cancelOnboardingId != null ? cancelOnboardingId : "N/A"} </b>  | &nbsp; &nbsp;
                    </p>
                    <h4 style={{ color: "#3F66FB", marginTop: "10px",marginLeft: "-15px" }}>
                        {cancelOnboardingStatus === "1" ? "Identifying Resource" :
                            cancelOnboardingStatus === "2" ? "Resource Reserved" :
                                cancelOnboardingStatus === "3" ? "Completed" :
                                    cancelOnboardingStatus === "4" ? "Cancelled" :
                                        cancelOnboardingStatus === "5" ? "External Blocker" : "N/A"}
                    </h4>
                </span>
                <div className="close-button" onClick={onCloseCancelOnboardingModal}>X</div>

            </ModalHeader>
            <Container >
                <div className="rrc-request-background" >
                    <Form >
                        <Form.Row>
                            <Form.Group as={Col} lg={6} style={{ marginTop: "11px" }}>

                                <Form.Label>Resource Name</Form.Label>
                                <Form.Control type="text" disabled value={resourceName} />

                            </Form.Group>
                            <Form.Group as={Col} lg={6}>
                                <TextField
                                    name="comments"
                                    label="Comments"
                                    formObj={requestFormState.formControls.comments}
                                    isRequired={requestFormState.formControls.comments.required}
                                    onChange={onInputChange}
                                />
                            </Form.Group>
                        </Form.Row>
                        {resourceType == "External" ?
                            <Row>
                                <p style={{ marginLeft: "20px", color: "gray", marginBottom: "15px" }}>If the reason for cancellation is an external blocker, then report external blocker.</p></Row> : ""}
                        <Row>
                            <Col>
                                <input onChange={() => setChecked(!checked)} defaultChecked={checked} type="checkbox" /><span style={{ display: "flex", marginLeft: "-100px", justifyContent: "center", textAlign: "left", marginTop: "-23px", color: "gray" }}>I understand that clicking Cancel will mean that I no longer intend for this resource to fulfill this request</span>
                            </Col>
                        </Row>
                    </Form>
                </div>
            </Container>
            <Row style={{ marginBottom: "20px", marginTop: "20px", marginRight: "-5px" }}>
                <Col className="d-flex justify-content-end align-items-end">
                    <div className="cancel-onboard-button">
                        {!checked ?
                            (<button style={unCheckedOnboarding} >Cancel Reservation </button>) :
                            (<button style={checkedOnboarding} onClick={onCancelOnboarding} >Cancel Reservation </button>)
                        }
                    </div>
                </Col>
            </Row>

        </Modal>
    )
}

export default CancelOnboarding;