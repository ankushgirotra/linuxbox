import React, { useRef, useState, useCallback, useEffect } from "react";
import { Filter, ArrowDown, ArrowUp, CheckSquare } from "react-feather";
import "./customFilter.scss";
import useOnClickOutside from "../../../../../../../shared/CustomHooks/clickOutsideHook";
import { connect } from "react-redux";
import { getRequestIdFilterStatusThunk, getCreatedFilterStatusThunk, getRMFilterStatusThunk, getStartDateFilterStatusThunk, getCurrentStatusFilterThunk, getProductFilterStatusThunk, getITPMFilterStatusThunk, getSkillsFilterStatusThunk } from "../../../../store/customFilter.reducer";

const CustomFilter = (props) => {
    const divRef = useRef();
    const itemEls = useRef(new Array());
    const selectAllref = useRef();

    const handler = useCallback(() => setFilterDialogOpen(false), []);
    useOnClickOutside(divRef, handler);

    const { tableData, dataToBeFiltered, columnTitle, title, originalData } = props
    const [filterArray, setFilterArray] = useState([]);

    /* Table Data */
    const filteredList = tableData && tableData.map(x => x[dataToBeFiltered]);
    const listWithoutDuplicate = [... new Set(filteredList)];
    const mapListToSelected = listWithoutDuplicate.map(x => { return { value: x, selected: true } })
    const [finalList, setFinalList] = useState(mapListToSelected);

    /* Original Data */
    const originalList = originalData && originalData.map(x => x[dataToBeFiltered]);
    const originalDataWithout = [... new Set(originalList)];
    const mapOriginalListToSelected = originalDataWithout.map(x => { return { value: x, selected: true } })
    const [originaFinalList, setOriginalFinalList] = useState(mapOriginalListToSelected);

    const [isFilterDialogOpen, setFilterDialogOpen] = useState(false);
    const [selectAll, setSelectAll] = useState(true);
    const [clearFilter, setClearFilter] = useState(false);
    const [sortByAtoZ, setSort] = useState(undefined);
    const [disableTrue, setDisableTrue] = useState(false);

    const onOpenFilter = () => {
        setFilterDialogOpen(!isFilterDialogOpen)
    }

    useEffect(() => {
        setFilterStates()
    }, [isFilterDialogOpen])

    const setFilterStates = () => {
        if (Object.keys(props.requestIdStatus).length > 0 && title == 'ID') {
            setClearFilter(props.requestIdStatus.clearFilter);
            setFilterStatus(props.requestIdStatus.selectAll, props.requestIdStatus.list);
        } else if (Object.keys(props.rm).length > 0 && title == 'Manager') {
            setClearFilter(props.rm.clearFilter);
            setFilterStatus(props.rm.selectAll, props.rm.list);
        }
        else if (Object.keys(props.createdStatus).length && title == 'Created') {
            setClearFilter(props.createdStatus.clearFilter)
            setFilterStatus(props.createdStatus.selectAll, props.createdStatus.list);
        }
        else if (Object.keys(props.startDateStatus).length && title == 'Start Date') {
            setClearFilter(props.startDateStatus.clearFilter)
            setFilterStatus(props.startDateStatus.selectAll, props.startDateStatus.list)
        }
        else if (Object.keys(props.status).length && title == 'Status') {
            setClearFilter(props.status.clearFilter)
            setFilterStatus(props.status.selectAll, props.status.list)
        }
        else if (Object.keys(props.productStatus).length && title == 'Product') {
            setClearFilter(props.productStatus.clearFilter)
            setFilterStatus(props.productStatus.selectAll, props.productStatus.list)
        } else if (Object.keys(props.itpmStatus).length && title == 'ITPM') {
            setClearFilter(props.itpmStatus.clearFilter)
            setFilterStatus(props.itpmStatus.selectAll, props.itpmStatus.list)
        } else if (Object.keys(props.skillsStatus).length && title == 'Skills') {
            setClearFilter(props.skillsStatus.clearFilter)
            setFilterStatus(props.skillsStatus.selectAll, props.skillsStatus.list)
        }
    }

    const setFilterStatus = (selectAll, list) => {
        setSelectAll(selectAll)
        setFinalList(list);
        onSelectOrDeselect(list);
    }

    const onSelectAll = (e) => {
        if (e.target.checked) {
            const selectAll = finalList.map(x => { return { value: x.value, selected: true } })
            setFilterStatus(true, selectAll)
            setDisableTrue(false)
        } else {
            const deSelectAll = finalList.map(x => { return { value: x.value, selected: false } })
            setFilterStatus(false, deSelectAll)
            setDisableTrue(true)
        }
    }

    const onChange = (event, i) => {
        if (!event.target.checked) {
            finalList[i].selected = false;
            onSelectOrDeselect(finalList);
            if (finalList.some(x => x.selected === false)) {
                setClearFilter(true)
            }
            if (finalList.some(x => x.selected === true)) {
                setSelectAll(null)
            }
            if (finalList.every(x => x.selected === false)) {
                setSelectAll(false)
                setDisableTrue(true)
            }

        } else {
            finalList[i].selected = true;
            setDisableTrue(false);
            if (finalList.some(x => x.selected === true)) {
                setSelectAll(null)
            }
            if (finalList.every(x => x.selected === true)) {
                setClearFilter(false)
                setSelectAll(true)
            }

            onSelectOrDeselect(finalList);
        }
    }

    const onSelectOrDeselect = (list) => {
        const selectedValue = list.filter(x => x.selected).map(y => y.value);
        setFilterArray(selectedValue)
    }

    const onColumnFilter = () => {
        let itemToBeFiltered = finalList.filter(x => x.selected).map(y => y.value);
        let filterData = {
            rmName: props.rm.itemToBeFiltered || [],
            request_id: props.requestIdStatus.itemToBeFiltered || [],
            createdDate: props.createdStatus.itemToBeFiltered || [],
            plannedStart: props.startDateStatus.itemToBeFiltered || [],
            status: props.status.itemToBeFiltered || [],
            product: props.productStatus.itemToBeFiltered || [],
            managername: props.itpmStatus.itemToBeFiltered || [],
            skills: props.skillsStatus.itemToBeFiltered || [],
        }

        const payLoad = { selectAll: selectAll, list: finalList, clearFilter: (!selectAll || clearFilter) ? true : false, itemToBeFiltered, sort: sortByAtoZ }
        if (title == 'ID') {
            props.getRequestIdFilterStatus(payLoad)
        } else if (title == 'Manager') {
            props.getRMFilterStatus(payLoad)
        }
        else if (title == 'Created') {
            props.getCreatedFilterStatus(payLoad)
        } else if (title == 'Start Date') {
            props.getStartDateFilterStatus(payLoad)
        } else if (title == 'Status') {
            props.getCurrentStatusFilter(payLoad)
        } else if (title == 'Product') {
            props.getProudctFilterStatus(payLoad)
        } else if (title == 'ITPM') {
            props.getITPMFilterStatus(payLoad)
        } else if (title == 'Skills') {
            props.getSkillsFilterStatus(payLoad)
        }
        props.onFilter(dataToBeFiltered, itemToBeFiltered, filterData, sortByAtoZ)
        setFilterDialogOpen(false);
    }

    const onClearFilter = () => {
        if (clearFilter) {
            const selectAll = originaFinalList.map(x => { return { value: x.value, selected: true } })
            setFilterStatus(true, selectAll)
            setClearFilter(false)
            setSort(undefined)
        }
    }

    const onCancel = () => {
        onClearFilter();
        setFilterDialogOpen(false)
    }

    const handleClick = (i) => {
        itemEls.current[i].click();
    }

    const handleSelectClick = () => {
        selectAllref.current.click();
    }

    const sort = (type) => {
        setSort(type);
    }

    return <div>
        <div>
            {columnTitle}
            {clearFilter ? <span onClick={onOpenFilter}><Filter size="15" /></span> : ''}
            {!clearFilter ? <span onClick={onOpenFilter}>&nbsp;<i className="fa fa-caret-down" style={{ fontSize: "16px" }}></i></span> : null}

        </div>
        {isFilterDialogOpen &&
            <div className="rrc-filter-list" style={title === "Skills" ? { right: "0px" } : {}} ref={divRef}>
                <div  >
                    <div className="filter-function"
                        onClick={() => sort(true)}
                    > <ArrowDown
                            size={15}
                            strokeWidth={2}
                            color="black"
                        />&nbsp;
                          {(title == 'Created' || title == 'Start Date') ?
                            <span style={{ textTransform: "none" }}>Sort Oldest to Newest</span> : (title == 'ID') ? <span style={{ textTransform: "none" }}>Sort Smallest to Largest</span> : <p style={{ all: "unset" }}>Sort A <span style={{ textTransform: "none" }}>to</span> Z                                </p>
                        }
                    &nbsp;{
                            (sortByAtoZ == true) ?

                                <CheckSquare
                                    size={15}
                                    strokeWidth={3}
                                    color="limegreen"
                                /> : ''}
                    </div>
                    <div className="filter-function filter-function-padding" onClick={() => sort(false)}
                    > <ArrowUp
                            size={15}
                            strokeWidth={2}
                            color="black"
                        />&nbsp;
                        {(title == 'Created' || title == 'Start Date') ?
                            <span style={{ textTransform: "none" }}>Sort Newest to Oldest</span> : (title == 'ID') ? <span style={{ textTransform: "none" }}>Sort Largest to Smallest</span> : <p style={{ all: "unset" }}>Sort Z <span style={{ textTransform: "none" }}>to</span> A                         </p>
                        }
                    &nbsp;{


                            (sortByAtoZ == false) ?

                                <CheckSquare
                                    size={15}
                                    strokeWidth={2}
                                    color="limegreen"
                                /> : ''}</div>

                    <div className="filter-function filter-function-padding" onClick={onClearFilter} style={clearFilter ? {} : { opacity: 0.5, cursor: "not-allowed" }}
                    > <Filter
                            size={15}
                            strokeWidth={2}
                            color="black"
                        />&nbsp;
                   Clear Filter from "{title}"</div>
                </div>
                <div className="filter-items-contianer">
                    <div className="filter-items">
                        <div className="rrc-filter-list-item" style={{ marginTop: "10px", marginLeft: "3px" }} >
                            <div className={`request-custom-tick ${
                                selectAll === true
                                    ? `pick-selected`
                                    : selectAll === false
                                        ? ``
                                        : `pick-partial`
                                }`} onClick={() => handleSelectClick()}>
                                <div className="pick"></div>
                                <div className="partials-tick"></div>
                            </div>
                            <div className="filter-label" style={{ fontSize: "14px", marginTop: "-8px", marginLeft: "7px" }}><strong>Select All</strong></div>
                            <input type="checkbox" ref={selectAllref} checked={selectAll} hidden className="filter-check-box" onChange={(e) => onSelectAll(e)} />
                        </div>
                        <div style={{ marginLeft: '25px' }}>
                            {finalList.map((y, i) => {

                                return (
                                    <>
                                        <div className="rrc-filter-list-item" key={y.value}>
                                            <div
                                                className={`request-custom-tick ${
                                                    y.selected === true
                                                        ? `pick-selected`
                                                        : y.selected === false
                                                            ? ``
                                                            : `pick-partial`
                                                    }`}
                                                onClick={() => handleClick(i)}>
                                                <div className="pick"></div>
                                                <div className="partials-tick"></div>
                                            </div>
                                            <div className="filter-label">{y.value}</div>
                                        </div>
                                        <input type="checkbox" hidden ref={(element) => itemEls.current[i] = element} checked={y.selected} value={y.value} onChange={(e) => onChange(e, i)} className="filter-check-box" />
                                    </>)
                            })}
                        </div>
                    </div>
                </div>
                <div className="ok-btn">
                    <div className="ok-button">
                        <button className={disableTrue?"btn-style-ok-disabled":"btn-style-ok"}  onClick={disableTrue ?'':() => onColumnFilter()}>OK</button>&nbsp;&nbsp;
                        <button className="btn-style-cancel" onClick={() => onCancel()}>Cancel</button>
                    </div>
                </div>
            </div>
        }
    </div>
};

const mapStateToProps = (state, ownProps) => ({
    rm: state.CustomFilterReducer.rm,
    requestIdStatus: state.CustomFilterReducer.requestId,
    createdStatus: state.CustomFilterReducer.created,
    startDateStatus: state.CustomFilterReducer.startDate,
    status: state.CustomFilterReducer.status,
    productStatus: state.CustomFilterReducer.product,
    itpmStatus: state.CustomFilterReducer.itpm,
    skillsStatus: state.CustomFilterReducer.skills,
});

const mapDispatchToProps = (dispatch) => ({
    getRequestIdFilterStatus: (status) =>
        dispatch(getRequestIdFilterStatusThunk(status)),
    getCreatedFilterStatus: (status) =>
        dispatch(getCreatedFilterStatusThunk(status)),
    getStartDateFilterStatus: (status) =>
        dispatch(getStartDateFilterStatusThunk(status)),
    getCurrentStatusFilter: (status) =>
        dispatch(getCurrentStatusFilterThunk(status)),
    getProudctFilterStatus: (status) =>
        dispatch(getProductFilterStatusThunk(status)),
    getITPMFilterStatus: (status) =>
        dispatch(getITPMFilterStatusThunk(status)),
    getSkillsFilterStatus: (status) =>
        dispatch(getSkillsFilterStatusThunk(status)),
    getRMFilterStatus: (status) =>
        dispatch(getRMFilterStatusThunk(status))
});

export default connect(mapStateToProps, mapDispatchToProps)(CustomFilter);
