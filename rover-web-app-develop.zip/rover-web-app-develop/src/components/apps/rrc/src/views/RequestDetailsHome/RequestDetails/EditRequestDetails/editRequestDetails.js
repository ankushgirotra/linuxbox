import React, { Component, useState } from 'react';
import { Row, Col, Container, Form } from "react-bootstrap";
import Button from "../../../../../../../shared/components/forms/Button/button";
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import ModalFooter from "react-bootstrap/ModalFooter";
import "bootstrap/dist/css/bootstrap.min.css";
import "./editRequestDetails.scss"
import SelectDropdown from '../../../../../../../shared/components/forms/SelectDropdown/selectDropdown';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { putRequestDetailsDataThunk,getTotalMatchesCountThunk, getApplicationsByProductId, getApplicationsByProductIdThunk, getJobTitleThunk, getProductLineThunk, getProductsByProductLineId, getProductsByProductLineIdThunk, getRequestDetailsDataThunk, getRequestDropdownValuesThunk, getRMListThunk, saveRequestThunk } from '../../../../store';
import TextField from '../../../../../../../shared/components/forms/TextField/textField';
import Datepicker from '../../../../../../pcdm/src/components/Datepicker/datepicker';
// import CustomSelect from '../../../../../../pcdm/src/components/forms'
import CustomSelect from '../../../../../../../shared/components/forms/MultiSelect/multiSelect';
import moment from 'moment';
import { FORM_DATE_FORMAT, DEFAULT_TECH_LIST } from '../../../../constants/request.constans';
import { getFormattedDate, validateRequestForm } from '../../../../services/requestForm.service';
import { getFormattedUserId } from '../../../../../../../../services/auth.services';

const INITIAL_FORM_STATE = {
    formControls: {
        // assignedRM: {
        //     value: "",
        //     error: false,
        //     errorMsg: "",
        //     required: true,
        //     disable: false,
        // },
        productLine: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        product: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        application: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        role: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        title: {
            value: "",
            options: [],
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        allocationPercentage: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        plannedStartDate: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        plannedEndDate: {
            value: "",
            error: false,
            errorMsg: "",
            min: null,
            max: null,
            required: true,
            disabled: false,
        },
        technologies: {
            value: DEFAULT_TECH_LIST,
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        location: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        comments: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        symbolsArray: ["e","-","+","-","E","."]
    },
};



class EditRequestDetails extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            ...INITIAL_FORM_STATE,
        };
    }

    componentDidMount() {
        let empId = localStorage.getItem('emplyoee_id')
        let id = empId ? empId : getFormattedUserId(this.props.userParams);
        const lanId = this.props.loggedInUser.isAuthenticated ? id : '';
        this.props.getDropdownValues(lanId);
        this.props.getJobTitle(lanId);
        this.props.getProductLine(lanId);
        this.props.getRMList(lanId);
        this.formPopulate()

    }

    formPopulate = async () => {
        const { requestDetails, jobtitle, dropdownValues } = this.props;
        const { formControls } = this.state;
        let titleList = [];

        let productLineList = this.props.productLine
        let productLine = productLineList.length !== 0 ? productLineList.find(function (product, index) {
            if (product.productlinename === requestDetails.product_line) {
                return product.productlineid
            }
        }) : ""

        if (productLine !== undefined) {
            await this.props.getProductsByProductLineId(productLine.productlineid)
        }
        let productList = [...this.props.productsByProductLineId.data]
        let product = productList.length !== 0 ? productList.find(function (product, index) {
            if (product.productName === requestDetails.product) {
                return product.id
            }
        }) : ""

        if (product !== undefined) {
            await this.props.getApplicationsByProductId(product.id);
        }
        let applicationList = [...this.props.applicationsByProductId.data]
        let application = applicationList.length !== 0 ? applicationList.find(function (application, index) {
            if (application.applicationName === requestDetails.application) {
                return application.id
            }
        }) : ""

        titleList = [...jobtitle.filter(jobtitle => jobtitle.roleDesc === requestDetails.role)];
        let title = titleList.length !== 0 ? titleList.find(function (title, index) {
            //let jobTitle = title.jobTitle.split('(')[1].split(')')[0]
            if (title.jobTitle === requestDetails.job_title) {
                return title.id
            }
        }) : ""
        let roleValue = dropdownValues.finalRolUn && dropdownValues.finalRolUn.length ? [...dropdownValues.finalRolUn.filter(finalRolUn => finalRolUn.roleDesc === requestDetails.role)][0].roleId : [];
        let allocationValue = requestDetails.allocation;

        let techList = requestDetails.technologies !== null && requestDetails.technologies !== undefined ? requestDetails.technologies.split(",") : ""
        let technoList = []
        let tL = techList.length
        if (dropdownValues.finalSkills !== undefined) {
            for (let i = 0; i < tL; i++) {
                for (let j = 0; j < dropdownValues.finalSkills.length; j++) {
                    if (techList[i] === dropdownValues.finalSkills[j].skillName) {
                        technoList.push(
                            {
                                value: dropdownValues.finalSkills[j].id,
                                label: dropdownValues.finalSkills[j].skillName,
                            }
                        )
                        break;
                    }
                }
            }
        }

        let fList = requestDetails.location !== null && requestDetails.location !== undefined ? requestDetails.location.split(", ") : ""
        // replace(/[;]/g,","):""
        // let lList = fList.split(",");
        // let locList = lList!==""?lList.filter(function(element, index, array){
        //     return (index % 2 !==0);
        // }):""
        let lL = fList.length
        let locationList = []
        if (dropdownValues.finalLocations !== undefined) {
            for (let i = 0; i < lL; i++) {
                for (let j = 0; j < dropdownValues.finalLocations.length; j++) {
                    if (fList[i] === dropdownValues.finalLocations[j].stateDesc) {
                        locationList.push(
                            {
                                value: dropdownValues.finalLocations[j].id,
                                label: dropdownValues.finalLocations[j].stateDesc,
                            }
                        )
                    }
                }
            }
        }
        titleList = [...dropdownValues.finalRoles !== undefined ? dropdownValues.finalRoles.filter(jobtitle => jobtitle.roleid === roleValue) : ""];

        let productLineValue = productLine !== undefined ? productLine.productlineid : "";
        let productIdValue = product !== undefined ? product.id : "";
        let applicationValue = application !== undefined ? application.id : "";


        this.setState({
            formControls: {
                ...formControls,
                productLine: {
                    ...formControls.productLine,
                    value: productLineValue
                },
                product: {
                    ...formControls.product,
                    value: productIdValue,
                },
                application: {
                    ...formControls.application,
                    value: applicationValue,
                },
                role: {
                    ...formControls.role,
                    value: roleValue,
                },
                title: {
                    ...formControls.title,
                    value: title ? title.id : "",
                    options: [...titleList]
                },
                allocationPercentage: {
                    ...formControls.allocationPercentage,
                    value: allocationValue,
                },
                plannedStartDate: {
                    ...formControls.plannedStartDate,
                    value: requestDetails.planned_start?moment(requestDetails.planned_start)._d:""
                },
                plannedEndDate: {
                    ...formControls.plannedEndDate,
                    value: requestDetails.end_date?moment(requestDetails.end_date)._d:"",
                    min: requestDetails.planned_start? moment(requestDetails.planned_start).add(1,'day')._d :""
                },
                technologies: {
                    ...formControls.technologies,
                    value: [...technoList]
                },
                location: {
                    ...formControls.location,
                    value: [...locationList]
                },
                comments: {
                    ...formControls.comments,
                    value: ""
                }

            }
        }
        )





    }

    onRoleChange = (e) => {
        const { dropdownValues } = this.props;
        const { formControls } = this.state;
        const value = e.target.value;
        let titleList = [];

        titleList = [...dropdownValues.finalRoles.filter(jobtitle => jobtitle.roleid === value)];

        this.setState({
            formControls: {
                ...formControls,
                error: false,
                role: {
                    ...formControls.role,
                    error: false,
                    value: value,
                },
                title: {
                    ...formControls.title,
                    error: false,
                    options: [...titleList],
                    value: ""
                },

            }

        })
    }

    onProductLineChange = async (selectedProductLine) => {
        await this.props.getProductsByProductLineId(selectedProductLine);

    };

    onProductChange = async (selectedProduct) => {
        await this.props.getApplicationsByProductId(selectedProduct);

    }

    onInputChange = (event) => {
        const { formControls } = this.state;
        const name = event.target.name;
        const value = event.target.value;

        if (name === "productLine") {
            this.onProductLineChange(value);
        }
        if (name === "product") {
            this.onProductChange(value);
        }

        this.setState({
            formControls: {
                ...formControls,
                error: false,
                [name]: {
                    ...formControls[name],
                    error: false,
                    value: value,
                },
            },
        });
    };

    onAllocationChange = (event) => {
        const { formControls } = this.state;
        const name = event.target.name;
        let allocationPercentage = event.target.value
        const pattern = /\b([0-9]|[1-9][0-9]|100)\b/;
        const newValue = pattern.test(allocationPercentage);
        if (allocationPercentage === '' || pattern.test(allocationPercentage)) {
            this.setState({
                formControls: {
                    ...formControls,
                    error: false,
                    [name]: {
                        ...formControls[name],
                        error: false,
                        value: allocationPercentage,
                    },
                },
            });
        }
        if (!newValue) {
            return
        }
    }

    manageMonthSelection = (type, date) => {
        let value = moment(date, FORM_DATE_FORMAT);
        const { formControls } = this.state;
        const { dropdownValues } = this.props;

        if (type === "plannedStartDate") {
            let ed = formControls.plannedEndDate.value,
                ed_disable = formControls.plannedEndDate.disabled,
                ed_min = value.add(1, "day").format(FORM_DATE_FORMAT);
            if (value.isValid() && !formControls.plannedEndDate.value) {
                /* If start month is selected and end month is empty enable end month and update its min */
                ed_disable = false;
            } else if (
                formControls.plannedEndDate.value &&
                value.isAfter(
                    moment(formControls.plannedEndDate.value, FORM_DATE_FORMAT)
                )
            ) {
                /* If start month is after selected end month , then reset the end month and its min */
                ed = "";
                ed_disable = false;
            }
            this.setState({
                formControls: {
                    ...formControls,
                    isEdited: true,
                    plannedStartDate: {
                        ...formControls.plannedStartDate,
                        value: date,
                        error: false,
                    },
                    plannedEndDate: {
                        ...formControls.plannedEndDate,
                        value: ed,
                        disabled: ed_disable,
                        min: new Date(getFormattedDate(ed_min)),
                    },
                },
            });
        } else if (type === "plannedEndDate") {
            this.setState({
                formControls: {
                    ...formControls,
                    isEdited: true,
                    plannedStartDate: {
                        ...formControls.plannedStartDate,
                        error: false,
                    },
                    plannedEndDate: {
                        ...formControls.plannedEndDate,
                        value: date,
                        error: false,
                    },
                },
            });
        }
    };

    reqPayload = () => {
        const { formControls } = this.state;
        const {
            productsByProductLineId,
            applicationsByProductId,
            productLine,
        } = this.props;

        let productOptions = productsByProductLineId.data;
        let applicationOptions = applicationsByProductId.data;
        let technologies = [...formControls.technologies.value];
        let technologyList = [];
        let locations = formControls.location.value !== null? [...formControls.location.value] : "";
        let locationsList = [];
        let roleId = "";
        let beltId = "";
        let jobTitleId = "";
        let empId = localStorage.getItem('emplyoee_id')
        let id = empId ? empId : getFormattedUserId(this.props.userParams);
        let lanId = this.props.loggedInUser.isAuthenticated ? id : ''

        if (formControls.title.value === "") {
            if (formControls.role.value === "Developer 2.0") {
                roleId = "AD0026";
            } else if (formControls.role.value === "Developer") {
                roleId = "AD0026";
            } else if (formControls.role.value === "Development Lead") {
                roleId = 4;
            } else if (formControls.role.value === "Systems Analyst") {
                roleId = "AD0030";
            } else if (formControls.role.value === "Scrum Master") {
                roleId = "AD0034";
            } else if (formControls.role.value === "Tooling Analyst") {
                roleId = "DO0018";
            } else if (formControls.role.value === "Non-ADC Role") {
                roleId = 16;
            } else if (formControls.role.value === "Business Analyst") {
                roleId = "PG0449";
            } else if (formControls.role.value === "DevOps Engineer") {
                roleId = 20;
            } else if (formControls.role.value === "Test Analyst") {
                roleId = 23;
            } else if (formControls.role.value === "Test Manager") {
                roleId = "QA0015";
            } else if (formControls.role.value === "Test Engineer") {
                roleId = "QA0007";
            } else if (formControls.role.value === "Test Architect") {
                roleId = "QA0012";
            } else if (formControls.role.value === "Quality Test Analyst") {
                roleId = 30;
            }
        } else {
            roleId = formControls.title.value;
        }

        if (formControls.title.value === "") {
            roleId = formControls.role.value;
        } else {
            roleId = formControls.role.value;
            beltId = formControls.title.value;
            jobTitleId = formControls.title.value;
        }

        for (let i = 0; i < technologies.length; i++) {
            technologyList.push(
                {
                    id: technologies[i].value,
                    skillName: technologies[i].label,
                }
            )
        }

        for (let i = 0; i < locations.length; i++) {
            locationsList.push(
                {
                    id: locations[i].value,
                    stateDesc: locations[i].label,
                }
            )
        }

        let reqComment = formControls.comments.value;

        let payload = {
            assignedRmId: lanId,
            productLineName:
                productLine.find(
                    (el) => el.productlineid === formControls.productLine.value
                ).productlinename || "",
            productLineId: formControls.productLine.value,
            productName:
                productOptions.find((el) => el.id === formControls.product.value)
                    .productName || "",
            productId: formControls.product.value,
            roleId: roleId,
            beltId: beltId,
            jobTitleId: jobTitleId,
            allocation: formControls.allocationPercentage.value,
            plannedStart: moment(formControls.plannedStartDate.value).format("YYYY-MM-DD"),
            endDate: moment(formControls.plannedEndDate.value).format("YYYY-MM-DD"),
            departmentId: 765,
            locationIds: locationsList,
            technologies: technologyList,
            comment: reqComment,
        };
        if (
            formControls.application.value &&
            formControls.application.value != ""
        ) {
            payload = {
                ...payload,
                applicationName:
                    applicationOptions.find(
                        (el) => el.id === formControls.application.value
                    ).applicationName || "",
                applicationId: formControls.application.value,
            };
        } else {
            payload = {
                ...payload,
                applicationName: "",
                applicationId: "",
            }
        }

        return payload;
    };

    callRequestId = async (status, response) => {
        let empId = localStorage.getItem('emplyoee_id')
        let id = empId ? empId : getFormattedUserId(this.props.userParams);
        const lanId = this.props.loggedInUser.isAuthenticated ? id : ''
        let requestId = response && response.request_id;
        await this.props.updateReqIdDetails(requestId, lanId);
    }

    // const {requestDetails} = this.props
    // const [requestFormState, setRequestFormState] = useState(INITIAL_FORM_STATE);

    onHide = () => {
        return (
            <>
                {this.props.onHide}
            </>

        )
    }
    onSubmit = async (e) => {
        e.preventDefault();

        const { requestDetails } = this.props;
        let empId = localStorage.getItem('emplyoee_id')
        let id = empId ? empId : getFormattedUserId(this.props.userParams);
        let lanId = this.props.loggedInUser.isAuthenticated ? id : '';
        let reqId = requestDetails.request_id
        // rmId = requestDetails.

        // let payload = reqPayload();
        // saveRequest(payload);

        let requestFormPostValidation = validateRequestForm(
            this.state.formControls
        );

        if (requestFormPostValidation.error) {
            this.setState({ formControls: { ...requestFormPostValidation } });

        } else {
            let payload = this.reqPayload();
            // let assignedRm = this.requestFormState.formControls.assignedRM.value;
            await this.props.putRequestDetailsData(lanId, reqId, payload);
            this.props.onHide()
           this.props.getTotalMatchesCount(localStorage.getItem('selectedRequestId'), lanId)
            // props.openrequestForm();
            //  this.onHandleRequestSubmission(assignedRm);
        }
    };

    render() {
        const { formControls } = this.state;
        const {
            dropdownValues,
            requestDetails
        } = this.props;

        return (
            <div>
                <Modal
                    {...this.props}
                    size="lg"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    backdrop="static"
                    keyboard={false}
                >
                    <ModalHeader style={{ border: "none" }} closeButton>
                        <Modal.Title id="contained-modal-title-vcenter">
                            <span className={"rrc-details-title"}>
                                <h3 style={{ color: "black" }}>
                                    Request ID {requestDetails.request_id && requestDetails.request_id != null ? requestDetails.request_id : "N/A"}{"  "}
                                    |&nbsp;
                                </h3>
                                <h4 style={{ color: "#3F66FB" }}>
                                    {requestDetails.status === "1" ? "Identifying Resource" :
                                        requestDetails.status === "2" ? "Resource Reserved" :
                                            requestDetails.status === "3" ? "Completed" :
                                                requestDetails.status === "4" ? "Cancelled" :
                                                    requestDetails.status === "5" ? "External Blocker" : "N/A"}
                                </h4>
                            </span>
                        </Modal.Title>
                    </ModalHeader>
                    <div className="rrc-request-background" style={{ backgroundColor: "#F5F6FA", marginTop: "7px", width: "95%", borderRadius: "6px", marginLeft: "18px" }}>
                        <ModalBody style={{ border: "none" }}>
                            <Form>
                                <Form.Row>
                                    <Form.Group as={Col}>
                                        <SelectDropdown
                                            name="productLine"
                                            label="Product Line"
                                            formObj={formControls.productLine}
                                            isRequired={formControls.productLine.required}
                                            config={{
                                                options: [...this.props.productLine],
                                                id: "productlineid",
                                                value: "productlinename",
                                            }}
                                            onChange={(e) => {
                                                this.onInputChange({
                                                    target: { name: e.name, value: e.value },
                                                });
                                            }}
                                            placeholder=""
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <SelectDropdown
                                            name="product"
                                            label="Product"
                                            formObj={formControls.product}
                                            isRequired={formControls.product.required}
                                            //config={options}
                                            config={{
                                                options: [...this.props.productsByProductLineId.data],
                                                id: "id",
                                                value: "productName",
                                            }}
                                            onChange={(e) =>
                                                this.onInputChange({
                                                    target: { name: e.name, value: e.value },
                                                })
                                            }
                                            placeholder=""
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <SelectDropdown
                                            name="application"
                                            label="Application"
                                            formObj={formControls.application}
                                            isRequired={formControls.application.required}
                                            config={{
                                                options: [...this.props.applicationsByProductId.data],
                                                id: "id",
                                                value: "applicationName",
                                            }}
                                            isClearable={true}
                                            placeholder={"Select an option"}
                                            onChange={(e) =>
                                                this.onInputChange({
                                                    target: { name: e.name, value: e.value },
                                                })
                                            }
                                            placeholder=""
                                        />
                                    </Form.Group>
                                </Form.Row>
                                <Form.Row>
                                    <Form.Group as={Col}>
                                        <SelectDropdown
                                            name="role"
                                            label="Role"
                                            formObj={formControls.role}
                                            isRequired={formControls.role.required}
                                            config={{
                                                options: dropdownValues.finalRolUn && dropdownValues.finalRolUn.length ? [...dropdownValues.finalRolUn] : [],
                                                id: "roleId",
                                                value: "roleDesc",
                                            }}
                                            onChange={(e) =>
                                                this.onRoleChange({
                                                    target: { name: e.name, value: e.value },
                                                })
                                            }
                                            placeholder=""
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <SelectDropdown
                                            name="title"
                                            label="Belt"
                                            formObj={formControls.title}
                                            isRequired={formControls.title.required}
                                            isClearable={true}
                                            config={{
                                                options: [...formControls.title.options],
                                                id: "id",
                                                value: "jobTitle",
                                            }}
                                            onChange={(e) =>
                                                this.onInputChange({
                                                    target: { name: e.name, value: e.value },
                                                })
                                            }
                                            imgSrc={"../../../../../../../src/assets/images/belts"}
                                            placeholder=""
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <TextField
                                            name="allocationPercentage"
                                            label="Allocation %"
                                            formObj={formControls.allocationPercentage}
                                            isRequired={formControls.allocationPercentage.required}
                                            className={"percentText"}
                                            min="0"
                                            onChange={this.onAllocationChange}
                                            type="number"
                                            onKeyDown={e => formControls.symbolsArray.includes(e.key) && e.preventDefault()}
                                        />
                                    </Form.Group>
                                </Form.Row>
                                <Form.Row>
                                    <Form.Group as={Col} style={{ padding: "10px 10px 10px 8px" }} className="rrc-request-calendar">
                                        <Datepicker
                                            name="plannedStartDate"
                                            label="Planned Start"
                                            formObj={formControls.plannedStartDate}
                                            onChange={this.manageMonthSelection}
                                            dateFormat={FORM_DATE_FORMAT}
                                            className={"request-datepicker"}
                                            isRequestDatePicker={true}
                                            placeholderText=""
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col} style={{ padding: "10px 10px 10px 2px" }} className="rrc-request-calendar">
                                        <Datepicker
                                            name="plannedEndDate"
                                            label="Planned End"
                                            formObj={formControls.plannedEndDate}
                                            onChange={this.manageMonthSelection}
                                            dateFormat={FORM_DATE_FORMAT}
                                            className={"request-datepicker"}
                                            isRequestDatePicker={true}
                                            placeholderText=""
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col} style={{ marginTop: "11px" }}>
                                        <CustomSelect
                                            name="technologies"
                                            label="Technologies"
                                            formObj={formControls.technologies}
                                            isRequired={formControls.technologies.required}
                                            isMulti={true}
                                            config={{
                                                options: dropdownValues.finalSkills !== undefined ? [...dropdownValues.finalSkills] : [],
                                                id: "id",
                                                value: "skillName",
                                            }}
                                            onChange={(e) =>
                                                this.onInputChange({
                                                    target: { name: e.name, value: e.value },
                                                })
                                            }
                                        />
                                    </Form.Group>
                                </Form.Row>
                                <Form.Row>
                                    <Form.Group as={Col} style={{ marginTop: "11px" }}>
                                        <CustomSelect
                                            name="location"
                                            label="Location"
                                            formObj={formControls.location}
                                            isRequired={formControls.location.required}
                                            isMulti={true}
                                            config={{
                                                options: dropdownValues.finalLocations !== undefined ? [...dropdownValues.finalLocations] : [],
                                                id: "id",
                                                value: "stateDesc",
                                            }}
                                            onChange={(e) =>
                                                this.onInputChange({
                                                    target: { name: e.name, value: e.value },
                                                })
                                            }
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col} style={{ paddingRight: "1px" }}>
                                        <TextField
                                            name="comments"
                                            label="Comments"
                                            formObj={formControls.comments}
                                            isRequired={formControls.comments.required}
                                            onChange={this.onInputChange}
                                        />
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                    </Form.Group>
                                </Form.Row>
                                {/* <Row>
                                    <Col>

                                        <div className="submit-request-button">
                                            <Button onClick={onSubmit}
                                            >
                                                <span className='mr-1'>Submit</span>
                                            </Button></div>
                                         <div className="rcc-buttons">
                                <button className="rcc-buttons-submit">Submit</button>
                            </div> 
                                    </Col>
                                </Row> */}
                            </Form>
                        </ModalBody>
                    </div>
                    <div class="col-md-12" style={{ marginTop: "10px" }}>
                        <div style={{ float: "right" }}>
                            <button style={{ width: "120px" }} id="okay-btn" onClick={this.onSubmit}>Update Request</button>
                        </div>
                        {/* <div className="add-comment-button" style={{ float: "right" }}>
                            <Button>
                                <span className='mr-1'>Add Comment</span>
                            </Button></div> */}
                        <div style={{ float: "right" }}>
                            <button id="cancel-btn" onClick={this.props.onHide}>Cancel</button>
                        </div>
                    </div>
                </Modal>
            </div>
        )
    }


}

const mapStateToProps = (state, ownProps) => ({
    productLine: state.RequestResourceReducer.productLine,
    dropdownValues: state.RequestResourceReducer.dropdownValues,
    jobtitle: state.RequestResourceReducer.jobtitle,
    productsByProductLineId: state.RequestResourceReducer.productsByProductLineId,
    applicationsByProductId: state.RequestResourceReducer.applicationsByProductId,
    rmList: state.RequestResourceReducer.rmList,
    userParams: state.AuthReducer.user,
    loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
    getProductLine: (lanId) => dispatch(getProductLineThunk(lanId)),
    getDropdownValues: (lanId) => dispatch(getRequestDropdownValuesThunk(lanId)),
    getProductsByProductLineId: (productLineId, callback) =>
        dispatch(getProductsByProductLineIdThunk(productLineId, callback)),
    getApplicationsByProductId: (productId, callback) =>
        dispatch(getApplicationsByProductIdThunk(productId, callback)),
    getJobTitle: (lanId) => dispatch(getJobTitleThunk(lanId)),
    getRMList: (lanId) => dispatch(getRMListThunk(lanId)),
    putRequestDetailsData: (rmId, requestId, callback, payload) =>
        dispatch(putRequestDetailsDataThunk(rmId, requestId, callback, payload)),
        getTotalMatchesCount: (reqId, lanId) => dispatch(getTotalMatchesCountThunk(reqId, lanId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(EditRequestDetails));