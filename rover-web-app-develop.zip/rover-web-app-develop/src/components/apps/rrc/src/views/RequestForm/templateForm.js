import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import { Row, Col, Container, Form } from "react-bootstrap";
import TextField from "../../../../../shared/components/forms/TextField/textField";
import {
  saveTemplateThunk,
  getSavedTemplatesThunk,
  checkTemplateThunk,
  updateTemplateThunk
} from "../../../src/store/requestForm.reducer";
import { getFormattedUserId } from "../../../../../../services/auth.services";
const INITIAL_FORM_STATE = {
  formControls: {
    templateName: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    productLine: {
      checked: false,
      error: false,
    },
    product: {
      checked: false,
      error: false,
    },
    application: {
      checked: false,
      error: false,
    },
    role: {
      checked: false,
      error: false,
    },
    allocationPercentage: {
      checked: false,
      error: false,
    },
    technologies: {
      checked: false,
      error: false,
    },
    showTemplateNameRequired: {
      value: false,
      error: false,
    },
    showCheckboxSelectionRequired: {
      value: false,
      error: false,
    },
    updateTemplateConfirmation: {
      value: false,
      error: false,
    },
    showSaveTemplateDialog: {
      value: false,
      error: false,
    },
    existingTemplateId: "",
  },
  payload1: {
    rmId: "",
    templateName: "",
    productLineId: "",
    productId: "",
    applicationCode: "",
    roleId: "",
    allocation: "",
    technologyIds: []
  }
};



class TemplateForm extends React.Component {


  constructor(props) {
    super(props);
    this.state = {
      ...INITIAL_FORM_STATE,
    };
  };
  onCheckboxClick = (event) => {
    const { formControls } = this.state;
    const { currentState } = this.props;
    const name = event.target.name;
    let error = "";
    if (name === "technologies") {
      error = currentState.formControls.technologies.value === null || currentState.formControls.technologies.value.length === 0
    }
    else {
      error = currentState.formControls[name].value === ""
    }
    this.setState({
      formControls: {
        ...formControls,
        [name]: {
          ...formControls[name],
          checked: !formControls[name].checked,
          error: error
        },
        showCheckboxSelectionRequired: {
          ...formControls.showCheckboxSelectionRequired,
          value: false,
        },
      },
    });
  }
  onConfirmationPopupClose = () => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        updateTemplateConfirmation: {
          ...formControls.updateTemplateConfirmation,
          value: false,
        },
        existingTemplateId: ""
      },
    });
  }
  onUpdateTemplate = async () => {
    const { formControls } = this.state;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(this.props.userParams);
    const lanId = this.props.loggedInUser.isAuthenticated ? id : '';
    let payload = {
      rmId: lanId,
      templateName: formControls.templateName.value,
      productLineId: "",
      productId: "",
      applicationCode: "",
      roleId: "",
      allocation: "",
      technologyIds: []
    };
    const selectedTemplate = this.props.savedTemplates.filter(
      (el) => el.id == formControls.existingTemplateId
    )[0];

    if (formControls.productLine.checked) {
      payload.productLineId = this.props.currentState.formControls.productLine.value;
    } else {
      payload.productLineId = selectedTemplate.productLineId;
    }
    if (formControls.product.checked) {
      payload.productId = this.props.currentState.formControls.product.value;
    } else {
      payload.productId = selectedTemplate.productId;
    }
    if (formControls.application.checked) {
      payload.applicationCode = this.props.currentState.formControls.application.value;
    } else {
      payload.applicationCode = selectedTemplate.applicationCode;
    }
    if (formControls.role.checked) {
      payload.roleId = this.props.currentState.formControls.role.value;
    } else {
      payload.roleId = selectedTemplate.roleId;
    }
    if (formControls.allocationPercentage.checked) {
      payload.allocation = this.props.currentState.formControls.allocationPercentage.value;
    } else {
      payload.allocation = selectedTemplate.allocation;
    }
    if (formControls.technologies.checked) {
      for (let i = 0; i < this.props.currentState.formControls.technologies.value.length; i++) {
        payload.technologyIds.push(this.props.currentState.formControls.technologies.value[i].value
        )
      }
    } else {
      payload.technologyIds = selectedTemplate.technologies.split(',');
    }
    await this.props.updateTemplate(formControls.existingTemplateId, payload, this.callRequestId);

  }
  onSaveTemplate = async () => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(this.props.userParams);
    const lanId = this.props.loggedInUser.isAuthenticated ? id : '';
    const { formControls } = this.state;
    const { payload1 } = this.state;

    if (formControls.templateName.value === "") {
      this.setState({
        formControls: {
          ...formControls,
          showTemplateNameRequired: {
            ...formControls.showTemplateNameRequired,
            value: true,
          },
        },
      });
    } else if (!(formControls.productLine.checked || formControls.product.checked || formControls.application.checked || formControls.role.checked || formControls.allocationPercentage.checked || formControls.technologies.checked)) {

      this.setState({
        formControls: {
          ...formControls,
          showCheckboxSelectionRequired: {
            ...formControls.showCheckboxSelectionRequired,
            value: true,
          },
        },
      });



    } else if ((formControls.productLine.error && formControls.productLine.checked) || (formControls.product.error && formControls.product.checked) || (formControls.application.error && formControls.application.checked) || (formControls.role.error && formControls.role.checked) || (formControls.allocationPercentage.error && formControls.allocationPercentage.checked) || (formControls.technologies.error && formControls.technologies.checked)) {
      this.onSaveTemplateClick()

    }
    else {
      let payload = {
        rmId: lanId,
        templateName: formControls.templateName.value,
        productLineId: "",
        productId: "",
        applicationCode: "",
        roleId: "",
        allocation: "",
        technologyIds: []
      };
      if (formControls.productLine.checked) {
        payload.productLineId = this.props.currentState.formControls.productLine.value;
      }
      if (formControls.product.checked) {
        payload.productId = this.props.currentState.formControls.product.value;
      }
      if (formControls.application.checked) {
        payload.applicationCode = this.props.currentState.formControls.application.value;
      }
      if (formControls.role.checked) {
        payload.roleId = this.props.currentState.formControls.role.value;
      }
      if (formControls.allocationPercentage.checked) {
        payload.allocation = this.props.currentState.formControls.allocationPercentage.value;
      }
      if (formControls.technologies.checked) {
        for (let i = 0; i < this.props.currentState.formControls.technologies.value.length; i++) {
          payload.technologyIds.push(this.props.currentState.formControls.technologies.value[i].value
          )
        }
      }
      this.setState({
        payload1: {
          rmId: lanId,
          templateName: payload.templateName,
          productLineId: payload.productLineId,
          productId: payload.productId,
          applicationCode: payload.applicationCode,
          roleId: payload.roleId,
          allocation: payload.allocation,
          technologyIds: payload.technologyIds

        },
      });
      await this.props.checkTemplate(lanId, payload.templateName, this.checkTemplateCallBack);
    }
  }
  onSaveTemplateSubmit = async () => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(this.props.userParams);
    const lanId = this.props.loggedInUser.isAuthenticated ? id : '';
    const { formControls } = this.state;
    let payload = {
      rmId: lanId,
      templateName: formControls.templateName.value,
      productLineId: "",
      productId: "",
      applicationCode: "",
      roleId: "",
      allocation: "",
      technologyIds: []
    };
    if (formControls.productLine.checked) {
      payload.productLineId = this.props.currentState.formControls.productLine.value;
    }
    if (formControls.product.checked) {
      payload.productId = this.props.currentState.formControls.product.value;
    }
    if (formControls.application.checked) {
      payload.applicationCode = this.props.currentState.formControls.application.value;
    }
    if (formControls.role.checked) {
      payload.roleId = this.props.currentState.formControls.role.value;
    }
    if (formControls.allocationPercentage.checked) {
      payload.allocation = this.props.currentState.formControls.allocationPercentage.value;
    }
    if (formControls.technologies.checked) {
      for (let i = 0; i < this.props.currentState.formControls.technologies.value.length; i++) {
        payload.technologyIds.push(this.props.currentState.formControls.technologies.value[i].value
        )
      }
    }
    this.setState({
      payload1: {
        rmId: lanId,
        templateName: payload.templateName,
        productLineId: payload.productLineId,
        productId: payload.productId,
        applicationCode: payload.applicationCode,
        roleId: payload.roleId,
        allocation: payload.allocation,
        technologyIds: payload.technologyIds
      },
    });
    await this.props.checkTemplate(lanId, payload.templateName, this.checkTemplateCallBack);
  }

  checkTemplateCallBack = async (status, response) => {
    const { formControls } = this.state;
    const { payload1 } = this.state;
    
    if (status == "Success") {
      this.setState({
        formControls: {
          ...formControls,
          updateTemplateConfirmation: {
            ...formControls.updateTemplateConfirmation,
            value: true,
          },
          showSaveTemplateDialog:{
            ...formControls.showSaveTemplateDialog,
            value: false,
          },
          existingTemplateId: response
        },
      });

    } else {
      await this.props.saveTemplate(payload1, this.callRequestId);
    }
  }

  callRequestId = async (status, response) => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(this.props.userParams);
    const lanId = this.props.loggedInUser.isAuthenticated ? id : '';
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        updateTemplateConfirmation: {
          ...formControls.updateTemplateConfirmation,
          value: false,
        },
        existingTemplateId: ""
      },
    });
    this.props.onHide();
    this.props.getSavedTemplates(lanId)
  }

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      formControls: {
        ...formControls,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
        showTemplateNameRequired: {
          ...formControls.showTemplateNameRequired,
          value: false,
        },
      },
    });
  }

  onSaveTemplateClick = () => {
    const { formControls } = this.state;
    
    this.setState({
      formControls: {
        ...formControls,
        showSaveTemplateDialog: {
          ...formControls.showSaveTemplateDialog,
          value: true
        }
      }
    })
  }

  closeSaveTemplateDialog = () => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        showSaveTemplateDialog: {
          ...formControls.showSaveTemplateDialog,
          value: false
        }
      }
    })
  }

  render() {
    const { formControls } = this.state;
    return (
      <>
        <Modal
          {...this.props}
          size="lg"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          backdrop="static"
          keyboard={false}
        >
          <ModalHeader style={{ border: "none" }} closeButton>
            <Modal.Title>Save Template</Modal.Title>
          </ModalHeader>
          <div
            className="rrc-request-background"
            style={{
              backgroundColor: "#F5F6FA",
              marginTop: "7px",
              width: "95%",
              borderRadius: "6px",
              marginLeft: "18px",
            }}
          >
            <ModalBody style={{ border: "none" }}>
              <Form>
                <Form.Row>
                  <Form.Group as={Col}>
                    <TextField
                      name="templateName"
                      label="Template Name"
                      formObj={formControls.templateName}
                      isRequired={formControls.templateName.required}
                      onChange={this.onInputChange}
                    />
                  </Form.Group>
                </Form.Row>
                {formControls.showTemplateNameRequired.value ? (
                  <Form.Row>
                    <p style={{ color: "red" }}>
                      Template Name is required
                    </p>
                  </Form.Row>
                ) : (
                  ""
                )}
                <Form.Row>
                  <b>
                    Please select the fields that you would like to save in
                    the Template.
                  </b>
                </Form.Row>
                <Form.Row>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "4px",
                    }}
                  >
                    <input
                      name="productLine"
                      type="checkbox"
                      checked={formControls.productLine.checked}
                      onClick={this.onCheckboxClick}
                    />
                    &nbsp;&nbsp;
                    <p>Product Line</p>
                  </span>
                </Form.Row>
                <Form.Row>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "4px",
                    }}
                  >
                    <input
                      name="product"
                      type="checkbox"
                      checked={formControls.product.checked}
                      onClick={this.onCheckboxClick}
                    />
                    &nbsp;&nbsp;
                    <p>Product</p>
                  </span>
                </Form.Row>
                <Form.Row>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "4px",
                    }}
                  >
                    <input
                      name="application"
                      type="checkbox"
                      checked={formControls.application.checked}
                      onClick={this.onCheckboxClick}
                    />
                    &nbsp;&nbsp;
                    <p>Application</p>
                  </span>
                </Form.Row>
                <Form.Row>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "4px",
                    }}
                  >
                    <input
                      name="allocationPercentage"
                      type="checkbox"
                      checked={formControls.allocationPercentage.checked}
                      onClick={this.onCheckboxClick}
                    />
                    &nbsp;&nbsp;
                    <p>Allocation%</p>
                  </span>
                </Form.Row>
                <Form.Row>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "4px",
                    }}
                  >
                    <input
                      name="role"
                      type="checkbox"
                      checked={formControls.role.checked}
                      onClick={this.onCheckboxClick}
                    />
                    &nbsp;&nbsp;
                    <p>Role</p>
                  </span>
                </Form.Row>
                <Form.Row>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "4px",
                    }}
                  >
                    <input
                      name="technologies"
                      type="checkbox"
                      checked={formControls.technologies.checked}
                      onClick={this.onCheckboxClick}
                    />
                    &nbsp;&nbsp;
                    <p>Technologies</p>
                  </span>
                </Form.Row>
                {formControls.showCheckboxSelectionRequired.value ? (
                  <Form.Row>
                    <p style={{ color: "red" }}>
                      Please select atleast one field
                    </p>
                  </Form.Row>
                ) : (
                  ""
                )}
              </Form>
            </ModalBody>
          </div>
          <div class="col-md-12" style={{ marginTop: "10px" }}>
            <div style={{ float: "right" }} onClick={this.onSaveTemplate}>
              <button style={{ width: "120px" }} id="okay-btn">
                Save Template
              </button>
            </div>
            <div style={{ float: "right" }}>
              <button id="cancel-btn" onClick={this.props.onHide}>
                Cancel
              </button>
            </div>
          </div>
        </Modal>
        <Modal
          {...this.props}
          aria-labelledby="contained-modal-title-vcenter"
          centered
          backdrop="static"
          keyboard={false}
          show={formControls.showSaveTemplateDialog.value}
          
        >
          <ModalHeader style={{ border: "none", padding: "10px 1rem" }} closeButton>
            <Modal.Title style={{ fontSize: "1.3rem" }}>
              Empty field(s) detected!
            </Modal.Title>
          </ModalHeader>
          <div
            className="rrc-request-background"
            style={{
              backgroundColor: "#F5F6FA",
              width: "95%",
              borderRadius: "6px",
              marginLeft: "12px",
              padding: "0px",
            }}
          >
            <ModalBody style={{ border: "none" }}>
              Following field(s) are empty in the current request{"\n"},
              {formControls.productLine.error && formControls.productLine.checked ? <p style={{ fontWeight: "bold" }}>Product Line</p> : ""}
              {formControls.product.error && formControls.product.checked ? <p style={{ fontWeight: "bold" }}>Product</p> : ""}
              {formControls.application.error && formControls.application.checked ? <p style={{ fontWeight: "bold" }}>Application</p> : ""}
              {formControls.allocationPercentage.error && formControls.allocationPercentage.checked ? <p style={{ fontWeight: "bold" }}>Allocation%</p> : ""}
              {formControls.role.error && formControls.role.checked ? <p style={{ fontWeight: "bold" }}>Role</p> : ""}
              {formControls.technologies.error && formControls.technologies.checked ? <p style={{ fontWeight: "bold" }}>Technologies</p> : ""}
              Do you want to continue?
            </ModalBody>
          </div>
          <div class="col-md-12" style={{ marginTop: "10px" }}>
            <div style={{ float: "right" }} onClick={this.onSaveTemplateSubmit}>
              <button style={{ width: "120px" }} id="okay-btn">
                Yes
              </button>
            </div>
            <div style={{ float: "right" }}>
              <button
                id="cancel-btn"
                style={{ marginBottom: "10px" }}
                onClick={this.closeSaveTemplateDialog}
              >
                No
              </button>
            </div>
          </div>
        </Modal>

        <Modal
          {...this.props}
          aria-labelledby="contained-modal-title-vcenter"
          centered
          backdrop="static"
          keyboard={false}
          show={formControls.updateTemplateConfirmation.value}
          // , this.setState({
          //   ...formControls,
          //   formControls:{
          //     showSaveTemplateDialog:{
          //       ...formControls.showSaveTemplateDialog,
          //       value:false
          //     }
          //   }
          // })}
        >
          <ModalHeader style={{ border: "none", padding: "10px 1rem" }} closeButton>
            <Modal.Title style={{ fontSize: "1.3rem" }}>
              Update Template Confirmation
            </Modal.Title>
          </ModalHeader>
          <div
            className="rrc-request-background"
            style={{
              backgroundColor: "#F5F6FA",
              width: "95%",
              borderRadius: "6px",
              marginLeft: "12px",
              padding: "0px",
            }}
          >
            <ModalBody style={{ border: "none" }}>
              A Template with name {formControls.templateName.value} already
              exists. If you save you will override it with the new values.
              Do you want to continue?
            </ModalBody>
          </div>
          <div class="col-md-12" style={{ marginTop: "10px" }}>
            <div style={{ float: "right" }} onClick={this.onUpdateTemplate}>
              <button style={{ width: "120px" }} id="okay-btn">
                Yes
              </button>
            </div>
            <div style={{ float: "right" }}>
              <button
                id="cancel-btn"
                style={{ marginBottom: "10px" }}
                onClick={this.onConfirmationPopupClose}
              >
                No
              </button>
            </div>
          </div>
        </Modal>
      </>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  saveTemplate: (payload, callback) =>
    dispatch(saveTemplateThunk(payload, callback)),
  checkTemplate: (lanId, name, callback) =>
    dispatch(checkTemplateThunk(lanId, name, callback)),
  updateTemplate: (templateId, payload, callback) =>
    dispatch(updateTemplateThunk(templateId, payload, callback)),
  getSavedTemplates: (lanId) => dispatch(getSavedTemplatesThunk(lanId))
});
export default connect(mapStateToProps, mapDispatchToProps)(withRouter(TemplateForm));