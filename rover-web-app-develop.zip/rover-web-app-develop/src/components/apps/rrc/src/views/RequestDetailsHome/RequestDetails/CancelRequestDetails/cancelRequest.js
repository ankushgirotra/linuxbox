import React, { Component, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Row, Col, Container, Form } from "react-bootstrap";
import Button from "../../../../../../../shared/components/forms/Button/button"
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import ModalFooter from "react-bootstrap/ModalFooter";
import "bootstrap/dist/css/bootstrap.min.css";
import "./cancelRequest.scss";
import { Radio } from '@material-ui/core'
import { FormControlLabel, RadioGroup } from '@material-ui/core';
import Select from 'react-select'
import { addCommentsThunk, getRequestDetailsDataThunk } from "../../../../store/requestDetailsData.reducer"
import RequestDetails from '../requestDetails';
import SelectDropdown from "../../../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import { useDropzone } from "react-dropzone";
import { Trash2, XCircle } from "react-feather";
import { connect } from "react-redux";
import { onUploadCancelRequestThunk, onUploadCancelRequestDuplicateThunk, onCancelRequestThunk } from "../../../../store/cancelRequest.reducer";
import { getFormattedUserId } from '../../../../../../../../services/auth.services';
import TextArea from '../../../../../../../shared/components/forms/TextArea/textArea';
import ErrorMsg from "../../../../../../../shared/components/forms/errorMsg/errorMsg";

const INITIAL_STATE = {
  formControls: {
    duplicateReasons: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    cancelComments: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    }
  }
}


const activeStyle = {
  borderColor: '#2196f3'
};

const acceptStyle = {
  borderColor: '#00e676'
};

const rejectStyle = {
  borderColor: '#ff1744'
};

const INITIAL_CHECKBOX_STATE = {
  value: "c",
  checked: "c"
}

const CancelRequest = (props) => {
  const { onHide, duplicateRequests, userParams, addComments } = props;
  let empId = localStorage.getItem('emplyoee_id')
  let id = empId ? empId : getFormattedUserId(userParams);
  const lanId = props.loggedInUser.isAuthenticated ? id : ''

  const [requestDetailsState, setRequestDetailsState] = useState(INITIAL_STATE);
  const { requestDetailsData, getRequestDetailsData, cancelRequestId, cancelRequestStatus } = props;
  const [myFiles, setMyFiles] = useState([]);
  const [duplicateRequest, setDuplicateRequest] = useState(INITIAL_CHECKBOX_STATE);
  const [otherRequest, setOtherRequest] = useState({
    value: "d",
    checked: "d"
  });
  const [selectReason, setSelectReason] = useState(false);

  const [requestIdError, setRequestIdError] = useState(false);
  const [emptyFileError, setEmptyFileError] = useState(false);

  const MaxSize = 5000000 //(5MB);
  const maxFiles = 1;
  const onDrop = (acceptedFiles, fileRejections) => {
    if (acceptedFiles.length >= 1) {

      setMyFiles([...myFiles, ...acceptedFiles]);
    }
    setEmptyFileError(false);
  };
  const {
    acceptedFiles,
    fileRejections,
    getRootProps,
    getInputProps,
    open,
    isDragActive,
    isDragAccept,
    isDragReject,
  } = useDropzone({ onDrop: onDrop, accept: 'image/*, application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf', noClick: true, noKeyboard: true, maxFiles: 2, maxSize: MaxSize, multiple: false });

  const removeFile = (file) => {
    const newFiles = [...myFiles];
    newFiles.splice(newFiles.indexOf(file), 1);
    setMyFiles(newFiles);
  };
  const acceptedFileItems = acceptedFiles.map(file => (
    <li key={file.path}>
      {file.path} - {file.size} bytes
    </li>
  ));

  const fileRejectionItems = fileRejections && fileRejections.map(({ file, errors }) => (
    <li key={file.path}>
      {file.path} - {file.size} bytes
      <ul>
        {errors.map(e => (
          <li key={e.code}>{e.message}</li>
        ))}
      </ul>
    </li>
  ));

  const style = useMemo(
    () => ({ ...(isDragAccept ? acceptStyle : {}), ...(isDragReject ? rejectStyle : {}) }),
    [isDragAccept, isDragReject]
  );

  const onChangeDuplicate = (e) => {
    setEmptyFileError(false);
    if (e.target.value === 'a') {
      setDuplicateRequest({
        value: "c",
        checked: "c"
      });

    } else {
      setSelectReason(false);
      setDuplicateRequest({
        value: "a",
        checked: "a"
      });
      setOtherRequest({
        value: "d",
        checked: "d"
      });
    }
  }

  const onOtherChanges = (e) => {
    setRequestIdError(false);
    if (e.target.value === 'b') {
      setOtherRequest({
        value: "d",
        checked: "d"
      });
    } else {
      setSelectReason(false);
      setOtherRequest({
        value: "b",
        checked: "b"
      });
      setDuplicateRequest({
        value: "c",
        checked: "c"
      });
    }
  }



  const onModalClose = () => {

    setRequestIdError(false);
    setEmptyFileError(false);
    setDuplicateRequest(INITIAL_CHECKBOX_STATE);
    setRequestDetailsState(INITIAL_STATE);
    setSelectReason(false);
    removeFile();
    props.onModalClose(true);

  }

  useEffect(() => {
    let requestStatus = ""
    if (cancelRequestStatus === 1) {
      requestStatus = "Identifying Resource";
    } else if (cancelRequestStatus === 2) {
      requestStatus = "Resource Reserved";
    } else if (cancelRequestStatus === 3) {
      requestStatus = "Completed";
    } else if (cancelRequestStatus === 4) {
      requestStatus = "Cancelled";
    } else if (cancelRequestStatus === 5) {
      requestStatus = "External Blocker";
    }

  }, [])
  const onInputChange = (event) => {
    const { formControls } = requestDetailsState;
    const name = event.target.name;
    const value = event.target.value;

    setRequestDetailsState({
      ...requestDetailsState,
      formControls: {
        ...formControls,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
    setRequestIdError(false);


  };
  const onInputChangeEvent = (event) => {
    const { formControls } = requestDetailsState;
    const name = event.target.name;
    const value = event.target.value;

    setRequestDetailsState({
      formControls: {
        ...formControls,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  const handleSubmit = () => {
    // if (otherRequest.value === 'd' && duplicateRequest.value === 'c') {
    //     setSelectReason(true);
    // }
    // else if (duplicateRequest.value === 'a' && requestDetailsState.formControls.duplicateReasons.value === '') {
    //     setRequestIdError(true);
    // }
    // else if (otherRequest.value === 'b' && myFiles.length === 0) {
    //     setEmptyFileError(true);
    // } else {
    //     if (otherRequest.value === 'b') {
    //         let bodyFormData = new FormData();
    //         bodyFormData.append("file", myFiles[0]);
    //         props.onCancelRequestOther(lanId, cancelRequestId, bodyFormData, onCancelSuccess)
    //     }
    //     if (duplicateRequest.value === 'a') {
    //         const duplicateId = requestDetailsState.formControls.duplicateReasons.value;
    //         props.onCancelRequestDuplicate(lanId, cancelRequestId, duplicateId, onCancelSuccess)
    //     }
    // }
    if (requestDetailsState.formControls.cancelComments.value == "") {
      let formControls = requestDetailsState.formControls;

      setRequestDetailsState({
        formControls: {
          ...formControls,
          cancelComments: {
            ...formControls.cancelComments,
            error: true,
            errorMsg: "Comments field is required",
          },
        },
      });
    } else {

      const cancelRequestPayload = {
        reqId: cancelRequestId,
        rmId: lanId,
        cancelComments: requestDetailsState.formControls.cancelComments.value,
      }

      // const commentsPayload = {
      //   requestId: cancelRequestId,
      //   commentType: "Request",
      //   createdBy: lanId,
      //   comment: requestDetailsState.formControls.cancelComments.value
      // }
      // addComments(commentsPayload)
      props.onCancelRequest(cancelRequestPayload, onCancelSuccess)
    }
  }


  const onCancelSuccess = (status, data) => {
    if (status === 'success') {
      props.updateReqIdDetails(lanId, cancelRequestId);
      onModalClose()
    }
  }


  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      backdrop="static"
      keyboard={false}
      fullscreen={true | 'sm-down'}
      onHide={onModalClose}
    >
      <ModalHeader style={{ border: "none", fontSize: "22px !important" }} closeButton>
        <span className={"rrc-details-title"}>
          <p id="title" style={{ color: "black", marginLeft: "20px" }}>
            <b>Cancel Request - Request ID  {cancelRequestId && cancelRequestId != null ? cancelRequestId : "N/A"} </b>  | &nbsp; &nbsp;
          </p>
          <h4 style={{ color: "#3F66FB", marginTop: "10px", marginLeft: "-15px" }}>
            {cancelRequestStatus === "1" ? "Identifying Resource" :
              cancelRequestStatus === "2" ? "Resource Reserved" :
                cancelRequestStatus === "3" ? "Completed" :
                  cancelRequestStatus === "4" ? "Cancelled" :
                    cancelRequestStatus === "5" ? "External Blocker" : "N/A"}
          </h4>
        </span>
      </ModalHeader>
      <div className="" style={{ backgroundColor: "#F5F6FA", width: "96%", padding: "15px", marginLeft: "15px", borderRadius: "6px" }}>
        <p>Comments <span style={{ color: "red" }}>*</span></p>
        <TextArea
          name="cancelComments"
          label=""
          formObj={requestDetailsState.formControls.cancelComments}
          required={requestDetailsState.formControls.cancelComments.required}
          error={requestDetailsState.formControls.cancelComments.errorMsg}
          onChange={onInputChangeEvent}
        />

      </div>

      {/* <div className="" style={{ backgroundColor: "#F5F6FA", width: "96%", marginLeft: "15px", borderRadius: "6px" }}>
                <div style={{ border: "none" }}>
                    <p className="select-reason" style={{ marginTop: "10px", marginLeft: "20px" }}><b>Select Reason For Cancellation</b> </p><br />
                    {selectReason && <p style={{ marginLeft: "20px", color: "red", fontSize: "13px" }}>Please select the reason for cancelling the request</p>}

                    <div className="col" >
                        <RadioGroup
                            aria-label="Cancellation Reason"
                            defaultValue=""
                            name="radio-buttons-group"
                            className="RadioGroup"
                        >

                            <FormControlLabel style={{ marginTop: "20px", backgroundColor: "white", marginLeft: "0px" }} control={<Radio onClick={onChangeDuplicate} value={duplicateRequest.value} checked={duplicateRequest.checked === 'a'} inputProps={{ 'aria-label': 'a' }} />} value="Duplicate Request" />
                            <div style={{ backgroundColor: "white", marginTop: "-10px", paddingBottom: "20px", width: "98%" }}>
                                <h5 classNme="duplicate-request" style={{ marginTop: "-30px", marginLeft: "45px", fontSize: "15px" }}><b>Duplicate Request</b></h5>
                                {requestIdError && <p style={{ marginLeft: "44px", color: "red", fontSize: "13px", marginTop: "10px" }}>Please select the duplicate request in order to cancel the request</p>}
                                <p style={{ marginLeft: "45px", fontSize: "13px", color: "#1A1A1C", marginTop: "8px" }}>Select Original Rover Request ID</p>
                                <div style={{ width: "40%", marginLeft: "45px", marginTop: "-15px" }}>
                                    <SelectDropdown
                                        name="duplicateReasons"
                                        formObj={requestDetailsState.formControls.duplicateReasons}
                                        config={{
                                            options: [...duplicateRequests.length !== 0 ? duplicateRequests : duplicateRequests],
                                            id: "request_id",
                                            value: "request_id",
                                        }}
                                        placeholder=""
                                        isClearable={true}
                                        onChange={(e) =>
                                            onInputChange({
                                                target: { name: e.name, value: e.value },
                                            })
                                        }

                                    />

                                </div>
                            </div>
                            <FormControlLabel style={{ marginTop: "20px", backgroundColor: "white", marginLeft: "0px" }} control={<Radio onClick={onOtherChanges} value={otherRequest.value} checked={otherRequest.checked === 'b'} inputProps={{ 'aria-label': 'b' }} />} value="Other Reasons" />
                            <div className="otherReason" style={{ backgroundColor: "white", marginTop: "-10px", paddingBottom: "20px", width: "98%" }}>
                                <h5 classNme="duplicate-request" style={{ marginTop: "-30px", marginLeft: "45px", fontSize: "15px" }}><b>Other Reasons</b></h5>
                                {emptyFileError && <p style={{ marginLeft: "44px", color: "red", fontSize: "13px", marginTop: "10px" }}>Please attach documentation for the cancellation reason in order to cancel the request</p>}

                                <div style={{ color: "#8686A2", fontSize: "13px", paddingBottom: "5px", marginLeft: "45px", marginTop: "10px" }}>
                                    Please attach a screenshot or email confirmation with ITPM that the request is no longer required or confirmation that funding for the request is not available or has been delayed/cancelled. (Attach jpegs, pdf, png or MS Word Document.)
                                </div>

                                <p >

                                    {myFiles && myFiles.length
                                        ? myFiles.map((file, index) => (
                                            <div style={{ marginLeft: "45px" }} key={index}>
                                                {file.name}

                                                <span className="rover-property__icon" style={{ marginLeft: "10px" }} onClick={removeFile}>
                                                    <XCircle size="20" strokeWidth={3} />
                                                </span>
                                            </div>
                                        ))
                                        : <div
                                            {...getRootProps({
                                                className: "dropzone--file-selector",
                                                style,
                                            })}
                                        >
                                            <input {...getInputProps()} />
                                            <div>
                                                <p style={{ margin: "20px" }}>Drag your file here or <span style={{ color: "blue", textDecoration: "underline", color: "#02C0ED", cursor:"pointer" }} onClick={open}>browse</span> to upload</p>
                                            </div>
                                        </div>}
                                </p>
                            </div>
                        </RadioGroup>
                    </div>
                </div>
            </div>*/}
      <Row sm={2} md={2} lg={2} xl={2} className="pad-left" style={{ marginTop: "10px" }}>
        <div id="submit-button" onClick={handleSubmit}>
          <Button >
            <Trash2 size="16" strokeWidth="2" />
            <span className='mr-1' >Cancel</span>
          </Button></div>
      </Row>

    </Modal>

  )
}


const mapStateToProps = (state, ownProps) => ({
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  onCancelRequestOther: (rmId, reqId, formData, callback) =>
    dispatch(onUploadCancelRequestThunk(rmId, reqId, formData, callback)),
  onCancelRequestDuplicate: (rmId, reqId, duplicateId, callback) =>
    dispatch(onUploadCancelRequestDuplicateThunk(rmId, reqId, duplicateId, callback)),
  onCancelRequest: (payload, callback) =>
    dispatch(onCancelRequestThunk(payload, callback)),
  updateReqIdDetails: (reqId, lanId) =>
    dispatch(getRequestDetailsDataThunk(reqId, lanId)),
  addComments: (comment, callback) =>
    dispatch(addCommentsThunk(comment, callback)),

});

export default connect(mapStateToProps, mapDispatchToProps)(CancelRequest);

