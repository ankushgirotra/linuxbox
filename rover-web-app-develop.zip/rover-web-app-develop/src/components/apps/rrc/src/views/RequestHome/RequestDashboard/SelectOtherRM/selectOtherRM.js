import React, { useRef, useState, useCallback, useEffect } from "react";
import useOnClickOutside from "./clickOutsideHook";
import {
    getRMByRequestThunk
} from "../../../../store/requestDashboard.reducer";
import { setSelectedRms } from "../../../../store/common.reducer";
import { connect } from "react-redux";
import "./selectOtherRM.scss";
const SelectOtherRM = (props) => {
    const { rmList, lanId, iiqRole, setSelectedRms, selectedRms } = props;
    const selectOption = useRef();
    const selectPlaceholder = useRef();
    const selectIcon = useRef();

    const [applyBtnClicked, setApplyBtnClicked] = useState(false);
    const [selectedRMArr, setSelectedRMArr] = useState([]);
    const [disableBtn, setDisableBtn] = useState(false);

    const handler = useCallback(() => {
        if (rmList.length === 0) {
            props.getRMByRequest()
        }
        if (JSON.parse(sessionStorage.getItem('selectedRMArr'))) {
            const updatedList = rmList.length > 0 ? rmList.map(x => {
                if (x.rmId == lanId) {
                    return { ...x, selected: true }
                }
                return { ...x, selected: false }
            }) : props.rmByRequestList.map(x => {
                if (x.rmId == lanId) {
                    return { ...x, selected: true }
                }
                return { ...x, selected: false }
            })

            const previousSelection = JSON.parse(sessionStorage.getItem('selectedRMArr'));
            const previousSelectionList = updatedList.map(x => {
                if (previousSelection.includes(x.rmId)) {
                    return { ...x, selected: true }
                } return { ...x, selected: false }
            });
            setList(previousSelectionList);
            setOptionSelected(previousSelection.length);
            if (previousSelectionList.every(x => x.selected === true)) {
                setSelectAll(true);
                setDisableBtn(false);
            } else if (previousSelectionList.every(x => x.selected === false)) {
                setSelectAll(false);
                setDisableBtn(true);
            } else if (previousSelectionList.some(x => x.selected === false)) {
                setSelectAll(false);
            }
        }
        setDropdownOpen(false);
        setSelectedRMArr([]);
    }, [props.rmByRequestList]);

    useOnClickOutside(selectOption, selectPlaceholder, selectIcon, handler);

    useEffect(()=>{
        if(iiqRole.ADMIN){
            const selectedRMArr = listOfRm.filter(x => x.selected == true);
            const list = selectedRMArr.map(x => x.rmId);
            setSelectedRms(list)
        }
    },[props.rmByRequestList])
    const listOfRm = rmList.map(x => {
        if(selectedRms.length==0 && iiqRole.ADMIN){
            return { ...x, selected: true}
        }
        if (x.rmId == lanId) {
            return { ...x, selected: true }
        }
        if (selectedRms.includes(x.rmId)) {
            return { ...x, selected:true}
        }
        return { ...x, selected: false }
    });

    useEffect(() => {
        if (selectedRMArr.length > 0) {
            const list = listOfRm.map(x => {
                if (selectedRMArr.includes(x.rmId)) {
                    return { ...x, selected: true }
                } else {
                    return { ...x, selected: false }
                }
            });
            setList(list)
        } else {
            setList(listOfRm)
            setSelectAll(false);
        }

        return () => {
            sessionStorage.removeItem('selectedRMArr')
        }

    }, [props.rmList, applyBtnClicked]);

    const [list, setList] = useState([]);
    const [isDropdownOpen, setDropdownOpen] = useState(false);
    const [selectAll, setSelectAll] = useState(false);
    const [optionSelected, setOptionSelected] = useState(null);

    const onOpenDropdown = () => {
        if (!isDropdownOpen) {
            setDropdownOpen(true);
        } else {
            setDropdownOpen(false);
        }
    }

    useEffect(() => {
        if (!isDropdownOpen && !applyBtnClicked) {
            setOptionSelected(null);
            setList(listOfRm);
            setSelectAll(false);
        }
    }, [isDropdownOpen]);

    const onSelectAll = (e) => {
        setSelectAll(e.target.checked);
        if (e.target.checked) {
            const selectAllList = list.map(x => { return { ...x, selected: true } });
            const arrOfRm = selectAllList.map(x => x.rmId);
            setSelectedRMArr(arrOfRm)
            setOptionSelected(list.length);
            setList(selectAllList);
            setDisableBtn(false);
        } else {
            const deSelectAllList = list.map(x => {
                if (x.rmId == lanId) {
                    return { ...x, selected: true }
                }
                return { ...x, selected: false }
            });
            // setDisableBtn(true);
            setSelectedRMArr([lanId]);
            setOptionSelected(null);
            setList(deSelectAllList);
        }
    }

    const onOptionSelected = (event, index) => {
        if (!event.target.checked) {
            list[index].selected = false;
            setList(list);
            const length = mapRmIdAsArray(list);
            if (list.some(x => x.selected === false)) {
                setOptionSelected(length);
                setSelectAll(false);
                setDisableBtn(false);
            }
            if (list.every(x => x.selected === false)) {
                setOptionSelected(null);
                setSelectedRMArr([]);
                setSelectAll(false);
                setDisableBtn(true);
            }
        } else {
            list[index].selected = true;
            setList(list);
            mapRmIdAsArray(list);
            if (list.some(x => x.selected === true)) {
                setDisableBtn(false);
                setSelectAll(false);
            }
            if (list.every(x => x.selected === true)) {
                setDisableBtn(false);
                setSelectAll(true);
            }
        }
    }

    const onApply = () => {
        setTimeout(() => { sessionStorage.setItem('selectedRMArr', JSON.stringify(selectedRMArr)); }, 100)
        setApplyBtnClicked(true);
        props.onApply(selectedRMArr);
        setDropdownOpen(false);
    }

    const mapRmIdAsArray = (rmObj) => {
        const arrOfRm = rmObj.filter(x => { if (x.selected === true) { return x } });
        const rmIdArr = arrOfRm.map(x => x.rmId);
        setOptionSelected(rmIdArr.length);
        setSelectedRMArr(rmIdArr);
        return rmIdArr.length;
    }

    const clearSelect = () => {
        if (optionSelected && optionSelected > 0) {
            setOptionSelected(null);
            setList(listOfRm);
            setSelectAll(false);
            setDropdownOpen(false);
            setSelectedRMArr([]);
            props.onApply([]);
            sessionStorage.removeItem('selectedRMArr')
        }
    }

    return (
        <div className="table-filter-item" style={{ width: "285px", height: "28px", marginLeft: "8px", cursor: "pointer" }} >
            <div className="table-filter-labels" style={optionSelected ? { cursor: "pointer", color: "#3B77FE", paddingRight: "7px", width: "100%" } : { paddingRight: "7px", width: "100%" }} >
                <div className="d-flex justify-content-between">
                    <div className="flex-grow-1" ref={selectPlaceholder} onClick={onOpenDropdown}>{optionSelected ? `${optionSelected} ${optionSelected === 1 ? 'Selection' : 'Selections'}` : "Select Other Resource Managers"}</div>
                    <span onClick={clearSelect}><i className="fa fa-times" style={{ color: "#9394ad", marginRight: "8px", height: "12px", marginTop: "2px" }}></i></span>
                    <span onClick={onOpenDropdown} ref={selectIcon} ><i className="fa fa-caret-down" style={{ color: "#9394ad" }}></i></span>
                </div>
            </div>
            {isDropdownOpen && <div className="select-other-rm-option" ref={selectOption}>
                <div className="options-container">
                    <div>
                        <input type="checkbox" onChange={onSelectAll} checked={selectAll} />
                        <p className="table-filter-label" style={{ marginTop: "2px !important", color: "#363636" }}>Select All</p>
                    </div>
                    {list.length > 0 && list.map((rm, i) => {
                        return (
                            <div key={rm.rmId} style={{ padding: "15px 0px 0px 0px" }}>
                                <input type="checkbox" checked={rm.selected} onChange={(e) => onOptionSelected(e, i)} />
                                <p className="table-filter-label" style={{ marginTop: "2px !important", color: "#363636" }}>{rm.rmFullName}</p>
                            </div>
                        )
                    })}
                </div>
                <hr className="divider" />
                <div className="apply-btn-container d-flex flex-row-reverse">
                    <button className="apply-btn" style={disableBtn ? { cursor: 'not-allowed' } : {}} onClick={disableBtn ? '' : onApply}>
                        Apply
                            </button>
                </div>
            </div>}
        </div >)
};

const mapStateToProps = (state, ownProps) => ({
    rmByRequestList: state.RequestDashboardReducer.rmByRequestList,
    iiqRole: state.AuthReducer.ROVER_IIQ_ROLES,
    selectedRms: state.RequestsCommonReducer.selectedRms,
});

const mapDispatchToProps = (dispatch) => ({
    getRMByRequest: () => dispatch(getRMByRequestThunk()),
    setSelectedRms: (payload) => dispatch(setSelectedRms(payload))
});

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(SelectOtherRM);

