import React, {
  useState,
  useEffect,
} from "react";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import { connect } from "react-redux";
import { getFormattedUserId } from "../../../../../../../services/auth.services";
import SkillProfile from "./../../../../../skillsCentral/src/views/SkillProfile/skillProfile";
import AsyncCustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/AsyncSelect";
import { Row, Col, Form } from "react-bootstrap";
import { FORM_DATE_FORMAT } from "../../../constants/request.constans";
import Datepicker from "../../../../../pcdm/src/components/Datepicker/datepicker";
import TextField from "../../../../../../shared/components/forms/TextField/textField";
import moment from "moment";
import "./skillsCentralProfile.scss";
import { Radio } from "@material-ui/core";
import { FormControlLabel, RadioGroup } from "@material-ui/core";
import {
  getRequestDetailsDataThunk,
  onBoardResourceThunk,
  onBoardResourceSuccessThunk,
} from "../../../store";
import ErrorMsg from "../../../../../../shared/components/forms/errorMsg/errorMsg";

const INITIAL_FORM_STATE = {
  formControls: {
    onboardDate: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    productManager: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    emailText: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
    mailRecipients: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
    sendOnboardingEmail: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
  },
};
const SkillsCentralProfile = (props) => {
  const [requestFormState, setRequestFormState] = useState(INITIAL_FORM_STATE);
  const {
    mailRecipients,
    productManager,
    selectResourceName,
    rmEmailAndVendor,
    internalResource,
    userParams,
  } = props;
  const [disableButton, setDisableButton] = useState(false);
  let empId = localStorage.getItem('emplyoee_id')
  let id = empId ? empId : getFormattedUserId(userParams);
  const lanId = props.loggedInUser.isAuthenticated
    ? id
    : "";
  const [formState, setFormState] = useState({
    date: null,
    checked: null,
    productManager: productManager.productManagerId ? true : false,
  });
  const [sendEmail, setSendEmail] = useState({
    checked: "",
    value: "",
  });
  const handleSendEmail = (e) => {
    setFormState({
      productManager: productManager.productManagerId ? true : "",
      date: formState.date,
      checked: true,
    });
    setRequestFormState({
      ...requestFormState,
      formControls: {
        ...requestFormState.formControls,
        sendOnboardingEmail: {
          ...requestFormState.formControls.sendOnboardingEmail,
          error: false,
        },
      },
    });
    if (e.target.value === "Yes") {
      setSendEmail({
        checked: "Yes",
        value: "Yes",
      });
    } else if (e.target.value === "No") {
      setSendEmail({
        checked: "No",
        value: "No",
      });
    } else {
      setSendEmail({
        checked: "",
        value: "",
      });
    }
    // checkButtonIsEnabled()
  };
  const onInputChange = (event) => {
    const { formControls } = requestFormState;
    const name = event.target.name;
    const value = event.target.value;

    setRequestFormState({
      formControls: {
        ...formControls,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };
  const onRecipientsSelected = (value) => {
    const { formControls } = requestFormState;
    setRequestFormState({
      formControls: {
        ...formControls,

        error: false,
        mailRecipients: {
          ...formControls["mailRecipients"],
          error: false,
          value: value,
        },
      },
    });
  };
  const manageMonthSelection = (type, date) => {
    // let value = moment(date, FORM_DATE_FORMAT);
    const { formControls } = requestFormState;
    if (type === "onboardDate") {
      setFormState({
        checked: formState.checked,
        productManager: productManager.productManagerId ? true : "",
        date: true,
      });
      setRequestFormState({
        formControls: {
          ...formControls,
          isEdited: true,
          onboardDate: {
            ...formControls.onboardDate,
            value: date,
            error: false,
            errorMsg: "",
          },
        },
      });
    }
  };

  const onOnboardResource = (e) => {
    let isValidatedSuccess = true;

    e.preventDefault();
    let formControls = requestFormState.formControls;

    if (requestFormState.formControls.onboardDate.value === "") {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        onboardDate: {
          ...formControls.onboardDate,
          error: true,
          errorMsg: "Onboard Date field is required",
        },
      };
    }

    if (sendEmail.value === "") {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        sendOnboardingEmail: {
          ...formControls.sendOnboardingEmail,
          error: true,
          errorMsg: "Send Reservation Email field is required",
        },
      };
    }
    setRequestFormState({
      ...requestFormState,
      formControls: formControls,
    });

    if (isValidatedSuccess) {
      let email = [];
      // let getRMList = props.requestDetails.commentsData.map(
      //   (getName) => getName.name
      // );
      // let getRM = getRMList[0];
      if (sendEmail.value == "Yes") {
        if (requestFormState.formControls.mailRecipients.value != "") {
          requestFormState.formControls.mailRecipients.value.forEach(
            (element) => {
              email.push(element.value2.email);
            }
          );
        }
      }
      let empId = localStorage.getItem('emplyoee_id')
      let id = empId ? empId : getFormattedUserId(userParams);
      const payload = {
        rmId: props.loggedInUser.isAuthenticated
          ? id
          : "",
        reqid: props.requestDetails.request_id,
        otherRM: props.productManager.productManagerId,
        onboardingMail: sendEmail.checked === "Yes" ? 1 : 0,
        onboardingdate: moment(
          requestFormState.formControls.onboardDate.value
        ).format("YYYY-MM-DD"),
        resourceid: props.selectedResID,
        productManagerEmail: props.productManager.productManagerEmail,
        assignRMEmail: props.rmEmailAndVendor.managerEmail,
        emailBody: requestFormState.formControls.emailText &&
          requestFormState.formControls.emailText.value
          ? requestFormState.formControls.emailText.value
          : "",
        additionalRecipients: email.length > 0 ? email : []
      }

      props.onBoardResource(payload, onClickSuccess);

    }

  }


  useEffect(() => {
    setRequestFormState(INITIAL_FORM_STATE);
    setSendEmail({
      checked: "",
      value: "",
    });
  }, [props.selectedResID]);

  useEffect(() => {
    let flag = [];
    for (let element in formState) {
      flag.push(formState[element]);
    }
    if (flag.every((x) => x === true)) {
      setDisableButton(false);
    }
  }, [formState]);

  const onClickSuccess = (status, data) => {
    if (status === "success") {
      props.hide();
      props.onBoardResourceSuccess(
        props.requestDetails.request_id,
        onOnboardSuccess
      );
    }
  };

  const renderFunc = () => {
    return (
      <>
        <SkillProfile
          showProfile={props.selectedResID}
          readOnlyProfile={true}
        />
        {!props.resourceName && props.selectedResID ? (
          <div>
            <div className="onboarding-details-container">
              <span className="onboarding-details-title">
                <b>Reservation Details</b>
              </span>

              <Form>
                <Form.Row>
                  <Form.Group
                    as={Col}
                    style={{
                      padding: "15px 5px 0px 5px",
                      marginBottom: "0px",
                      marginTop: "-4px",
                    }}
                    className="rrc-request-calendar"
                  >
                    <Datepicker
                      name="onboardDate"
                      label="Onboard Date"
                      formObj={requestFormState.formControls.onboardDate}
                      isRequired={
                        requestFormState.formControls.onboardDate.required
                      }
                      onChange={manageMonthSelection}
                      dateFormat={FORM_DATE_FORMAT}
                      className={"request-datepicker"}
                    />
                  </Form.Group>
                  <Form.Group
                    as={Col}
                    style={{
                      padding: "15px 20px 15px 150px",
                      marginBottom: "0px",
                    }}
                  >
                    <p style={{ marginBottom: "15px", marginTop: "-4px" }}>
                      Send Reservation Email?{" "}
                      <span style={{ color: "red" }}>*</span>
                    </p>
                    <RadioGroup
                      style={{ marginTop: "-10px" }}
                      row
                      aria-label="send-onboarding-mail"
                      name="row-radio-buttons-group"
                    >
                      <FormControlLabel
                        value="yes"
                        control={
                          <Radio
                            onClick={handleSendEmail}
                            value="Yes"
                            checked={sendEmail.checked === "Yes"}
                          />
                        }
                        label="Yes"
                      />
                      <FormControlLabel
                        value="no"
                        control={
                          <Radio
                            onClick={handleSendEmail}
                            value="No"
                            checked={sendEmail.checked === "No"}
                          />
                        }
                        label="No"
                      />
                    </RadioGroup>
                    {requestFormState.formControls.sendOnboardingEmail.error ? (
                      <ErrorMsg
                        message={
                          requestFormState.formControls.sendOnboardingEmail
                            .errorMsg
                        }
                      />
                    ) : null}
                  </Form.Group>
                  <Form.Group as={Col} style={{ marginBottom: "0px" }}>
                    <div className="product-manager-field">
                      {sendEmail.value == "Yes" ? (
                        <div>
                          <p style={{ marginBottom: "2px"}}>
                            Product Manager{" "}
                            <span style={{ color: "red" }}>*</span>
                          </p>
                          <input
                            type="text"
                            isRequired={
                              requestFormState.formControls.productManager
                                .required
                            }
                            name="Product Manager"
                            value={
                              productManager.productManagerName &&
                                productManager.productManagerName.length
                                ? productManager.productManagerName
                                : "N/A"
                            }
                            disabled
                          />
                        </div>
                      ) : (
                          ""
                        )}
                    </div>
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group
                    style={{ width: "29%", padding: "0px 10px 5px 5px" }}
                  >
                    {sendEmail.value == "Yes" ? (
                      <AsyncCustomSelect
                        name="mailRecipients"
                        label="Add Email Recipients"
                        placeholder="Add Recipients"
                        isMulti={true}
                        formObj={requestFormState.formControls.mailRecipients}
                        config={{
                          options: mailRecipients,
                          value: "fullName",
                          id: "employeeId",
                        }}
                        onChange={(value) => onRecipientsSelected(value)}
                        showDefaultValues={true}
                      />
                    ) : (
                        ""
                      )}
                  </Form.Group>
                  <Form.Group
                    as={Col}
                    style={{
                      padding: "0px 0px 0px 15px",
                      marginTop: "-12px",
                    }}
                  >
                    {sendEmail.value == "Yes" ? (
                      <TextField
                        name="emailText"
                        label="Email Body Text"
                        formObj={requestFormState.formControls.emailText}
                        onChange={onInputChange}
                      />
                    ) : (
                        ""
                      )}
                  </Form.Group>
                </Form.Row>
              </Form>
            </div>
            <Row>
              <Col>
                <div className="onboard-button rcc-buttons">
                  <button
                    className="rcc-buttons-submit"
                    style={{ cursor: disableButton ? "not-allowed" : "" }}
                    onClick={disableButton ? "" : onOnboardResource}
                  >
                    Reserve Resource
                  </button>
                </div>
              </Col>
            </Row>
          </div>
        ) : null}
      </>
    );
  };

  const onOnboardSuccess = (status, data) => {
    if (status === "success") {
      props.updateReqIdDetails(lanId, props.requestDetails.request_id);
      props.hide();
    }
  };

  return (
    <>
      {props.showContent || props.resourceName ? (
        <FormModal
          visible={props.profile}
          closeModal={props.hide}
          header={"Skill Central Profile"}
          content={() => {
            return renderFunc();
          }}
          footer={() => null}
          className="rover-request-skill-profile"
          isSCForm={true}
        />
      ) : (
          renderFunc()
        )}
    </>
  );
};

const mapStateToProps = (state, ownProps) => ({
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
  requestDetails: state.RequestDetailsDataReducer.requestDetailsData,
});

const mapDispatchToProps = (dispatch) => ({
  updateReqIdDetails: (reqId, lanId) =>
    dispatch(getRequestDetailsDataThunk(reqId, lanId)),
  onBoardResourceSuccess: (rmId, callback) =>
    dispatch(onBoardResourceSuccessThunk(rmId, callback)),
  onBoardResource: (payload, callback) =>
    dispatch(onBoardResourceThunk(payload, callback)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SkillsCentralProfile);
