import React, { useMemo, useState, useRef, useEffect } from "react";
import DataGrid from "../../../../../../../pcdm/src/components/DataGrid/dataGrid";
import "./workOrderSearchTable.scss";


export default function WorkOrderSearchTable(props) {

  const { bflexWorkOrder, onWorkOrderSelect, parentContainer } = props;

  const searchBarWithTableContainer = useRef(null);

  const [filterText, setFilterText] = useState("");

  useEffect(() => {

    const handleOutsideClick = (event) => {
      if (
        searchBarWithTableContainer &&
        searchBarWithTableContainer.current &&
        parentContainer &&
        parentContainer.current &&
        !searchBarWithTableContainer.current.contains(event.target) &&
        !parentContainer.current.contains(event.target)
      ) {
        onWorkOrderSelect("outsideClick");
      }
    };

    document.addEventListener("mousedown", handleOutsideClick)

    return () => document.removeEventListener("mousedown", handleOutsideClick)

  }, [searchBarWithTableContainer, parentContainer])

  const columns = useMemo(() => [
    {
      Header: "Full Name",
      accessor: "fullName",
      Cell: ({ row: { original } }) => showTickIcon(original, "fullName", "workOrderId"),
      disableFilters: true,
    },
    {
      Header: "Job Posting",
      accessor: "jobPosting",
      Cell: ({ row: { original } }) => showTickIcon(original, "jobPosting", "workOrderId"),
      disableSortBy: true,
      disableFilters: true,
    },
    {
      Header: "Work Order #",
      accessor: "workOrderId",
      Cell: ({ row: { original } }) => showTickIcon(original, "workOrderId", "workOrderId"),
      disableFilters: true,
    },
  ]);

  const showTickIcon = (row, key, id) => {
    let displayValue = row[key];
    return <div onClick={() => onWorkOrderSelect(row[id])} className="workorder-link">{displayValue}</div>
  };

  const onSearch = (event) => {
    const value = event.target.value;
    setFilterText(value);
  };

  const data = useMemo(() => {
    let filteredData = [...bflexWorkOrder];
    if (filterText && filterText.trim().length) {
      let searchedKeyword = filterText.toLowerCase();
      filteredData = filteredData.filter(
        (row) =>
          row.workOrderId.toLowerCase().includes(searchedKeyword) ||
          row.jobPosting.toLowerCase().includes(searchedKeyword) ||
          row.fullName.toLowerCase().includes(searchedKeyword)
      );
    }
    let displayData = filteredData.length < 100 ? filteredData : filteredData.slice(0,100)
    return displayData;
  }, [filterText, bflexWorkOrder]);

  return (
    <div className="workorder_search_table-container" ref={searchBarWithTableContainer}>
      <div className="search-container">
        <label htmlFor="searchText">Search or select a work Order:</label>
        <input
          name="searchText"
          id="searchText"
          className={"pcdm-input sog-textbox"}
          type={"text"}
          placeholder="Type a Name, Job Posting or Work order #"
          value={filterText}
          onChange={onSearch}
          required={false}
        />
      </div>

      <div className="workorder_search_table sc-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          showUpdatedDataGrid={true}
          noRowText={"No Matching Results Found"}
        />
      </div>
    </div>
  )
}