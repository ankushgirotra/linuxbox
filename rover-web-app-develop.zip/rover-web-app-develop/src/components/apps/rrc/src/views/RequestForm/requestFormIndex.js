import React, { Fragment, useEffect } from "react";
import { Switch, Route, useRouteMatch, useHistory } from "react-router";
import { Row, Col } from "react-bootstrap";
import RequestForm from "./../RequestForm/requestForm";
import RequestStatus from "../RequestHome/RequestStatus/requestStatus"
import RequestNotification from "../RequestHome/RequestNotification/requestNotification"
import "./requestForm.scss";
import { connect } from "react-redux";
import {
  getOpenRequestThunk,
  getNotificationsThunk,
  getNotificationsListThunk,
} from "../../../src/store/requestStatus.reducer";
import { REQUEST_ROUTES } from "../../../../../../components/app/Route/constants/requestRoutes.constants";
import { getFormattedUserId } from "../../../../../../services/auth.services";


const RequestFormIndex = (props) => {

  useEffect(() => {
    const { userParams, loggedInUser } = props;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    let lanId = loggedInUser.isAuthenticated ? id : "";
    getOpenRequest(lanId)
    getNotifications(lanId)
    getNotificationsList(lanId)
  }, []);

  const history = useHistory();
  let { path } = useRouteMatch();

  const onHandleCloseRequest = () => {
    history.push(`${REQUEST_ROUTES.ROUTE}`);
  };

  const { getOpenRequest, openRequests, notificationsList, getNotificationsList, getNotifications, notifications } = props;

  return (
    <Fragment>
      <div className="container-fluid pad-25-top">
        {/* <Row style={{ margin: "0px" }}>
          <Col>
            <Row sm={2} md={2} lg={2} xl={2}>
              <RequestStatus openRequests={openRequests}></RequestStatus>
            </Row>
            <Row sm={2} md={2} lg={2} xl={2} style={{ marginTop: "10px" }}>
              <RequestNotification notifications={notifications} notificationsList={notificationsList}></RequestNotification>
            </Row>
          </Col>
          <Col sm={10} md={10} lg={10} xl={10} class="remove-padding">
            <div className={"rrc-container"}>
              <div className={"rrc-details-wrapper"}>
                <Row className="rrc-header-container">
                  <Col sm={4} md={4} lg={10} xl={10} className="adjust-padding">
                    <p className="rrc-header">Create new Request</p>
                  </Col>
                  <Col sm={2} md={2} lg={2} xl={2}>
                    <button
                      className="close-request"
                      onClick={() => onHandleCloseRequest()}
                    >
                      X
                    </button>
                  </Col>
                </Row>

                <RequestForm />
              </div>
            </div>

          </Col>
        </Row> */}
        <div className="request-container">
          <div className="request-status">
            <RequestStatus openRequests={openRequests}></RequestStatus>
            <RequestNotification notifications={notifications} notificationsList={notificationsList}></RequestNotification>
          </div>
          <div className="request-dash">
            <div className={"rrc-container"}>
              <div className={"rrc-details-wrapper"}>
                <Row className="rrc-header-container">
                  <Col sm={4} md={4} lg={10} xl={10} className="adjust-padding">
                    <p className="rrc-header">Create new Request</p>
                  </Col>
                  <Col sm={2} md={2} lg={2} xl={2}>
                    <button
                      className="close-request"
                      onClick={() => onHandleCloseRequest()}
                    >
                      X
                    </button>
                  </Col>
                </Row>
                <RequestForm />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

const mapStateToProps = (state, ownProps) => ({
  openRequests: state.RequestStatusReducer.openRequest,
  notifications: state.RequestStatusReducer.notifications,
  notificationsList: state.RequestStatusReducer.notificationsList,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  getOpenRequest: (lanId) => dispatch(getOpenRequestThunk(lanId)),
  getNotifications: (lanId) => dispatch(getNotificationsThunk(lanId)),
  getNotificationsList: (lanId) => dispatch(getNotificationsListThunk(lanId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestFormIndex);

