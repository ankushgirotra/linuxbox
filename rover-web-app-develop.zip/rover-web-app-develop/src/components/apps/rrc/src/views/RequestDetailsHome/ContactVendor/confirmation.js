import React, { Component, useEffect, useState } from "react";
import { Row, Col, Container, Form } from "react-bootstrap";
import Button from "../../../../../../shared/components/forms/Button/button";
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import ModalFooter from "react-bootstrap/ModalFooter";
import { connect } from "react-redux";
import Moment from 'moment';
import "bootstrap/dist/css/bootstrap.min.css";
import "./confirmation.scss";
import { addVendorEngagementThunk, getWorkflowDetailsThunk } from "../../../store/requestDetailsData.reducer";

const Confirmation = (props) => {
  const { requestDetailsData, addVendorEngagement, vendorList, vendor_id } = props;
  
  const [checked, setChecked] = useState(false);
  const [isRepeated, setIsRepeated] = useState(false);
  const { onHide } = props;
  let plannedStartDate =  Moment(requestDetailsData.planned_start).format("MM-DD-YYYY");
  useEffect(()=>{
    if(vendorList.findIndex(element => element.vendor===vendor_id && element.statusdescr==="Open")!==-1){
      setIsRepeated(true);
    }
  });

  const getMailBody = () => {
    return `Product Line: ${requestDetailsData.product_line}
Product:  ${requestDetailsData.product}
Role:  ${requestDetailsData.role}
Allocation %:  ${requestDetailsData.allocation}
Planned Start Date:  ${plannedStartDate}
Technologies:  ${requestDetailsData.technologies}
Location:  ${requestDetailsData.location?requestDetailsData.location:"-"}`;
  };

  const onModalClose = async (e) => {
    const currentDate =
      new Date().getFullYear() +
      "-" +
      (new Date().getMonth() + 1) +
      "-" +
      new Date().getDate();
    const payload = {
      vendorId: vendor_id,
      requestId: requestDetailsData.request_id,
      engagementStartDate: currentDate,
      engagementEndDate: requestDetailsData.end_date,
      vendorEngagementStatusId: "1",
      isVendorAccountable: "0",
      cancelComments: "",
    };
    console.log(vendorList.findIndex(element => element.vendor===vendor_id && element.statusdescr==="Open"))
    // let vendor
    if(vendorList.findIndex(element => element.vendor===vendor_id && element.statusdescr==="Open")!==-1){
      alert("Selected vendor already exists in opened state")
      props.onModalClose(false, vendorList)
      setChecked(false);
      setIsRepeated(true);
    } else{
      await addVendorEngagement(payload, updateVendorsList);
      props.getWorkflowDetails(requestDetailsData.request_id);
      setChecked(false);
      setIsRepeated(false)
    }
    
  };
  const updateVendorsList = (data) => {
    props.onModalClose(false, data);
  };

  const onCloseCancel = () => {
    setChecked(false);
    props.onReopenClose(true)
    props.onHide()
  }


  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      backdrop="static"
      keyboard={false}
    >
      <ModalHeader style={{ border: "none" }} >
        <Modal.Title id="contained-modal-title-vcenter">
          Contact Vendor
        </Modal.Title>
        <div
          className="close-button"
          style={{ marginTop: "5px" }}
          onClick={() => onCloseCancel()}
        >
          X
        </div>


        {/* const onModalClose = async (e) => {
       
        const currentDate = new Date().getFullYear()+ '-' + (new Date().getMonth() + 1) + '-' +new Date().getDate();
        const payload = {                
            vendorId: vendor_id,
            requestId: requestDetailsData.request_id,                
            engagementStartDate: currentDate,
            engagementEndDate: requestDetailsData.end_date,
            vendorEngagementStatusId: "1",
            isVendorAccountable: "0",
            cancelComments: ""
        }
        await addVendorEngagement(payload, updateVendorsList)
        setChecked(false);
        props.getWorkflowDetails(requestDetailsData.request_id);
    }
    const updateVendorsList = (data) => {
        props.onModalClose(false,data)
    }
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            backdrop="static"
            keyboard={false}

        >
          X
        </div> */}
      </ModalHeader>
      <div
        className="card-body"
        style={{
          backgroundColor: "#F5F6FA",
          marginTop: "7px",
          width: "95%",
          borderRadius: "6px",
          marginLeft: "18px",
        }}
      >
        <ModalBody style={{ border: "none" }}>
          <Row>
            <Col>
              <input
                onChange={() => setChecked(!checked)}
                defaultChecked={checked}
                type="checkbox"
                style={{ marginLeft: "-30px" }}
              />
              <span
                style={{
                  display: "flex",
                  marginLeft: "-8px",
                  justifyContent: "center",
                  textAlign: "left",
                  marginTop: "-23px",
                  color: "gray",
                }}
              >
                I understand that by clicking OK, I must contact the selected
                vendor immediately so that the Staffing Velocity metric can be
                properly calculated
              </span>
            </Col>
          </Row>
        </ModalBody>
      </div>
      <div class="col-md-12" style={{ marginTop: "15px" }}>
        {isRepeated?(
          <div style={{ float: "right" }}>
            <button disabled={!checked} id="okay-btn" onClick={onModalClose}>
              OK{" "}
            </button>
        </div>
        ):(
          <div style={{ float: "right" }}>
          <a href={`mailto:${""}?body=${encodeURIComponent(getMailBody())}`}>
            <button disabled={!checked} id="okay-btn" onClick={onModalClose}>
              OK{" "}
            </button>
          </a>{" "}
          </div>
        )}
        <div style={{ float: "right" }}>
          <button onClick={() => onCloseCancel()} id="cancel-btn">
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
};

const mapStateToProps = (state, ownProps) => ({
  requestDetailsData: state.RequestDetailsDataReducer.requestDetailsData,
});

const mapDispatchToProps = (dispatch) => ({
  addVendorEngagement: (vendorDetails, callback) =>
    dispatch(addVendorEngagementThunk(vendorDetails, callback)),

  addVendorEngagement: (vendorDetails, callback) => dispatch(addVendorEngagementThunk(vendorDetails, callback)),
  getWorkflowDetails: (reqId) => dispatch(getWorkflowDetailsThunk(reqId))

});

export default connect(mapStateToProps, mapDispatchToProps)(Confirmation);
