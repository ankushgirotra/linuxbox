import React, { useEffect, useState } from "react";
import "./requestTable.scss";
import { useTable, useFilters, useSortBy, useExpanded } from "react-table";
import { getRequestDetailsDataThunk, getRequestOpenVendorsThunk } from "../../../../store";
import { setRequestDetailsSelectStatus } from "../../../../store/common.reducer";
import { connect } from "react-redux";
import { useHistory } from "react-router";
import { REQUEST_ROUTES } from "../../../../../../../app/Route/constants/requestRoutes.constants";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { Copy } from "react-feather";
import ToolTip from "../../../../../../pcdm/src/components/ToolTip/ToolTip";
import moment from "moment";

const RequestTable = (props) => {
    const {
        data,
        columns,
        appendToCell,
        noRowText,
        userParams,
        loggedInUser,
        sortType,
        columnToBeSorted,
        setRequestDetailsSelectStatus,
        updateReqIdDetails,
    } = props;
    const [sortBy, setSortBy] = useState([{ id: columns.id, undefined }]);
    const {
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow,
    } = useTable(
        {
            columns, data, autoResetFilters: false, initialState: { sortBy }
        },
        useFilters,
        useSortBy,
        useExpanded
    );

    const cloneTtStyle = {
        display:"flex"
    }

    const ttTextStyle ={
        whiteSpace: "nowrap",
        flex: 1,
        textOverflow: "ellipsis",
        overflow: "hidden",
        minWidth: 0,
        color:"black"
    }

    const tooltipContent = () => {
        return (
            <span style={{cursor:"pointer"}} >
                <Copy size={14} id={"clone-icon-requests_table"}/> 
            </span>
        );
    };
    
    const getTableData = (row, cell) => {
        if (cell.column.id === 'status') {
            if (cell.value === 'Identifying Resource') {
                return (<p className={"status status-identifying d-flex justify-content-center align-items-center"}>{cell.value}</p>)
            } else if (cell.value === 'External Blocker') {
                return (<p className={"status status-blocker d-flex justify-content-center align-items-center"}>{cell.value}</p>)

            } else if (cell.value === 'Resource Reserved') {
                return (<p className={"status status-identified d-flex justify-content-center align-items-center"}>{cell.value}</p>)
            }
            else if (cell.value === 'Completed') {
                return (<p className={"status status-completed d-flex justify-content-center align-items-center"}>{cell.value}</p>)
            }
            else if (cell.value === 'Cancelled') {
                return (<p className={"status status-cancelled d-flex justify-content-center align-items-center"}>{cell.value}</p>)
            }
        } else if (cell.column.id === "plannedStart") {
            let cellValue = "";
            if (cell.value !== "") {
                cellValue = moment(cell.value).format("MM/DD/YYYY");
            } else {
                cellValue = "";
            }
            return cellValue;
        } else if (cell.column.id === "rmName") {
            if (row.original.plannedStart === "" && row.original.plannedEnd === "" && !(row.original.status === "Completed")) {
                return (<span style={cloneTtStyle}><p title={row.original.rmName} style={ttTextStyle}><ToolTip content={tooltipContent} toolTipTitle={"Cloned From"} toolTipPlacement={"top"} toolTipMessage={()=><p style={{color:"black"} }>Request Id: {row.original.clonedFrom}</p>}></ToolTip>{"   "}{row.original.rmName}</p></span>);
            } else {
                return (<p title={cell.value} style={ttTextStyle}>{cell.value}</p>);
            }
        } else {
            return cell.render("Cell")
        }
    }

    const history = useHistory();

    const onRowClick = async (request) => {
        if (request.column.id === "request_id") {
            let empId = localStorage.getItem('emplyoee_id')
            let id = empId ? empId : getFormattedUserId(userParams);
            let lanId = loggedInUser.isAuthenticated ? id : "";
            let requestId = request && request.row.values.request_id;
            let rmId = data.filter(x => x.request_id === requestId)[0];
            if (lanId != rmId.rmId) {
                localStorage.setItem('selectedRm', rmId.rmId)
            } else {
                localStorage.setItem('selectedRm', lanId)
            }

            localStorage.setItem('selectedRequestId', requestId);
            setRequestDetailsSelectStatus(true)
            await updateReqIdDetails(rmId.rmId,requestId)
            await props.getRequestOpenVendors(requestId);
            history.push({
                pathname: `${REQUEST_ROUTES.ROUTE}${REQUEST_ROUTES.CHILDREN.ROUTE1}`,
            });
        }
    }

    const getTableHeaderStyle = (header) => {
        if (header.id === 'plannedStart') {
            return { width: '13%' }
        } else if (header.id === 'request_id') {
            return { width: '7%' }

        } else if (header.id === 'createdDate') {
            return { width: '12%' }
        } else if (header.id === 'skills') {
            return { width: '12%' }
        }
        else {
            return {};
        }
    }

    useEffect(() => {
        let currentColumn = headerGroups[0].headers.find(header => header.id === columnToBeSorted)
        if (sortType === true || sortType === false) {
            setSortBy([{ id: currentColumn.id, desc: !sortType }]);
        } else if (headerGroups[0].headers.find(header => header.id === columnToBeSorted)) {
            setSortBy([{ id: currentColumn.id, desc: undefined }]);
        }

    }, [sortType, columnToBeSorted])

    return (
        <div className="rrc-data-grids">
            <table className="full-width">
                {" "}
                <thead>
                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map((column) => (
                                <th {...column.getHeaderProps()} style={getTableHeaderStyle(column)}>
                                    <span>{column.render("Header")}</span>
                                </th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {rows.length ? (
                        rows.map((row, i) => {
                            prepareRow(row);
                            return (
                                <React.Fragment>
                                    <tr>
                                        {row.cells.map((cell) => {
                                            return (
                                                <>
                                                    <td className={cell.column.id === "request_id" ? "id-props" : ""} onClick={() => onRowClick(cell)}>
                                                        {getTableData(row, cell)}
                                                        {appendToCell ? appendToCell(row, cell) : null}
                                                    </td>
                                                </>
                                            );
                                        })}
                                    </tr>
                                </React.Fragment>
                            );
                        })
                    ) : (
                            (props.tableData.status === DATA_STATUS.SUCCESS) && <tr>
                                <td className="empty-row" colSpan={columns.length}>
                                    {"No Results Found"}
                                </td>
                            </tr>
                        )}
                </tbody>
            </table>
        </div>
    );
};

const mapStateToProps = (state, ownProps) => ({
    tableData: state.RequestDashboardReducer.dashboardTableData,
    requestIdFilterStatus: state.AuthReducer.user,
    loggedInUser: state.AuthReducer,
    userParams: state.AuthReducer.user,
});

const mapDispatchToProps = (dispatch) => ({
    updateReqIdDetails: (reqId, lanId) =>
        dispatch(getRequestDetailsDataThunk(reqId, lanId)),
    getRequestOpenVendors: (reqId) => dispatch(getRequestOpenVendorsThunk(reqId)),
    setRequestDetailsSelectStatus: (status) => dispatch(setRequestDetailsSelectStatus(status))
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestTable);
