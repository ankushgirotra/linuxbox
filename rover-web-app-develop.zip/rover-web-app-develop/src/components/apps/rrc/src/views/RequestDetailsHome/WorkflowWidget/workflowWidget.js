import React, {useState, useEffect} from "react";
import "./workflowWidget.scss";
import { Row } from "react-bootstrap";
import moment from "moment";

const WorkflowWidget = (props) => {
    const { workflowDetails } = props;
    const [workFlowFirst, setFirstWorkFlow] = useState("null");
    const [workFlowSecond, setSecondWorkFlow] = useState("null");

    useEffect(() => {
       setFirstWorkFlow(workflowDetails[0] && workflowDetails[0].workflow_desc);
       setSecondWorkFlow(workflowDetails[1] && workflowDetails[1].workflow_desc);
    }, [workflowDetails]);
    
    const getStatus = (statusId) => {
        if (statusId === 1) {
            return (<p className={"widget-status widget-status-identifying d-flex justify-content-center align-items-center"}>Identifying Resource</p>)
        } else if (statusId === 2) {
            return (<p className={"widget-status widget-status-identified d-flex justify-content-center align-items-center"}>Resource Reserved</p>)
        } else if (statusId === 3) {
            return (<p className={"widget-status widget-status-completed d-flex justify-content-center align-items-center"}>Completed</p>)
        } else if (statusId === 4) {
            return (<p className={"widget-status widget-status-cancelled d-flex justify-content-center align-items-center"}>Cancelled</p>)
        } else if (statusId === 5) {
            return (<p className={"widget-status widget-status-blocker d-flex justify-content-center align-items-center"}>External Blocker</p>)
        } else {
            return ''
        }
    }

    return (<div>
        <Row>
            <p className="request-workflow-title">Timeline</p>
        </Row>
        <div className="prog">
            {workflowDetails && workflowDetails.map((workflow, i) => {
                if (i === 0 && workFlowFirst != "null") {
                    return (
                        <div className="grey-circle">
                            <span className="title d-flex">{workflow.timestamp?moment.utc(workflow.timestamp).format("MM/DD/YYYY"):"Please fill in the Planned Start date"}<br />{workflow.workflow_desc}</span>
                        </div>
                    )
                } else {
                    return (
                        <>
                            {i === 1 && workFlowFirst != "null" && workFlowSecond != "null" && <span className='grey'></span>}
                            {i === 2 && (workFlowSecond != "null" || workFlowFirst != "null")  && <><span className='grey-short'></span> <span className='short'></span></>}
                            {i > 2 && <span className='bar'></span>}
                            {i === 1 && workFlowSecond != "null" && 
                            <div className="grey-circle">
                                <div className="title d-flex flex-column">
                                    {/* <div className="order:1">{workflow.timestamp && moment.utc(workflow.timestamp).format("MM/DD/YYYY")}</div> */}
                                    <div className="order:2 status-spacing-2">{workflow.status_id !== 0 && getStatus(workflow.status_id)}</div>
                                    {!workflow.status_id ?
                                        <div className={"order:3 status-spacing-1"}>{workflow.workflow_desc}</div> :
                                        <div className={workflow.timestamp ? "order:3 status-spacing" : 'order:1'}>{workflow.workflow_desc}</div>}

                                </div>
                            </div>
                            }
                            {i > 1 && <div className="circle">
                                <div className="title d-flex flex-column" style={{ color: "#1A1A1C" }}>
                                    <div className="order:1">{workflow.timestamp && moment.utc(workflow.timestamp).format("MM/DD/YYYY")}</div>
                                    <div className="order:2 status-spacing-2">{workflow.status_id !== 0 && getStatus(workflow.status_id)}</div>
                                    {!workflow.status_id ?
                                        <div className={"order:3 status-spacing-1"}>{workflow.workflow_desc}</div> :
                                        <div className={workflow.timestamp ? "order:3 status-spacing" : 'order:1'}>{workflow.workflow_desc}</div>}

                                </div>
                            </div>}
                        </>
                    )
                }
            })}
        </div>
    </div>)
}

export default WorkflowWidget;