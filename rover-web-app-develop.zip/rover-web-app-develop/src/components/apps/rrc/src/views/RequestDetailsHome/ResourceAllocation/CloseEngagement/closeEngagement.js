import React, { Component, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Row, Col, Container, Form } from "react-bootstrap";
import Button from "../../../../../../../shared/components/forms/Button/button"
import Modal from "react-bootstrap/Modal";
import ModalHeader from "react-bootstrap/ModalHeader";
import "bootstrap/dist/css/bootstrap.min.css";
import "./closeEngagement.scss";
import TextField from "../../../../../../../shared/components/forms/TextField/textField";
import { getRequestDetailsDataThunk, onCloseVendorEngagementThunk,getWorkflowDetailsThunk } from "../../../../store/requestDetailsData.reducer";
import { getFormattedUserId } from '../../../../../../../../services/auth.services';
import { connect } from "react-redux";
import { Radio } from '@material-ui/core'
import { FormControlLabel, RadioGroup } from '@material-ui/core';


const CloseEngagement = (props) => {
    const { RequestId, RequestStatus, vendorDetails, userParams} = props;
    const [engagedVendorDetails, setEngagedVendorDetails] = useState(vendorDetails);
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated ? id : ''
    const [checked, setChecked] = useState(false)
    const [symbolsArray] = useState(["e","-","+","-","E","."])
    const onCloseEngagementModal = () => {
        const vendorArray = [...engagedVendorDetails];
        for (var i = 0; i < vendorArray.length; i++) {
                vendorArray[i].showVendorAccountableRequired = false;
                vendorArray[i].showCommentsRequired = false; 
                vendorArray[i].comments = ""; 
                vendorArray[i].vendorAccountable = ""; 
        }
        setEngagedVendorDetails(vendorArray);
        setChecked(false);
        props.onModalClose(true)
    }
    const onCheckBoxClick = (e) => {
        setChecked(e.target.checked)
    }
    const renderFunc = (vendors, index) => {
        if (vendors.selected) {
            return (
<>
                <Form.Row style={{ padding: "15px 10px",paddingLeft: "0px" }}>

                    <Form.Group as={Col} style={{ marginTop: "-2px", paddingRight: "0px", marginBottom: "0px" }}>
                        <div>
                            <div>
                                <p style={{ borderBottom: "1px solid #E8E8ED",marginTop:"2px", paddingLeft: "10px" }}>Vendor</p>
                                <Form.Control type="text" disabled value={vendors.vendordescr} /></div>

                        </div>
                    </Form.Group>
                    <Form.Group as={Col} style={{ paddingLeft: "0px", paddingRight: "0px", marginBottom: "0px" }} className="rrc-vendor-accountable">
                        <p style={{ borderBottom: "1px solid #E8E8ED", paddingLeft: "10px", marginBottom:"5px" }}>Is Vendor accountable for this?<span style={{ color: "red" }}>*</span></p>
                        <RadioGroup style={{ paddingLeft: "10px" }} row aria-label="send-onboarding-mail" name="row-radio-buttons-group">
                            <FormControlLabel control={<Radio onChange={(e) => handleVendorAccountable(e, index)} value="Yes" checked={vendors.vendorAccountable === 'Yes'} />} label="Yes" />
                            <FormControlLabel control={<Radio onChange={(e) => handleVendorAccountable(e, index)} value="No" checked={vendors.vendorAccountable === 'No'} />} label="No" />
                        </RadioGroup>
                        {vendors.showVendorAccountableRequired ?
                            <p style={{ color: "red" }}>Vendor Accountable field is required</p> : ""}

                    </Form.Group>
                    <Form.Group as={Col} className="close-engagement-comments" style={{ paddingLeft: "0px", marginBottom: "0px" }}>
                        <p style={{ borderBottom: "1px solid #E8E8ED" }}>Comments<span style={{ color: "red" }}>*</span></p>
                        <TextField
                            name="comments"
                            label=""
                            formObj={vendors.comments}
                            onChange={(e) => onInputChange(e, index)}
                        />
                        {vendors.showCommentsRequired ?
                            <p style={{ color: "red", marginTop: "5px" }}>Comments field is required</p> : ""}
                    </Form.Group>
                </Form.Row>
                <Form.Row style={{ borderBottom: "1px solid #B9B9CE"}}>
                <Form.Group as={Col} lg={4}>   
                <p >Profiles Received<span style={{ color: "red" }}>*</span></p>         
              <TextField
                name="profilesReceived"
                label=""
                type="number"
                min="0"
                formObj={vendors.profilesReceived}
                onChange={(e) => onInputChange(e, index)}
                onKeyDown={e =>  symbolsArray.includes(e.key) && e.preventDefault()}
              />
             {vendors.showProfilesReceivedRequired ? (
                <p style={{ color: "red", marginTop: "5px" }}>
                 {vendors.profilesReceivedErrorMsg}
                </p>
              ) : (
                ""
              )}
            </Form.Group>
            <Form.Group as={Col} lg={4}>     
            <p>Interviews Conducted<span style={{ color: "red" }}>*</span></p>       
              <TextField
                name="interviewsConducted"
                label=""
                type="number"
                min="0"
                formObj={vendors.interviewsConducted}
                onChange={(e) => onInputChange(e, index)}
                onKeyDown={e =>  symbolsArray.includes(e.key) && e.preventDefault()}
              />
              {vendors.showInterviewsConductedRequired ? (
                <p style={{ color: "red", marginTop: "5px" }}>
                     {vendors.interviewsConductedErrorMsg}
                </p>
              ) : (
                ""
              )}
            </Form.Group>
                </Form.Row>
                </>
            )
        }
    }
    useEffect(() => {
        let requestStatus = ""
        if (RequestStatus === 1) {
            requestStatus = "Identifying Resource";
        } else if (RequestStatus === 2) {
            requestStatus = "Resource Reserved";
        } else if (RequestStatus === 3) {
            requestStatus = "Completed";
        } else if (RequestStatus === 4) {
            requestStatus = "Cancelled";
        } else if (RequestStatus === 5) {
            requestStatus = "External Blocker";
        }
        setEngagedVendorDetails(vendorDetails)
    }, [vendorDetails])

    const onSubmit = () => {
        const vendorArray = [...engagedVendorDetails];
        for (var i = 0; i < vendorArray.length; i++) {
            if (vendorArray[i].selected && vendorArray[i].vendorAccountable == "") {
                vendorArray[i].showVendorAccountableRequired = true;
                setEngagedVendorDetails(vendorArray);
                return;
            } if (vendorArray[i].selected && vendorArray[i].comments == "") {
                vendorArray[i].showCommentsRequired = true;
                setEngagedVendorDetails(vendorArray);
                return;
            }
            if (vendorArray[i].selected && (vendorArray[i].profilesReceived == "" || vendorArray[i].profilesReceived < 0 || parseFloat(vendorArray[i].profilesReceived) % 1 != 0)) {
                
                vendorArray[i].showProfilesReceivedRequired = true;
                vendorArray[i].profilesReceivedErrorMsg =(vendorArray[i].profilesReceived == "" || parseFloat(vendorArray[i].profilesReceived) % 1 != 0) ? "Profiles Received field is required":"Negative numbers not allowed"
                setEngagedVendorDetails(vendorArray);
                setEngagedVendorDetails(vendorArray);
                return;
            }
            if (vendorArray[i].selected && (vendorArray[i].interviewsConducted == "" || vendorArray[i].interviewsConducted < 0 || parseFloat(vendorArray[i].interviewsConducted) % 1 != 0)) {

                vendorArray[i].showInterviewsConductedRequired = true;
                vendorArray[i].interviewsConductedErrorMsg = (vendorArray[i].interviewsConducted == "" || parseFloat(vendorArray[i].interviewsConducted) % 1 != 0) ? "Interviews Conducted field is required":"Negative numbers not allowed"
                setEngagedVendorDetails(vendorArray);
                return;
            }
        }
        let payload = {      
            requestId: localStorage.getItem('selectedRequestId'),
            vendorEngagementId: [],
            isVendorAccountable:[],
            closeComment:[],
            profilesReceived:[],
            interviewsConducted:[]
            
        };
        for (var i = 0; i < engagedVendorDetails.length; i++) {
            if (engagedVendorDetails[i].selected == true) {
                let object1 = { vendorId:engagedVendorDetails[i].vendorId, vendordescr:engagedVendorDetails[i].vendordescr }
                payload.vendorEngagementId.push(engagedVendorDetails[i].vendorEngagementId);
                payload.isVendorAccountable.push(engagedVendorDetails[i].vendorAccountable=="Yes"?1:0);
                payload.closeComment.push(engagedVendorDetails[i].comments)
                payload.profilesReceived.push(engagedVendorDetails[i].profilesReceived)
                payload.interviewsConducted.push(engagedVendorDetails[i].interviewsConducted)
            }
        }
      props.onCloseVendorEngagement(payload, onSubmitSuccess);
    }

    const onSubmitSuccess = (status, data) => {
        if (status === 'success') {
                props.getWorkflowDetails(RequestId)

            onCloseEngagementModal()
        }
    }
    const onInputChange = (e, i) => {
        const vendorArray = [...engagedVendorDetails];
        let allocationPercentage = e.target.value
        const pattern = /\b([0-9]|[1-9][0-9]|100)\b/;
        const newValue = pattern.test(allocationPercentage);        
        if(e.target.name == "comments"){  
        vendorArray[i].comments = e.target.value;
        vendorArray[i].showCommentsRequired = false;
        }
        else if(e.target.name == "profilesReceived"){  
            if (pattern.test(allocationPercentage) || String(allocationPercentage) == "" || allocationPercentage == '') {
               vendorArray[i].profilesReceived = e.target.value;
               vendorArray[i].showProfilesReceivedRequired = false;
            }
            if (!newValue && String(allocationPercentage) != "") {         
                return
            }
        }else if(e.target.name == "interviewsConducted"){  
            if (pattern.test(allocationPercentage) || String(allocationPercentage) == "" ||  allocationPercentage == '') {
                
               vendorArray[i].interviewsConducted = e.target.value;
               vendorArray[i].showInterviewsConductedRequired = false;
             }
             if (!newValue && String(allocationPercentage) != "") {         
                 return
             }
        }
        setEngagedVendorDetails(vendorArray);
    };

    const handleVendorAccountable = (e, i) => {
        const vendorArray = [...engagedVendorDetails];
        vendorArray[i].vendorAccountable = e.target.value;
        vendorArray[i].showVendorAccountableRequired = false;
        setEngagedVendorDetails(vendorArray);


    }


    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            backdrop="static"
            keyboard={false}
            fullscreen={true | 'sm-down'}
        >
            <ModalHeader style={{ border: "none", fontSize: "22px !important" }}>
                <span className={"rrc-details-title"}>
                    <span id="title" style={{ color: "black", marginLeft: "25px" }}>
                        <b>Close Vendor Engagement - Request ID  {RequestId && RequestId != null ? RequestId : "N/A"}   |</b> &nbsp; &nbsp;
                    </span>
                    <h4 style={{ color: "#3F66FB", marginTop: "10px", marginLeft: "-15px" }}>
                        {RequestStatus}
                    </h4>
                </span>
                <div className="close-button" style={{marginTop:"5px"}} onClick={onCloseEngagementModal}>X</div>
            </ModalHeader>

            <div className="close-engagement-container" >

                <Form>
                    {engagedVendorDetails.length != 0 ?
                        <div >
                        <div className={"rrc-vendors-list"}>
                            {engagedVendorDetails.map(renderFunc)}
                            </div>
                            <Form.Row>
                                <div className="checkbox" style={{ marginLeft: "0px",width:"98%"  }}>
                                    <input type="checkbox" style={{ marginTop: "20px", width: "18px", height: "18px"}} onChange={(e) => onCheckBoxClick(e)} defaultChecked={checked} /><span className="confirmation-text">I understand that the vendor{props.totalVendorsSelected >1?'s':""} should be considered accountable for this time if significant delays were caused by how long it took them to respond and/or act.</span>
                                </div>
                            </Form.Row>
                        </div> : ""}
                </Form>


            </div>
            <div className="pad-left" style={{ marginBottom: "15px", marginTop: "15px" }}>
                <div className="close-engagement-button" >
                    <button id="close-btn" disabled={!checked} onClick={onSubmit} >Close Engagement</button>
                </div>
            </div>

        </Modal>

    )
}

const mapStateToProps = (state, ownProps) => ({
    userParams: state.AuthReducer.user,
    loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
    onCloseVendorEngagement: (payload, callback) => dispatch(onCloseVendorEngagementThunk(payload, callback)),
    updateReqIdDetails: (reqId, lanId) =>
        dispatch(getRequestDetailsDataThunk(reqId, lanId)),
        getWorkflowDetails: (reqId) => dispatch(getWorkflowDetailsThunk(reqId))

});

export default connect(mapStateToProps, mapDispatchToProps)(CloseEngagement);
