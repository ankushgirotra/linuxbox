import React, {Fragment} from "react";
import "./requestNotification.scss";
import { REQUEST_ROUTES } from "../../../../../../app/Route/constants/requestRoutes.constants";
import { connect } from "react-redux";
import { useHistory } from "react-router";
import { getRequestDetailsDataThunk, getRequestOpenVendorsThunk } from "../../../store";
import moment from "moment";
import { getFormattedUserId } from "../../../../../../../services/auth.services";


const RequestNotification = (props) => {

  const { notifications, 
    notificationsList,
    userParams,
    loggedInUser } = props;

  const history = useHistory();

  const onReqClick = async (request) => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    let lanId = loggedInUser.isAuthenticated ? id : "";
   // await props.updateReqIdDetails(request,lanId);
   localStorage.setItem('selectedRequestId',request);
    await props.getRequestOpenVendors(request);
    history.push({
      pathname: `${REQUEST_ROUTES.ROUTE}${REQUEST_ROUTES.CHILDREN.ROUTE1}`,
    });

  }

  const renderFunc = (notif, index) => {
    let notifMessage=""
    if(notif.days === "0") {
      notifMessage = (
        <Fragment>
          <b>Due Today</b>
        </Fragment>
      );
    } else {
      notifMessage = (
        <Fragment>
          Late by <span style={{display:"inline-block"}}><b>{notif.days}</b> {notif.days>1?'days':'day'}</span>
        </Fragment>
      );
    }
    return (
      <div className={notif.days === moment(notif.days).format("YYYY-MM-DD") ? "rrc-notifications-details-notificationsDue" : "rrc-notifications-details-notificationsLate"}>
        <tr key={index}>
          {notif.days !== moment(notif.days).format("YYYY-MM-DD") ?
            <p style={{ padding: "5px" }}>
              <span>
                Request <td className={"id-props"} onClick={() => onReqClick(notif.request_id)}>#{notif.request_id}</td> - {notifMessage}
              </span>
            </p>
            :
            <p style={{ padding: "5px" }}>
              <span>
                Request <td className={"id-props"} onClick={() => onReqClick(notif.request_id)}>#{notif.request_id}</td> - Due on <b>{moment(notif.days).format("MM/DD")}</b>
              </span>
            </p>
          }
        </tr>
      </div>

    )
  }

  return (
    <div className="rrc-user-details-notification">
      <div className="rrc-notifications-details">
        <h5 className="rrc-notifications-details-title" style={{color:"black"}}>
          Action Items
        </h5>
        <hr style={{marginTop:"5px"}}/>
        <div className="rrc-request-notifications">
          <div>
            <p className="rrc-request-notifications-description">
              <span className="rrc-request-notifications-late">{notifications.lateStatus}</span> Late
            </p>
          </div>
          <div>
            <p className="rrc-request-notifications-description">
              <span className="rrc-request-notifications-due">{notifications.upComing}</span> Upcoming
            </p>
          </div>
        </div>
        <hr />
        <div className={"rrc-notifications-list"}>
          <table>
            <tbody>
              <tr>
                {notificationsList.length === 0 ? "" : notificationsList.map(renderFunc)}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )

}

const mapStateToProps = (state, ownProps) => ({
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  updateReqIdDetails: (requestId, callback) =>
    dispatch(getRequestDetailsDataThunk(requestId, callback)),
  getRequestOpenVendors: (reqId) => dispatch(getRequestOpenVendorsThunk(reqId))
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestNotification);
