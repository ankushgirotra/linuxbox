import React, { useState, useEffect } from 'react';
import { connect } from "react-redux";
import { useHistory } from "react-router";
import { Row, Col, Form } from "react-bootstrap";
import Modal from "react-bootstrap/Modal";
import ModalHeader from "react-bootstrap/ModalHeader";
import { Radio } from "@material-ui/core";
import { FormControlLabel, RadioGroup } from "@material-ui/core";
import { REQUEST_ROUTES } from "../../../../../../app/Route/constants/requestRoutes.constants";

import SelectDropdown from "../../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../../shared/components/forms/TextField/textField";
import { reassignRequestThunk, getRequestDetailsDataThunk } from "../../../store/requestDetailsData.reducer";
import { getFormattedUserId } from '../../../../../../../services/auth.services';

import "./reassignResource.scss";

const INITIAL_FORM_STATE = {
    formControls: {
        rm: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        email: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        rmName: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disabled: false,
        },
    },
};

const ReassignResource = (props) => {
    const { RequestId, RequestStatus, newRMList, reassignRequest, userParams } = props;
    const [reassignState, setReassignState] = useState(INITIAL_FORM_STATE);
    const [checked, setChecked] = useState(false)
    const [rmList, setRMList] = useState([])
    const [sendEmail, setSendEmail] = useState({
        checked: "No",
        value: "No",
    });
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated ? id : ''

    useEffect(() => {
        const newList = [...newRMList];
        let index = newList.findIndex((list) => list.rmId === lanId);
        if (index > -1) {
            newList.splice(index, 1);
            setRMList(newList);
        }
    }, [newRMList]);
    const onSelectChange = (event) => {
        const newManagerObj = rmList.filter(rm => rm.rmId === event.target.value)[0];
        const { formControls } = reassignState;
        setReassignState({
            ...reassignState,
            formControls: {
                ...formControls,
                rm: {
                    ...formControls.rm,
                    errorMsg: '',
                    error: false,
                    value: event.target.value,
                },
                rmName: {
                    ...formControls.rmName,
                    errorMsg: '',
                    error: false,
                    value: newManagerObj.rmFullName,
                },
            },
        });
    };


    const onInputChange = (event) => {
        const { formControls } = reassignState;
        setReassignState({
            ...reassignState,
            formControls: {
                ...formControls,
                email: {
                    ...formControls.email,
                    errorMsg: '',
                    error: false,
                    value: event.target.value,
                },
            },
        });
    };

    const onCheckBoxClick = (e) => {
        setChecked(e.target.checked)
    }

    const onSubmit = () => {
        const { formControls } = reassignState;
        if (reassignState.formControls.rm.value === '') {
            setReassignState({
                ...reassignState,
                formControls: {
                    ...formControls,
                    rm: {
                        ...formControls.rm,
                        error: true,
                        errorMsg: 'New resource manager field is required',
                    },
                },
            });
        } else if (reassignState.formControls.email.value === '') {
            setReassignState({
                ...reassignState,
                formControls: {
                    ...formControls,
                    email: {
                        ...formControls.email,
                        error: true,
                        errorMsg: 'Email body content field is required',
                    },
                },
            });
        } else {
            const requestPayload = {
                requestId: RequestId,
                newManagerId: reassignState.formControls.rm.value,
                newManagerName: reassignState.formControls.rmName.value,
                originalRMId: lanId,
                emailText: reassignState.formControls.email.value
            
            }
            reassignRequest(requestPayload, onSubmitSuccess)
        }
    }
    const history = useHistory();
    const onSubmitSuccess = (status, data) => {
        if (status === 'success') {
            props.updateReqIdDetails(lanId,RequestId);
            onModalClose();
            history.push({
                pathname: `${REQUEST_ROUTES.ROUTE}`
              })
        }
    }

    const onModalClose = () => {
        setReassignState(INITIAL_FORM_STATE);
        setChecked(false);
        props.onModalClose(true)
    }

    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            backdrop="static"
            keyboard={false}
            fullscreen={true | 'sm-down'}
        >
            <ModalHeader style={{ border: "none", fontSize: "22px !important" }}>
                <span className={"rrc-details-title"}>
                    <span id="title" style={{ color: "black", marginLeft: "25px" }}>
                        <b>Reassign Request - Request ID  {RequestId && RequestId != null ? RequestId : "N/A"}   |</b> &nbsp; &nbsp;
                    </span>
                    <h4 style={{ color: "#3F66FB", marginTop: "10px", marginLeft: "-15px" }}>
                        {RequestStatus === "1" ? "Identifying Resource" :
                            RequestStatus === "2" ? "Resource Reserved" :
                                RequestStatus === "3" ? "Completed" :
                                    RequestStatus === "4" ? "Cancelled" :
                                        RequestStatus === "5" ? "External Blocker" : "N/A"}
                    </h4>
                </span>
                <div className="close-button" onClick={onModalClose}>X</div>
            </ModalHeader>
            <div className="external-blocker-container" >
                <Form>
                    <Form.Row>
                        <div className="external-blocker-dropdown">
                            <SelectDropdown
                                name="newResourceManager"
                                label="New Resource Manager"
                                formObj={reassignState.formControls.rm}
                                config={{
                                    options: [...rmList.length !== 0 ? rmList : rmList],
                                    id: "rmId",
                                    value: "rmFullName",
                                }}
                                placeholder="New Resource Manager"
                                isRequired={reassignState.formControls.rm.required}
                                isClearable={true}
                                onChange={(e) =>
                                    onSelectChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                            />
                        </div>
                        <Form.Group as={Col} style={{ marginBottom: "0px" }}>
                            <div className="plan-to-resolve">
                                    <TextField
                                        name="emailText"
                                        label="Email Body Content"
                                        formObj={reassignState.formControls.email}
                                        onChange={onInputChange}
                                        isRequired={reassignState.formControls.email.required}
                                    />
                            </div>
                        </Form.Group>
                    </Form.Row>
                    <Form.Row>
                        <div className="checkbox" style={{ marginLeft: "30px" }}>
                            <input onChange={(e) => onCheckBoxClick(e)} defaultChecked={checked} type="checkbox" style={{ marginTop: "20px", width: "18px", height: "18px" }} /><span className="confirmation-text">&nbsp;&nbsp;By clicking the checkbox, I am confirming that the resource request will belong to the resource manager selected above and I will no longer be able to edit the request.</span>
                        </div>
                    </Form.Row>
                </Form>
            </div>
            <Row sm={2} md={2} lg={2} xl={2} className="pad-left" style={{ marginTop: "10px" }}>
                <div className={checked ? "submits-button" : "submits-button disable-btn"} style={{ padding: "0px", paddingTop: "9px", textAlign: "center" }} onClick={checked ? onSubmit : ''}>
                    <p style={{ marginTop: "20px !important" }}>Submit</p>
                </div>
            </Row>
        </Modal>
    )
}

const mapStateToProps = (state, ownProps) => ({
    newRMList: state.RequestDetailsDataReducer.rmNewList,
    userParams: state.AuthReducer.user,
    loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
    reassignRequest: (reqPayload, callback) => dispatch(reassignRequestThunk(reqPayload, callback)),
    updateReqIdDetails: (reqId, lanId) => dispatch(getRequestDetailsDataThunk(reqId, lanId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ReassignResource);
