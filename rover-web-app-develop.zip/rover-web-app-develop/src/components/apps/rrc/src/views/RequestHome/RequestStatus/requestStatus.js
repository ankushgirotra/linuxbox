import React, { useEffect } from "react";
import "./requestStatus.scss";
import { connect } from "react-redux";
import {
  getLoggedInRmInfoThunk
} from "../../../../src/store/requestStatus.reducer";
import { getFormattedUserId } from "../../../../../../../services/auth.services";
import Avatar from "../../../../../../../assets/images/avatar@2x.png"
const RequestStatus = (props) => {
  const { openRequests, rmInfo, getLoggedInRmInfo, userParams, loggedInUser } = props;
  const { openRequests: openRequest, identifyResource, resourceIdentified, externalBlockers } = openRequests;
  let empId = localStorage.getItem('emplyoee_id')
  let id = empId ? empId : getFormattedUserId(userParams);
  const lanId = loggedInUser.isAuthenticated ? id : "";

  useEffect(() => {
    getLoggedInRmInfo(lanId)
  }, [lanId]);

  return (
    <div className="rrc-user-details-status">
      <div className="avatar"><img src={Avatar}></img><div className="initials">{rmInfo.initials}</div></div>
      <div className="rrc-user-details-name">
        <p className="rrc-user-details-name-color">{rmInfo.full_name}</p>
      </div>
      <div className="rrc-user-details-title">
        <p className="rrc-user-details-title-color">
          {rmInfo.department_descr}
        </p>
      </div>
      <div className="rrc-user-details-location">
        <p className="rrc-user-details-location-color">{rmInfo.location_descr}</p>
      </div>
      <div className="rrc-user-details-manager">
        <p className="rrc-user-details-manager-color">Manager:</p>
        <p className="rrc-user-details-manager-name">{rmInfo.manager_name}</p>
      </div>
      <hr />
      <div>
        <div className="rrc-request">
          <div className="rrc-request-open">
            <p className="rrc-request-open-text">{openRequest} Open Requests</p>
          </div>
        </div>
        <div className="rrc-request-status">
          <div>
            <p className="rrc-request-status-description">
              <span className="rrc-request-status-assigned">{identifyResource}</span> Identifying 
              Resource
            </p>
          </div>
          <div>
            <p className="rrc-request-status-description">
              <span className="rrc-request-status-identified">{resourceIdentified}</span> Resource
              Reserved
            </p>
          </div>
          <div>
            <p className="rrc-request-status-description">
              <span className="rrc-request-status-external">{externalBlockers}</span> External
              Blocker
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = (state, ownProps) => ({
  rmInfo: state.RequestStatusReducer.rmInfo,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  getLoggedInRmInfo: (loggedInId) => dispatch(getLoggedInRmInfoThunk(loggedInId))
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestStatus);

