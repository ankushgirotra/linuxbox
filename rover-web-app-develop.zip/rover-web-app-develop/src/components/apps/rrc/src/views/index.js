import React, { useEffect } from "react";
import { Switch, Route, useRouteMatch, useHistory } from "react-router";
// import ReviewerHome from "./Reviewer/reviewerHome";
// import SOGSubmissionForm from "./SOGSubmissionForm/submissionForm";
import { REQUEST_ROUTES } from "../../../../../components/app/Route/constants/requestRoutes.constants";
import RequestHome from "./RequestHome/requestHome";
import "./index.scss";
import requestFormIndex from "./RequestForm/requestFormIndex";
import RequestDetailsHome from "./RequestDetailsHome/requestDetailsHome";

const RequestIndexPage = () => {
  let { path } = useRouteMatch();

  useEffect(()=>{
    document.title = "Rover Requests";
  })

  return (
    <Switch>
      <Route path={`${path}`} component={RequestHome} />
      <Route
        path={`${path}${REQUEST_ROUTES.CHILDREN.ROUTE}`}
        component={requestFormIndex}
      />
      <Route
        path={`${path}${REQUEST_ROUTES.CHILDREN.ROUTE1}`}
        component={RequestDetailsHome}
      />
    </Switch>
  );
};

export default RequestIndexPage;
