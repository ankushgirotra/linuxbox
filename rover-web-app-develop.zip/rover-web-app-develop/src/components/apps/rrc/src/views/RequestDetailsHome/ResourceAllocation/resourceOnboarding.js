import React, {
  Component,
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from "react";
import { Row, Col, Container, Form } from "react-bootstrap";
import Modal from "react-bootstrap/Modal";
import ModalHeader from "react-bootstrap/ModalHeader";
import "bootstrap/dist/css/bootstrap.min.css";
import Datepicker from "../../../../../pcdm/src/components/Datepicker/datepicker";
import { getFormattedUserId } from "../../../../../../../services/auth.services";
import  moment  from "moment";
import { FORM_DATE_FORMAT } from "./../../../constants/request.constans";
import TextField from "../../../../../../shared/components/forms/TextField/textField";
import ErrorMsg from "../../../../../../shared/components/forms/errorMsg/errorMsg";
import { Radio } from "@material-ui/core";
import {
  getRequestDetailsDataThunk,
  onCloseVendorEngagementThunk,
  getProductManagerThunk,
} from "../../../store";
import { FormControlLabel, RadioGroup } from "@material-ui/core";
import "./resourceOnboarding.scss";
import { connect } from "react-redux";
import { onboardExternalVendorResourceThunk } from "../../../store";
import { getRequestOpenVendorsThunk } from "./../../../store/requestDetailsData.reducer";
import AsyncCustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/AsyncSelect";


const INITIAL_FORM_STATE = {
  formControls: {
    vendor: {
      value: "",
      error: false,
      errorMsg: "",
      disable: true,
    },
    location: {
      value: "",
      error: false,
      errorMsg: "",
      disable: true,
    },
    resourceFullName: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    profilesReceived: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    interviewsConducted: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    onboardDate: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    productManager: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    onboardingComments: {
      value: "",
      error: false,
      errorMsg: "",
      disable: false,
    },
    sendOnboardingEmail: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    additionalMailRecipients: {
      value: "",
      error: false,
      errorMsg: "",
      disable: false,
    },
  },
};

const ResourceOnboarding = (props) => {
  const [requestFormState, setRequestFormState] = useState(INITIAL_FORM_STATE);
  const {
    resourceOnboardingId,
    resourceOnboardingStatus,
    vendorDetails,
    totalVendorsSelected,
    additionalMailRecipients,
    productManager,
  } = props;
  const [engagedVendorDetails, setEngagedVendorDetails] =
    useState(vendorDetails);
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(props.userParams);
  const lanId = props.loggedInUser.isAuthenticated
    ? id
    : "";
  const [checked, setChecked] = useState(false);
  const [symbolsArray] = useState(["e","-","+","-","E","."])
  const [formState, setFormState] = useState({
    date: null,
    checked: null,
  });

  const onCheckBoxClick = (e) => {
    setChecked(e.target.checked);
  };
  
  const onRecipientsSelected = (value) => {
    const { formControls } = requestFormState;
    setRequestFormState({
      formControls: {
        ...formControls,

        error: false,
        additionalMailRecipients: {
          ...formControls["additionalMailRecipients"],
          error: false,
          value: value,
        },
      },
    });
  };
  const onBoardResourceVendorFunc = (vendors, index) => {
    if (vendors.selected) {
      return (
        <div>
          <Form.Row>
            <Form.Group as={Col} lg={4}>
              <Form.Label>Vendor</Form.Label>
              <Form.Control
                style={{ fontSize: "14px" }}
                type="text"
                value={vendors.vendordescr}
                disabled={true}
              />
            </Form.Group>
            <Form.Group as={Col} lg={4}>
              <p style={{ marginBottom: "10px" }}>
                Location <span style={{ color: "red" }}>*</span>
              </p>
              <RadioGroup
                style={{ marginTop: "-10px" }}
                row
                aria-label="send-onboarding-mail"
                name="row-radio-buttons-group"
              >
                <FormControlLabel
                  value="Onshore"
                  control={
                    <Radio
                      onClick={handleLocation}
                      value="Onshore"
                      checked={sendLocation.checked === "Onshore"}
                    />
                  }
                  label="Onshore"
                />
                <FormControlLabel
                  value="Offshore"
                  control={
                    <Radio
                      onClick={handleLocation}
                      value="Offshore"
                      checked={sendLocation.checked === "Offshore"}
                    />
                  }
                  label="Offshore"
                />
                <FormControlLabel
                  value="Nearshore"
                  control={
                    <Radio
                      onClick={handleLocation}
                      value="Nearshore"
                      checked={sendLocation.checked === "Nearshore"}
                    />
                  }
                  label="Nearshore"
                />
              </RadioGroup>
              {requestFormState.formControls.location.error ? (
                <ErrorMsg
                  message={requestFormState.formControls.location.errorMsg}
                />
              ) : null}
            </Form.Group>

            <Form.Group as={Col} lg={4} className="onboard-date rrc-request-calendar">
            <Datepicker
                name="onboardDate"
                label="Onboard Date"
                formObj={requestFormState.formControls.onboardDate}
                isRequired={requestFormState.formControls.onboardDate.required}
                onChange={manageMonthSelection}
                dateFormat={FORM_DATE_FORMAT}
                className={"request-datepicker"}
                popperPlacement={"left"}
              />
            </Form.Group>
          </Form.Row>
          <Form.Row>
          <Form.Group as={Col} lg={4}>            
              <TextField
                name="resourceFullName"
                label="Resource Full Name"
                formObj={requestFormState.formControls.resourceFullName}
                isRequired={
                  requestFormState.formControls.resourceFullName.required
                }
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group as={Col} lg={4}>            
              <TextField
                name="profilesReceived"
                label="Profiles Received"
                type="number"
                min="0"
                onKeyDown={e =>  symbolsArray.includes(e.key) && e.preventDefault()}
                formObj={requestFormState.formControls.profilesReceived}
                isRequired={
                  requestFormState.formControls.profilesReceived.required
                }
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group as={Col} lg={4}>            
              <TextField
                name="interviewsConducted"
                label="Interviews Conducted"
                type="number"
                min="0"
                onKeyDown={e =>  symbolsArray.includes(e.key) && e.preventDefault()}
                formObj={requestFormState.formControls.interviewsConducted}
                isRequired={
                  requestFormState.formControls.interviewsConducted.required
                }
                onChange={onInputChange}
              />
            </Form.Group>
            <Form.Group as={Col} lg={4} style={{ marginTop: "10px",marginBottom:"0px" }}>
              <p style={{ marginBottom: "7px" }}>
                Send Reservation Email? <span style={{ color: "red" }}>*</span>
              </p>
              <RadioGroup
                style={{ marginTop: "-5px" }}
                row
                aria-label="send-onboarding-mail"
                name="row-radio-buttons-group"
              >
                <FormControlLabel
                  value="yes"
                  control={
                    <Radio
                      onClick={handleSendEmail}
                      value="Yes"
                      checked={sendEmail.checked === "Yes"}
                    />
                  }
                  label="Yes"
                />
                <FormControlLabel
                  value="no"
                  control={
                    <Radio
                      onClick={handleSendEmail}
                      value="No"
                      checked={sendEmail.checked === "No"}
                    />
                  }
                  label="No"
                />
              </RadioGroup>
              {requestFormState.formControls.sendOnboardingEmail.error ? (
                <ErrorMsg
                  message={
                    requestFormState.formControls.sendOnboardingEmail.errorMsg
                  }
                />
              ) : null}
            
            </Form.Group>
            <Form.Group as={Col} lg={4}>
              {sendEmail.value=="Yes"?
              <div className="product-manager-field">
                <div>
                  <p>
                    Product Manager<span style={{ color: "red" }}>*</span>
                  </p>
                  <input
                    type="text"
                    isRequired={
                      requestFormState.formControls.productManager.required
                    }
                    name="Product Manager"
                    value={productManager.productManagerName && productManager.productManagerName.length ? productManager.productManagerName:"N/A"}
                    disabled
                  />
                </div>
              </div>:""}
            </Form.Group>
            <Form.Group as={Col} lg={4} style={{marginTop:"10px"}}>
            {sendEmail.value == "Yes" ? (
                        <AsyncCustomSelect
                        menuPlacement="top"
                          name="additionalMailRecipients"
                          label="Add Email Recipients"
                          placeholder="Add Recipients"
                          isMulti={true}
                          formObj={requestFormState.formControls.additionalMailRecipients}
                          config={{
                            options: additionalMailRecipients,
                            value: "fullName",
                            id: "employeeId",
                          }}
                          onChange={(value) => onRecipientsSelected(value)}
                          showDefaultValues={true}
                        />
                      ) : (
                        ""
                      )}
            </Form.Group>            
            <Form.Group as={Col}>
            {sendEmail.value=="Yes"?
            <TextField
                name="onboardingComments"
                label="Email Body Text"
                formObj={requestFormState.formControls.onboardingComments}
                onChange={onInputChange}
              />:""}
            </Form.Group>
          </Form.Row>
        </div>
      );
    }
  };

  const holdVendorFunc = (vendors, index) => {
    if (
      (!vendors.selected || vendors.selected == undefined) &&
      vendors.statusdescr == "Open"
    ) {
      return (
        <div>
          {engagedVendorDetails.findIndex(x => x.selected == undefined && x.statusdescr=="Open") == index ?
          <div>
          <hr />
            <p style={engagementHold}>
              <b>Cancel Other Vendor Engagements</b>
            </p>
            </div>:""}
          <Form.Row
            style={engagedVendorDetails.findIndex(x => x.selected == undefined && x.statusdescr=="Open") != index ?{ borderTop: "1px solid #B9B9CE", padding: "15px 10px 0px 10px" }:{ padding: "15px 10px 0px 10px"  }}
          >
            <Form.Group
              as={Col}
              style={{
                marginTop: "-2px",
                paddingRight: "0px",
                marginBottom: "0px",
              }}
            >
              <div className="vendor-field">
                <div>
                  <p
                    style={{
                      borderBottom: "1px solid #E8E8ED"
                    }}
                  >
                    Vendor
                  </p>
                  <input
                    type="text"
                    name="Product Manager"
                    value={vendors.vendordescr}
                    disabled
                  />
                </div>
              </div>
            </Form.Group>
            <Form.Group
              as={Col}
              style={{
                paddingLeft: "0px",
                paddingRight: "0px",
                marginBottom: "0px",
              }}
            >
              <p
                style={{
                  borderBottom: "1px solid #E8E8ED",
                  paddingLeft: "10px",
                  marginBottom: "1px"
                }}
              >
                Is Vendor accountable for this?
                <span style={{ color: "red" }}>*</span>
              </p>
              <RadioGroup
                style={{ paddingLeft: "10px" }}
                row
                aria-label="send-onboarding-mail"
                name="row-radio-buttons-group"
              >
                <FormControlLabel
                  control={
                    <Radio
                      onChange={(e) => handleVendorAccountable(e, index)}
                      value="Yes"
                      checked={vendors.vendorAccountable === "Yes"}
                    />
                  }
                  label="Yes"
                />
                <FormControlLabel
                  control={
                    <Radio
                      onChange={(e) => handleVendorAccountable(e, index)}
                      value="No"
                      checked={vendors.vendorAccountable === "No"}
                    />
                  }
                  label="No"
                />
              </RadioGroup>
              {vendors.showVendorAccountableRequired ? (
                <p style={{ color: "#de350b",fontSize:"12px" }}>
                  Vendor Accountable field is required
                </p>
              ) : (
                ""
              )}
            </Form.Group>
            {/* {vendo} */}
            <Form.Group
              as={Col}
              className="close-engagement-comments"
              style={{ paddingLeft: "0px", marginBottom: "0px" }}
            >
              <p style={{ borderBottom: "1px solid #E8E8ED",marginBottom:"5px"}}>
                Comments<span style={{ color: "red" }}>*</span>
              </p>
              <TextField
                name="comments"
                label=""
                formObj={vendors.comments}
                onChange={(e) => onInputChangeHold(e, index)}
              />
              {vendors.showCommentsRequired ? (
                <p style={{ color: "#de350b",fontSize:"12px", marginTop: "5px" }}>
                  Comments field is required
                </p>
              ) : (
                ""
              )}
            </Form.Group>            
          </Form.Row>
          <Form.Row style={{padding: "0px 10px 0px 10px" }}>
          <Form.Group as={Col} lg={4}>   
          <p style={{marginBottom:"5px"}}>
                Profiles Received<span style={{ color: "red" }}>*</span>
              </p>         
              <TextField
                name="profilesReceived"
                label=""
                type="number"
                min="0"
                formObj={vendors.profilesReceived}
                onChange={(e) => onProfilesReceivedChanged(e, index)}
                onKeyDown={e =>  symbolsArray.includes(e.key) && e.preventDefault()}
              />
               {vendors.showProfilesReceivedRequired ? (
                <p style={{color: "#de350b",fontSize:"12px", marginTop: "5px" }}>
                 {vendors.profilesReceivedErrorMsg}
                </p>
              ) : (
                ""
              )}
            </Form.Group>
            <Form.Group as={Col} lg={4}> 
            <p style={{marginBottom:"5px"}}>
            Interviews Conducted<span style={{ color: "red" }}>*</span>
              </p>            
              <TextField
                name="interviewsConducted"
                label=""
                type="number"
                min="0"
                formObj={vendors.interviewsConducted}
                onChange={(e) => onInterviewsConductedChanged(e, index)}
                onKeyDown={e =>  symbolsArray.includes(e.key) && e.preventDefault()}
              />
               {vendors.showInterviewsConductedRequired ? (
                <p style={{ color: "#de350b",fontSize:"12px", marginTop: "5px" }}>
                     {vendors.interviewsConductedErrorMsg}
                </p>
              ) : (
                ""
              )}
            </Form.Group>
          </Form.Row>
        </div>
      );
    }
  };
  useEffect(() => {
    let resourceOnboardingStatus = "";
    if (resourceOnboardingStatus === 1) {
      resourceOnboardingStatus = "Identifying Resource";
    } else if (resourceOnboardingStatus === 2) {
      resourceOnboardingStatus = "Resource Reserved";
    } else if (resourceOnboardingStatus === 3) {
      resourceOnboardingStatus = "Completed";
    } else if (resourceOnboardingStatus === 4) {
      resourceOnboardingStatus = "Cancelled";
    } else if (resourceOnboardingStatus === 5) {
      resourceOnboardingStatus = "External Blocker";
    }
    setEngagedVendorDetails(vendorDetails);
  }, [vendorDetails]);

  const onSubmit = (e) => {
    let isValidatedSuccess = true;

    e.preventDefault();
    let formControls = requestFormState.formControls;
    if (sendLocation.value === "") {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        location: {
          ...formControls.location,
          error: true,
          errorMsg: "Location field is required",
        },
      };
    }
    if (requestFormState.formControls.resourceFullName.value === "") {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        resourceFullName: {
          ...formControls.resourceFullName,
          error: true,
          errorMsg: "Resource Full Name field is required",
        },
      };
    }
    if (requestFormState.formControls.onboardDate.value === "") {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        onboardDate: {
          ...formControls.onboardDate,
          error: true,
          errorMsg: "Onboard Date field is required",
        },
      };
    }
    if (requestFormState.formControls.profilesReceived.value === "" || parseFloat(requestFormState.formControls.profilesReceived.value) % 1 !== 0 || requestFormState.formControls.profilesReceived.value < 0) {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        profilesReceived: {
          ...formControls.profilesReceived,
          error: true,
          errorMsg: requestFormState.formControls.profilesReceived.value === "" ?"Profiles Received field is required":"Negative numbers not allowed"
        },
      };
    }
    if (requestFormState.formControls.interviewsConducted.value === "" || parseFloat(requestFormState.formControls.interviewsConducted.value) % 1 !== 0 || requestFormState.formControls.interviewsConducted.value < 0) {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        interviewsConducted: {
          ...formControls.interviewsConducted,
          error: true,
          errorMsg: requestFormState.formControls.interviewsConducted.value === "" ?"Interviews Conducted field is required":"Negative numbers not allowed",
        },
      };
    }
    // if (requestFormState.formControls.productManager.value === "") {
    //     isValidatedSuccess=false;
    //      console.log("Manager", isValidatedSuccess)
    //   formControls = {
    //     ...formControls,
    //     productManager: {
    //       ...formControls.productManager,
    //       error: true,
    //       errorMsg: "Product Manager field is required",
    //     },
    //   };
    // }
    if (sendEmail.value === "") {
      isValidatedSuccess = false;
      formControls = {
        ...formControls,
        sendOnboardingEmail: {
          ...formControls.sendOnboardingEmail,
          error: true,
          errorMsg: "Send Reservation Email field is required",
        },
      };
    }

    setRequestFormState({
      ...requestFormState,
      formControls: formControls,
    });

    const vendorArray = [...engagedVendorDetails];
    for (var i = 0; i < vendorArray.length; i++) {
      if (
        vendorArray[i].selected != true &&
        vendorArray[i].statusdescr == "Open" &&
        vendorArray[i].vendorAccountable == "" 
    
      ) {
        vendorArray[i].showVendorAccountableRequired = true;
        setEngagedVendorDetails(vendorArray);
        return;
      }
      if (
        vendorArray[i].selected != true &&
        vendorArray[i].statusdescr == "Open" &&
        vendorArray[i].comments == ""
      ) {
        vendorArray[i].showCommentsRequired = true;
        setEngagedVendorDetails(vendorArray);
        return;
      }
      if (
        vendorArray[i].selected != true &&
        vendorArray[i].statusdescr == "Open" &&
        (vendorArray[i].profilesReceived == "" || vendorArray[i].profilesReceived < 0)
    
      ) {
        vendorArray[i].showProfilesReceivedRequired = true;
        vendorArray[i].profilesReceivedErrorMsg = vendorArray[i].profilesReceived == "" ? "Profiles Received field is required":"Negative numbers not allowed"
        setEngagedVendorDetails(vendorArray);
        return;
      }
      if (
        vendorArray[i].selected != true &&
        vendorArray[i].statusdescr == "Open" &&
        (vendorArray[i].interviewsConducted == "" || vendorArray[i].interviewsConducted < 0)
      ) {
        vendorArray[i].showInterviewsConductedRequired = true;
        vendorArray[i].interviewsConductedErrorMsg = vendorArray[i].interviewsConducted == "" ? "Interviews Conducted field is required":"Negative numbers not allowed"
        setEngagedVendorDetails(vendorArray);
        return;
      }
    }

    if (isValidatedSuccess) {
      let email = []; 
      if (requestFormState.formControls.additionalMailRecipients.value != "") {
        requestFormState.formControls.additionalMailRecipients.value.forEach(
          (element) => {
            email.push(element.value2.email);
          }
        );
      }
      let payload = {
        requestId: localStorage.getItem("selectedRequestId"),
        vendorEngagementId: engagedVendorDetails.find(x => x.selected==true).vendorEngagementId,        
        location:
          sendLocation.checked === "Onshore"
            ? 1
            : sendLocation.checked === "Offshore"
            ? 2
            : 3,
        resourceName: requestFormState.formControls.resourceFullName.value,
        onBoardingDate:moment(requestFormState.formControls.onboardDate.value).format(),
        isEmailSent: sendEmail.checked === "Yes" ? 1 : 0,
        otherVendorEngagementIds: [],
        otherProfilesReceived: [],
        otherInterviewsConducted: [],
        isVendorAccountable: [],
        closeComment: [],
        additionalRecipients: email,
        emailBody: requestFormState.formControls.onboardingComments.value,
        profilesReceived: parseInt(requestFormState.formControls.profilesReceived.value),
        interviewsConducted: parseInt(requestFormState.formControls.interviewsConducted.value),
      };
      for (var i = 0; i < engagedVendorDetails.length; i++) {
        if (engagedVendorDetails[i].selected != true && engagedVendorDetails[i].statusdescr == "Open") {
          payload.otherVendorEngagementIds.push(engagedVendorDetails[i].vendorEngagementId);
          payload.isVendorAccountable.push(
            engagedVendorDetails[i].vendorAccountable == "Yes" ? 1 : 0
          );
          payload.closeComment.push(engagedVendorDetails[i].comments);
          payload.otherProfilesReceived.push(parseInt(engagedVendorDetails[i].profilesReceived));
          payload.otherInterviewsConducted.push(parseInt(engagedVendorDetails[i].interviewsConducted));
        }
      }
      props.onboardExternalVendorResource(payload, onSubmitSuccess);
    }
  };

  const onCloseModal = () => {
    const vendorArray = [...engagedVendorDetails];
    let requestId = localStorage.getItem("selectedRequestId");
    for (var i = 0; i < vendorArray.length; i++) {
      vendorArray[i].showVendorAccountableRequired = false;
      vendorArray[i].showCommentsRequired = false;
      vendorArray[i].comments = "";
      vendorArray[i].vendorAccountable = "";
      vendorArray[i].showProfilesReceivedRequired = false;
      vendorArray[i].showInterviewsConductedRequired = false;
      vendorArray[i].profilesReceived = "";
      vendorArray[i].interviewsConducted = "";
    }
    setRequestFormState(INITIAL_FORM_STATE);
    setEngagedVendorDetails(vendorArray);
    setChecked(false);
    setSendLocation({
      checked: "",
      value: "",
    });
    setSendEmail({
      checked: "",
      value: "",
    });
    props.onCloseResourceOnboardingModal(true);
    // props.getRequestOpenVendors(requestId)
  };

  const onSubmitSuccess = () => {
    onCloseModal();
    props.updateReqIdDetails(lanId,resourceOnboardingId);
  };
  const onInputChange = (event) => {
    const { formControls } = requestFormState;
    const name = event.target.name;
    const value = event.target.value;

    setRequestFormState({
      formControls: {
        ...formControls,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  const onInputChangeHold = (e, i) => {
    const vendorArray = [...engagedVendorDetails];
    vendorArray[i].comments = e.target.value;
    vendorArray[i].showCommentsRequired = false;
    setEngagedVendorDetails(vendorArray);

  };

  const handleVendorAccountable = (e, i) => {
    const vendorArray = [...engagedVendorDetails];
    vendorArray[i].vendorAccountable = e.target.value;
    vendorArray[i].showVendorAccountableRequired = false;
    setEngagedVendorDetails(vendorArray);

  };
  const onProfilesReceivedChanged = (e, i) => {
    const vendorArray = [...engagedVendorDetails];
    vendorArray[i].profilesReceived = e.target.value;
    vendorArray[i].showProfilesReceivedRequired = false;
    setEngagedVendorDetails(vendorArray);

  };
  const onInterviewsConductedChanged = (e, i) => {
    const vendorArray = [...engagedVendorDetails];
    vendorArray[i].interviewsConducted = e.target.value;
    vendorArray[i].showInterviewsConductedRequired = false;
    setEngagedVendorDetails(vendorArray);

  };

  const handleLocation = (e) => {
    setFormState({
      checked: true,
    });
    setRequestFormState({
      ...requestFormState,
      formControls: {
        ...requestFormState.formControls,
        location: {
          ...requestFormState.formControls.location,
          error: false,
        },
      },
    });
    if (e.target.value === "Onshore") {
      setSendLocation({
        checked: "Onshore",
        value: "Onshore",
      });
    } else if (e.target.value === "Offshore") {
      setSendLocation({
        checked: "Offshore",
        value: "Offshore",
      });
    } else if (e.target.value === "Nearshore") {
      setSendLocation({
        checked: "Nearshore",
        value: "Nearshore",
      });
    } else {
      setSendLocation({
        checked: "",
        value: "",
      });
    }
  };

  const [sendLocation, setSendLocation] = useState({
    checked: "",
    value: "",
  });

  const handleSendEmail = (e) => {
    setFormState({
      checked: true,
    });
    setRequestFormState({
      ...requestFormState,
      formControls: {
        ...requestFormState.formControls,
        sendOnboardingEmail: {
          ...requestFormState.formControls.sendOnboardingEmail,
          error: false,
        },
      },
    });
    if (e.target.value === "Yes") {
      setSendEmail({
        checked: "Yes",
        value: "Yes",
      });
    } else if (e.target.value === "No") {
      setSendEmail({
        checked: "No",
        value: "No",
      });
    } else {
      setSendEmail({
        checked: "",
        value: "",
      });
    }
  };

  const [sendEmail, setSendEmail] = useState({
    checked: "",
    value: "",
  });

  const manageMonthSelection = (type, date) => {
    const { formControls } = requestFormState;
    if (type === "onboardDate") {
      setFormState({
        checked: formState.checked,
        date: true,
      });
      setRequestFormState({
        formControls: {
          ...formControls,
          isEdited: true,
          onboardDate: {
            ...formControls.onboardDate,
            value: date,
            error: false,
            errorMsg: "",
          },
        },
      });
    }
  };

  const onCloseResourceOnboardingModal = () => {
    const vendorArray = [...engagedVendorDetails];
    for (var i = 0; i < vendorArray.length; i++) {
      vendorArray[i].showVendorAccountableRequired = false;
      vendorArray[i].showCommentsRequired = false;
      vendorArray[i].comments = "";
      vendorArray[i].vendorAccountable = "";
      vendorArray[i].showProfilesReceivedRequired = false;
      vendorArray[i].showInterviewsConductedRequired = false;
      vendorArray[i].profilesReceived = "";
      vendorArray[i].interviewsConducted = "";
    }
    setRequestFormState(INITIAL_FORM_STATE);
    setEngagedVendorDetails(vendorArray);
    setChecked(false);
    setSendLocation({
      checked: "",
      value: "",
    });
    setSendEmail({
      checked: "",
      value: "",
    });
    props.onCloseResourceOnboardingModal(true);
  };

  const onboardResource = {
    fontSize: "16px",
    marginLeft: "6px",
    width: "135px",
    height: "19px",
    textAlign: "left",
    letterSpacing: "0px",
    color: "#1A1A1C",
    opacity: 1,
  };

  const engagementHold = {
    fontSize: "16px",
    marginLeft: "6px",
    height: "19px",
    textAlign: "left",
    letterSpacing: "0px",
    color: "#1A1A1C",
    opacity: 1,
  };

  return (
    <Modal
      {...props}
      size="xl"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      backdrop="static"
      keyboard={false}
      fullscreen={true | "sm-down"}
    >
      <ModalHeader style={{ border: "none", fontSize: "22px !important" }}>
        <span className={"rrc-details-title"}>
          <span id="title" style={{ color: "black", marginLeft: "25px" }}>
            <b>
              Vendor Engagement Request - Request ID{" "}
              {resourceOnboardingId && resourceOnboardingId != null
                ? resourceOnboardingId
                : "N/A"}{" "}
              |
            </b>{" "}
            &nbsp; &nbsp;
          </span>
          <h4
            style={{ color: "#3F66FB", marginTop: "10px", marginLeft: "-15px" }}
          >
            {resourceOnboardingStatus === "1"
              ? "Identifying Resource"
              : resourceOnboardingStatus === "2"
              ? "Resource Reserved"
              : resourceOnboardingStatus === "3"
              ? "Completed"
              : resourceOnboardingStatus === "4"
              ? "Cancelled"
              : resourceOnboardingStatus === "5"
              ? "External Blocker"
              : "N/A"}
          </h4>
        </span>
        <div
          className="close-button"
          style={{ marginTop: "5px" }}
          onClick={onCloseResourceOnboardingModal}
        >
          X
        </div>
      </ModalHeader>
      <Container>
        <div className="rrc-request-background">
          <Form>
            {engagedVendorDetails.length != 0 ? (
              <div>
                <div >
                  <Form.Row>
                    <p style={onboardResource}>
                      <b>Reserve Resource</b>
                    </p>
                  </Form.Row>
                  <br />
                  {engagedVendorDetails.map(onBoardResourceVendorFunc)}
                </div>
              </div>
            ) : (
              ""
            )}

           
            {engagedVendorDetails.length != 0? (
              <div>
                <div className={"rrc-vendors-list"}>
                  {engagedVendorDetails.map(holdVendorFunc)}
                </div>
              </div>
            ) : (
              ""
            )}
            <Form.Row>
              <div
                className="checkbox"
                style={{ marginLeft: "0px", width: "98%" }}
              >{engagedVendorDetails.some(x => x.selected == false && x.statusdescr=="Open") || engagedVendorDetails.some(x => x.selected == undefined && x.statusdescr=="Open") ?
                <div>
                <input
                  type="checkbox"
                  style={{ marginTop: "20px", width: "18px", height: "18px" }}
                  onChange={(e) => onCheckBoxClick(e)}
                  defaultChecked={checked}
                />
                
                <span className="confirmation-text">
                  I understand that the vendor
                  {props.totalVendorsSelected > 1 ? "s" : ""} should be
                  considered accountable for this time if significant delays
                  were caused by how long it took them to respond and/or act..
                </span></div>
:""}
              </div>
            </Form.Row>
          </Form>
        </div>
      </Container>

      <div
        class="col-md-12"
        style={{ marginTop: "15px", marginBottom: "15px", marginLeft: "8px" }}
      >
        <div style={{ float: "right" }}>
          <button disabled={!checked && (engagedVendorDetails.some(x => x.selected == false && x.statusdescr=="Open") || engagedVendorDetails.some(x => x.selected == undefined && x.statusdescr=="Open"))} id="okay-btn" onClick={onSubmit}>
            Save{" "}
          </button>
        </div>
      </div>
    </Modal>
  );
};

const mapStateToProps = (state, ownProps) => ({
  productManager: state.RequestDetailsDataReducer.productManager,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  onCloseVendorEngagement: (payload, callback) =>
    dispatch(onCloseVendorEngagementThunk(payload, callback)),
  updateReqIdDetails: (reqId, lanId) =>
    dispatch(getRequestDetailsDataThunk(reqId, lanId)),
  onboardExternalVendorResource: (payload, callback) =>
    dispatch(onboardExternalVendorResourceThunk(payload, callback)),
  getRequestOpenVendors: (reqId) => dispatch(getRequestOpenVendorsThunk(reqId)),
  get_Product_Manager: (reqId) => dispatch(getProductManagerThunk(reqId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ResourceOnboarding);
