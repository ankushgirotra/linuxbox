import React, { useState, useEffect } from "react";
import SelectDropdown from "../../../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import "./resourceSelection.scss";
import ViewMatches from './ViewMatches/viewMatches';
import SkillsCentralProfile from './../skillsCentralProfile';
import { getEmployeeDetailsThunk, getReporteesByLanIdThunk } from "../../../../../../skillsCentral/src/store/users.reducer";
import { connect } from "react-redux";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import { getRmEmailAndVendorThunk, getMatchProfilesThunk, getInternalResourcesThunk } from "../../../../store";

const ResourceSelection = (props) => {
  let lanId;
  let isOtherRmRequest = false;
  if (localStorage.getItem('selectedRm')&&localStorage.getItem('selectedRm')!==localStorage.getItem('emplyoee_id')) {
    isOtherRmRequest = true;
  }
  const [internalResource, setIternalResource] = useState({
    disable: false,
    error: false,
    errorMsg: "",
    required: false,
    value: ""
  });

  const { requestStatus, getMatchProfiles, peopleMatches, getInternalResources, internalResourcesList } = props;

  const [modalShow, setModalShow] = useState(false);

  const [popUp, setPopUp] = useState(false);

  useEffect(() => {

    const { loggedInUser } = props;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(props.userParams);
    lanId = loggedInUser.isAuthenticated ? empId : "" ;
    props.getReporteesByLanId(lanId);
    props.getEmployeeDetails(lanId,fetchApi);
    
    

  }, []);
  const fetchApi = (emp) => {
    let deptId = emp && emp.deptId;
    getInternalResources(deptId)
  }

  const getLANID = (user) => {
    const {
      user: { id },
    } = user;
    if (
      id.toUpperCase().includes("CH") ||
      id.toUpperCase().includes("CN") ||
      id.toUpperCase().includes("MS")
    ) {
      return id.toUpperCase();
    }
    return id.replace(/[A-Z]/gi, "");
  };
  const onInputChange = (e) => {
    setIternalResource({
      disable: false,
      error: false,
      errorMsg: "",
      required: true,
      value: e.target.value
    })
  }
  const onModalClose = (hideModal) => {
    setModalShow(hideModal);
  }

  const closePopUp = () => {
    setPopUp(false)
  }

  const openViewMatches = () => {
    const { loggedInUser } = props;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(props.userParams);
    lanId = loggedInUser.isAuthenticated ? id : "";
    getMatchProfiles(localStorage.getItem('selectedRequestId'), lanId, 1)
    setTimeout(() => setModalShow(true), 300);
  }

  const onResourceNameClick = () => {
    setPopUp(true);
    // props.getRmEmailAndVendor(internalResource.value);
    props.getInternalResourceDetails(internalResource.value);
  }

  return (
    <div className="card-body resource-alloc" style={{ backgroundColor: "#F5F6FA", height: "88%", marginTop: "0px", width: "100%", paddingTop: "11px", paddingLeft: "20px" }}>
      <p className="card-main-title">
        <b>Search Internal Resources</b>
      </p>
      <p target="_blank" className={(requestStatus == "Cancelled" || isOtherRmRequest) ? "disableShowAllMatches" : "hyper-link"} onClick={ (requestStatus == "Cancelled" || isOtherRmRequest) ? PointerEvent = "none" : openViewMatches}>Show all matches</p>
      <ViewMatches show={modalShow}
        onModalClose={onModalClose}
        onHide={() => setModalShow(false)}
        productManager={props.productManager} mailRecipients={props.mailRecipients}
        peopleMatches={peopleMatches}
        className="view-matches" />
      <div className="resource-name">
        <SelectDropdown
          formObj={internalResource}
          name="resourceName"
          config={{
            options: internalResourcesList.sort(function (x, y) {
              let a = x.fullName.toUpperCase();
              let b = y.fullName.toUpperCase();
              return a === b ? 0 : a > b ? 1 : -1;
            }),
            id: "employeeId",
            value: "fullName",
          }}
          placeholder="Search for internal resources"
          disabled={(requestStatus == "Cancelled" || requestStatus == "Completed" || isOtherRmRequest) ? true : false}
          isClearable={true}
          onChange={(e) =>
            onInputChange({
              target: { name: e.name, value: e.value },
            })
          }
        />
      </div>
      <div className="empty-space"> <hr /></div>
      <div className="assign-resource-button pad-left">
        <button id="okay-btn" disabled={internalResource.value === "" ? true : false} onClick={onResourceNameClick}>
          View Profile
        </button>
      </div>
      {popUp ?
        <SkillsCentralProfile internalResource={props.employeeDetails} rmEmailAndVendor={props.getRmEmail} selectResourceName={internalResourcesList.filter(obj => obj.employeeId == internalResource.value)[0].employeeName} hide={closePopUp} productManager={props.productManager} mailRecipients={props.mailRecipients} profile={popUp} selectedResID={internalResource.value}
          lanId={lanId}
          showContent={true}
        /> : null}

    </div>);

}
const mapStateToProps = (state, ownProps) => {

  return {
    loggedInUser: state.AuthReducer,
    userParams: state.AuthReducer.user,
    reportees: state.SCUsersReducer.reportees,
    getRmEmail: state.RequestDetailsDataReducer.getRmEmailAndVendor,
    employeeDetails: state.SCUsersReducer.employeeDetails,
    peopleMatches: state.RequestDetailsDataReducer.matchProfiles,
    internalResourcesList: state.RequestDetailsDataReducer.internalResourcesList
  };
};

const mapDispatchToProps = (dispatch) => ({
  getReporteesByLanId: (id) => dispatch(getReporteesByLanIdThunk(id)),
  getInternalResources: (deptId,callback) => dispatch(getInternalResourcesThunk(deptId,callback)),
  getEmployeeDetails: (empID, callback) => dispatch(getEmployeeDetailsThunk(empID,callback)),
  getRmEmailAndVendor: (empId) =>
    dispatch(getRmEmailAndVendorThunk(empId)),
  getInternalResourceDetails: (empID) => dispatch(getEmployeeDetailsThunk(empID)),
  getMatchProfiles: (reqId, lanId, pageNum) => dispatch(getMatchProfilesThunk(reqId, lanId, pageNum)),

});

export default connect(mapStateToProps, mapDispatchToProps)(ResourceSelection);