import React, { Fragment, useState, useEffect } from 'react';
import { Row, Col } from "react-bootstrap";
import TextField from "../../../../../../shared/components/forms/TextArea/textArea";
import Avatar from "../../../../../../shared/components/Avatar/avatar";
import { connect } from "react-redux";
import { addCommentsThunk,getRequestDetailsDataThunk } from "../../../store/requestDetailsData.reducer";
import { getFormattedUserId } from "../../../../../../../services/auth.services";

import moment from 'moment';
import "./comments.scss";

const COMMENTS_INITIAL_STATE = {
    formControls: {
        comments: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        }
    },
    detailsCollapsed: true
}

const Comments = (props) => {
    const { addComments, commentsData, comments, requestID, loggedInUser, userParams, requestStatus } = props;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = loggedInUser.isAuthenticated ? id : "";
    const [commentState, setCommentState] = useState(COMMENTS_INITIAL_STATE);
    const [requestCommentsState, setRequestCommentsState] = useState(COMMENTS_INITIAL_STATE);
    const [commentsList, setCommentsList] = useState(commentsData);

    let isOtherRmRequest = false;
    if (localStorage.getItem('selectedRm')&&localStorage.getItem('selectedRm')!==localStorage.getItem('emplyoee_id')) {
        isOtherRmRequest = true;
    }

    useEffect(() => {
        let listComments=commentsData && commentsData.length ? commentsData.filter((data)=>data.comment!="") :[]

        setCommentsList(listComments)
    }, [commentsData]);

    const onArrowClick = () => {
        setRequestCommentsState({
            ...requestCommentsState,
            detailsCollapsed: !requestCommentsState.detailsCollapsed
        })
    }

    const onCommentsChange = (e) => {
        const { detailsCollapsed } = commentState;
        setCommentState({
            ...detailsCollapsed,
            formControls: {
                comments: {
                    value: e.target.value,
                    error: false,
                    errorMsg: "",
                    required: false,
                    disable: false,
                }
            }
        });
    }

    const onAddComments = async (e) => {
        const { detailsCollapsed } = commentState;
        if (commentState.formControls.comments.value.trim() && commentState.formControls.comments.value !== '') {
            const payload = {
                requestId: requestID,
                commentType: "Request",
                createdBy: lanId,
                comment: commentState.formControls.comments.value
            }
            setCommentState({
                ...detailsCollapsed,
                formControls: {
                    comments: {
                        value: "",
                        error: false,
                        errorMsg: "",
                        required: false,
                        disable: false,
                    }
                }
            });
            await addComments(payload, updateComment)
        }
    }

    const updateComment = (comment) => {
        let listComments=comment && comment.length ? comment.filter((data)=>data.comment!="") :[]
        setCommentsList(listComments);
        window.scrollBy({
            top: 250,
            left: 0,
            behaviour: 'smooth'
        })
        props.updateReqIdDetails(lanId, requestID )
    }

    return (<Fragment>
        <Row className="rrc-request-comments-header" style={{ margin: "5px" }}>
            <div className="rrc-request-comments-blueBar">
            </div>
            <Col className="rrc-request-comments-titleProps">
                <p style={{ color: "#3B77FE", paddingRight: "5px", fontSize: "16px" }} >Comments</p>
            </Col>
            <Col className="rrc-request-comments-collapsible">
                {requestCommentsState.detailsCollapsed ?
                    <span style={{ fontSize: "20px" }} onClick={onArrowClick}>
                        <i className="fas fa-caret-up"></i>
                    </span> :
                    <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                        <i className="fas fa-caret-down"></i>
                    </div>
                }
            </Col>
        </Row>
        <Row className="rrc-request-comments-body" >
            {requestCommentsState.detailsCollapsed ?
                <>
                    <Col sm={10} md={10} lg={10} xl={10} className="pad-right">                    
                             <TextField readOnly={(requestStatus == "Cancelled" || requestStatus == "Completed" || isOtherRmRequest)  ? true : false}
                             name="comments"
                             label="Comments"
                             formObj={commentState.formControls.comments}
                             isRequired={commentState.formControls.comments.required}
                             onChange={onCommentsChange}
                             placeholder="Enter Comment"
                         />                      
                    </Col>
                    <Col sm={2} md={2} lg={2} xl={2} className="pad-left">
                            <button className="add-comment-btn" disabled={!commentState.formControls.comments.value} onClick={onAddComments}>
                                Add Comments
                            </button>
                    </Col>
                    <hr />
                    <Col sm={12} md={12} lg={12} xl={12} >
                        <div className="add-scroll">
                            {commentsList && commentsList.map((comment) => {
                                return (
                                    <div key={comment.id}><Row style={{ marginTop: "10px" }}>
                                        <Col sm={1} md={1} lg={1} xl={1}>
                                            <Avatar initial={comment.initialName}></Avatar></Col>
                                        <Col sm={11} md={11} lg={11} xl={11} style={{ paddingRight: "0px", paddingLeft: "0px" }}>
                                            <div className="commentor-info">
                                                <p><span className="commentor-name">{comment.name} |</span> {moment(comment.created_date).format("DD MMMM YYYY h:mm A")}</p>
                                                <span className="comment">{comment.comment}</span>
                                            </div></Col>
                                    </Row><hr className="hr" /></div>);
                            })}
                        </div>
                    </Col>
                </> : ""
            }
        </Row>
    </Fragment>);
}

const mapStateToProps = (state, ownProps) => ({
    comments: state.RequestDetailsDataReducer.comments,
    userParams: state.AuthReducer.user,
    loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
    addComments: (comment, callback) => dispatch(addCommentsThunk(comment, callback)),
    updateReqIdDetails: (id, lanId) =>
    dispatch(getRequestDetailsDataThunk(id, lanId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Comments);
