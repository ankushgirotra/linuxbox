import React, { useMemo } from "react";
import { PlusCircle } from "react-feather";
import sortBy from "../../../../../../../services/helper.service";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../pcdm/src/components/DataGrid/dataGrid";
import './adminExternalBlockers.scss'
import { DATA_STATUS, REQUEST_ADMIN_ACTIONS } from '../../../constants/action.constants';


export default function AdminExternalBlockersTable(props) {

    const { externalBlockers, onAddorEditAdminExternalBlockers } = props;

    const columns = useMemo(() => [
        {
            Header: (props) => vendorHeader(),
            accessor: "description",
            // Cell: ({ row: { original } }) => showVendorHead(original, "description"),
            disableFilters: true,
        },
        {
            Header: "Vendor",
            accessor: "vendor",
            Cell: ({ row: { original } }) => showVendor(original, "vendor"),
            disableFilters: true,
            disableSortBy: true,
        },
    ]);

    const vendorHeader = () => {
        console.log(externalBlockers)
        return (
            <div className="add-manage_vendor-head">
                <p>External Blockers</p>
                <CustomButton
                 onClick={(e) => {
                    e.stopPropagation(); // --> to disable sort on click of this button
                    onAddorEditAdminExternalBlockers(REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS, {});
                  }}
                    title={"Click to add external blockers"}
                    className="manage_vendor-add-link"
                >
                    <span className="mr-2">ADD</span>
                    <PlusCircle size="15" strokeWidth={3} />
                </CustomButton>
            </div>
        );
    };

    const showVendor = (row, key) => {
        // return (
        //     // <LinkExtended
        //     //     className="td-product"
        //     // >
        //         {row.vendor?""}
        //     // </LinkExtended>
        // );
        if (row.vendor) { return "YES" }
        else {
            return "NO"
        }
    };

    // const showVendorHead = (row, key) => {
    //     return (
    //         <LinkExtended
    //             className="td-product"
    //         >
    //             {row.description}
    //         </LinkExtended>
    //     );
    // };
    const onRowClickAddEdit = (row) => {

       props.onRowClickAddEdit(row.original);
       
       props.onAddorEditAdminExternalBlockers(REQUEST_ADMIN_ACTIONS.EDIT_EXTERNAL_BLOCKERS);
    }

    const data = sortBy(externalBlockers.data);
    return (
        <>
            <OverlayLoader
                loading={externalBlockers.status === DATA_STATUS.LOADING}
            />
            <div className="admin-manage_vendor-table-container pcdm-scroll-vertical">
                <DataGrid
                    onCellClick={(row, cell) => {
                        onRowClickAddEdit(row);
                      }}
                    data={data}
                    columns={columns}
                    noRowText={"Click + icon to start adding vendor"}
                />
            </div>
        </>
    );

}
