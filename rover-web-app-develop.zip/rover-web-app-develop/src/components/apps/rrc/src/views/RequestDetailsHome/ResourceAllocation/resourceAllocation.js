import React, { Fragment, useState, useEffect } from "react";
import { Card, Row, Col, Container } from "react-bootstrap";
import Button from "../../../../../../shared/components/forms/Button/button";
import SelectDropdown from "../../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import { connect } from "react-redux";
import {
  getRequestDetailsDataThunk,
  getRequestUsedVendorsThunk,
  cancelOnboardingThunk,
  cancelOnboardingVendorThunk,
  getCancelledRequestThunk,
  getRequestOpenVendorsThunk,
  onBoardVendorResourceSuccessThunk,
  onBoardResourceSuccessThunk,
} from "../../../store/requestDetailsData.reducer";
import CancelOnboarding from "./cancelOnboarding";
import moment from "moment";
import "./resourceAllocation.scss";
import Confirmation from "../ContactVendor/confirmation";
import ResourceSelection from "./ResourceSelection/resourceSelection";
import CloseEngagement from "./CloseEngagement/closeEngagement";
import ResourceOnboarding from "./resourceOnboarding";
import SkillsCentralProfile from "./skillsCentralProfile";
import { getReporteesByLanIdThunk } from "../../../../../skillsCentral/src/store/users.reducer";
import { getFormattedUserId } from "../../../../../../../services/auth.services";
import sortBy from "../../../../../../../services/helper.service";

const INITIAL_STATE = {
  formControls: {
    vendorsList: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    cancelledVendors: {
      value: [],
    },
  },
  detailsCollapsed: true,
  resourceAllocationCollapsed: true,
  showMoreDetails: false,
};

const ResourceAllocation = (props) => {
  const [resourceAllocationState, setResourceAllocationState] = useState(
    INITIAL_STATE
  );
  const {
    requestOpenVendors,
    requestVendors,
    getRequestUsedVendors,
    requestUsedVendors,
    requestStatus,
    getRequestOpenVendors,
    requestContactedVendors,
    onBoardResourceSuccess,
    onBoardVendorResourceSuccess,
    allocatedResourceDetail,
    allocatedVendorResourceDetail,
  } = props;
  const [modalShow, setModalShow] = React.useState(false);
  const [onReopenModelChange, setReopenModelChange] = React.useState(false);
  const [
    showCloseEngagementModal,
    setShowCloseEngagementModal,
  ] = React.useState(false);
  const [engagedVendorsList, setEngagedVendorsList] = useState(
    requestOpenVendors
  );
  const [resourceOnboarded, setResourceOnboarded] = useState({});
  const [vendorResourceOnboarded, setVendorResourceOnboarded] = useState({});
  const [cancelledRequest, setCancelledRequest] = useState({});

  const [closeVendorsList, setCloseEngagementList] = useState(
    engagedVendorsList
  );
  const [totalVendorsSelected, setTotalVendorsSelected] = useState(0);
  const [selectAll, setSelectAll] = useState(false);
  const [cancelOnboardingModal, setCancelOnboardingModal] = useState(false);
  const { requestDetailsData, getRequestDetailsData } = props;
  const [resourceOnboardingModal, setResourceOnboardingModal] = useState(false);
  const [showSelectAll, setShowSelectAll] = useState(false);
  const [popUp, setPopUp] = useState(false);
  const [resourceId, setResourceId] = useState();
  const [usedContractVendors, setUsedContractVendors] = useState([]);
  const [vendorsCancelledList, setVendorsCancelledList] = useState([]);
  let isOtherRmRequest = false;

  useEffect(() => {
    setUsedContractVendors(requestUsedVendors);
  }, [requestUsedVendors]);

  if (localStorage.getItem('selectedRm')&&localStorage.getItem('selectedRm')!==localStorage.getItem('emplyoee_id')) {
    isOtherRmRequest = true;
  }

  useEffect(() => {
    const { loggedInUser, userParams } = props;
    // lanId = loggedInUser.isAuthenticated ? getLANID(loggedInUser) !== "" ?
    //   getLANID(loggedInUser) : getFormattedUserId(props.userParams) : "";
    let empId = localStorage.getItem("emplyoee_id");
    let id = empId ? empId : getFormattedUserId(userParams);
    let lanId = loggedInUser.isAuthenticated ? id : "";
    if (localStorage.getItem('selectedRm')&&localStorage.getItem('selectedRm')!==localStorage.getItem('emplyoee_id')) {
      lanId = localStorage.getItem("selectedRm");
    }
    props.getReporteesByLanId(lanId);
  }, []);

  const getLANID = (user) => {
    const {
      user: { id },
    } = user;
    if (
      id.toUpperCase().includes("CH") ||
      id.toUpperCase().includes("CN") ||
      id.toUpperCase().includes("MS")
    ) {
      return id.toUpperCase();
    }
    return id.replace(/[A-Z]/gi, "");
  };

  useEffect(() => {
    getRequestDetailsData(requestDetailsData);
    getRequestUsedVendors(requestDetailsData.request_id);
    let requestStatus = "";
    if (requestDetailsData.status === 1) {
      requestStatus = "Identifying Resource";
    } else if (requestDetailsData.status === 2) {
      requestStatus = "Resource Reserved";
    } else if (requestDetailsData.status === 3) {
      requestStatus = "Completed";
    } else if (requestDetailsData.status === 4) {
      requestStatus = "Cancelled";
    } else if (requestDetailsData.status === 5) {
      requestStatus = "External Blocker";
    }
  }, [requestDetailsData]);

  const onResourceArrowClick = () => {
    setResourceAllocationState({
      ...resourceAllocationState,
      resourceAllocationCollapsed: !resourceAllocationState.resourceAllocationCollapsed,
    });
  };

  const selectAllVendors = (event) => {
    const engagedVendorArray = [...engagedVendorsList];
    if (event.target.checked) {
      for (var i = 0; i < engagedVendorArray.length; i++) {
        if (engagedVendorArray[i].statusdescr == "Open") {
          engagedVendorArray[i].selected = true;
          engagedVendorArray[i].showVendorAccountableRequired = false;
          engagedVendorArray[i].showCommentsRequired = false;
          engagedVendorArray[i].comments = "";
          engagedVendorArray[i].vendorAccountable = "";
          engagedVendorArray[i].showProfilesReceivedRequired = false;
          engagedVendorArray[i].showInterviewsConductedRequired = false;
          engagedVendorArray[i].profilesReceived = "";
          engagedVendorArray[i].interviewsConducted = "";
        }
      }
      setEngagedVendorsList(engagedVendorArray);
      setTotalVendorsSelected(
        engagedVendorArray.filter((obj) => obj.statusdescr == "Open").length
      );
      setSelectAll(true);
    } else {
      for (var i = 0; i < engagedVendorArray.length; i++) {
        engagedVendorArray[i].selected = false;
      }
      setEngagedVendorsList(engagedVendorArray);
      setTotalVendorsSelected(0);
      setSelectAll(false);
    }
  };

  const cancelledVendorSelected = (event, vendor) => {
    const { formControls } = resourceAllocationState;
    const currentCancelledVendors = formControls.cancelledVendors.value;
    let tempVendorList = [];

    if (currentCancelledVendors.length) {
      tempVendorList = [...currentCancelledVendors];
      let checkExist = tempVendorList.findIndex(
        (ele) => ele.vendordescr === vendor.vendordescr
      );
      if (checkExist !== -1) {
        tempVendorList.splice(checkExist, 1);
      } else {
        alert("Only one vendor can be re-opened at a time");
        tempVendorList.push(vendor);
      }
    } else {
      tempVendorList.push(vendor);
    }
    // console.log("before",currentCancelledVendors, "after", tempVendorList)

    setResourceAllocationState({
      ...resourceAllocationState,
      formControls: {
        ...formControls,
        cancelledVendors: {
          value: tempVendorList,
        },
      },
    });
  };

  const vendorSelected = (event, i) => {
    const engagedVendorArray = [...engagedVendorsList];
    if (!event.target.checked) {
      engagedVendorArray[i].selected = false;
      setTotalVendorsSelected(totalVendorsSelected - 1);
      setSelectAll(false);
    } else {
      for (var j = 0; j < engagedVendorArray.length; j++) {
        if (engagedVendorArray[i].statusdescr == "Open") {
          engagedVendorArray[j].showVendorAccountableRequired = false;
          engagedVendorArray[j].showCommentsRequired = false;
          engagedVendorArray[j].comments = "";
          engagedVendorArray[j].vendorAccountable = "";
          engagedVendorArray[j].showProfilesReceivedRequired = false;
          engagedVendorArray[j].showInterviewsConductedRequired = false;
          engagedVendorArray[j].profilesReceived = "";
          engagedVendorArray[j].interviewsConducted = "";
        }
      }
      engagedVendorArray[i].selected = true;

      if (engagedVendorArray.some((x) => x.selected === true)) {
        setSelectAll(false);
      }
      if (engagedVendorArray.every((x) => x.selected === true)) {
        setSelectAll(true);
      }
      setTotalVendorsSelected(totalVendorsSelected + 1);
      let totalcount =
        totalVendorsSelected +
        engagedVendorArray.reduce(
          (a, v) => (v.statusdescr === "Cancelled" ? a + 1 : a),
          0
        ) +
        1;
      if (totalcount == engagedVendorArray.length) {
        setSelectAll(true);
      }
    }
    setEngagedVendorsList(engagedVendorArray);
  };

  useEffect(() => {
    setEngagedVendorsList(requestOpenVendors);
    if (requestOpenVendors.some((x) => x.statusdescr == "Open")) {
      setShowSelectAll(true);
    }
  }, [requestOpenVendors]);

  useEffect(() => {
    if (requestContactedVendors.some((x) => x.statusdescr == "Open")) {
      setShowSelectAll(true);
    } else {
      setShowSelectAll(false);
      const cancelledVendors = requestContactedVendors.filter(
        (x) => x.statusdescr == "Cancelled"
      );
      setVendorsCancelledList(cancelledVendors);
    }
  }, [requestContactedVendors]);

  useEffect(() => {
    if (Object.keys(props.allocatedResourceDetail).length > 0) {
      props.setContactedVendorsCount(1);
      setResourceOnboarded(props.allocatedResourceDetail);
    } else {
      props.setContactedVendorsCount(0);
      setResourceOnboarded({});
    }
    if (Object.keys(props.allocatedVendorResourceDetail).length > 0) {
      setVendorResourceOnboarded(props.allocatedVendorResourceDetail);
    } else {
      setVendorResourceOnboarded({});
    }
    if (Object.keys(props.cancelledRequest).length > 0) {
      setCancelledRequest(props.cancelledRequest);
    } else {
      setCancelledRequest({});
    }
  }, [
    props.allocatedResourceDetail,
    props.cancelledRequest,
    props.allocatedVendorResourceDetail,
  ]);

  const onMoreDetailsClick = () => {
    setResourceAllocationState({
      ...resourceAllocationState,
      showMoreDetails: !resourceAllocationState.showMoreDetails,
    });
  };

  const renderFunc = (vendors, index) => {
    const cancelledVendorsList =
      resourceAllocationState.formControls.cancelledVendors.value || [];
    let isExist =
      vendors.statusdescr === "Cancelled" &&
      cancelledVendorsList.includes(vendors);
    return (
      <tr
        key={index}
        style={{ display: "flex", margin: "10px", padding: "10px" }}
        className={"rrc-vendor-row"}
      >
        <Col>
          <span style={{ display: "flex" }}>
            {vendors.statusdescr === "Open" ? (
              <input
                disabled={
                  requestStatus == "Completed" || requestStatus == "Cancelled" || isOtherRmRequest
                    ? true
                    : false
                }
                type="checkbox"
                style={{ margin: "3px 10px 0px 0px" }}
                label="Vendors"
                onChange={(e) => vendorSelected(e, index)}
                checked={vendors.selected}
              />
            ) : (
              ""
            )}
            {vendors.statusdescr === "Cancelled" ? (
              <input
                disabled={
                  requestStatus == "Completed" || requestStatus == "Cancelled" || isOtherRmRequest
                    ? true
                    : false
                }
                type="checkbox"
                style={{ margin: "3px 10px 0px 0px" }}
                label="Vendors"
                onChange={(e) => cancelledVendorSelected(e, vendors)}
                checked={isExist}
              />
            ) : (
              ""
            )}
            {vendors.statusdescr === "Open" ? (
              <p
                style={
                  vendors.statusdescr == "Open"
                    ? { color: "black" }
                    : showSelectAll
                    ? { color: "black", marginLeft: "27px" }
                    : { color: "black" }
                }
              >
                {vendors.vendordescr}
              </p>
            ) : (
              ""
            )}
            {vendors.statusdescr === "Cancelled" ? (
              <p
                style={
                  vendors.statusdescr == "Cancelled"
                    ? { color: "black" }
                    : { color: "black" }
                }
              >
                {vendors.vendordescr}
              </p>
            ) : (
              ""
            )}
          </span>
        </Col>
        <Col>{moment(vendors.vendorstartdate).format("MM/DD/YYYY")}</Col>
        <Col>{vendors.statusdescr}</Col>
        <Col>
          {vendors.staffingvelocity} day
          {vendors.staffingvelocity > 1 ? <span>s</span> : ""}
        </Col>
        {/* {vendors.statusdescr === "Cancelled" ? <Col><p onClick={onMoreDetailsClick}>{resourceAllocationState.showMoreDetails ? "Date" : <p className="text-format">View Cancellation Details</p>}</p></Col> : <Col>-</Col>} */}
      </tr>
    );
  };

  const onInputChange = (event) => {
    const { formControls } = resourceAllocationState;
    const name = event.target.name;
    const value = event.target.value;
    setResourceAllocationState({
      ...resourceAllocationState,
      formControls: {
        ...formControls,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  const mystyle = {
    marginTop: "20px",
    height: "36px",
    width: "130px",
    marginLeft: "200px",
    color: "#fff",
    border: "none",
    padding: "8px 10px 8px 10px",
    borderRadius: "8px",
    backgroundColor: "blue",
    boxShadow: "0px 3px 6px #00000029",
    background:
      "transparent linear-gradient(180deg, #1792eb 0%, #3b77fb 100%) 0% 0% no-repeat padding-box",
  };

  const onReopenClose = (status) => {
    setReopenModelChange(status);
  };

  const onModalClose = (hideModal, vendorList) => {
    getRequestUsedVendors(localStorage.getItem("selectedRequestId"));
    const { formControls } = resourceAllocationState;
    const updatedVendorList = vendorList.map((row) => ({
      ...row,
      selected: false,
    }));
    setResourceAllocationState({
      ...resourceAllocationState,
      formControls: {
        ...formControls,
        vendorsList: {
          ...formControls.vendorsList,
          error: false,
          value: "",
        },
        cancelledVendors: {
          ...formControls.cancelledVendors,
          value: [],
        },
      },
    });
    setEngagedVendorsList(updatedVendorList);
    setTotalVendorsSelected(0);
    setSelectAll(false);
    setShowSelectAll(true);
    setTimeout(() => setModalShow(hideModal), 900);
  };

  const onHideModal = () => {
    const { formControls } = resourceAllocationState;
    setResourceAllocationState({
      ...resourceAllocationState,
      formControls: {
        ...formControls,
        vendorsList: {
          ...formControls.vendorsList,
          error: false,
          value: "",
        },
      },
    });
    setModalShow(false);
  };

  const onCloseCancelOnboardingModal = () => {
    setCancelOnboardingModal(false);
  };

  const onCloseEngagementModal = () => {
    getRequestOpenVendors(requestDetailsData.request_id);
    setEngagedVendorsList(requestContactedVendors);
    setSelectAll(false);
    setTotalVendorsSelected(0);
    setShowCloseEngagementModal(false);
    getRequestUsedVendors(localStorage.getItem("selectedRequestId"));
  };

  const cancelOnboarding = (payload) => {
    if (
      resourceOnboarded.type == "Internal" ||
      vendorResourceOnboarded.type == "Internal"
    ) {
      props.cancelOnboarding(payload, onCancelOnboardingSuccess);
    } else if (
      resourceOnboarded.type == "External" ||
      vendorResourceOnboarded.type == "External"
    ) {
      props.cancelOnboardingVendor(payload, onCancelOnboardingSuccess);
    }
  };

  const onCloseResourceOnboardingModal = () => {
    setResourceOnboardingModal(false);
    const engagedVendorArray = [...engagedVendorsList];
    for (var i = 0; i < engagedVendorArray.length; i++) {
      if (engagedVendorArray[i].statusdescr == "Open") {
        engagedVendorArray[i].selected = false;
        engagedVendorArray[i].showVendorAccountableRequired = false;
        engagedVendorArray[i].showCommentsRequired = false;
        engagedVendorArray[i].comments = "";
        engagedVendorArray[i].vendorAccountable = "";
        engagedVendorArray[i].showProfilesReceivedRequired = false;
        engagedVendorArray[i].showInterviewsConductedRequired = false;
        engagedVendorArray[i].profilesReceived = "";
        engagedVendorArray[i].interviewsConducted = "";
      }
    }
    setEngagedVendorsList(engagedVendorArray);
    setSelectAll(false);
    setTotalVendorsSelected(0);
  };

  const onCancelOnboardingSuccess = (status, data) => {
    if (status === "success") {
      onBoardResourceSuccess(requestDetailsData.request_id, onOnboardSuccess);
      onBoardVendorResourceSuccess(
        requestDetailsData.request_id,
        onOnboardVendorSuccess
      );
      setResourceOnboarded(allocatedResourceDetail);
      props.getCancelledRequest(requestDetailsData.request_id, onSucess);
      props.onUpdate();
    }
  };

  const onOnboardSuccess = () => {};
  const onOnboardVendorSuccess = () => {};

  const onSucess = (status, data) => {
    if (status === "success") {
      setCancelOnboardingModal(false);
    }
  };

  const closePopUp = () => {
    setPopUp(false);
  };

  const onResourceNameClick = () => {
    setPopUp(true);
    setResourceId(
      props.reportees.data.filter(
        (obj) => obj.employeeName == resourceOnboarded.resourceName
      )[0].employeeId
    );
  };

  const onReopenClick = () => {
    let vendorId =
      resourceAllocationState.formControls.cancelledVendors.value[0].vendor;
    const { formControls } = resourceAllocationState;
    setResourceAllocationState({
      ...resourceAllocationState,
      formControls: {
        ...formControls,
        vendorsList: {
          ...formControls.vendorList,
          value: vendorId,
        },
      },
    });
    setModalShow(true);
  };

 

  const getMailBody = () => {
    let plannedStartDate =  moment(requestDetailsData.planned_start).format("MM-DD-YYYY");
    let plannedEndDate = moment(requestDetailsData.end_date).format("MM-DD-YYYY");
    let onboardDate = moment(vendorResourceOnboarded.onBoardDate).format("MM-DD-YYYY");
    let managerArr = vendorResourceOnboarded.productManagerName?vendorResourceOnboarded.productManagerName.split(","):[];
    let managerName = managerArr.length?managerArr[1]+" "+managerArr[0]:"";
    return(
`Product Line: ${requestDetailsData.product_line}
Product:  ${requestDetailsData.product}
Role:  ${requestDetailsData.role}
Allocation %:  ${requestDetailsData.allocation}
Planned Start Date:  ${plannedStartDate}
Planned End Date:  ${plannedEndDate}
Technologies:  ${requestDetailsData.technologies}
Location:  ${requestDetailsData.location?requestDetailsData.location:"-"}
Vendor:  ${vendorResourceOnboarded.vendorName}
Onboard Date:  ${onboardDate}
Resource Name:  ${vendorResourceOnboarded.resourceName}
Product Manager:  ${managerName?managerName:"-"}`
    );
  };

  let allVendors = [
    ...engagedVendorsList.map((element) => {
      return element.vendor, element.statusdescr;
    }),
  ];
  return (
    <>
      <Row className="rrc-request-details-header" style={{ margin: "5px" }}>
        <div className="rrc-request-details-blueBar"></div>
        <Col className="rrc-request-details-titleProps">
          <p style={{ color: "#3B77FE", fontSize: "16px" }}>
            Resource Reservation{" "}
          </p>
        </Col>
        <Col className="rrc-request-details-collapsible">
          {resourceAllocationState.resourceAllocationCollapsed ? (
            <span style={{ fontSize: "20px" }} onClick={onResourceArrowClick}>
              <i className="fas fa-caret-up"></i>
            </span>
          ) : (
            <div style={{ fontSize: "20px" }} onClick={onResourceArrowClick}>
              <i className="fas fa-caret-down"></i>
            </div>
          )}
        </Col>
      </Row>
      <Row
        className="rrc-request-details-body"
        style={{ margin: "10px" }}
      ></Row>
      <div>
        {Object.keys(resourceOnboarded).length > 0 &&
          resourceOnboarded.type == "Internal" &&
          resourceAllocationState.resourceAllocationCollapsed && (
            <>
              <Row>
                <Col>
                  <div
                    style={{
                      padding: "5px",
                      paddingLeft: "10px",
                      fontWeight: "600",
                      color: "#1A1A1C !important",
                      fontSize: "15px",
                    }}
                  >
                    Reservation Details
                  </div>
                </Col>
              </Row>
              <Row
                style={
                  Object.keys(cancelledRequest).length > 0
                    ? { marginBottom: "70px" }
                    : { marginBottom: "0px" }
                }
              >
                <Card className={"onboard-card col"}>
                  <Card.Body className={"onboard-card-body"}>
                    <Row>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <div style={{ color: "#8686A2" }} className="d-flex">
                          <div>Resource Name</div>&nbsp;&nbsp;
                          {/* <p className="text-format">View Skill Central Profile</p> */}
                        </div>
                        <p
                          className="text-format"
                          onClick={onResourceNameClick}
                        >
                          {resourceOnboarded.resourceName}
                        </p>
                      </Col>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <p style={{ color: "#8686A2" }}>Onboard Date</p>
                        <p style={{ color: "#000000" }}>
                          {moment(resourceOnboarded.onboardDate).format(
                            "MM/DD/YYYY"
                          )}{" "}
                        </p>
                      </Col>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <p style={{ color: "#8686A2" }}>Product Manager</p>
                        <p style={{ color: "#000000" }}>
                          {resourceOnboarded.productManagerName}
                        </p>
                      </Col>
                      <Col
                        sm={3}
                        md={3}
                        lg={3}
                        xl={3}
                        className="d-flex justify-content-end align-items-end"
                      >
                        <div className="cancel-onboard-button">
                          {requestStatus == "Cancelled" ||
                          requestStatus == "Completed" ||
                          isOtherRmRequest ? null : (
                            <span className="cancel-button-span">
                              <Button
                                className={"request-cancel-button"}
                                onClick={() => {
                                  setCancelOnboardingModal(true);
                                }}
                              >
                                <span className="mr-1">Cancel Reservation</span>
                              </Button>
                            </span>
                          )}
                        </div>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
              </Row>
            </>
          )}
      </div>

      {popUp ? (
        <SkillsCentralProfile
          hide={closePopUp}
          productManager={props.productManager}
          mailRecipients={props.mailRecipients}
          profile={popUp}
          resourceName={resourceOnboarded.resourceName}
          selectedResID={resourceId}
        />
      ) : null}
      <div>
        {Object.keys(vendorResourceOnboarded).length > 0 &&
          vendorResourceOnboarded.type == "External" &&
          resourceAllocationState.resourceAllocationCollapsed && (
            <>
              <Row>
                <Col>
                  <div
                    style={{
                      padding: "5px",
                      paddingLeft: "20px",
                      fontWeight: "600",
                      color: "#1A1A1C !important",
                      fontSize: "15px",
                    }}
                  >
                    Vendor Engagement Request - Reservation Details
                  </div>
                </Col>
              </Row>
              <Row
                style={
                  Object.keys(cancelledRequest).length > 0
                    ? { marginBottom: "70px" }
                    : { marginBottom: "0px" }
                }
              >
                <Card className={"onboard-card col"}>
                  <Card.Body className={"onboard-card-body"}>
                    <Row>
                      <Col sm={4} md={4} lg={4} xl={4}>
                        <div style={{ color: "#8686A2" }} className="d-flex">
                          <div>Vendor</div>
                        </div>
                        <p style={{ color: "#01A88F" }}>
                          {vendorResourceOnboarded.vendorName}
                        </p>
                      </Col>
                      <Col sm={4} md={4} lg={4} xl={4}>
                        <p style={{ color: "#8686A2" }}>Onboard Date</p>
                        <p style={{ color: "#000000" }}>
                          {moment(vendorResourceOnboarded.onBoardDate).format(
                            "MM/DD/YYYY"
                          )}{" "}
                        </p>
                      </Col>
                      <Col sm={4} md={4} lg={4} xl={4}>
                        <p style={{ color: "#8686A2" }}>Resource Name</p>
                        <p style={{ color: "#000000" }}>
                          {vendorResourceOnboarded.resourceName}
                        </p>
                      </Col>
                    </Row>
                    <Row style={{ marginTop: "10px" }}>
                      <Col sm={4} md={4} lg={4} xl={4}>
                        <p style={{ color: "#8686A2" }}>
                          Planned Start Date & End Date
                        </p>
                        <p style={{ color: "#000000" }}>
                          {moment(
                            vendorResourceOnboarded.plannedStartDate
                          ).format("MM/DD/YYYY")}{" "}
                          -{" "}
                          {moment(vendorResourceOnboarded.endDate).format(
                            "MM/DD/YYYY"
                          )}
                        </p>
                      </Col>
                      <Col sm={4} md={4} lg={4} xl={4}>
                        <p style={{ color: "#8686A2" }}>Product Manager</p>
                        <p style={{ color: "#000000" }}>
                          {vendorResourceOnboarded.productManagerName}
                        </p>
                      </Col>
                    </Row>
                    <hr />
                    <Row>
                      <Col className="d-flex justify-content-end align-items-end">
                        <div className="cancel-onboard-button">
                          {requestStatus == "Cancelled" ||
                          requestStatus == "Completed" ||
                          isOtherRmRequest ? null : (
                            <span className="cancel-button-span">
                                <Button
                                  className={"request-contact-button"}
                                >
                                  <a href={`mailto:${""}?body=${encodeURIComponent(getMailBody())}`}>
                                    <span className="mr-1">Contact Vendor</span>
                                  </a>
                                </Button>
                              <Button
                                className={"request-cancel-button"}
                                onClick={() => {
                                  setCancelOnboardingModal(true);
                                }}
                              >
                                <span className="mr-1">Cancel Reservation</span>
                              </Button>
                            </span>
                          )}
                        </div>
                      </Col>
                    </Row>
                  </Card.Body>
                </Card>
              </Row>
            </>
          )}
      </div>

      <CancelOnboarding
        show={cancelOnboardingModal}
        cancelOnboardingId={requestDetailsData.request_id}
        cancelOnboardingStatus={requestDetailsData.status}
        onCloseCancelOnboardingModal={onCloseCancelOnboardingModal}
        onHide={() => setCancelOnboardingModal(false)}
        resourceName={
          resourceOnboarded.type == "Internal"
            ? resourceOnboarded.resourceName
            : vendorResourceOnboarded.resourceName
        }
        cancelOnboarding={cancelOnboarding}
        resourceType={resourceOnboarded.type}
      />
      {Object.keys(resourceOnboarded).length === 0 && (
        <Row
          className="rrc-request-details-body"
          style={{ marginLeft: "10px", marginRight: "10px" }}
        >
          {resourceAllocationState.resourceAllocationCollapsed ? (
            <Container>
              <Row>
                <Col>
                  <div
                    className="row"
                    style={{ height: "103%", marginBottom: "10px" }}
                  >
                    <div
                      className="col-md-6"
                      style={{
                        paddingLeft: "0px !important",
                        height: "90%",
                        paddingLeft: "0px",
                      }}
                    >
                      <ResourceSelection
                        requestStatus={props.requestStatus}
                        productManager={props.productManager}
                        mailRecipients={props.mailRecipients}
                        resourceNames={props.resourceNames}
                        matchProfiles={props.matchProfiles}
                      />
                    </div>

                    <div
                      className="col-md-6"
                      style={{
                        borderLeft: "1px solid lightgray",
                        height: "80%",
                        position: "relative",
                      }}
                    >
                      <div
                        className="card-body"
                        style={{
                          backgroundColor: "#F5F6FA",
                          height: "100%",
                          marginTop: "0px",
                          width: "104%",
                          paddingBottom: "5px",
                        }}
                      >
                        <p
                          style={{
                            marginLeft: "-10px",
                            marginTop: "-20px",
                            width: "105%",
                          }}
                          className="card-text"
                        >
                          <b>Contact Vendor</b>
                        </p>
                        <p style={{ marginLeft: "-10px", marginTop: "-20px" }}>
                          <SelectDropdown
                            name="vendorsList"
                            formObj={
                              resourceAllocationState.formControls.vendorsList
                            }
                            config={{
                              options: [
                                ...sortBy(usedContractVendors, "vendorname"),
                              ],
                              // options: [...usedContractVendors.length !== 0 ? usedContractVendors : usedContractVendors],
                              id: "vendorid",
                              value: "vendorname",
                            }}
                            placeholder="Select Vendor"
                            isClearable={true}
                            disabled={
                              requestStatus == "Cancelled" ||
                              requestStatus == "Completed" ||
                              isOtherRmRequest
                                ? true
                                : false
                            }
                            onChange={(e) =>
                              onInputChange({
                                target: { name: e.name, value: e.value },
                              })
                            }
                          />
                        </p>
                        <Row>
                          <Col>
                            <p
                              style={{
                                marginTop: "10px",
                                color: "#8686A2",
                                fontSize: "13px",
                                marginLeft: "-10px",
                              }}
                            >
                              By clicking <b>Send Email</b>, you will be
                              redirected to Outlook with the request details so
                              you can contact the vendor. Please send this email
                              immediately, because Rover will begin tracking the
                              Staffing Velocity SLA to determine how long it
                              takes the vendor to provide a viable candidate.
                              You can send multiple emails to multiple vendors,
                              but you must engage them through this process in
                              Rover.
                            </p>
                          </Col>
                        </Row>
                        <Row
                          sm={2}
                          md={2}
                          lg={2}
                          xl={2}
                          className="pad-left"
                          style={{ marginTop: "0px" }}
                        >
                          <div className="add-email-button">
                            <button
                              disabled={
                                resourceAllocationState.formControls.vendorsList
                                  .value === ""
                                  ? true
                                  : false
                              }
                              id="okay-btn"
                              onClick={() => setModalShow(true)}
                            >
                              Send Email
                            </button>
                          </div>
                        </Row>
                        <Confirmation
                          show={modalShow}
                          vendor_id={
                            resourceAllocationState.formControls.vendorsList
                              .value
                          }
                          onModalClose={onModalClose}
                          onReopenClose={onReopenClose}
                          vendorList={engagedVendorsList}
                          onHide={onHideModal}
                        />
                      </div>
                      <p
                        style={{
                          position: "absolute",
                          zIndex: "10",
                          top: "44%",
                          left: "-9px",
                          backgroundColor: "#fff",
                          padding: "10px 0px",
                        }}
                      >
                        <b>Or</b>
                      </p>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
          ) : (
            ""
          )}
        </Row>
      )}
      {Object.keys(cancelledRequest).length > 0 &&
        resourceAllocationState.resourceAllocationCollapsed && (
          <div>
            <Row style={{ marginTop: "-55px" }}>
              <Col>
                <div
                  style={{
                    padding: "5px",
                    paddingLeft: "10px",
                    fontWeight: "600",
                    color: "#1A1A1C !important",
                    fontSize: "15px",
                  }}
                >
                  Cancelled Reservations
                </div>
              </Col>
            </Row>
            <Row>
              <Card className={"onboard-card col"}>
                <Card.Body className={"onboard-card-body"}>
                  <Row>
                    <Col sm={3} md={3} lg={3} xl={3}>
                      <div style={{ color: "#8686A2" }} className="d-flex">
                        Resource Name
                      </div>
                    </Col>
                    <Col sm={3} md={3} lg={3} xl={3}>
                      <p style={{ color: "#8686A2" }}>Product Manager</p>
                    </Col>
                    <Col sm={3} md={3} lg={3} xl={3}>
                      <p style={{ color: "#8686A2" }}>Date Of Onboarding</p>
                    </Col>
                    <Col sm={3} md={3} lg={3} xl={3}>
                      <p style={{ color: "#8686A2" }}>Cancellation Date</p>
                    </Col>
                    {/* <Col sm={3} md={3} lg={3} xl={3}>
                                        <p style={{ color: "#8686A2" }}>More Details</p>
                                    </Col> */}
                  </Row>
                  <hr />
                  {cancelledRequest.map((request) => {
                    return (
                      <Row>
                        <Col sm={3} md={3} lg={3} xl={3}>
                          <div style={{ color: "#000000" }} className="d-flex">
                            {request.resourceName}
                          </div>
                        </Col>
                        <Col sm={3} md={3} lg={3} xl={3}>
                          <p style={{ color: "#000000" }}>
                            {request.productManagerName}
                          </p>
                        </Col>
                        <Col sm={3} md={3} lg={3} xl={3}>
                          <p style={{ color: "#000000" }}>
                            {moment(request.onboardDate).format(
                              "MM/DD/YYYY"
                            ) === "Invalid date"
                              ? ""
                              : moment(request.onboardDate).format(
                                  "MM/DD/YYYY"
                                )}
                          </p>
                        </Col>
                        <Col sm={3} md={3} lg={3} xl={3}>
                          <p style={{ color: "#000000" }}>
                            {moment(request.cancelledDate).format("MM/DD/YYYY")}
                          </p>
                        </Col>
                        {/* <Col sm={3} md={3} lg={3} xl={3}>
                                            <p className="text-format" >View Cancellation Details</p>
                                        </Col> */}
                      </Row>
                    );
                  })}
                </Card.Body>
              </Card>
            </Row>
          </div>
        )}
      <div>
        {Object.keys(vendorResourceOnboarded).length > 0 &&
          vendorResourceOnboarded.type == "External" &&
          resourceAllocationState.resourceAllocationCollapsed &&
          vendorsCancelledList.length > 0 && (
            <div>
              <Row>
                <Col>
                  <div
                    style={{
                      padding: "5px",
                      paddingLeft: "10px",
                      fontWeight: "600",
                      color: "#1A1A1C !important",
                      fontSize: "15px",
                    }}
                  >
                    Cancelled Vendors
                  </div>
                </Col>
              </Row>
              <Row>
                <Card className={"onboard-card col"}>
                  <Card.Body className={"onboard-card-body"}>
                    <Row>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <div style={{ color: "#8686A2" }} className="d-flex">
                          Vendor Name
                        </div>
                      </Col>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <p style={{ color: "#8686A2" }}>Vendor Contacted</p>
                      </Col>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <p style={{ color: "#8686A2" }}>Staffing Velocity</p>
                      </Col>
                      <Col sm={3} md={3} lg={3} xl={3}>
                        <p style={{ color: "#8686A2" }}>Cancellation Date</p>
                      </Col>
                    </Row>
                    <hr />
                    {vendorsCancelledList.map((vendor) => {
                      return (
                        <Row>
                          <Col sm={3} md={3} lg={3} xl={3}>
                            <div
                              style={{ color: "#000000" }}
                              className="d-flex"
                            >
                              {vendor.vendordescr}
                            </div>
                          </Col>
                          <Col sm={3} md={3} lg={3} xl={3}>
                            <p style={{ color: "#000000" }}>
                              {moment(vendor.vendorstartdate).format(
                                "MM/DD/YYYY"
                              )}
                            </p>
                          </Col>
                          <Col sm={3} md={3} lg={3} xl={3}>
                            <p style={{ color: "#000000" }}>
                              {vendor.staffingvelocity}
                            </p>
                          </Col>
                          <Col sm={3} md={3} lg={3} xl={3}>
                            <p style={{ color: "#000000" }}>
                              {moment(vendor.closeDate).format("MM/DD/YYYY")}
                            </p>
                          </Col>
                        </Row>
                      );
                    })}
                  </Card.Body>
                </Card>
              </Row>
            </div>
          )}
      </div>
      {engagedVendorsList.length !== 0 &&
      Object.keys(resourceOnboarded).length === 0 &&
      resourceAllocationState.resourceAllocationCollapsed ? (
        <Container
          style={
            cancelledRequest.length > 0
              ? { padding: "0px 20px 10px 20px" }
              : { padding: "0px 20px 10px 20px", marginTop: "-55px" }
          }
        >
          <Row>
            <div
              style={{
                padding: "5px",
                fontWeight: "600",
                color: "#1A1A1C !important",
                fontSize: "15px",
              }}
            >
              Vendors Contacted
            </div>
          </Row>
          <Row className="rrc-request-background" style={{ marginTop: "5px" }}>
            <Row>
              <table>
                <thead>
                  <tr
                    style={{
                      display: "flex",
                      margin: "0px 10px 0px 10px",
                      padding: "0px 10px 0px 10px",
                    }}
                  >
                    <Col>
                      <span style={{ display: "flex" }}>
                        {showSelectAll ? (
                          <input
                            disabled={
                              requestStatus == "Completed" ||
                              requestStatus == "Cancelled" ||
                              isOtherRmRequest
                                ? true
                                : false
                            }
                            type="checkbox"
                            style={{ margin: "3px 10px 0px 0px" }}
                            label="Vendors"
                            onChange={(e) => selectAllVendors(e)}
                            checked={selectAll}
                          />
                        ) : (
                          ""
                        )}
                        <p style={{ color: "8686A2" }}>Vendor</p>
                      </span>
                    </Col>
                    <Col>
                      <p style={{ color: "8686A2" }}>Vendor Contacted</p>
                    </Col>
                    <Col>
                      <p style={{ color: "8686A2" }}>Status</p>
                    </Col>
                    <Col>
                      <p style={{ color: "8686A2" }}>Staffing Velocity</p>
                    </Col>
                    {/* <Col><p style={{ color: "8686A2" }}>More Details</p></Col> */}
                  </tr>
                </thead>
                <tbody>{engagedVendorsList.map(renderFunc)}</tbody>
              </table>
            </Row>
            <hr />
            <Row className="vendor-list-footer">
              <div className="pad-left" style={{ margin: "5px" }}>
                <div className="reopen-engagement-button">
                  <button
                    id="reopen-btn"
                    onClick={onReopenClick}
                    disabled={
                      resourceAllocationState.formControls.cancelledVendors
                        .value.length > 1 ||
                      resourceAllocationState.formControls.cancelledVendors
                        .value.length === 0
                    }
                  >
                    Reopen Engagement
                  </button>
                </div>
                <div className="close-engagement-button">
                  <button
                    id="close-btn"
                    onClick={() => setShowCloseEngagementModal(true)}
                    disabled={totalVendorsSelected == 0}
                  >
                    Close Engagement
                  </button>
                </div>
                <div className="onboard-resource-button">
                  <button
                    id="okay-btn"
                    disabled={totalVendorsSelected != 1 || requestStatus == "Cancelled" || requestStatus == "Completed"}
                    onClick={() => {
                      setResourceOnboardingModal(true);
                    }}
                  >
                    Reserve Resource
                  </button>
                </div>
              </div>
            </Row>
          </Row>
        </Container>
      ) : (
        ""
      )}

      <ResourceOnboarding
        show={resourceOnboardingModal}
        resourceOnboardingId={requestDetailsData.request_id}
        vendorDetails={engagedVendorsList}
        totalVendorsSelected={totalVendorsSelected}
        resourceOnboardingStatus={requestDetailsData.status}
        additionalMailRecipients={props.mailRecipients}
        onCloseResourceOnboardingModal={onCloseResourceOnboardingModal}
        onHide={() => setResourceOnboardingModal(false)}
      />

      <CloseEngagement
        show={showCloseEngagementModal}
        RequestId={props.requestId}
        RequestStatus={props.requestStatus}
        vendorDetails={engagedVendorsList}
        totalVendorsSelected={totalVendorsSelected}
        onModalClose={onCloseEngagementModal}
        onHide={() => setShowCloseEngagementModal(false)}
      />
    </>
  );
};
const mapStateToProps = (state, ownProps) => ({
  requestDetailsData: state.RequestDetailsDataReducer.requestDetailsData,
  allocatedResourceDetail:
    state.RequestDetailsDataReducer.onBoardResourceResponseSuccess,
  allocatedVendorResourceDetail:
    state.RequestDetailsDataReducer.onBoardVendorResourceResponseSuccess,
  cancelledRequest: state.RequestDetailsDataReducer.cancelledRequest,
  requestContactedVendors: state.RequestDetailsDataReducer.requestOpenVendors,
  loggedInUser: state.AuthReducer,
  userParams: state.AuthReducer.user,
  reportees: state.SCUsersReducer.reportees,
  requestUsedVendors: state.RequestDetailsDataReducer.requestUsedVendors,
});

const mapDispatchToProps = (dispatch) => ({
  getRequestDetailsData: (reqId) => dispatch(getRequestDetailsDataThunk(reqId)),
  cancelOnboarding: (payload, callback) =>
    dispatch(cancelOnboardingThunk(payload, callback)),
  cancelOnboardingVendor: (payload, callback) =>
    dispatch(cancelOnboardingVendorThunk(payload, callback)),
  getCancelledRequest: (reqId, callback) =>
    dispatch(getCancelledRequestThunk(reqId, callback)),
  getRequestOpenVendors: (reqId) => dispatch(getRequestOpenVendorsThunk(reqId)),
  onBoardResourceSuccess: (rmId, callback) =>
    dispatch(onBoardResourceSuccessThunk(rmId, callback)),
  onBoardVendorResourceSuccess: (rmId, callback) =>
    dispatch(onBoardVendorResourceSuccessThunk(rmId, callback)),
  getReporteesByLanId: (id) => dispatch(getReporteesByLanIdThunk(id)),
  getRequestUsedVendors: (reqId) => dispatch(getRequestUsedVendorsThunk(reqId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ResourceAllocation);
