import React, { Fragment, useEffect, useState } from "react";
import { useHistory } from "react-router";
import { Row, Col } from "react-bootstrap";
import RequestDetails from "./RequestDetails/requestDetails";
import Comments from "./Comments/comments";
import ResourceAllocation from "./ResourceAllocation/resourceAllocation";
import "./RequestDetails/requestDetails.scss";
import { connect } from "react-redux";
import {
  getRequestDetailsDataThunk,
  getRequestOpenVendorsThunk,
  getRequestUsedVendorsThunk,
  getRequestVendorsThunk,
  getResourceNamesThunk,
  getDuplicateRequestsThunk,
  getMatchProfilesThunk,
  getProductManagerThunk,
  getMailRecipientsThunk,
  getExternalBlockersThunk,
  onBoardResourceSuccessThunk,
  onBoardVendorResourceSuccessThunk,
  getCancelledRequestThunk,
  getNewRMListThunk,
} from "../../store/requestDetailsData.reducer";
import { getWorkflowDetailsThunk } from "../../store/requestDetailsData.reducer";
import { REQUEST_ROUTES } from "../../../../../app/Route/constants/requestRoutes.constants";
import { ArrowLeft } from "react-feather"
import Button from "../../../../../shared/components/forms/Button/button";
import { Trash2, AlertCircle, Check, Repeat } from "react-feather";
import "./requestDetailsHome.scss";
import CancelRequest from "./RequestDetails/CancelRequestDetails/cancelRequest";
import { getFormattedUserId } from "../../../../../../services/auth.services";
import ReportExternalBlocker from "./RequestDetails/ReportExternalBlocker/reportExternalBlocker";
import CompleteRequest from "./RequestDetails/CompleteRequest/completeRequest";
import { getProductLineThunk, getProductsByProductLineIdThunk } from "../../store";
import WorkflowWidget from "./WorkflowWidget/workflowWidget";
import ReassignResource from "./ReassignResource/reassignResource";

const RequestDetailsHome = (props) => {
  const [modalShow, setModalShow] = useState(false);
  const [showExternalBlockerModal, setExternalBlockerModalShow] = useState(false);
  const [showCompleteRequestModal, setCompleteRequestShow] = useState(false);
  const [showReassignResourceModal, setReassignModal] = useState(false);
  const [requestDetails, setRequestDetails] = useState(null);
  const [contactedVendorsCount, setContactedVendorsCount] = useState(0);

  const { requestDetailsData, updateReqIdDetails, requestVendors, duplicateRequests, getProductLine, getProductsByProductLineId, getRequestDetailsData, getRequestOpenVendors, requestOpenVendors, getRequestVendors, getDuplicateRequests,
    getRequestUsedVendors, requestUsedVendors, userParams, loggedInUser, getResourceNames,
    resourceNames, getMatchProfiles, matchProfiles, productManager, getProductManager,
    mailRecipients, getMailRecipients, externalBlockers, getExternalBlockers, allocatedResourceDetail, onBoardResourceSuccess, onBoardVendorResourceSuccess, workflowDetails, getNewRmList } = props;

  const requestId = localStorage.getItem('selectedRequestId');
  let empId = localStorage.getItem('emplyoee_id')
  let id = empId ? empId : getFormattedUserId(userParams);
  let lanId  = props.loggedInUser.isAuthenticated ? id : '';
  let isOtherRmRequest = false;
  if( localStorage.getItem('selectedRm')&&localStorage.getItem('selectedRm')!==localStorage.getItem('emplyoee_id')) {
    lanId =localStorage.getItem('selectedRm')
    isOtherRmRequest = true;
  }
  // const lanId = props.loggedInUser.isAuthenticated ? getFormattedUserId(props.userParams) : '';
  // const lanId = requestDetailsData.rmId;
  if (requestDetailsData.request_id != requestId) {
    updateReqIdDetails(lanId, requestId)
  }

  useEffect(() => {
  // getRequestDetailsData(requestDetailsData.request_id)
    getRequestOpenVendors(requestDetailsData.request_id)
    getRequestVendors()
    getDuplicateRequests(requestDetailsData.request_id, lanId)
    getRequestUsedVendors(requestDetailsData.request_id)
    getResourceNames(lanId)
    getMatchProfiles(requestDetailsData.request_id, lanId)
    getProductManager(requestDetailsData.request_id)
    getMailRecipients()
    getExternalBlockers()
    getProductLine(lanId)
    getProductsByProductLineId("PRT00000020")
    let requestStatus = ""
    if (requestDetailsData.status === 1) {
      requestStatus = "Identifying Resource";
    } else if (requestDetailsData.status === 2) {
      requestStatus = "Resource Reserved";
    } else if (requestDetailsData.status === 3) {
      requestStatus = "Completed";
    } else if (requestDetailsData.status === 4) {
      requestStatus = "Cancelled";
    } else if (requestDetailsData.status === 5) {
      requestStatus = "External Blocker";
    }
    onBoardResourceSuccess(requestDetailsData.request_id, onOnboardSuccess)
    onBoardVendorResourceSuccess(requestDetailsData.request_id, onOnboardSuccess)
  }, [requestDetailsData]);

  useEffect(() => {
    setRequestDetails(requestDetailsData)
    props.getCancelledRequest(requestDetailsData.request_id, onGetRequestCancelRequest)
    onBoardResourceSuccess(requestDetailsData.request_id, onOnboardSuccess)
    onBoardVendorResourceSuccess(requestDetailsData.request_id, onOnboardSuccess)
    props.getWorkflowDetails(requestDetailsData.request_id)
  }, [props.requestDetailsData])

  const onOnboardSuccess = () => { }

  const onGetRequestCancelRequest = () => { }

  const onModalClose = () => {
    setModalShow(false)
  }

  const onExternalBlockerModalClose = () => {
    setExternalBlockerModalShow(false)
  }

  const onReassignResourceModalClose = () => {
    setReassignModal(false)
  }

  const openReassignResourceModal = () => {
    setReassignModal(true);
    getNewRmList(lanId);
  }

  const onCompleteRequestModalClose = () => {
    setCompleteRequestShow(false)
    updateReqIdDetails(lanId, requestId )
  }

  const updateDetails = () => {
    updateReqIdDetails(lanId, requestId )
  }

  const history = useHistory();

  const onReturnClick = () => {
    history.push({
      pathname: `${REQUEST_ROUTES.ROUTE}`
    })
  }

  return (
    <Fragment>
      <div className="container-fluid pad-25-top">
        <div>
          <Row style={{ padding: "10px 10px 2px 10px" }}>
            <Col sm={5} md={5} lg={5} xl={5}>
              <span className={"rrc-details-title"}>
                <h3 style={{ color: "black" }}>
                  Request ID {requestDetailsData.request_id && requestDetailsData.request_id != null ? requestDetailsData.request_id : "N/A"}{"  "}
                  |&nbsp;
                </h3>
                <h4 style={{ color: "#3F66FB" }}>
                  {requestDetailsData.status === "1" ? "Identifying Resource" :
                    requestDetailsData.status === "2" ? "Resource Reserved" :
                      requestDetailsData.status === "3" ? "Completed" :
                        requestDetailsData.status === "4" ? "Cancelled" :
                          requestDetailsData.status === "5" ? "External Blocker" : "N/A"}
                </h4>
              </span>

            </Col>
            <Col sm={7} md={7} lg={7} xl={7} >
              {!isOtherRmRequest && <>
              {(requestDetailsData.status !== "3" && requestDetailsData.status !== "4") ?
                <div className="cancel-request-button" style={{marginLeft:"5px", float: "right" , width: "auto" }}>
                  <Button onClick={() => { setModalShow(true) }} >
                    <Trash2 size="16" strokeWidth="2" />
                    <span className='mr-1'>Cancel Request</span>
                  </Button>
                </div> : null
              }
              {((requestDetailsData.status !== "3" && requestDetailsData.status !== "4") && (requestDetailsData.planned_start !== "" && requestDetailsData.end_date !== "")) ?
                <div className="cancel-request-button" style={{ marginLeft:"5px",float: "right", width: "auto" }}>
                  <Button onClick={() => { setExternalBlockerModalShow(true) }} >
                    <AlertCircle size="16" strokeWidth="2" />
                    <span className='mr-1'>Report External Blocker</span>
                  </Button>
                </div> : null
              }

              {((requestDetailsData.status == "2" || (contactedVendorsCount == "1" &&requestDetailsData.status == "5")) && (requestDetailsData.planned_start !== "" && requestDetailsData.end_date !== "")) ?
                <div className="complete-request-button" style={{marginLeft:"5px", float: "right", width: "auto" }}>
                  <Button onClick={() => { setCompleteRequestShow(true) }}>
                    <span style={{ border: "1px solid #fff", borderRadius: "50px" }}>
                      <Check size="14" strokeWidth="2" /></span>
                    <span className='mr-1'>Complete Request</span>
                  </Button>
                </div> : null
              }
               {((requestDetailsData.status !== "3" && requestDetailsData.status !== "4") && (requestDetailsData.planned_start !== "" && requestDetailsData.end_date !== "")) ?
                <div className="cancel-request-button" style={{marginLeft:"5px", float: "right", width: "auto" }}>
                  <Button onClick={openReassignResourceModal}>
                    <Repeat size="16" strokeWidth="2" />
                    <span className='mr-1'>Reassign Request</span>
                  </Button>
                </div> : null
              }</>
              }
            </Col>
            <ReassignResource show={showReassignResourceModal}
              RequestId={requestDetailsData.request_id}
              RequestStatus={requestDetailsData.status}
              onModalClose={onReassignResourceModalClose}
            />
            <ReportExternalBlocker show={showExternalBlockerModal}
              RequestId={requestDetailsData.request_id}
              RequestStatus={requestDetailsData.status}
              vendor={requestVendors}
              externalBlockerType={externalBlockers}
              onModalClose={onExternalBlockerModalClose}
              onHide={() => setExternalBlockerModalShow(false)}
            />
            <CompleteRequest show={showCompleteRequestModal}
              RequestId={requestDetailsData.request_id}
              RequestStatus={requestDetailsData.status}
              ResourceType={allocatedResourceDetail.type}
              onModalClose={onCompleteRequestModalClose}
              onHide={() => setCompleteRequestShow(false)}
            />
            <CancelRequest show={modalShow}
              cancelRequestId={requestDetailsData.request_id}
              cancelRequestStatus={requestDetailsData.status}
              duplicateRequests={duplicateRequests}

              onModalClose={onModalClose}
              onHide={() => setModalShow(false)}
            />
          </Row>
          <Row style={{ padding: "0px 10px 10px 10px" }}>
            <span className={"go-back-arrow"} style={{ marginLeft: "15px", marginTop: "-8px" }}>
              <p onClick={onReturnClick} style={(requestDetailsData.status == 3 || requestDetailsData.status == 4) ? { paddingTop: "6px" } : { paddingTop: "0px" }}>
                <ArrowLeft size={13} />Go Back To Request Dashboard
              </p>
            </span>
          </Row>
        </div>
        <div className="" >
          <div className="request-container">
            <div className="request-status-details">
              <div className="rrc-container" style={{ paddingRight: "5px", paddingLeft: "10px" }}>
                <div className="rrc-details-wrapper">
                  <WorkflowWidget workflowDetails={workflowDetails} />
                </div></div>
            </div>
            <div className="request-dash-details">
              <div className="rrc-container" >
                <div className="rrc-details-wrapper">
                  <RequestDetails
                    requestStatus={requestDetailsData.status === "1" ? "Identifying Resource" :
                      requestDetailsData.status === "2" ? "Resource Reserved" :
                        requestDetailsData.status === "3" ? "Completed" :
                          requestDetailsData.status === "4" ? "Cancelled" :
                            requestDetailsData.status === "5" ? "External Blocker" : "N/A"}
                    requestDetails={requestDetailsData}
                  />
                  {((requestDetailsData.planned_start && requestDetailsData.end_date) && (requestDetailsData.planned_start !== "" && requestDetailsData.end_date !== "")) ?
                    <>
                      <ResourceAllocation requestId={requestDetailsData.request_id} requestStatus={requestDetailsData.status === "1" ? "Identifying Resource" :
                        requestDetailsData.status === "2" ? "Resource Reserved" :
                          requestDetailsData.status === "3" ? "Completed" :
                            requestDetailsData.status === "4" ? "Cancelled" :
                              requestDetailsData.status === "5" ? "External Blocker" : "N/A"} requestVendors={requestVendors} requestOpenVendors={requestOpenVendors} requestUsedVendors={requestUsedVendors} resourceNames={resourceNames} matchProfiles={matchProfiles} productManager={productManager}
                        mailRecipients={mailRecipients}
                        onUpdate={updateDetails}
                        setContactedVendorsCount={setContactedVendorsCount} />
                    </>
                    : ""}
                  <Comments
                    requestStatus={requestDetailsData.status === "1" ? "Identifying Resource" :
                      requestDetailsData.status === "2" ? "Resource Reserved" :
                        requestDetailsData.status === "3" ? "Completed" :
                          requestDetailsData.status === "4" ? "Cancelled" :
                            requestDetailsData.status === "5" ? "External Blocker" : "N/A"}
                    commentsData={requestDetails && requestDetails.commentsData} requestID={requestDetailsData.request_id} />
                    
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

const mapStateToProps = (state, ownProps) => ({
  requestDetailsData: state.RequestDetailsDataReducer.requestDetailsData,
  requestVendors: state.RequestDetailsDataReducer.requestVendors,
  duplicateRequests: state.RequestDetailsDataReducer.duplicateRequests,
  requestOpenVendors: state.RequestDetailsDataReducer.requestOpenVendors,
  requestUsedVendors: state.RequestDetailsDataReducer.requestUsedVendors,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
  resourceNames: state.RequestDetailsDataReducer.resourceNames,
  matchProfiles: state.RequestDetailsDataReducer.matchProfiles,
  productManager: state.RequestDetailsDataReducer.productManager,
  mailRecipients: state.RequestDetailsDataReducer.mailRecipients,
  externalBlockers: state.RequestDetailsDataReducer.externalBlockers,
  allocatedResourceDetail: state.RequestDetailsDataReducer.onBoardResourceResponseSuccess,
  workflowDetails: state.RequestDetailsDataReducer.workflowDetails
});

const mapDispatchToProps = (dispatch) => ({
  updateReqIdDetails: (id, lanId) =>
    dispatch(getRequestDetailsDataThunk(id, lanId)),
  getRequestDetailsData: (reqId) => dispatch(getRequestDetailsDataThunk(reqId)),
  getRequestVendors: () => dispatch(getRequestVendorsThunk()),
  getDuplicateRequests: (reqId, lanId) => dispatch(getDuplicateRequestsThunk(reqId, lanId)),
  getRequestOpenVendors: (reqId) => dispatch(getRequestOpenVendorsThunk(reqId)),
  getRequestUsedVendors: (reqId) => dispatch(getRequestUsedVendorsThunk(reqId)),
  getResourceNames: (lanId) => dispatch(getResourceNamesThunk(lanId)),
  getMatchProfiles: (reqId, lanId) => dispatch(getMatchProfilesThunk(reqId, lanId)),
  getProductManager: (reqId) => dispatch(getProductManagerThunk(reqId)),
  getMailRecipients: () => dispatch(getMailRecipientsThunk()),
  getExternalBlockers: () => dispatch(getExternalBlockersThunk()),
  onBoardResourceSuccess: (rmId, callback) => dispatch(onBoardResourceSuccessThunk(rmId, callback)),
  onBoardVendorResourceSuccess: (rmId, callback) => dispatch(onBoardVendorResourceSuccessThunk(rmId, callback)),
  getProductsByProductLineId: (productLineId, callback) =>
    dispatch(getProductsByProductLineIdThunk(productLineId, callback)),
  getProductLine: (lanId) => dispatch(getProductLineThunk(lanId)),
  getCancelledRequest: (reqId, callback) => dispatch(getCancelledRequestThunk(reqId, callback)),
  getWorkflowDetails: (reqId) => dispatch(getWorkflowDetailsThunk(reqId)),
  getNewRmList: (rmId) => dispatch(getNewRMListThunk(rmId))
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestDetailsHome);