import React, { useState, useEffect } from "react";
import { Row, Col, Container } from "react-bootstrap";
import { connect } from "react-redux";
import "./requestDetails.scss";
import { Copy } from "react-feather";
import moment from "moment";
import BrownBelt from "../../../../../../../assets/images/belts/brownBelt@2x.png";
import GreenBelt from "../../../../../../../assets/images/belts/greenBelt@2x.png";
import BlueBelt from "../../../../../../../assets/images/belts/blueBelt@2x.png";
import BlackBelt from "../../../../../../../assets/images/belts/blackBelt@2x.png";
import EditRequestDetails from "./EditRequestDetails/editRequestDetails";
import SelectDropdown from "../../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import Button from "../../../../../../shared/components/forms/Button/button";
import ToolTip from "../../../../../../shared/components/ToolTip/toolTip";
import {
  addClonesThunk,
  getJobTitleThunk,
  getRequestDetailsDataThunk,
  getRequestDropdownValuesThunk,
  GET_OPEN_REQUEST,
} from "../../../store";
import { getFormattedUserId } from "../../../../../../../services/auth.services";
import { Popover } from "react-bootstrap";
import { CloneRequests } from "./CloneRequest/cloneRequest";

const INITIAL_STATE = {
  formControls: {
    vendorsList: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
  },
  detailsCollapsed: true,
  resourceAllocationCollapsed: true,
  editRequestFrom: false,
  copyRequestForm: false,
  isClonedRequest: false,
};

const RequestDetails = (props) => {
  const [requestDetailsState, setRequestDetailsState] = useState(INITIAL_STATE);
  const {
    requestDetails,
    getRequestDetailsData,
    dropdownValues,
    requestVendors,
    jobtitle,
    getDropdownValues,
    userParams,
    loggedInUser,
    getJobTitle,
    requestStatus,
    addClones,
  } = props;

  let isOtherRmRequest = false;

  if (localStorage.getItem('selectedRm')&&localStorage.getItem('selectedRm')!==localStorage.getItem('emplyoee_id')) {
      isOtherRmRequest = true;
  }
  let otherRmId = localStorage.getItem('selectedRm')?localStorage.getItem('selectedRm'):"";
  let rmId = localStorage.getItem('emplyoee_id');
  let passRmId = rmId ? rmId : getFormattedUserId(userParams);

  let [check, setCheck] = useState(false);
  useEffect(() => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = loggedInUser.isAuthenticated
      ? id
      : "";
    checkIfCloned();
    getRequestDetailsData(requestDetails.request_id);
    getDropdownValues(lanId);
    getJobTitle(lanId);
  }, [requestDetails,check]);

  const checkIfCloned = () => {
    if(requestDetails.planned_start == "" && requestDetails.end_date == ""){
      setTimeout(()=>{
        setCheck(true);
      },1000)
      if(!isOtherRmRequest && !(requestStatus == "Cancelled" ||requestStatus == "Completed")){
        setRequestDetailsState({
          ...requestDetailsState,
          isClonedRequest:check,
        })
      }
    } else {
      setRequestDetailsState({
        ...requestDetailsState,
        isClonedRequest:false,
      })
    }
  }

  const onArrowClick = () => {
    setRequestDetailsState({
      ...requestDetailsState,
      detailsCollapsed: !requestDetailsState.detailsCollapsed,
    });
  };

  const onEditRequestClick = () => {
    setRequestDetailsState({
      ...requestDetailsState,
      editRequestFrom: true,
    });
  };

  const onCloseEditClick = () => {
    setRequestDetailsState({
      ...requestDetailsState,
      editRequestFrom: false,
      isClonedRequest:false
    });
  };

  const getImage = (label) => {
    if (label) {
      if (label.includes("Brown")) {
        return (
          <div>
            {label} <img src={BrownBelt} className={"belt-img-size"} />
          </div>
        );
      } else if (label.includes("Green")) {
        return (
          <div>
            {label} <img src={GreenBelt} className={"belt-img-size"} />
          </div>
        );
      } else if (label.includes("Blue")) {
        return (
          <div>
            {label} <img src={BlueBelt} className={"belt-img-size"} />
          </div>
        );
      } else if (label.includes("Black")) {
        return (
          <div>
            {label} <img src={BlackBelt} className={"belt-img-size"} />
          </div>
        );
      } else if (label == "null (null)") {
        return <div>-</div>
      } else {
        return <div>{label}</div>;
      }
    } else {
      return <div>-</div>;
    }
  };
  const getWrappedSkills = (skills) => {
    if (skills) {
      const skill = skills.split(",");
      const skillsset = skill.length > 1 ? skill[0] + "," + skill[1] : skill[0];
      return skill.length < 3 ? (
        skillsset
      ) : (
        <div>
          {skillsset}
          <ToolTip
            toolTipMessage={skill.join(", ")}
            toolTipTitle={"Technologies"}
            content={() => <span style={{ cursor: "pointer" }}>...</span>}
          ></ToolTip>
        </div>
      );
    }
  };

  const onCopyClick = (event) => {
    setRequestDetailsState({
      ...requestDetailsState,
      copyRequestForm: !requestDetailsState.copyRequestForm,
    });
  }

  const onCloseCopyClick = () => {
    setRequestDetailsState({
      ...requestDetailsState,
      copyRequestForm: false,
    });
  }

  return (
    <div className="rrc-container">
      <div>
        <>
          <Row className="rrc-request-details-header" style={{ margin: "5px" }}>
            <div className="rrc-request-details-blueBar"></div>
            <Col className="rrc-request-details-titleProps" sm={9} md={9} lg={9} xs={9}>
              <p
                style={{
                  color: "#3B77FE",
                  paddingRight: "5px",
                  fontSize: "16px",
                }}
              >
                Request Details
              </p>
              <div style={{ gap: "5px", display: "flex", alignItems: "center" }}>
                {(requestStatus == "Cancelled" ||
                  requestStatus == "Completed" || isOtherRmRequest) ? null : (
                  <button
                    style={{ background: "transparent", border: "none" }}
                    onClick={onEditRequestClick}
                  >
                    <img alt="" src="/img/edit-icon.svg" />
                  </button>
                )}
                {((requestDetails.planned_start == "" && requestDetails.end_date == "") || isOtherRmRequest) ? null :(
                  <Copy
                  id={"clone-icon-details_page"}
                  size={15}
                  onClick={onCopyClick}
                />
                )}
                {((requestDetails.planned_start == "" && requestDetails.end_date == "") && (!isOtherRmRequest) && !(requestStatus == "Cancelled" ||requestStatus == "Completed")) ?
                  <p style={{color:"red"}}>* Please fill <b>Planned Start Date</b> and <b>Planned End Date</b> to continue.</p>
                  : ""
                }
                
              </div>
            </Col>
            {requestDetailsState.editRequestFrom || requestDetailsState.isClonedRequest ? (
              <EditRequestDetails
                show={requestDetailsState.isClonedRequest?requestDetailsState.isClonedRequest:requestDetailsState.editRequestFrom}
                onHide={onCloseEditClick}
                requestDetails={requestDetails}
                dropdownValues={dropdownValues}
                jobtitle={jobtitle}
              />
            ) : (
              null
            )}
            {requestDetailsState.copyRequestForm ? (
              <CloneRequests
                rmId={passRmId}
                requestDetails={requestDetails}
                show={requestDetailsState.copyRequestForm}
                onHide={onCloseCopyClick}
                addClones={addClones}
                otherRmId={isOtherRmRequest?otherRmId:rmId}
              />
            ) : (
              ""
            )}
            <Col className="rrc-request-details-collapsible">
              {requestDetailsState.detailsCollapsed ? (
                <span style={{ fontSize: "20px" }} onClick={onArrowClick}>
                  <i className="fas fa-caret-up"></i>
                </span>
              ) : (
                <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                  <i className="fas fa-caret-down"></i>
                </div>
              )}
            </Col>
          </Row>
          <Row className="rrc-request-details-body" style={{ margin: "10px" }}>
            {requestDetailsState.detailsCollapsed ? (
              <Container>
                <Row>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Portfolio</p>
                    <p style={{ color: "#000000" }}>
                      {requestDetails.product_line}
                    </p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Product</p>
                    <p style={{ color: "#000000" }}>{requestDetails.product}</p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Product Manager</p>
                    <p style={{ color: "#000000" }}>
                      {requestDetails.product_owner}
                    </p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Application</p>
                    {requestDetails.application === "" ? (
                      "-"
                    ) : (
                      <p style={{ color: "#000000" }}>
                        {requestDetails.application}
                      </p>
                    )}
                  </Col>
                </Row>
                <hr />
                <Row>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Role</p>
                    <p style={{ color: "#000000" }}>{requestDetails.role}</p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Belt</p>
                    {requestDetails.job_title === "" ? (
                      "-"
                    ) : (
                      <p style={{ color: "#000000" }}>
                        {getImage(requestDetails.job_title)}
                      </p>
                    )}
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Allocation %</p>
                    <p style={{ color: "#000000" }}>
                      {requestDetails.allocation}
                    </p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Technologies</p>
                    <p style={{ color: "#000000" }}>
                      {getWrappedSkills(requestDetails.technologies)}
                    </p>
                  </Col>
                </Row>
                <hr />
                <Row>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Planned Start Date</p>
                    <p style={{ color: "#000000" }}>
                      {requestDetails.planned_start?moment(requestDetails.planned_start).format("MM/DD/YYYY"):"-"}
                    </p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Planned End Date</p>
                    <p style={{ color: "#000000" }}>
                      {requestDetails.end_date?moment(requestDetails.end_date).format("MM/DD/YYYY"):"-"}
                    </p>
                  </Col>
                  <Col>
                    <p style={{ color: "#8686A2" }}>Location</p>
                    {requestDetails.location === "" || requestDetails.location === undefined || requestDetails.location === null  ? (
                      "-"
                    ) : (
                      <p style={{ color: "#000000" }}>
                      {requestDetails.location}
                    </p>
                    )}  
                  </Col>
                  <Col>
                    {/* <p style={{ color: "#8686A2" }}>Comments</p>
                    <p style={{ color: "#000000" }}>-</p> */}
                  </Col>
                </Row>
                <hr />
              </Container>
            ) : (
              ""
            )}
          </Row>
        </>
      </div>
    </div>
  );
};

const mapStateToProps = (state, ownProps) => ({
  jobtitle: state.RequestResourceReducer.jobtitle,
  requestDetails: state.RequestDetailsDataReducer.requestDetailsData,
  dropdownValues: state.RequestResourceReducer.dropdownValues,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  getRequestDetailsData: (reqId) => dispatch(getRequestDetailsDataThunk(reqId)),
  getDropdownValues: (lanId) => dispatch(getRequestDropdownValuesThunk(lanId)),
  getJobTitle: (lanId) => dispatch(getJobTitleThunk(lanId)),
  addClones: (payload, callback) => dispatch(addClonesThunk(payload, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestDetails);
