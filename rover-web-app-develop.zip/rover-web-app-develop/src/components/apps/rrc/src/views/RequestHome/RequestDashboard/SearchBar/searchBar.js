import React, { useState, useEffect } from "react";
import { Search } from "react-feather";
import { connect } from "react-redux";
import { setSearchWord } from "../../../../store/common.reducer";
import "./searchBar.scss";

const SearchBar = (props) => {
    const { searchWord, setSearchWord } = props;
    const [searchTerm, setSearchTerm] = useState(searchWord);
    const [debouncedTerm, setDebouncedTerm] = useState(searchWord);

    useEffect(() => {
        const timeId = setTimeout(() => { setDebouncedTerm(searchTerm) }, 500)
        return () => { clearTimeout(timeId) };
    }, [searchTerm]);

    useEffect(() => {
        const search = () => {
            props.getSearchTerm(searchTerm == 'null'? null : searchTerm)
        }
        if (debouncedTerm) {
            search()
        }
    }, [debouncedTerm]);

    const onSearch = (e) => {
        if(!e.target.value) {
            setSearchTerm('null')
        } else {
            setSearchTerm(e.target.value)
        }
    }

    return (
        <div className="search-bar-wrapper">
            <span className="search-icon">
                <Search size="20" strokeWidth={2} />
            </span>
            <input className="search-bar" type="text" placeholder="Search" 
            value={searchTerm == 'null'? null : searchTerm} onChange={(e) =>onSearch(e)} />
        </div>
    );
};

const mapStateToProps = (state) => ({
    searchWord: state.RequestsCommonReducer.searchWord,
});
  
const mapDispatchToProps = (dispatch) => ({
    setSearchWord: (word) => dispatch(setSearchWord(word))
});

export default connect(mapStateToProps, mapDispatchToProps)(SearchBar);
