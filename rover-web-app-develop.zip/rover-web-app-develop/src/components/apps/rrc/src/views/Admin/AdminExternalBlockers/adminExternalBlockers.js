import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { REQUEST_ADMIN_ACTIONS } from "../../../constants/action.constants";
import { ACTIONS } from "../../../constants/action.constants";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { REQUEST_ADMIN_ACTION_TYPE } from "../../../constants/action.constants";
import { ERROR_MSG } from './../../../../../timesheet/constants/message.constants';
import Toaster from './../../../../../pcdm/src/components/Toaster/toaster';
import AdminExternalBlockersTable from "./adminExternalBlockersTable";
import AdminExternalBlockersForm from "./adminExternalBlockersForm";
import "./adminExternalBlockers.scss"
import "../admin.scss"
import { getExternalBlockerThunk } from './../../../store/admin.reducer';

function AdminExternalBlockers(props) {

  const { showNotification, getExternalBlockers } = props;

  const [showAdminExternalBlockersForm, setShowAdminExternalBlockersForm] = useState(false);
  const [adminExternalBlockersFormMode, setAdminExternalBlockersFormMode] = useState("");
  const [selectedVendor, setSelectedVendor] = useState({});
  const [formState, setFormState] = useState({ externalBlockers: '', vendor: '' });
  const [externalBlockers, setExternalBlockers] = useState(props.externalBlockers)
  const onAddorEditAdminExternalBlockers = (formMode, data) => {
    if (formMode === REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS) {
      setShowAdminExternalBlockersForm(true);
      setAdminExternalBlockersFormMode(REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS);
    } else {
      setAdminExternalBlockersFormMode(REQUEST_ADMIN_ACTIONS.EDIT_EXTERNAL_BLOCKERS);
    }
  };

  const onModalClose = (status, responseData, keepModal = false) => {
    let isAddForm = adminExternalBlockersFormMode === REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS;
    if (
      status === REQUEST_ADMIN_ACTION_TYPE.ADD_EXTERNAL_BLOCKERS_SUCCESS ||
      status === REQUEST_ADMIN_ACTION_TYPE.DELETE_EXTERNAL_BLOCKERS_SUCCESS
    ) {
      if(adminExternalBlockersFormMode === REQUEST_ADMIN_ACTIONS.EDIT_EXTERNAL_BLOCKERS) {
        if (status === REQUEST_ADMIN_ACTION_TYPE.DELETE_EXTERNAL_BLOCKERS_SUCCESS) {
          showNotification({
            title: "Success",
            variant: ACTIONS.SUCCESS,
            content: "External Blocker deleted successfully"
          });
        } else {
          showNotification({
            title: "Success",
            variant: ACTIONS.SUCCESS,
            content: "External Blocker edited successfully"
          });
        } 
      }
       else {
        showNotification({
          title: "Success",
          variant: ACTIONS.SUCCESS,
          content: isAddForm ? "External Blocker added successfully" : null
        });
      }
      getExternalBlockers()
      setShowAdminExternalBlockersForm(false);
    } else if (
      status === REQUEST_ADMIN_ACTION_TYPE.ADD_EXTERNAL_BLOCKERS_ERROR||
      status === REQUEST_ADMIN_ACTION_TYPE.DELETE_EXTERNAL_BLOCKERS_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (!keepModal || showAdminExternalBlockersForm) {
      setShowAdminExternalBlockersForm(false);  //close the form on click of cancel or close icon
    }
  };

  const onRowClickAddEdit = (row) => {
    setShowAdminExternalBlockersForm(true);
    setFormState({
      externalBlockers: row.description, vendor: row.vendor, id: row.blockerId
    });
  }

  useEffect(() => {
    if (props.externalBlockers) {
      setExternalBlockers(props.externalBlockers)
    }
  }, [props.externalBlockers])

  return (
    <div className='admin-container sc-admin-manage_vendor-container'>
      <AdminExternalBlockersTable externalBlockers={externalBlockers}
        onAddorEditAdminExternalBlockers={onAddorEditAdminExternalBlockers}
        onRowClickAddEdit={onRowClickAddEdit}
      />
      {showAdminExternalBlockersForm ? (
        <AdminExternalBlockersForm
          formVisible={showAdminExternalBlockersForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          formMode={adminExternalBlockersFormMode}
          selectedVendor={selectedVendor}
          formState={formState}
        />
      ) : null}
      <Toaster />
    </div>
  )

}

const mapStateToProps = (state) => ({
  externalBlockers: state.RoverRequestAdmin.externalBlockers

});

const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
  getExternalBlockers: () => dispatch(getExternalBlockerThunk()),

});

export default connect(mapStateToProps, mapDispatchToProps)(AdminExternalBlockers);