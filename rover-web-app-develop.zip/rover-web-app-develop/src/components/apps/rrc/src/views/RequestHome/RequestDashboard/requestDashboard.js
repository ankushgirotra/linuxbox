import React from "react";
import { Col, Row } from "react-bootstrap";
import { Plus, Download } from "react-feather";
import "./requestDashboard.scss";
import { connect } from "react-redux";
import {
  getDashboardTableThunk,
  getTableDataOnSearchThunk,
  getRMByRequestThunk,
  getRequestCountThunk
} from "../../../store/requestDashboard.reducer";
import CustomFilter from "./CustomFilter/customFilter";
import SearchBar from "./SearchBar/searchBar";
import { REQUEST_ROUTES } from "../../../../../../../components/app/Route/constants/requestRoutes.constants";
import { withRouter } from "react-router";
import Button from "../../../../../../shared/components/forms/Button/button";
import RequestTable from "./RequestTable/requestTable";
import { getFormattedUserId } from "../../../../../../../services/auth.services";
import ToolTip from "../../../../../../shared/components/ToolTip/toolTip";
import {
  getRequestIdFilterStatusThunk,
  getCreatedFilterStatusThunk,
  getStartDateFilterStatusThunk,
  getCurrentStatusFilterThunk,
  getProductFilterStatusThunk,
  getITPMFilterStatusThunk,
  getSkillsFilterStatusThunk,
} from "../../../store/customFilter.reducer";
import { setSelectedRms, setSearchWord, setCheckboxFilter, setCheckboxFilterStatus, setRequestDetailsSelectStatus } from "../../../store/common.reducer";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import SelectOtherRM from "./SelectOtherRM/selectOtherRM";
import moment from "moment";
import Tooltip from './../../RequestDetailsHome/Tooltip';
//import requestLocalURL from '../../../../../../../apis/exportLocal_api';
import { ListItemText,IconButton, Button as MuiBtn } from "@material-ui/core";
import {DateRange} from "@material-ui/icons";
import Popover from '@material-ui/core/Popover';
import TimeLineHome from '../../../../../../apps/suite/views/Financials/Components/timeLine/home';

//c:/Workspace/Newwk/rover-web-app/src/components/apps/suite/views/Financials/Components/timeLine/home
import requestURL from '../../../../../../../apis/request_api';
const CHECKBOX_FILTER_INITIAL_STATE = {
  open: true,
  completed: false,
  cancelled: false,
};

const DateCalculation =(type)=>{
  var d = new Date();
let m = d.getMonth(); //current month
let y = d.getFullYear(); //current year
var firstDay ='';
var DayOfMonth ='';
if(type=='last'){
  DayOfMonth = new Date(d.getFullYear(), d.getMonth(), 0);
  firstDay = new Date(d.getFullYear(), d.getMonth()-1, 1);
  let result ={
      'start':firstDay,
      'end':DayOfMonth
  }
   return result;
}else if(type =='current'){
  firstDay = new Date(d.getFullYear(), d.getMonth(), 1);
  DayOfMonth = new Date();
  
  let result ={
      'start':firstDay,
      'end':DayOfMonth
  }
   return result;
}else if(type =='year'){
  DayOfMonth = new Date();
  firstDay = new Date(new Date().getFullYear(), 0, 1);
  let result ={
      'start':firstDay,
      'end':DayOfMonth
  }
   return result;
 
}
}
class RequestDashboard extends React.Component {
  sortingOrder = undefined;
  rmId = this.props.loggedInUser.isAuthenticated
    ? localStorage.getItem('emplyoee_id') ? localStorage.getItem('emplyoee_id') 
    : getFormattedUserId(this.props.userParams)
    : "";

  constructor(props) {
    super(props);
    this.state = {
      filter: false,
      tableData: [],
      originalTableData: [],
      sortingOrder: undefined,
      columnToBeSorted: null,
      checkBoxFilter: CHECKBOX_FILTER_INITIAL_STATE,
      isCheckBoxFilter: true,
      search: null,
      rmSelected: [],
      progress: false,
      anchorEl: null,
      hover: false,
      timLineType:'Year of month',
      startDate:DateCalculation('year').start,
      endDate:DateCalculation('year').end
    };
  }

  onHandleNewRequest = () => {
    const { location } = this.props;
    if (this.props.history) {
      this.props.history.push(
        `${location.pathname}${REQUEST_ROUTES.CHILDREN.ROUTE}`
      );
    }
  };

  componentDidMount = async () => {
    debugger
    const { userParams, loggedInUser } = this.props;
    if(this.props.requuestDetailsSelectStatus || this.props.searchWord !="" || this.props.selectedRms.length!=0 || 
    this.props.checkboxFilters.open!=true || this.props.checkboxFilters.completed!=false ||
    this.props.checkboxFilters.cancelled!=false){
      await this.getStatusAsCSV();
      this.setCustomFilters();
    }else{
      localStorage.removeItem("selectedRm");
      let empId = localStorage.getItem('emplyoee_id')
      let id = empId ? empId : getFormattedUserId(userParams);
      let lanId = loggedInUser.isAuthenticated
        ? id
        : "";
      let payload = {
        rmId: [],
        empId: lanId,
        createdFromDate:moment(this.state.startDate).format('YYYY-MM-DD'),
        createdToDate:moment(this.state.endDate).format('YYYY-MM-DD')
      };
      payload.rmId.push(lanId);
     

      // const rmsId = this.props.iiqRoles.RESOURCE_MANAGER || this.props.iiqRoles.SC.RM ? lanId : ''
      await this.props.getTableData("o", payload);
      await this.props.getRMByRequest();
      await this.props.getRequestCount(lanId,lanId); 
      this.setState({
        tableData: this.props.tableData.data,
        originalTableData: this.props.tableData.data,
      });
    }
    
  };

  setCustomFilters = async () => {
    const { rm, requestIdStatus, createdStatus, startDateStatus, status, productStatus,
       itpmStatus, skillsStatus, } = this.props;
       let filterData = {
        rmName: rm.itemToBeFiltered || [],
        request_id: requestIdStatus.itemToBeFiltered || [],
        createdDate: createdStatus.itemToBeFiltered || [],
        plannedStart: startDateStatus.itemToBeFiltered || [],
        status: status.itemToBeFiltered || [],
        product: productStatus.itemToBeFiltered || [],
        managername: itpmStatus.itemToBeFiltered || [],
        skills: skillsStatus.itemToBeFiltered || [],
    }
    if(rm.itemToBeFiltered){
     await this.onColumnFilter('rmName', rm.itemToBeFiltered, filterData, true)  
    }
    else if(requestIdStatus.itemToBeFiltered){
     await this.onColumnFilter('request_id', requestIdStatus.itemToBeFiltered, filterData, true)  
    }
    else if(createdStatus.itemToBeFiltered){
      await this.onColumnFilter('createdDate', createdStatus.itemToBeFiltered, filterData, true)  
     }
    else if(startDateStatus.itemToBeFiltered){
      await this.onColumnFilter('plannedStart', startDateStatus.itemToBeFiltered, filterData, true)  
     }
    else if(status.itemToBeFiltered){
      await this.onColumnFilter('status', status.itemToBeFiltered, filterData, true)  
     }
    else if(productStatus.itemToBeFiltered){
      await this.onColumnFilter('product', productStatus.itemToBeFiltered, filterData, true)  
     }
    else if(itpmStatus.itemToBeFiltered){
      await this.onColumnFilter('managername', itpmStatus.itemToBeFiltered, filterData, true)  
     }
    else if(skillsStatus.itemToBeFiltered){
      await this.onColumnFilter('skills', skillsStatus.itemToBeFiltered, filterData, true)  
     }
     this.props.setRequestDetailsSelectStatus(false)
  }

  onColumnFilter = (
    columnToBeFiltered,
    datasToBeFiltered,
    filter,
    sortType
  ) => {
    const duplicateTableData = [...this.state.originalTableData];
    const data = duplicateTableData.filter((obj) =>
      datasToBeFiltered.includes(obj[columnToBeFiltered])
    );
    delete filter[columnToBeFiltered];
    const filterKeys = Object.keys(filter);
    let filteredArray = data.filter((item) => {
      return filterKeys.every((key) => {
        if (!filter[key].length) {
          return true;
        }
        return filter[key].find((filter) => filter === item[key]);
      });
    });
    this.setState({
      tableData: filteredArray,
      filter: true,
    });
    if (sortType === true || sortType === false) {
      this.setState({
        columnToBeSorted: columnToBeFiltered,
        sortingOrder: sortType,
      });
    }
  };

  onCheckFilter = (e) => {
    debugger
    const name = e.target.name;
    const { tableData, originalTableData } =this.state;
    this.props.setCheckboxFilter({ ...this.props.checkboxFilters, [name]:e.target.checked})
    setTimeout(
      function () {
        this.getStatusAsCSV();
      }.bind(this),
      100
    );
  };



  getStatusAsCSV = async () => {
    if(!(this.props.requuestDetailsSelectStatus|| this.props.searchWord !="" || this.props.selectedRms.length!=0 || 
    this.props.checkboxFilters.open!=true || this.props.checkboxFilters.completed!=false ||
    this.props.checkboxFilters.cancelled!=false)){
      this.onClearFilter();
    }
    const statusArray = this.props.checkboxFilters;
    let csv = [];
    for (let element in statusArray) {
      if (element === "open" && statusArray[element]) {
        csv.push("o");
      }
      if (element === "completed" && statusArray[element]) {
        csv.push("co");
      }
      if (element === "cancelled" && statusArray[element]) {
        csv.push("ca");
      }
    }
    const status = csv.map((status) => status).join(",");
    if (status == "") {
      this.props.setCheckboxFilterStatus(false)
      if (this.props.searchWord) {
        this.onSearch(this.props.searchWord);
      }
    } else if (
      status &&
      !this.props.searchWord &&
      this.props.selectedRms.length === 0
    ) {
      const { userParams, loggedInUser } = this.props;
      let empId = localStorage.getItem('emplyoee_id')
      let id = empId ? empId : getFormattedUserId(userParams);
      let lanId = loggedInUser.isAuthenticated
        ? id
        : "";
      let payload = {
        rmId: [],
        empId: lanId,
        createdFromDate:moment(this.state.startDate).format('YYYY-MM-DD'),
        createdToDate:moment(this.state.endDate).format('YYYY-MM-DD')
      };
      payload.rmId.push(lanId);
      await this.props.getTableData(csv.map((x) => x).join(","), payload);
      this.setState({
        tableData: this.props.tableData.data,
        originalTableData: this.props.tableData.data,
      });
      this.props.setCheckboxFilterStatus(true)
    } else if (
      status &&
      this.props.selectedRms.length > 0 &&
      !this.props.searchWord
    ) {
      const { userParams, loggedInUser } = this.props;
      let lanId = loggedInUser.isAuthenticated
        ? getFormattedUserId(userParams)
        : "";
      let payload = {
        rmId: this.props.selectedRms,
        empId: lanId,
        createdFromDate:moment(this.state.startDate).format('YYYY-MM-DD'),
        createdToDate:moment(this.state.endDate).format('YYYY-MM-DD')
      };
      await this.props.getRequestCount(lanId, payload.rmId.join(","));
      await this.props.getTableData(csv.map((x) => x).join(","), payload);
      this.setState({
        tableData: this.props.tableData.data,
        originalTableData: this.props.tableData.data,
      });
      this.props.setCheckboxFilterStatus(true)
    }
  };

  onSearch = async (searchTerm) => {
    this.onClearFilter();
    let word = searchTerm === null ? searchTerm : searchTerm.trim();
    const { userParams, loggedInUser } = this.props;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    let lanId = loggedInUser.isAuthenticated
      ? id
      : "";
    let otherRms =  this.props.selectedRms.map(rm => rm).join(",")
    let employeesSelected = otherRms ? `${lanId},${otherRms}` : lanId

    /*  checking for date string in format mm/dd/yyyy and converting it to yyyy-mm-dd */
    if(!Number.isNaN(word)){
      if(word && word.length>=8){
        const newWord = word.split("/")
        if(newWord.length==3){
          if(newWord[0]>=1 && newWord[0]<=12){
            if(newWord[1]>=1 && newWord[1]<=31){
              if(newWord[2].length == 4){
                word = moment(new Date(word)).format().split("T")[0]
              }
            }
          }
        }
      }
    }
    /* end */
    
    let payload = {
      employee:employeesSelected,
      word:word,
      // otherRMIds:this.props.selectedRms.map(rm => rm).join(",")
    }
    if (word != null) {
      await this.props.getSearchResults(payload);
      this.setState({
        search: word,
        tableData: this.props.searchResults,
      });
      this.props.setSearchWord(word)
    } else {
      this.setState({
        search: null,
      });
      this.props.setSearchWord(null)
      setTimeout(
        function () {
          this.getStatusAsCSV();
        }.bind(this),
        100
      );
    }
  };

  getWrappedSkills = (skills) => {
    const skill = skills?skills.split(","):[];
    return skill.length === 1 ? (
      skill[0]
    ) : (
      <div>
        {skill[0]}
        <ToolTip
          toolTipMessage={skill.join(", ")}
          toolTipTitle={"Skills"}
          content={() => <span style={{ cursor: "pointer" }}>...</span>}
        ></ToolTip>
      </div>
    );
  };

  onClearFilter = () => {
    this.setState({
      tableData: this.state.originalTableData,
    });
    const {
      getRequestIdFilterStatus,
      getStartDateFilterStatus,
      getCreatedFilterStatus,
      getCurrentStatusFilter,
      getProudctFilterStatus,
      getITPMFilterStatus,
      getSkillsFilterStatus,
    } = this.props;
    getRequestIdFilterStatus({});
    getStartDateFilterStatus({});
    getCreatedFilterStatus({});
    getCurrentStatusFilter({});
    getProudctFilterStatus({});
    getITPMFilterStatus({});
    getSkillsFilterStatus({});
  };

  onRmSelect = (selectedRmList) => {
    // const { userParams, loggedInUser } = this.props;
    // let lanId = loggedInUser.isAuthenticated
    //   ? getFormattedUserId(userParams)
    //   : "";
    // if (
    //   selectedRmList.length === 0 ||
    //   selectedRmList.filter((x) => x == lanId).length === 0
    // ) {
    //   selectedRmList.push(lanId);
    // }
    this.setState({ rmSelected: selectedRmList });
    this.props.setSelectedRms(selectedRmList)
    setTimeout(
      function () {
        this.getStatusAsCSV();
      }.bind(this),
      100
    );
  };

  
  toggleHover =()=>{
    this.setState({hover:!this.state.hover}) 
  }
   handleTimeClick = (event) => {
    //setAnchorEl(event.currentTarget);
    this.setState({anchorEl:event.currentTarget})
  };
   handleTimeClose = () => {
    //setAnchorEl(null);
    debugger
    this.setState({anchorEl:null})
  };

  handleSelectDate = (type,data)=>{

      this.setState({timLineType:data});
   
     if(type== 'defult'){
        if(data=='This month'){
         this.setState({startDate:DateCalculation('current').start});
         this.setState({endDate:DateCalculation('current').end});
         
       }
       else if(data =='Last month'){
         this.setState({startDate:DateCalculation('last').start});
         this.setState({endDate:DateCalculation('last').end});
       
       }
       else if(data =='Year of month'){
        this.setState({startDate:DateCalculation('year').start});
         this.setState({endDate:DateCalculation('year').end});
       }
     }else if(type=='custom'){
      this.setState({startDate:moment(data.start).format('MM-DD-YYYY')});
      this.setState({endDate:moment(data.end).format('MM-DD-YYYY')});
     }
  
  this.setState({anchorEl:null})
  setTimeout(
    function () {
      this.getStatusAsCSV();
    }.bind(this),
    100
  );
  }

//   onExport = () => {
//     const mID = this.state.tableData.map((request) => request.rmId).join(",");
//     this.setState({progress:true})
// debugger
//     let params={
//       managerId:mID,
//         status:["co,o"]
//     }
//     requestURL
//     .put(
//       `request/exportRequestReport`, {
//         managerId:mID,
//         status:["co,o"],
//        // domainId:domainName,
//       },
//       // {body: JSON.stringify({
//       //   managerId:mID,
//       //   status:["co,o"]
//       // })},
//       { responseType: "blob" },
      
//     )
//     // .get(
//     //   `request/exportRequestReport=${encodeURIComponent(JSON.stringify(params))}`,
//     //   //`request/exportRequestReport=${JSON.stringify(params)}`,
//     //   { responseType: "arraybuffer" }
//     // )
//     .then((response) => {
//       var blob = new Blob([response.data], {
//         type:
//           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
//       });

//       const url = window.URL.createObjectURL(blob);
//       const link = document.createElement("a");
//       link.href = url;
//       link.setAttribute("download",`Rover_Requests_${moment.utc(new Date()).format("MM/DD/YYYY")}`);
//       document.body.appendChild(link);
//       link.click();
//       this.setState({progress:false})
//     }).catch(err =>{
//       console.log(err)
//       this.setState({progress:false})
//     })
//   }

onExport = () => {
  const params = this.state.tableData.map((request) => request.request_id).join(",");
  this.setState({progress:true})
  requestURL
  .get(
    `request/requestReport?reqId=${params}`,
    { responseType: "arraybuffer" }
  )
  .then((response) => {
    var blob = new Blob([response.data], {
      type:
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download",`Rover_Requests_${moment.utc(new Date()).format("MM/DD/YYYY")}`);
    document.body.appendChild(link);
    link.click();
    this.setState({progress:false})
  }).catch(err =>{
    console.log(err)
    this.setState({progress:false})
  })
}

  componentWillUnmount = () => {
    // this.onClearFilter();
  };

  render() {
    const data = this.state.tableData;
    const progress = this.state.progress;
    //const [anchorEl, setAnchorEl] = React.useState(null);
    const timLineType= this.state.timLineType;
    const anchorEl = this.state.anchorEl;
    const openTime = Boolean(anchorEl);
    var btnStyle;
    if(this.state.hover){
      btnStyle={
        background:'#3b77fe 0% 0% no-repeat padding-box',
        color:'white',
        fontWeight:'400',
        fontSize:'12px',
        textTransform:'none'}
    }else{
      btnStyle={background:'#fff 0% 0% no-repeat padding-box',
        color:'#3b77fe',
        fontWeight:'400',
        fontSize:'12px',
        textTransform:'none'}
    }
    const id = openTime ? 'simple-popover' : undefined;
    const columns = [
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"rmName"}
            title={"Manager"}
            columnTitle={"MANAGER"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "rmName",
        disableFilters: true,
        disableSortBy: false,
        sortType: "basic",
        Cell: ({ row }) => (
          <div className="rrc-product-field">
          <span className="rrc-product-field-span" title={row.values.rmName}>{row.values.rmName}</span>
        </div>
        ),
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"request_id"}
            title={"ID"}
            columnTitle={"ID"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "request_id",
        disableFilters: true,
        disableSortBy: false,
        sortType: "basic",
        
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"createdDate"}
            title={"Created"}
            columnTitle={"CREATED"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "createdDate",
        disableFilters: true,
        disableSortBy: false,
        sortType: "basic",
        Cell: ({ row }) => (
          <div>{moment(row.values.createdDate, "").format("MM/DD/YYYY")}</div>
        ),
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"plannedStart"}
            title={"Start Date"}
            columnTitle={"START DATE"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "plannedStart",
        disableFilters: true,
        disableSortBy: false,
        sortType: "basic",
        Cell: ({ row }) => (
          <div>{moment(row.values.plannedStart, "").format("MM/DD/YYYY")}</div>
        ),
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"status"}
            title={"Status"}
            columnTitle={"STATUS"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "status",
        disableFilters: true,
        disableSortBy: false,
        sortType: "basic",
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"product"}
            title={"Product"}
            columnTitle={"PRODUCT"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "product",
        disableFilters: true,
        disableSortBy: false,
        Cell: ({ row }) => (
          <div className="rrc-product-field">
          <span className="rrc-product-field-span" title={row.values.product}>{row.values.product}</span>
        </div>
        ),
        sortType: "basic",
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"managername"}
            title={"ITPM"}
            columnTitle={"ITPM"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "managername",
        disableFilters: false,
        Cell: ({ row }) =>
        <div className="rrc-product-field">
        <span className="rrc-product-field-span" title={row.values.managername}>{row.values.managername}</span>
      </div>,
        sortType: "basic",
      },
      {
        Header: () => (
          <CustomFilter
            filter={this.state.filter}
            originalData={this.state.originalTableData}
            tableData={this.state.tableData}
            dataToBeFiltered={"skills"}
            title={"Skills"}
            columnTitle={"SKILLS"}
            onFilter={this.onColumnFilter}
          />
        ),
        accessor: "skills",
        disableFilters: true,
        disableSortBy: false,
        Cell: ({ row }) => (
          <div>{this.getWrappedSkills(row.values.skills)}</div>
        ),
        sortType: "basic",
      },
    ];

    return (
      <div className="rrc-container">
        <OverlayLoader
          loading={this.props.tableData.status === DATA_STATUS.LOADING}
        />
        <div className="rrc-details-wrapper">
          <>
            <Row className="rrc-header-container">
              <Col sm={2} md={2} lg={2} xl={2} style={{ paddingLeft: "0px" }}>
                <p className="rrc-header">My Requests</p>
              </Col>
              <Col sm={2} md={2} lg={2} xl={2} style={{ paddingLeft: "0px" }}>
              {/* <IconButton  aria-describedby={id}  color="primary" component={"span"} 
              onClick={this.handleTimeClick} 
              style={{marginTop:'-9px'}}>
              <DateRange style={{fontWeight:'600',fontSize:'18px' ,color:'#4966c7'}}/><p style={{color:'#4966c7',fontSize:'18px',fontWeight:'600'}}>&nbsp;Timeline</p>
            </IconButton> */}
            <MuiBtn aria-describedby={id} 
            onMouseEnter={this.toggleHover}
            onMouseLeave={this.toggleHover}
            style={btnStyle}
             startIcon={<DateRange/>}
            size={"small"} color="primary" variant="outlined" 
            onClick={this.handleTimeClick} >
              TimeLine</MuiBtn>
        <Popover
        id={id}
        open={openTime}
        anchorEl={anchorEl}
        onClose={this.handleTimeClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <TimeLineHome 
        defultType={timLineType}
        popClose={()=>this.handleTimeClose()} 
        popselectDate={this.handleSelectDate}
        />
      </Popover>
              </Col>
              {/* close Timeline */}
              <Col
                sm={6}
                md={6}
                lg={6}
                xl={6}
                className="searchbar-outline adjust-padding"
              >
                <SearchBar getSearchTerm={this.onSearch} />
              </Col>
              <Col sm={2} md={2} lg={2} xl={2}>
                <div className="new-request-button">
                  <Button onClick={this.onHandleNewRequest} >
                    <Plus size="17" strokeWidth="3" />
                    <span className="mr-1">New Request</span>
                  </Button>
                </div>
              </Col>

              {/* <Grid item lg={2} xl={2} md={3} sm={4} xs={6} style={{color:'blue',marginLeft: windowSize[0] > 950 ?'-67px':''}}> */}
              <Col
                sm={12}
                md={12}
                lg={12}
                xl={12}
                // style={{ padding: "20px 20px 10px 0px" }}
              >
      <p style={{color:'#8686a2',fontSize:'15px'}}>Selected Period :&nbsp;&nbsp;&nbsp;&nbsp;{moment(this.state.startDate).format('MM-DD-YYYY')} - {moment(this.state.endDate).format('MM-DD-YYYY')}   </p> {/* {moment(startDate).format('MM-DD-YYYY')} - {moment(endDate).format('MM-DD-YYYY')} */}
         </Col>
          {/* </Grid> */}
              <Col
                sm={10}
                md={10}
                lg={10}
                xl={10}
                style={{ padding: "20px 20px 10px 0px" }}
              >
                <div className="table-filter">
                  <div
                    className={
                      this.props.checkboxFilters.open
                        ? "table-filter-item table-filter-item-selected"
                        : "table-filter-item"
                    }
                  >
                    <input
                      type="checkbox"
                      name="open"
                      onChange={this.onCheckFilter}
                      defaultChecked={this.props.checkboxFilters.open}
                      id="open"
                    />
                    <div className="table-filter-label" htmlFor="open">
                      Open {this.props.requestCount.open}
                    </div>
                  </div>
                  <div
                    className={
                      this.props.checkboxFilters.completed
                        ? "table-filter-item table-filter-item-selected"
                        : "table-filter-item"
                    }
                  >
                    <input
                      type="checkbox"
                      name="completed"
                      onChange={this.onCheckFilter}
                      defaultChecked={this.props.checkboxFilters.completed}
                      id="completed"
                    />
                    <div className="table-filter-label" htmlFor="completed">
                      Completed {this.props.requestCount.complete}
                    </div>
                  </div>
                  <div
                    className={
                      this.props.checkboxFilters.cancelled
                        ? "table-filter-item table-filter-item-selected"
                        : "table-filter-item"
                    }
                  >
                    <input
                      type="checkbox"
                      name="cancelled"
                      onChange={this.onCheckFilter}
                      defaultChecked={this.props.checkboxFilters.cancelled}
                      id="cancelled"
                    />
                    <div className="table-filter-label" htmlFor="cancelled">
                      Cancelled {this.props.requestCount.cancelled}
                    </div>
                  </div>
                  {/* <div className="table-filter-items">
                                    </div> */}
                  <SelectOtherRM
                    rmList={this.props.rmByRequestList}
                    lanId={this.rmId}
                    onApply={this.onRmSelect}
                  />
                </div>
              </Col>
              <Col
                sm={2}
                md={2}
                lg={2}
                xl={2}
                style={{ padding: "20px 20px 10px 10px" }}
              >
                  <div className="export-requests-btn" style={{ marginLeft: "45px" }}>
                  <Tooltip content="Export the requests in the current view" direction="left">
                    <Button onClick={this.onExport} loading={progress} fliud={true} className="export-requests-button">
                     <Download size={15} strokeWidth={3} />
                      <span>Export</span>
                    </Button>
                    </Tooltip>
                  </div>
              </Col>
            </Row>
            {(this.props.checkboxFiltersStatus ||
              (this.props.searchWord &&
                this.props.tableData.status === DATA_STATUS.SUCCESS)) && (
              <RequestTable
                filter={this.state.filter}
                data={data || []}
                sortType={this.state.sortingOrder}
                columnToBeSorted={this.state.columnToBeSorted}
                columns={columns}
                resetFilter={this.onResetColumnFilter}
              />
            )}
            {this.props.checkboxFiltersStatus === false && (
              <div style={{ textAlign: "center" }}>{"No Results Found"}</div>
            )}
          </>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => ({
  tableData: state.RequestDashboardReducer.dashboardTableData,
  searchResults: state.RequestDashboardReducer.tableDataAfterSearch,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
  rmByRequestList: state.RequestDashboardReducer.rmByRequestList,
  requestCount: state.RequestDashboardReducer.requestCount,
  selectedRms: state.RequestsCommonReducer.selectedRms,
  searchWord: state.RequestsCommonReducer.searchWord,
  checkboxFilters: state.RequestsCommonReducer.checkboxFilters,
  checkboxFiltersStatus: state.RequestsCommonReducer.checkboxFiltersStatus,
  requuestDetailsSelectStatus: state.RequestsCommonReducer.requuestDetailsSelectStatus,
  rm: state.CustomFilterReducer.rm,
  requestIdStatus: state.CustomFilterReducer.requestId,
  createdStatus: state.CustomFilterReducer.created,
  startDateStatus: state.CustomFilterReducer.startDate,
  status: state.CustomFilterReducer.status,
  productStatus: state.CustomFilterReducer.product,
  itpmStatus: state.CustomFilterReducer.itpm,
  skillsStatus: state.CustomFilterReducer.skills,
  iiqRoles: state.AuthReducer.ROVER_IIQ_ROLES,
});

const mapDispatchToProps = (dispatch) => ({
  getTableData: (status, payload) =>
    dispatch(getDashboardTableThunk(status, payload)),
  getSearchResults: (payload) =>
    dispatch(getTableDataOnSearchThunk(payload)),
  getRequestIdFilterStatus: (status) =>
    dispatch(getRequestIdFilterStatusThunk(status)),
  getCreatedFilterStatus: (status) =>
    dispatch(getCreatedFilterStatusThunk(status)),
  getStartDateFilterStatus: (status) =>
    dispatch(getStartDateFilterStatusThunk(status)),
  getCurrentStatusFilter: (status) =>
    dispatch(getCurrentStatusFilterThunk(status)),
  getProudctFilterStatus: (status) =>
    dispatch(getProductFilterStatusThunk(status)),
  getITPMFilterStatus: (status) => dispatch(getITPMFilterStatusThunk(status)),
  getSkillsFilterStatus: (status) =>
    dispatch(getSkillsFilterStatusThunk(status)),
  getRMByRequest: () => dispatch(getRMByRequestThunk()),
  getRequestCount: (lanId, rmIds) => dispatch(getRequestCountThunk(lanId, rmIds)),
  setSelectedRms: (payload) => dispatch(setSelectedRms(payload)),
  setSearchWord: (word) => dispatch(setSearchWord(word)),
  setCheckboxFilter: (payload) => dispatch(setCheckboxFilter(payload)),
  setCheckboxFilterStatus: (status) => dispatch(setCheckboxFilterStatus(status)),
  setRequestDetailsSelectStatus: (status) => dispatch(setRequestDetailsSelectStatus(status)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(RequestDashboard));