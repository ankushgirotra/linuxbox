import React, { Fragment, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import RequestDashboard from "./RequestDashboard/requestDashboard";
import RequestStatus from "./RequestStatus/requestStatus";
import RequestNotification from "./RequestNotification/requestNotification"
import "./requestHome.scss";
import { connect } from "react-redux";
import {
  getOpenRequestThunk,
  getNotificationsThunk,
  getNotificationsListThunk,
  getLoggedInRmInfoThunk
} from "../../../src/store/requestStatus.reducer";
import { getFormattedUserId } from "../../../../../../services/auth.services";
import { getApplicationsByProductIdThunk, getProductLineThunk, getProductsByProductLineIdThunk } from "../../store";

const RequestHome = (props) => {



  useEffect(() => {
    const { userParams, loggedInUser } = props;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    let lanId = loggedInUser.isAuthenticated ? id : "";
    getOpenRequest(lanId)
    getNotifications(lanId)
    getNotificationsList(lanId)
    getLoggedInRmInfo(lanId)
    getProductLine(lanId)
    getProductsByProductLineId("PRT00000020")
  }, []);

  const { getOpenRequest, openRequests, getProductLine, getProductsByProductLineId, getNotificationsList, getLoggedInRmInfo, notificationsList, getNotifications, notifications, rmInfo } = props;
  return (
    <Fragment>
      <div className="container-fluid pad-25-top" >
        <div className="request-container">
          <div className="request-status">
            <RequestStatus openRequests={openRequests} rmInfo={rmInfo}></RequestStatus>
            <RequestNotification notifications={notifications} notificationsList={notificationsList}></RequestNotification>
          </div>
          <div className="request-dash">
            <RequestDashboard ></RequestDashboard>
          </div>
          {/* <Row style={{ margin: "0px" }}>
          <Col>
            <Row sm={2} md={2} lg={2} xl={2}>
              <RequestStatus openRequests={openRequests} rmInfo={rmInfo}></RequestStatus>
            </Row>
            <Row sm={2} md={2} lg={2} xl={2} style={{ marginTop: "10px" }}>
              <RequestNotification notifications={notifications} notificationsList={notificationsList}></RequestNotification>
            </Row>
          </Col>
          <Col sm={10} md={10} lg={10} xl={10} class="remove-padding">
            <RequestDashboard ></RequestDashboard>
          </Col>
        </Row> */}
        </div>
      </div>
    </Fragment>
  );
};

const mapStateToProps = (state, ownProps) => ({
  openRequests: state.RequestStatusReducer.openRequest,
  notifications: state.RequestStatusReducer.notifications,
  notificationsList: state.RequestStatusReducer.notificationsList,
  rmInfo: state.RequestStatusReducer.rmInfo,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  getOpenRequest: (lanId) => dispatch(getOpenRequestThunk(lanId)),
  getNotifications: (lanId) => dispatch(getNotificationsThunk(lanId)),
  getNotificationsList: (lanId) => dispatch(getNotificationsListThunk(lanId)),
  getLoggedInRmInfo: (lanId) => dispatch(getLoggedInRmInfoThunk(lanId)),
  getProductsByProductLineId: (productLineId, callback) =>
        dispatch(getProductsByProductLineIdThunk(productLineId, callback)),
  getProductLine: (lanId) => dispatch(getProductLineThunk(lanId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestHome);

