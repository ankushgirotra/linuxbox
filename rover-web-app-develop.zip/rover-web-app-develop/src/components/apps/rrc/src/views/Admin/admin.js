import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Route, useRouteMatch, useHistory, Switch } from "react-router";
import { Container, Row, Col } from "react-bootstrap";
import {
  getEmailNotificationStatusThunk,
  getExternalBlockerThunk,
} from "./../../store/admin.reducer";

import { REQUEST_ROUTES } from "../../../../../app/Route/constants/requestRoutes.constants";
import { RequestAdminfilterListOptions as filterList } from "./../../constants/listOptions.constants";
import { OverlayLoader } from "../../../../pcdm/src/components/DataHandler/dataHandler";
import List from "../../../../pcdm/src/components/List/list";
import AdminExternalBlockers from "./AdminExternalBlockers/adminExternalBlockers";
import AdminEmailNotificationControl from "./AdminEmailNotification/adminEmailNotification";
import "./admin.scss";
import { getExternalBlockers } from "./../../store/requestDetailsData.reducer";

function Admin(props) {
  const {
    CHILDREN: {
      ADMIN: {
        ROUTE,
        CHILDREN: { EXTERNAL_BLOCKERS,
             EMAIL_NOTIFICATION },
      },
    },
  } = REQUEST_ROUTES;

  useEffect(() => {
    props.getExternalBlockers();
    props.getEmailNotification();
  }, []);

  const history = useHistory();

  let { url, path } = useRouteMatch();

  let currentAction = {};



  if (history.location.pathname.includes(`${EXTERNAL_BLOCKERS}`)) {
    currentAction = filterList[0];
  }
  if (history.location.pathname.includes(`${EMAIL_NOTIFICATION}`)) {
    currentAction = filterList[1];
  }

  const onFilterChange = (item) => {
    if (item.id === 1) {
      history.push(`${REQUEST_ROUTES.getExternalBlockersRoute()}`);
    } else if (item.id === 2) {
      history.push(`${REQUEST_ROUTES.getEmailNotificationRoute()}`);
    }
  };

  const getRequestsAdminRoutes = () => {
    return (
      <Switch>
        <Route exact path={REQUEST_ROUTES.getAdminRoute()}>
          <>
            <h4 className="pcdm-head">Please select any option</h4>
          </>
        </Route>
        <Route path={`${REQUEST_ROUTES.getExternalBlockersRoute()}`}>
          <AdminExternalBlockers />
        </Route>
        <Route path={`${REQUEST_ROUTES.getEmailNotificationRoute()}`}>
          <AdminEmailNotificationControl />
        </Route>
      </Switch>
    );
  };

  return (
    <div className="pcdm-admin-container" style={{ position: "relative" }}>
      <OverlayLoader />
      {currentAction.name ? (
        <h4 style={{ marginTop: "30px" }} className="pcdm-head center">
          {currentAction.name}
        </h4>
      ) : null}

      <Container fluid>
        <Row style={{ marginTop: "10px" }}>
          <Col sm={2} md={2} lg={2} xl={2}>
            <div className="pcdm-admin-filter-container">
              <List
                className={"pcdm-admin-filter-list"}
                list={[...filterList]}
                title={"Admin Actions"}
                onChange={onFilterChange}
                selected={currentAction}
                id="id"
                value="name"
                groupName="pcdm-admin-filter-list"
              />
            </div>
          </Col>
          <Col sm={10} md={10} lg={10} xl={10}>
            {getRequestsAdminRoutes()}
          </Col>
        </Row>
      </Container>
    </div>
  );
}

const mapStateToProps = (state) => ({});

const mapDispatchToProps = (dispatch) => ({
  getExternalBlockers: () => dispatch(getExternalBlockerThunk()),
  getEmailNotification: () => dispatch(getEmailNotificationStatusThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Admin);
