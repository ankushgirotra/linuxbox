import React, { Component } from "react";
import { connect } from "react-redux";
import { addExternalBlockersThunk, deleteExternalBlockersThunk } from "../../../store/admin.reducer";
import { validateAdminForm } from "../../../../../skillsCentral/src/Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { REQUEST_ADMIN_ACTIONS, ACTIONS } from './../../../constants/action.constants';
import { RequestVendorOptions as requestVendor } from "../../../constants/listOptions.constants";
import { DATA_STATUS } from "./../../../constants/action.constants";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import { DEFAULT_MSG_MODAL_CONFIG, MessageModal } from "../../../../../pcdm/src/components/MessageModal/messageModal";
import CustomButton, { BUTTON_VARIANTS } from './../../../../../pcdm/src/components/forms/Button/button';
import CustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../pcdm/src/components/forms/textField/textField";
import "../admin.scss"
import "./adminExternalBlockers.scss";
import { ADMIN_DELETE_VENDOR_POPUP_MSG } from "../../../../../skillsCentral/src/Constants/toolTip.messages";


const ADMIN_EXTERNAL_BLOCKERS_INITIAL_STATE = {
    messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
    formControls: {
        edited: false,
        error: false,
        errorMessage: "",
        errorDetail: "",
        description: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
        vendor: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
    },
};

class AdminExternalBlockersForm extends Component {
    constructor(props) {
        super(props);
        this.state = { ...ADMIN_EXTERNAL_BLOCKERS_INITIAL_STATE };
    }

    onInputChange = (event) => {

        const { formControls } = this.state;
        const name = event.target.name;
        const value = event.target.value;
    
        this.setState({
            formControls: {
                ...formControls,
                edited: true,
                error: false,
                [name]: {
                    ...formControls[name],
                    error: false,
                    value: value,
                },
            },
        });
    };

    getHeader = () => {
        const { formMode, formState } = this.props;
        if (formMode === REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS) {
            return "Add External Blockers";
        } else {
            return "Edit External Blockers";
        }
    };

    componentDidMount() {
        const { formMode, formState } = this.props;
        const { formControls } = this.state;
        let vendor = formState.vendor === true?1:2
        if (formMode === REQUEST_ADMIN_ACTIONS.EDIT_EXTERNAL_BLOCKERS) {
            this.setState({
                formControls: {
                    ...formControls,
                    edited: true,
                    error: false,
                    description: {
                        ...formControls.description,
                        error: false,
                        value: formState.externalBlockers,
                    },
                    vendor: {
                        ...formControls.vendor,
                        value: vendor,
                    }
                },
            });
        }
    }

    getAdminExternalBlockersForm = () => {
        const { formControls } = this.state;
        return (
            <form className="pcdm-form">
                <div className="pcdm-form__form-group">
                    <div className="pcdm-form__form-group-field">
                        <TextField
                            name="description"
                            label={"External Blockers"}
                            type="text"
                            formObj={formControls.description}
                            isRequired={formControls.description.required}
                            onChange={this.onInputChange}
                        />
                    </div>
                    <div className={`pcdm-form__form-group-field`}>
                        <CustomSelect
                            name="vendor"
                            label={"Vendor"}
                            formObj={formControls.vendor}
                            isRequired={formControls.vendor.required}
                            config={{
                                options: [...requestVendor],
                                id: "id",
                                value: "name",
                            }}
                            onChange={(e) =>
                                this.onInputChange({
                                    target: { name: e.name, value: e.value },
                                })}
                        />
                    </div>
                </div>
            </form>
        );
    };

    reqPayload = () => {
        const { formControls } = this.state;
        const { formMode, formState } = this.props;

        let vendor = false;

        if (formControls.vendor.value === 1) {
            vendor = true;
        }
        const id = formMode === REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS ? null : formState.id;

        let payload = {
            blocker_id: id,
            descr: formControls.description.value,
            is_vendor: vendor,
        };
        return payload;
    }

    onSubmit = async (e) => {
        if (e) {
            e.preventDefault();
        }
        const { formControls } = this.state;
        const { formMode, closeModal, addExternalBlockers, selectedVendor } = this.props;
        let validation = validateAdminForm(formControls);
        if (validation.error) {
            this.setState({ formControls: { ...validation } });
        } else {
            let payload = this.reqPayload();
            if (formMode === REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS) {
                await addExternalBlockers(payload, closeModal);
            }
            if (formMode === REQUEST_ADMIN_ACTIONS.EDIT_EXTERNAL_BLOCKERS) {
                await addExternalBlockers(payload, closeModal);
            }
        }
    };

    onDeleteClick = (e) => {
        if (e) {
            e.preventDefault();
        }
        const { formControls } = this.state;
        const { formState, closeModal, deleteExternalBlockers } = this.props;
        let validation = validateAdminForm(formControls);
        
        if (validation.error) {
            this.setState({ formControls: { ...validation } });
        } else {
            
            this.setState({
                messageModalConfig: {
                    ...DEFAULT_MSG_MODAL_CONFIG,
                    title: "Delete",
                    message: ADMIN_DELETE_VENDOR_POPUP_MSG(formState.externalBlockers),
                    visible: true,
                    onClose: this.handleDelete,
                },
            })
            
        }
    }

    handleDelete = async (button, data) => {
        const { messageModalConfig } = this.state;
        const { formState, closeModal, deleteExternalBlockers } = this.props;
        if (button === ACTIONS.YES) {
            let blockerId = formState.id;
            await deleteExternalBlockers(blockerId, closeModal);
            this.setState({
                messageModalConfig: {
                    ...messageModalConfig,
                    visible: false,
                },
            });
        } else {
            this.setState({
                messageModalConfig: {
                    ...messageModalConfig,
                    visible: false,
                },
            });
        }
    };

    getFooter = () => {
        const { formControls } = this.state;
        const { closeModal, formMode } = this.props;
        return (
            <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
                <CustomButton
                    variant={BUTTON_VARIANTS.PRIMARY}
                    size="md"
                    type={"submit"}
                    disable={!formControls.edited}
                    onClick={(e) => this.onSubmit(e)}
                >
                    {formMode === REQUEST_ADMIN_ACTIONS.ADD_EXTERNAL_BLOCKERS ? 'Save' : 'Update'}
                </CustomButton>
                {formMode === REQUEST_ADMIN_ACTIONS.EDIT_EXTERNAL_BLOCKERS ? (
                    <CustomButton
                        variant={BUTTON_VARIANTS.ERROR}
                        onClick={(e) => this.onDeleteClick(e)}
                        size="md"
                    >
                        Delete
                    </CustomButton>
                ) : <CustomButton
                    disable={false}
                    loading={false}
                    variant={BUTTON_VARIANTS.LIGHT}
                    onClick={() => closeModal()}
                    size="md"
                    type={"button"}
                >
                        Cancel
                </CustomButton>}
            </div>
        );
    }


    render() {
        const {
            formVisible,
            closeModal,
            addExternalBlockersStatus
        } = this.props;
        const { messageModalConfig } = this.state;
        return (
            <>
                <FormModal
                    className="sc-admin-manage_vendor-form"
                    visible={formVisible}
                    closeModal={() => closeModal()}
                    header={this.getHeader()}
                    content={() => this.getAdminExternalBlockersForm()}
                    footer={() => this.getFooter()}
                    isLoading={
                        addExternalBlockersStatus.status === DATA_STATUS.LOADING
                    }
                />
                <MessageModal {...messageModalConfig} />
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    addExternalBlockersStatus: state.RoverRequestAdmin.addExternalBlockersStatus,
    deleteExternalBlockersStatus: state.RoverRequestAdmin.deleteExternalBlockersStatus,
});

const mapDispatchToProps = (dispatch) => ({
    addExternalBlockers: (addExternalBlockersFormData, callback) =>
        dispatch(addExternalBlockersThunk(addExternalBlockersFormData, callback)),
    deleteExternalBlockers: (blockerId, callback) => 
        dispatch(deleteExternalBlockersThunk(blockerId, callback))
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminExternalBlockersForm);

