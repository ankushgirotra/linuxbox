import React, { Component, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Row, Col, Container, Form } from "react-bootstrap";
import Button from "../../../../../../../shared/components/forms/Button/button"
import Modal from "react-bootstrap/Modal";
import ModalHeader from "react-bootstrap/ModalHeader";
import "bootstrap/dist/css/bootstrap.min.css";
import "./reportExternalBlocker.scss";
import SelectDropdown from "../../../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../../../shared/components/forms/TextField/textField";
import { getRequestDetailsDataThunk, onReportExternalBlockersThunk } from "../../../../store/requestDetailsData.reducer";
import { getFormattedUserId } from '../../../../../../../../services/auth.services';
import { connect } from "react-redux";

const INITIAL_FORM_STATE = {
    formControls: {
        vendor: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        externalBlockerType: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        planToResolve: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disabled: false,
        },
    },
};

const ReportExternalBlocker = (props) => {
    const [externalBlockerState, setExternalBlockerState] = useState(INITIAL_FORM_STATE);
    const { RequestId, RequestStatus, vendor, externalBlockerType, userParams } = props;
    const [checked, setChecked] = useState(false)
    const [vendorDisabled, setVendorDisabled] = useState(false)
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated ? id : ''

    const onExternalBlockerModalClose = () => {
        setExternalBlockerState(INITIAL_FORM_STATE);
        setChecked(false);
        setVendorDisabled(false);
        props.onModalClose(true)
    }
    const onInputChange = (event) => {
        const { formControls } = externalBlockerState;
        const name = event.target.name;
        const value = event.target.value;
        if (name == "externalBlockerType") {
            setVendorDisabled(value!==""?externalBlockerType.find(x => x.blockerId == value).vendor:"");
            if (vendorDisabled) {
                externalBlockerState.formControls.vendor.value = "";
            }
        }
        setExternalBlockerState({
            ...externalBlockerState,
            formControls: {
                ...formControls,
                [name]: {
                    ...formControls[name],
                    errorMsg: '',
                    error: false,
                    value: value,
                },
            },
        });
    };

    useEffect(() => {
        let requestStatus = ""
        if (RequestStatus === 1) {
            requestStatus = "Identifying Resource";
        } else if (RequestStatus === 2) {
            requestStatus = "Resource Reserved";
        } else if (RequestStatus === 3) {
            requestStatus = "Completed";
        } else if (RequestStatus === 4) {
            requestStatus = "Cancelled";
        } else if (RequestStatus === 5) {
            requestStatus = "External Blocker";
        }
    }, [])

    const onSubmit = () => {
        const { formControls } = externalBlockerState;
        if (externalBlockerState.formControls.externalBlockerType.value === '') {
            setExternalBlockerState({
                ...externalBlockerState,
                formControls: {
                    ...formControls,
                    externalBlockerType: {
                        ...formControls.externalBlockerType,
                        error: true,
                        errorMsg: 'External blocker type field is required',
                    },
                },
            });
        }
        else if (vendorDisabled && externalBlockerState.formControls.vendor.value === '') {
            setExternalBlockerState({
                ...externalBlockerState,
                formControls: {
                    ...formControls,
                    vendor: {
                        ...formControls.vendor,
                        error: true,
                        errorMsg: 'Vendor field is required',
                    },
                },
            });
        }
        else if (externalBlockerState.formControls.planToResolve.value === '') {
            setExternalBlockerState({
                ...externalBlockerState,
                formControls: {
                    ...formControls,
                    planToResolve: {
                        ...formControls.planToResolve,
                        error: true,
                        errorMsg: 'Plan to resolve field is required',
                    },
                },
            });
        }
        else {
            const payload = {
                request_id: RequestId,
                blocker_id: externalBlockerState.formControls.externalBlockerType.value,
                vendor_id: externalBlockerState.formControls.vendor.value,
                plan_to_resolve: externalBlockerState.formControls.planToResolve.value
            }
            props.onReportExternalBlocker(payload, lanId, onSubmitSuccess);
        }
    }

    const onSubmitSuccess = (status, data) => {
        if (status === 'success') {
            props.updateReqIdDetails(lanId, RequestId );
            onExternalBlockerModalClose()
        }
    }

    const onCheckBoxClick = (e) => {
        setChecked(e.target.checked)
    }

    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            backdrop="static"
            keyboard={false}
            fullscreen={true | 'sm-down'}
        >
            <ModalHeader style={{ border: "none", fontSize: "22px !important" }}>
                <span className={"rrc-details-title"}>
                    <span id="title" style={{ color: "black", marginLeft: "25px" }}>
                        <b>Request ID  {RequestId && RequestId != null ? RequestId : "N/A"}   |</b> &nbsp; &nbsp;
                    </span>
                    <h4 style={{ color: "#3F66FB", marginTop: "10px", marginLeft: "-15px" }}>
                        {RequestStatus === "1" ? "Identifying Resource" :
                            RequestStatus === "2" ? "Resource Reserved" :
                                RequestStatus === "3" ? "Completed" :
                                    RequestStatus === "4" ? "Cancelled" :
                                        RequestStatus === "5" ? "External Blocker" : "N/A"}
                    </h4>
                </span>
                <div className="close-button" onClick={onExternalBlockerModalClose}>X</div>
            </ModalHeader>

            <div className="external-blocker-container" >
                <h5 className="external-blocker-title"><b>Report External Blocker</b></h5>

                <Form>
                    <Form.Row>
                        <div className="external-blocker-dropdown">
                            <SelectDropdown
                                name="externalBlockerType"
                                label="External Blocker Type"
                                formObj={externalBlockerState.formControls.externalBlockerType}
                                config={{
                                    options: [...externalBlockerType.length !== 0 ? externalBlockerType : externalBlockerType],
                                    id: "blockerId",
                                    value: "description",
                                }}
                                placeholder="Select External Blocker Type"
                                isRequired={externalBlockerState.formControls.externalBlockerType.required}
                                isClearable={true}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }

                            />

                        </div>
                        <div className="external-blocker-dropdown">
                            <div className={!vendorDisabled ? 'vendor-dropdown' : ''}>
                                <SelectDropdown
                                    name="vendor"
                                    label="Select Vendor"
                                    formObj={externalBlockerState.formControls.vendor}
                                    config={{
                                        options: [...vendor.length !== 0 ? vendor : vendor],
                                        id: "vendorid",
                                        value: "vendorname",
                                    }}
                                    placeholder="Select Vendor"
                                    isRequired={vendorDisabled}
                                    isClearable={true}
                                    onChange={(e) =>
                                        onInputChange({
                                            target: { name: e.name, value: e.value },
                                        })
                                    }


                                />
                            </div>
                        </div>
                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col} style={{ marginBottom: "0px" }}>
                            <div className="plan-to-resolve">
                                <TextField
                                    name="planToResolve"
                                    label="Plan To Resolve"
                                    formObj={externalBlockerState.formControls.planToResolve}
                                    isRequired={externalBlockerState.formControls.planToResolve.required}
                                    onChange={onInputChange}
                                />
                            </div>
                        </Form.Group>
                    </Form.Row>
                    <Form.Row>
                        <div className="checkbox">
                            <input onChange={(e) => onCheckBoxClick(e)} defaultChecked={checked} type="checkbox" style={{ marginTop: "20px", width: "18px", height: "18px" }} /><span className="confirmation-text">I understand that external blockers should only be reported if they are outside of the ADC's sphere of control and impede your ability to complete this request by the planned start date.</span>
                        </div>
                    </Form.Row>
                </Form>


            </div>
            <Row sm={2} md={2} lg={2} xl={2} className="pad-left" style={{ marginTop: "10px" }}>
                <div className={checked ? "submits-button" : "submits-button disable-btn"} style={{padding:"0px",paddingTop:"9px",textAlign:"center"}} onClick={checked ? onSubmit : ''}>
                    <p style={{ marginTop: "20px !important" }}>Submit</p>
                </div>
            </Row>

        </Modal>

    )
}

const mapStateToProps = (state, ownProps) => ({
    userParams: state.AuthReducer.user,
    loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
    onReportExternalBlocker: (payload, lanId, callback) => dispatch(onReportExternalBlockersThunk(payload, lanId, callback)),
    updateReqIdDetails: (reqId, lanId) =>
        dispatch(getRequestDetailsDataThunk(reqId, lanId)),

});

export default connect(mapStateToProps, mapDispatchToProps)(ReportExternalBlocker);
