import React, { useState, useEffect } from "react";
import { useHistory } from "react-router";
import { Row, Col, Form, Container } from "react-bootstrap";
import { connect } from "react-redux";
import moment from "moment";
import { getFormattedDate } from "../../services/requestForm.service";
import {
  getProductLineThunk,
  getProductsByProductLineIdThunk,
  getApplicationsByProductIdThunk,
  saveRequestThunk,
  getJobTitleThunk,
  getRequestDropdownValuesThunk,
  getRMListThunk,
  getSavedTemplatesThunk,
} from "../../../src/store/requestForm.reducer";
import SelectDropdown from "../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../shared/components/forms/TextField/textField";
import "./requestForm.scss";
import { validateRequestForm } from "../../services/requestForm.service";
import { FORM_DATE_FORMAT } from "../../constants/request.constans";
import Datepicker from "../../../../pcdm/src/components/Datepicker/datepicker";
import CustomSelect from "../../../../../shared/components/forms/MultiSelect/multiSelect";
import { REQUEST_ROUTES } from "../../../../../../components/app/Route/constants/requestRoutes.constants";
import { getRequestDetailsDataThunk } from "../../store";
import Button from "../../../../../shared/components/forms/Button/button";
import { getFormattedUserId } from "../../../../../../services/auth.services";
import TemplateForm from "./templateForm";
import { getEmployeeDetailsThunk } from "../../../../skillsCentral/src/store/users.reducer";

const INITIAL_FORM_STATE = {
  saveTemplateForm: false,
  formControls: {
    departmentId: "",
    assignedRM: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    selectTemplate: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
    productLine: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    product: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    application: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
    role: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    title: {
      value: "",
      options: [],
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
    allocationPercentage: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    plannedStartDate: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    plannedEndDate: {
      value: "",
      error: false,
      errorMsg: "",
      min: null,
      max: null,
      required: true,
      disabled: false,
    },
    technologies: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    location: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
    comments: {
      value: "",
      error: false,
      errorMsg: "",
      required: false,
      disable: false,
    },
  },
};

const dummyList = [
  {
    template: 1,
    templateName: "Temp 1",
  },
  {
    template: 2,
    templateName: "Temp 2",
  },
  {
    template: 3,
    templateName: "Temp 3",
  },
];

const RequestForm = (props) => {
  const [requestFormState, setRequestFormState] = useState(INITIAL_FORM_STATE);
  const [showAllocationError, setShowAllocationError] = useState(false);
  const { rmList } = props;
  const [symbolsArray] = useState(["e", "-", "+", "-", "E", "."]);

  useEffect(() => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated
      ? id
      : "";
    getEmployeeDetails(lanId, setDepartmentId);
    getDropdownValues(lanId);
    getJobTitle(lanId);
    getProductLine(lanId);
    getRMList(lanId);
    getSavedTemplates(lanId);
  }, []);

  const setDepartmentId = (empDetails) => {
    // console.log(empDetails);
    const { formControls } = requestFormState;
    if (Object.keys(empDetails).length) {
      setRequestFormState(
        {
          formControls: {
            ...formControls,
            departmentId: empDetails.deptId,
            error: false,
            assignedRM: {
              ...formControls.assignedRM,
              error: false,
              value: empDetails.employeeId,
            },
          },
        }
        // console.log(empDetails.deptId)
      );
    }
  };

  useEffect(() => {
    populateAssignedRmField();
  }, [rmList]);

  useEffect(() => {}, [props.saveRequestStatus]);

  const {
    getEmployeeDetails,
    getDropdownValues,
    getProductsByProductLineId,
    getApplicationsByProductId,
    getJobTitle,
    getProductLine,
    getRMList,
    dropdownValues,
    productsByProductLineId,
    applicationsByProductId,
    userParams,
    loggedInUser,
    getSavedTemplates,
    savedTemplates,
  } = props;

  const history = useHistory();

  useEffect(() => {
    const { formControls } = requestFormState;
    // console.log("updating", formControls.departmentId);
  }, [requestFormState]);

  const populateAssignedRmField = () => {
    const { formControls } = requestFormState;
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated
      ? id
      : "";
    const idExistInRmList = rmList.find((rmList) => rmList.rmId == lanId);
    if (idExistInRmList) {
      setRequestFormState({
        formControls: {
          ...formControls,
          error: false,
          assignedRM: {
            ...formControls.assignedRM,
            error: false,
            value: lanId,
          },
        },
      });
    }
  };

  const onHandleRequestSubmission = (assignedRm) => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated
      ? id
      : "";
    if (assignedRm === lanId) {
      // if(props.saveRequestStatus.status==="SUCCESS"){
      history.push({
        pathname: `${REQUEST_ROUTES.ROUTE}${REQUEST_ROUTES.CHILDREN.ROUTE1}`,
      });
      // }
      // else{
      //     alert("Something Went wrong")
      // }
    } else {
      history.push({
        pathname: `${REQUEST_ROUTES.ROUTE}`,
      });
    }
  };
  const {
    finalLocations: location,
    finalProductsLine: productLine,
    finalRolUn: role,
    finalSkills: technologie,
    finalRoles: jobTitle,
  } = dropdownValues;

  const onProductLineChange = async (selectedProductLine) => {
    await getProductsByProductLineId(selectedProductLine);
    //         await getApplicationsByProductId();
  };

  const onProductChange = async (selectedProduct) => {
    await getApplicationsByProductId(selectedProduct);
  };

  const onRoleChange = (event) => {
    const { jobtitle } = props;
    const { formControls } = requestFormState;
    const value = event.target.value;
    let titleList = [];

    titleList = [...jobtitle.filter((jobtitle) => jobtitle.roleid === value)];

    setRequestFormState({
      formControls: {
        ...formControls,
        error: false,
        role: {
          ...formControls.role,
          error: false,
          value: value,
        },
        title: {
          ...formControls.title,
          error: false,
          options: [...titleList],
          value: "",
        },
      },
    });
  };

  const onSelectTemplate = async (event) => {
    const { formControls } = requestFormState;
    const { jobtitle } = props;
    let selectedTemplate = "";
    let technoList = [];
    let titleList = [];
    if (event.label == "" && event.value == "") {
      //   setRequestFormState({
      //     formControls: {
      //       ...INITIAL_FORM_STATE.formControls,
      //     },
      //   });
    } else {
      selectedTemplate = savedTemplates.filter((el) => el.id == event.value)[0];
      if (selectedTemplate && selectedTemplate.productLineId)
        onProductLineChange(selectedTemplate.productLineId);
      if (selectedTemplate && selectedTemplate.productId)
        onProductChange(selectedTemplate.productId);
      if (selectedTemplate && selectedTemplate.technologies) {
        let techList =
          selectedTemplate.technologies !== null &&
          selectedTemplate.technologies !== undefined
            ? selectedTemplate.technologies.split(",")
            : "";
        let tL = techList.length;
        if (dropdownValues.finalSkills !== undefined) {
          for (let i = 0; i < tL; i++) {
            for (let j = 0; j < dropdownValues.finalSkills.length; j++) {
              if (techList[i] == dropdownValues.finalSkills[j].id) {
                technoList.push({
                  value: dropdownValues.finalSkills[j].id,
                  label: dropdownValues.finalSkills[j].skillName,
                });
                break;
              }
            }
          }
        }
      }
      if (selectedTemplate && selectedTemplate.roleId) {
        titleList = [
          ...jobtitle.filter(
            (jobtitle) => jobtitle.roleid === selectedTemplate.roleId
          ),
        ];
      }
    }
    setRequestFormState({
      formControls: {
        ...formControls,
        error: false,
        selectTemplate: {
          ...formControls["selectTemplate"],
          error: false,
          value: event.value,
        },
        productLine: {
          ...formControls["productLine"],
          value: selectedTemplate ? selectedTemplate.productLineId : "",
          error: false,
        },
        product: {
          ...formControls["product"],
          value: selectedTemplate ? selectedTemplate.productId : "",
          error: false,
        },
        application: {
          ...formControls["application"],
          value: selectedTemplate ? selectedTemplate.applicationCode : "",
          error: false,
        },
        role: {
          ...formControls["role"],
          value: selectedTemplate ? selectedTemplate.roleId : "",
          error: false,
        },
        allocationPercentage: {
          ...formControls["allocationPercentage"],
          value: selectedTemplate ? selectedTemplate.allocation ? selectedTemplate.allocation : "" : "",
          error: false,
        },
        technologies: {
          ...formControls["technologies"],
          value: technoList,
          error: false,
        },
        title: {
          ...formControls["title"],
          error: false,
          options: [...titleList],
          value: "",
        },
      },
    });
  };

  const onInputChange = (event) => {
    const { formControls } = requestFormState;
    // console.log(event);
    const name = event.target.name;
    const value = event.target.value;
    // console.log(formControls.departmentId);

    if (name === "productLine") {
      setRequestFormState({
        formControls: {
          ...formControls,
          error: false,
          productLine: {
            ...formControls.productLine,
            error: false,
            value: value,
          },
          product: {
            ...formControls.product,
            error: false,
            value: "",
          },
          application: {
            ...formControls.application,
            error: false,
            value: "",
          },
        },
      });
      onProductLineChange(value);
    } else if (name === "product") {
      setRequestFormState({
        formControls: {
          ...formControls,
          error: false,
          product: {
            ...formControls.product,
            error: false,
            value: value,
          },
          application: {
            ...formControls.application,
            error: false,
            value: "",
          },
        },
      });
      onProductChange(value);
    } else if (name === "assignedRM") {
      getEmployeeDetails(value, setDepartmentId);
    } else {
      setRequestFormState({
        formControls: {
          ...formControls,
          error: false,
          [name]: {
            ...formControls[name],
            error: false,
            value: value,
          },
        },
      });
    }
  };

  const onAllocationChange = (event) => {
    setShowAllocationError(false);
    const { formControls } = requestFormState;
    const name = event.target.name;
    let allocationPercentage = event.target.value;
    const pattern = /\b([0-9]|[1-9][0-9]|100)\b/;
    const newValue = pattern.test(allocationPercentage);
    if (allocationPercentage === "" || pattern.test(allocationPercentage)) {
      setRequestFormState({
        formControls: {
          ...formControls,
          error: false,
          [name]: {
            ...formControls[name],
            error: false,
            value: allocationPercentage,
          },
        },
      });
    }
    if (!newValue) {
      return;
    }
  };

  const manageMonthSelection = (type, date) => {
    let value = moment(date, FORM_DATE_FORMAT);
    const { formControls } = requestFormState;
    if (type === "plannedStartDate") {
      let ed = formControls.plannedEndDate.value,
        ed_disable = formControls.plannedEndDate.disabled,
        ed_min = value.add(1, "day").format(FORM_DATE_FORMAT);
      if (value.isValid() && !formControls.plannedEndDate.value) {
        /* If start month is selected and end month is empty enable end month and update its min */
        ed_disable = false;
      } else if (
        formControls.plannedEndDate.value &&
        value.isAfter(
          moment(formControls.plannedEndDate.value, FORM_DATE_FORMAT)
        )
      ) {
        /* If start month is after selected end month , then reset the end month and its min */
        ed = "";
        ed_disable = false;
      }
      setRequestFormState({
        formControls: {
          ...formControls,
          isEdited: true,
          plannedStartDate: {
            ...formControls.plannedStartDate,
            value: date,
            error: false,
          },
          plannedEndDate: {
            ...formControls.plannedEndDate,
            value: ed,
            disabled: ed_disable,
            min: new Date(getFormattedDate(ed_min)),
          },
        },
      });
    } else if (type === "plannedEndDate") {
      setRequestFormState({
        formControls: {
          ...formControls,
          isEdited: true,
          plannedStartDate: {
            ...formControls.plannedStartDate,
            error: false,
          },
          plannedEndDate: {
            ...formControls.plannedEndDate,
            value: date,
            error: false,
          },
        },
      });
    }
  };

  const reqPayload = () => {
    const { formControls } = requestFormState;
    const {
      productsByProductLineId,
      applicationsByProductId,
      productLine,
    } = props;

    let productOptions = productsByProductLineId.data;
    let applicationOptions = applicationsByProductId.data;
    let technologies = [...formControls.technologies.value];
    let technologyList = [];
    let locations = [...formControls.location.value];
    let locationsList = [];
    let roleId = "";
    let beltId = "";
    let jobTitleId = "";

    if (formControls.title.value === "") {
      if (formControls.role.value === "Developer 2.0") {
        roleId = "AD0026";
      } else if (formControls.role.value === "Developer") {
        roleId = "AD0026";
      } else if (formControls.role.value === "Development Lead") {
        roleId = 4;
      } else if (formControls.role.value === "Systems Analyst") {
        roleId = "AD0030";
      } else if (formControls.role.value === "Scrum Master") {
        roleId = "AD0034";
      } else if (formControls.role.value === "Tooling Analyst") {
        roleId = "DO0018";
      } else if (formControls.role.value === "Non-ADC Role") {
        roleId = 16;
      } else if (formControls.role.value === "Business Analyst") {
        roleId = "PG0449";
      } else if (formControls.role.value === "DevOps Engineer") {
        roleId = 20;
      } else if (formControls.role.value === "Test Analyst") {
        roleId = 23;
      } else if (formControls.role.value === "Test Manager") {
        roleId = "QA0015";
      } else if (formControls.role.value === "Test Engineer") {
        roleId = "QA0007";
      } else if (formControls.role.value === "Test Architect") {
        roleId = "QA0012";
      } else if (formControls.role.value === "Quality Test Analyst") {
        roleId = 30;
      }
    } else {
      roleId = formControls.title.value;
    }

    if (formControls.title.value === "") {
      roleId = formControls.role.value;
    } else {
      roleId = formControls.role.value;
      beltId = formControls.title.value;
      jobTitleId = formControls.title.value;
    }

    for (let i = 0; i < technologies.length; i++) {
      technologyList.push({
        id: technologies[i].value,
        skillName: technologies[i].label,
      });
    }

    for (let i = 0; i < locations.length; i++) {
      locationsList.push({
        id: locations[i].value,
        stateDesc: locations[i].label,
      });
    }

    let reqComment = formControls.comments.value;

    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated
      ? id
      : "";

    let payload = {
      assignedRmId: formControls.assignedRM.value,
      createdRmId: lanId,
      productLineName:
        productLine.find(
          (el) => el.productlineid === formControls.productLine.value
        ).productlinename || "",
      productLineId: formControls.productLine.value,
      productName:
        productOptions.find((el) => el.id === formControls.product.value)
          .productName || "",
      productId: formControls.product.value,
      roleId: roleId,
      beltId: beltId,
      jobTitleId: jobTitleId,
      allocation: formControls.allocationPercentage.value,
      plannedStart: moment(formControls.plannedStartDate.value).format(
        "YYYY-MM-DD"
      ),
      endDate: moment(formControls.plannedEndDate.value).format("YYYY-MM-DD"),
      departmentId: formControls.departmentId,
      locationIds: locationsList,
      technologies: technologyList,
      comment: reqComment,
    };
    if (
      formControls.application.value &&
      formControls.application.value != ""
    ) {
      payload = {
        ...payload,
        applicationName:
          applicationOptions.length > 0
            ? applicationOptions.find(
                (el) => el.id === formControls.application.value
              ).applicationName || ""
            : "",
        applicationId: formControls.application.value,
      };
    } else {
      payload = {
        ...payload,
        applicationName: "",
        applicationId: "",
      };
    }

    return payload;
  };

  const callRequestId = async (status, response) => {
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated
      ? id
      : "";
    let requestId = response && response.request_id;
    localStorage.setItem("selectedRequestId", requestId);
    let assignedRm = requestFormState.formControls.assignedRM.value;
    await props.updateReqIdDetails(lanId, requestId );
    if (status === "SAVE_REQUEST_SUCCESS") {
      onHandleRequestSubmission(assignedRm);
    } else {
      alert("Something Went Wrong");
    }
  };

  const onSubmit = async (e) => {
    const { saveRequestStatus } = props;
    e.preventDefault();

    // let payload = reqPayload();
    // saveRequest(payload);

    let requestFormPostValidation = validateRequestForm(
      requestFormState.formControls
    );

    if (requestFormPostValidation.error) {
      setRequestFormState({ formControls: { ...requestFormPostValidation } });
    } else {
      let payload = reqPayload();
      await props.saveRequest(payload, callRequestId);
      // props.openrequestForm();
      // onHandleRequestSubmission(assignedRm);
    }
  };

  const onSaveTemplate = () => {
    const { formControls } = requestFormState;
    if (parseInt(formControls.allocationPercentage.value) < 1) {
      setShowAllocationError(true);
    } else {
      setRequestFormState({
        ...requestFormState,
        saveTemplateForm: true,
      });
    }
  };

  const onCloseTemplate = () => {
    setRequestFormState({
      ...requestFormState,
      saveTemplateForm: false,
    });
  };

  return (
    <Container>
      {productLine ? (
        <div className="rrc-request-background">
          <Form onSubmit={onSubmit}>
            <Form.Row>
              <Form.Group as={Col} lg={4}>
                <SelectDropdown
                  name="assignedRM"
                  label="Assigned RM"
                  formObj={requestFormState.formControls.assignedRM}
                  isRequired={requestFormState.formControls.assignedRM.required}
                  config={{
                    options: [...rmList],
                    id: "rmId",
                    value: "fullName",
                  }}
                  onChange={(e) => {
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    });
                  }}
                  placeholder=""
                />
              </Form.Group>
              <Form.Group as={Col} lg={4}>
                <SelectDropdown
                  name="selectTemplate"
                  label="Select Template"
                  formObj={requestFormState.formControls.selectTemplate}
                  config={{
                    options: [...savedTemplates],
                    id: "id",
                    value: "templateName",
                  }}
                  isRequired={
                    requestFormState.formControls.selectTemplate.required
                  }
                  isClearable={true}
                  onChange={(e) => {
                    onSelectTemplate(e);
                  }}
                  placeholder=""
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col}>
                <SelectDropdown
                  name="productLine"
                  label="Product Line"
                  formObj={requestFormState.formControls.productLine}
                  isRequired={
                    requestFormState.formControls.productLine.required
                  }
                  config={{
                    options: [...productLine],
                    id: "productlineid",
                    value: "productlinename",
                  }}
                  onChange={(e) => {
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    });
                  }}
                  placeholder=""
                />
              </Form.Group>
              <Form.Group as={Col}>
                <SelectDropdown
                  name="product"
                  label="Product"
                  formObj={requestFormState.formControls.product}
                  isRequired={requestFormState.formControls.product.required}
                  //config={options}
                  config={{
                    options: [...productsByProductLineId.data],
                    id: "id",
                    value: "productName",
                  }}
                  onChange={(e) =>
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    })
                  }
                  placeholder=""
                />
              </Form.Group>
              <Form.Group as={Col}>
                <SelectDropdown
                  name="application"
                  label="Application"
                  formObj={requestFormState.formControls.application}
                  isRequired={
                    requestFormState.formControls.application.required
                  }
                  config={{
                    options: [...applicationsByProductId.data],
                    id: "id",
                    value: "applicationName",
                  }}
                  isClearable={true}
                  placeholder={"Select an option"}
                  onChange={(e) =>
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    })
                  }
                  placeholder=""
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col}>
                <SelectDropdown
                  name="role"
                  label="Role"
                  formObj={requestFormState.formControls.role}
                  isRequired={requestFormState.formControls.role.required}
                  config={{
                    options: role && role.length ? [...role] : [],
                    id: "roleId",
                    value: "roleDesc",
                  }}
                  onChange={(e) =>
                    onRoleChange({
                      target: { name: e.name, value: e.value },
                    })
                  }
                  placeholder=""
                />
              </Form.Group>
              <Form.Group as={Col}>
                <SelectDropdown
                  name="title"
                  label="Belt"
                  formObj={requestFormState.formControls.title}
                  isRequired={requestFormState.formControls.title.required}
                  isClearable={true}
                  config={{
                    options: [...requestFormState.formControls.title.options],
                    id: "id",
                    value: "jobTitle",
                  }}
                  onChange={(e) =>
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    })
                  }
                  imgSrc={"../../../../../../../src/assets/images/belts"}
                  placeholder=""
                />
              </Form.Group>
              <Form.Group as={Col}>
                <TextField
                  name="allocationPercentage"
                  label="Allocation %"
                  type="number"
                  min="0"
                  formObj={requestFormState.formControls.allocationPercentage}
                  isRequired={
                    requestFormState.formControls.allocationPercentage.required
                  }
                  className={"percentText"}
                  onChange={onAllocationChange}
                  onKeyDown={(e) =>
                    symbolsArray.includes(e.key) && e.preventDefault()
                  }
                />
                {showAllocationError &&
                requestFormState.formControls.allocationPercentage.errorMsg ==
                  "" ? (
                  <p style={{ color: "#de350b", fontSize: "12px" }}>
                    Please enter a value greater than 0
                  </p>
                ) : (
                  ""
                )}
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group
                as={Col}
                style={{ padding: "10px 10px 10px 8px" }}
                className="rrc-request-calendar"
              >
                <Datepicker
                  name="plannedStartDate"
                  label="Planned Start"
                  formObj={requestFormState.formControls.plannedStartDate}
                  onChange={manageMonthSelection}
                  dateFormat={FORM_DATE_FORMAT}
                  className={"request-datepicker"}
                  isRequestDatePicker={true}
                  placeholderText=""
                />
              </Form.Group>
              <Form.Group
                as={Col}
                style={{ padding: "10px 10px 10px 2px" }}
                className="rrc-request-calendar"
              >
                <Datepicker
                  name="plannedEndDate"
                  label="Planned End"
                  formObj={requestFormState.formControls.plannedEndDate}
                  onChange={manageMonthSelection}
                  dateFormat={FORM_DATE_FORMAT}
                  className={"request-datepicker"}
                  isRequestDatePicker={true}
                  placeholderText=""
                />
              </Form.Group>
              <Form.Group as={Col} style={{ marginTop: "11px" }}>
                <CustomSelect
                  name="technologies"
                  label="Technologies"
                  formObj={requestFormState.formControls.technologies}
                  isRequired={
                    requestFormState.formControls.technologies.required
                  }
                  isMulti={true}
                  config={{
                    options: [...technologie],
                    id: "id",
                    value: "skillName",
                  }}
                  onChange={(e) =>
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    })
                  }
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} style={{ marginTop: "11px" }}>
                <CustomSelect
                  name="location"
                  label="Location"
                  formObj={requestFormState.formControls.location}
                  isRequired={requestFormState.formControls.location.required}
                  isMulti={true}
                  config={{
                    options: [...location],
                    id: "id",
                    value: "stateDesc",
                  }}
                  onChange={(e) =>
                    onInputChange({
                      target: { name: e.name, value: e.value },
                    })
                  }
                />
              </Form.Group>
              <Form.Group as={Col} style={{ paddingRight: "1px" }}>
                <TextField
                  name="comments"
                  label="Comments"
                  formObj={requestFormState.formControls.comments}
                  isRequired={requestFormState.formControls.comments.required}
                  onChange={onInputChange}
                />
              </Form.Group>
              <Form.Group as={Col}></Form.Group>
            </Form.Row>
            <Row>
              <Col>
                <span style={{ alignItems: "inline" }}>
                  <div className="submit-request-button">
                    <Button onClick={onSubmit}>
                      <span className="mr-1">Submit</span>
                    </Button>
                  </div>
                  <div className="cancel-request-button-form">
                    <Button onClick={onSaveTemplate}>
                      <span className="mr-1">Save Template</span>
                    </Button>
                  </div>
                </span>

                {/* <div className="rcc-buttons">
                                <button className="rcc-buttons-submit">Submit</button>
                            </div> */}
              </Col>
            </Row>
          </Form>
        </div>
      ) : (
        ""
      )}
      {requestFormState.saveTemplateForm ? (
        <TemplateForm
          show={requestFormState.saveTemplateForm}
          onHide={onCloseTemplate}
          currentState={requestFormState}
          savedTemplates={savedTemplates}
        />
      ) : (
        ""
      )}
    </Container>
  );
};

const mapStateToProps = (state, ownProps) => ({
  productLine: state.RequestResourceReducer.productLine,
  dropdownValues: state.RequestResourceReducer.dropdownValues,
  jobtitle: state.RequestResourceReducer.jobtitle,
  productsByProductLineId: state.RequestResourceReducer.productsByProductLineId,
  applicationsByProductId: state.RequestResourceReducer.applicationsByProductId,
  saveRequestStatus: state.RequestResourceReducer.saveRequestStatus,
  rmList: state.RequestResourceReducer.rmList,
  savedTemplates: state.RequestResourceReducer.savedTemplates,
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
});

const mapDispatchToProps = (dispatch) => ({
  getEmployeeDetails: (empID, callback) =>
    dispatch(getEmployeeDetailsThunk(empID, callback)),
  getProductLine: (lanId) => dispatch(getProductLineThunk(lanId)),
  getDropdownValues: (lanId) => dispatch(getRequestDropdownValuesThunk(lanId)),
  getProductsByProductLineId: (productLineId, callback) =>
    dispatch(getProductsByProductLineIdThunk(productLineId, callback)),
  getApplicationsByProductId: (productId, callback) =>
    dispatch(getApplicationsByProductIdThunk(productId, callback)),
  saveRequest: (requestForm, callback) =>
    dispatch(saveRequestThunk(requestForm, callback)),
  updateReqIdDetails: (requestId, lanId) =>
    dispatch(getRequestDetailsDataThunk(requestId, lanId)),
  getJobTitle: (lanId) => dispatch(getJobTitleThunk(lanId)),
  getRMList: (lanId) => dispatch(getRMListThunk(lanId)),
  getSavedTemplates: (lanId) => dispatch(getSavedTemplatesThunk(lanId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestForm);
