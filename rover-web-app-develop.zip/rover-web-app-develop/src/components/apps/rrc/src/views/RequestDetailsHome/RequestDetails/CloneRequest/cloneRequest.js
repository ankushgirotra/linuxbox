import React, { useState } from 'react';
import { useHistory } from "react-router";
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import ModalFooter from "react-bootstrap/ModalFooter";
import "./cloneRequest.scss";
import TextField from '../../../../../../../shared/components/forms/TextField/textField';
import { validateRequestForm } from '../../../../services/requestForm.service';
import { REQUEST_ROUTES } from '../../../../../../../app/Route/constants/requestRoutes.constants';

const INITIAL_STATE = {
  formControls: {
    error: false,
    numberOfClones: {
      value: "",
      error: false,
      errorMsg: "",
      required: true,
      disable: false,
    },
    showConfirmation: false,
  }
}

export function CloneRequests(props) {
  const {
    rmId,
    show,
    onHide,
    requestDetails,
    addClones,
    otherRmId,
  } = props;

  const [cloneRequestState, setCloneRequestState] = useState(INITIAL_STATE);

  const history = useHistory();

  const cloneRequestHeadClass = {
    borderBottom: "none"
  }

  const cloneRequestBodyClass = {
    backgroundColor: "#F5F6FA",
    margin: "0px 10px 0px 10px",
    width: "95%",
    borderRadius: "6px",
  }

  const cloneRequestFootClass = {
    borderTop: "none",
    display: "flex",
    alignItems: "center",

  }

  const reqPayload = () => {
    const { formControls } = cloneRequestState;
    let payload = {
      rmId:rmId,
      numberOfClones: formControls.numberOfClones.value,
      requestId: requestDetails.request_id,
      otherRmId: otherRmId,
    }
    return payload;
  }

  const onAllocationChange = (event) => {
    const { formControls } = cloneRequestState;
    const name = event.target.name;
    let numberOfClones = event.target.value
    const pattern = /\b(0?[1-9]|1[0-9]|2[0-5])\b/;
    const newValue = pattern.test(numberOfClones);
    if (numberOfClones === '' || pattern.test(numberOfClones)) {
      setCloneRequestState({
        formControls: {
          ...formControls,
          error: false,
          [name]: {
            ...formControls[name],
            error: false,
            value: numberOfClones,
          },
        },
      });
    }
    if (!newValue) {
      return
    }
  }

  const onCloneClick = () => {
    const { formControls } = cloneRequestState;
    {
      let payload = reqPayload();
      // console.log(payload)
      addClones(payload,after);  
      setCloneRequestState({
        formControls: {
          ...formControls,
          showConfirmation: false
        }
      });
      onHide();
      history.push({
        pathname: `${REQUEST_ROUTES.ROUTE}`,
      });
    }
  }

  const after = (data) => {
    
  }

  const onCorfirmationClick = () => {
    const { formControls } = cloneRequestState
    let cloneRequestValidate = validateRequestForm(formControls);

    if (cloneRequestValidate.error) {
      setCloneRequestState({ formControls: { ...cloneRequestValidate } });
    } else {
      setCloneRequestState({
        formControls: {
          ...formControls,
          showConfirmation: true
        }
      })
    }
  }

  const confirmationHide = () => {
    const { formControls } = cloneRequestState
    setCloneRequestState({
      formControls: {
        ...formControls,
        showConfirmation: false
      }
    })
  }

  return (
    <div className="clone-request_container">
      <Modal
        show={show}
        onHide={onHide}
        className="clone-request_modal"
      >
        <ModalHeader
          style={cloneRequestHeadClass}
        >
          <h3>Clone Request</h3>
        </ModalHeader>
        <ModalBody
          style={cloneRequestBodyClass}
        >
          <p style={{ color: "red" }}>Note: Maximum of 25 clones can be created at once.</p>
          <TextField
            name="numberOfClones"
            label="Number of Clones"
            formObj={cloneRequestState.formControls.numberOfClones}
            isRequired={cloneRequestState.formControls.numberOfClones.required}
            min="0"
            onChange={onAllocationChange}
            type="number"
          />
        </ModalBody>
        <ModalFooter
          style={cloneRequestFootClass}
        >
          <div>
            <button id="clone-cancel-button" onClick={onHide}>Cancel</button>
          </div>
          <div>
            <button id="clone-ok-button" onClick={onCorfirmationClick}>Clone</button>
          </div>
        </ModalFooter>
      </Modal>
      {/* Confirmation Modal */}
      <Modal
        show={cloneRequestState.formControls.showConfirmation}
        onHide={confirmationHide}
        size={"sm"}
        backdrop={"static"}
        style={{ marginTop: "15px" }}
      >
        <ModalHeader>
          <h4>Confirmation</h4>
        </ModalHeader>
        <ModalBody>
          <p><b>{cloneRequestState.formControls.numberOfClones.value} clone{cloneRequestState.formControls.numberOfClones.value > 1 ? "s " : " "}</b>
            will be created for <b>Request ID {requestDetails.request_id}</b></p>
          <p>Do you want to continue?</p>
        </ModalBody>
        <ModalFooter>
          <div>
            <button id="goback-btn" onClick={confirmationHide}>Go back</button>
          </div>
          <div>
            <button id="clone-ok-button" onClick={onCloneClick}>Confirm</button>
          </div>
        </ModalFooter>
      </Modal>
    </div>
  )
}