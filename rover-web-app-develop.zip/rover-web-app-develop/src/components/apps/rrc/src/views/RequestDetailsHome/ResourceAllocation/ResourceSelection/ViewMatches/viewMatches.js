import React, { useState, useEffect } from 'react';
import { Row, Col } from "react-bootstrap";
import Modal from "react-bootstrap/Modal";
import ModalHeader from "react-bootstrap/ModalHeader";
import "bootstrap/dist/css/bootstrap.min.css";
import "./viewMatches.scss";
import SkillsCentralProfile from '../../skillsCentralProfile';
import { getRmEmailAndVendorThunk, getMatchProfilesThunk, getTotalMatchesCountThunk, searchMatchingProfilesThunk, searchMatchingProfilesCountThunk } from "../../../../../store";
import { connect } from "react-redux";
import { getEmployeeDetailsThunk } from "../../../../../../../skillsCentral/src/store/users.reducer";
import { getFormattedUserId } from "../../../../../../../../../services/auth.services";
import InfiniteScroll from 'react-infinite-scroll-component';

const ViewMatches = (props) => {
    const { getMatchProfiles, getTotalMatchesCount, totalMatchesCount, matchProfiles, peopleMatches, searchMatchingProfiles, searchMatchingProfile, userParams } = props;
    const [selectResourceId, setSelectedResID] = useState(null);
    const [selectResourceName, setSelectedResName] = useState(null);
    const [showSkillCentral, setShowSkillCentral] = useState(true);
    const [peopleList, setpeopleList] = useState(peopleMatches);
    const [searchPeopleList, setSearchPeopleList] = useState([]);
    const [searchResult, setSearchResult] = useState(false);
    const [isSearch, setIsSearch] = useState(false);
    const [loadMore, setLoadMore] = useState(true);
    const [page, setPage] = useState(2);
    const [searchPage, setSearchPage] = useState(2);
    const [searchTerm, setSearchTerm] = useState(null)

    const onModalClose = () => {
        props.onModalClose(false);
        setpeopleList([])
        getMatchProfiles(localStorage.getItem('selectedRequestId'), lanId, 0)
        setSelectedResID(null)
        setSelectedResName(null)
        // props.getRmEmailAndVendor(peopleList[0] && peopleList[0].employee_id);
        setSearchResult(null);
        setPage(2);
        setSearchPage(2);
        setSearchPeopleList([])
        setIsSearch(false)
    }
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated ? id : '';
    const skillMatchPercentage = "100";

    useEffect(() => {
        getTotalMatchesCount(localStorage.getItem('selectedRequestId'), lanId)
    }, []);

    useEffect(() => {
        if (!isSearch) {
            if(peopleList[0]) {
            setSelectedResID(peopleList[0] && peopleList[0].employee_id)
            setSelectedResName(peopleList[0] && peopleList[0].full_name)
            // props.getRmEmailAndVendor(peopleList[0] && peopleList[0].employee_id);
            props.getInternalResourceDetails(peopleList[0] && peopleList[0].employee_id);
            }
            getTotalMatchesCount(localStorage.getItem('selectedRequestId'), lanId)
        }
        if (searchPeopleList.length <= 0) {
            setLoadMore(true)
        }
        if (searchPage > 2) {
            setSearchPeopleList([...searchPeopleList, ...searchMatchingProfile])
        } else {
            setSearchPeopleList(searchMatchingProfile)
        }
        // if (searchTerm && searchPeopleList && searchPeopleList.length > 0 && !selectResourceId  || !setSelectedResName) {
        //     setSelectedResID(searchPeopleList[0] && searchPeopleList[0].employee_id)
        //     setSelectedResName(searchPeopleList[0] && searchPeopleList[0].full_name)
        //     props.getRmEmailAndVendor(searchPeopleList[0] && searchPeopleList[0].employee_id);
        //     props.getInternalResourceDetails(searchPeopleList[0].employee_id);
        // } else 
        if (searchTerm){
            setSelectedResID(searchMatchingProfile[0] && searchMatchingProfile[0].employee_id)
            setSelectedResName(searchMatchingProfile[0] && searchMatchingProfile[0].full_name)
            // props.getRmEmailAndVendor(searchMatchingProfile[0] && searchMatchingProfile[0].employee_id);
            props.getInternalResourceDetails(searchMatchingProfile[0] && searchMatchingProfile[0].employee_id);
        }
    }, [searchMatchingProfile, isSearch,searchTerm]);

    useEffect(() => {
        setSearchPeopleList([]);
        if (peopleList.length <= 0) {
            setLoadMore(true)
        }
        setpeopleList([...peopleList, ...matchProfiles])
        if (peopleList && peopleList.length > 0 && !selectResourceId || !setSelectedResName) {
            setSelectedResID(peopleList[0] && peopleList[0].employee_id)
            setSelectedResName(peopleList[0] && peopleList[0].full_name)
            // props.getRmEmailAndVendor(peopleList[0] && peopleList[0].employee_id);
        } else if (!selectResourceId || !setSelectedResName ){
            setSelectedResID(matchProfiles[0] && matchProfiles[0].employee_id)
            setSelectedResName(matchProfiles[0] && matchProfiles[0].full_name)
            // props.getRmEmailAndVendor(matchProfiles[0] && matchProfiles[0].employee_id);
        }
    }, [matchProfiles]);

    const onResourceSelected = (employeeDetails, index) => {
        setSelectedResID(employeeDetails.employee_id);
        setSelectedResName(employeeDetails.full_name);
        // props.getRmEmailAndVendor(employeeDetails.employee_id);
        props.getInternalResourceDetails(employeeDetails.employee_id);
    }

    const onSearch = (searchTerm) => {
        if (searchTerm.target.value !== '') {
            setSelectedResID(null);
            setSelectedResName(null)
            setSearchPage(2);
            setIsSearch(true)
            const payload = {
                requestId: Number(localStorage.getItem('selectedRequestId')),
                rmId: lanId,
                pageNo: 1,
                pageCount: 10,
                searchWord: searchTerm.target.value
            }
            props.searchMatchingProfiles(payload);
            const payload2 = {
                requestId: Number(localStorage.getItem('selectedRequestId')),
                rmId: lanId,
                searchWord: searchTerm.target.value
            }
            props.searchMatchingCount(payload2)
        setSearchTerm(searchTerm.target.value);
            
        } else {
            getTotalMatchesCount(localStorage.getItem('selectedRequestId'), lanId)
            setIsSearch(false)
            setSearchTerm(null)
            setSelectedResID(null)
            setSelectedResName(null)
        }
    }

    const fetchData = () => {
        if (peopleList.length > 0 && !isSearch) {
            getMatchProfiles(localStorage.getItem('selectedRequestId'), lanId, page)
            if (matchProfiles.length <= 0) {
                setLoadMore(false)
            }
            setPage(page + 1)
        }
        if (searchPeopleList.length > 0 && isSearch) {
            setSearchPage(searchPage + 1)
            const payload = {
                requestId: Number(localStorage.getItem('selectedRequestId')),
                rmId: lanId,
                pageNo: searchPage,
                pageCount: 10,
                searchWord: searchTerm
            }
            props.searchMatchingProfiles(payload);
            if (searchMatchingProfile.length <= 0) {
                setLoadMore(false)
            }
        }
    }

    const renderFunc = (employeeDetails, index) => {
        return (
            <div >
                {employeeDetails.employee_id == selectResourceId ? <div className="rrc-request-details-blueBar" style={{ float: "left", height: "66px", position: "relative", zIndex: "1" }}></div> : ""}
                <div className={employeeDetails.employee_id == selectResourceId ? `resourceselected` : `resourcenotselected`} onClick={() => onResourceSelected(employeeDetails, index)}>
                    <div>
                        <p style={{ color: "#191C1D", fontSize: "13px" }}>
                            {employeeDetails.full_name}
                        </p>
                    </div>
                    {/* <div>
                    <div style={{float:"left",width:"25%",color:"#8686A2",fontSize:"11px"}}>Skill Match</div>
                    <div style={{float:"right",width:"75%",color:"#555579",fontSize:"11px"}}>:  <ProgressBar now={skillMatchPercentage}/><span style={{color:"#191C1D",fontSize:"11px",marginLeft:"3px"}}>{`${skillMatchPercentage}%`}</span></div>

                    </div> */}
                    <div>
                        <p style={{ width: "25%", float: "left", color: "#8686A2", fontSize: "11px" }}>
                            Job title
                        </p>
                        <p style={{ color: "#555579", fontSize: "11px" }}>
                            : {employeeDetails.job_role ? employeeDetails.job_role : "N/A"}
                        </p>
                    </div>
                    <div>
                        <p style={{ width: "25%", float: "left", color: "#8686A2", fontSize: "11px" }}>
                            RM
                        </p>
                        <p style={{ color: "#555579", fontSize: "11px" }}>
                            : {employeeDetails.manager_name ? employeeDetails.manager_name : "N/A"}
                        </p>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <Modal
            {...props}
            size={(searchPeopleList.length > 0 || peopleList.length > 0) ? "xl" : "lg"}
            aria-labelledby="contained-modal-title-vcenter"
            centered
            backdrop="static"
            keyboard={false}
        >
            <ModalHeader style={{ border: "none" }}>
                <Modal.Title id="contained-modal-title-vcenter" style={{ marginLeft: "10px" }}>
                    <div style={{ color: "#1A1A1C", fontSize: "20px" }}> Request ID - {localStorage.getItem("selectedRequestId")} | Resource Matches</div>
                    {/* {peopleList.length > 0? <p style={{fontSize:"14px",color:"#8686A2"}}>{peopleList.length} Resource Matches</p>:""} */}
                    <p style={{ fontSize: "14px", color: "#8686A2" }}>
                        {searchResult ? searchResult.length : totalMatchesCount} Resource Matches</p>
                </Modal.Title>
                <div className="close-button" style={{ marginTop: "5px" }} onClick={onModalClose}>X</div>
            </ModalHeader>
            
            <div className="view-matches" style={{ minHeight:"300px",width: "96%", borderRadius: "6px", marginLeft: "2%", marginRight: "2%", marginBottom: "20px" }}>
                <Row>
                    <Col sm={3} lg={3} xl={3} xs={3} style={{ maxHeight: "500px", paddingRight: "0px" }}>
                        <Row>
                            <Col sm={12} lg={12} xl={12} xs={12}>
                                <input type="text" class="icon-rtl" placeholder="Search Resource Name" onChange={(e) => onSearch(e)} />
                            </Col></Row>
                        <div className={"rrc-matches-list"} id="scrollableDiv" style={{ marginTop: "15px" }}>
                            <InfiniteScroll
                                dataLength={searchPeopleList.length ? searchPeopleList.length : peopleList.length}
                                next={fetchData}
                                hasMore={loadMore}
                                // loader={<p>Loading...</p>}
                                endMessage={<p></p>}
                                scrollableTarget="scrollableDiv"
                            >
                                <table>
                                    <tbody>
                                        {/* {setIsSearch && } */}
                                        {!isSearch && peopleList.length === 0 ? <span style={{ paddingLeft: "20px" }}>No Matches Found</span> : ''}
                                        {isSearch && searchPeopleList.length === 0 ? <span style={{ paddingLeft: "20px" }}>No Matches Found</span> : ''}

                                        {/* {searchResult !== null ? searchResult.map(renderFunc) : peopleList.map(renderFunc)}} */}
                                        {isSearch && searchPeopleList.map(renderFunc)}
                                        {!isSearch && peopleList.map(renderFunc)}
                                    </tbody>
                                </table>

                            </InfiniteScroll>
                        </div>

                    </Col>{peopleList.length != 0 && showSkillCentral ?
                        <Col sm={9} lg={9} xl={9} xs={9} style={{ borderLeft: "1px solid #E8E8ED" }}>
                            <SkillsCentralProfile internalResource={props.employeeDetails} rmEmailAndVendor={props.getRmEmail} selectResourceName={selectResourceName} productManager={props.productManager} mailRecipients={props.mailRecipients} selectedResID={selectResourceId} showContent={false} hide={onModalClose}

                            />
                        </Col> : ""}
                </Row>

            </div>
        </Modal>

    )
}

const mapStateToProps = (state, ownProps) => {
    return {
        userParams: state.AuthReducer.user,
        loggedInUser: state.AuthReducer,
        getRmEmail: state.RequestDetailsDataReducer.getRmEmailAndVendor,
        employeeDetails: state.SCUsersReducer.employeeDetails,
        matchProfiles: state.RequestDetailsDataReducer.matchProfiles,
        searchMatchingProfile: state.RequestDetailsDataReducer.searchMatchingProfiless,
        totalMatchesCount: state.RequestDetailsDataReducer.totalMatchesCount,
    };
};

const mapDispatchToProps = (dispatch) => ({
    getRmEmailAndVendor: (empId) =>
        dispatch(getRmEmailAndVendorThunk(empId)),
    getInternalResourceDetails: (empID) => dispatch(getEmployeeDetailsThunk(empID)),
    getMatchProfiles: (reqId, lanId, pageNum) => dispatch(getMatchProfilesThunk(reqId, lanId, pageNum)),
    getTotalMatchesCount: (reqId, lanId) => dispatch(getTotalMatchesCountThunk(reqId, lanId)),
    searchMatchingProfiles: (payload) => dispatch(searchMatchingProfilesThunk(payload)),
    searchMatchingCount: (payload) => dispatch(searchMatchingProfilesCountThunk(payload)),

});

export default connect(mapStateToProps, mapDispatchToProps)(ViewMatches);