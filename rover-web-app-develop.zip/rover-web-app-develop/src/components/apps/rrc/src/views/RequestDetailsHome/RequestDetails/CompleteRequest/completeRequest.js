import React, { useState, useEffect, useRef } from "react";
import { connect } from "react-redux";
import { Check } from "react-feather";
import { Row, Col, Form } from "react-bootstrap";
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import Button from "../../../../../../../shared/components/forms/Button/button";
import {
  updateCompleteStatusThunk,
  getRequestDetailsDataThunk,
  getBflexWorkOrderThunk,
  updateCompleteRequestExternalThunk,
} from "../../../../store/requestDetailsData.reducer";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import { FORM_CONTROL_DEFAULT } from "../../../../../../pcdm/src/constants/form.constants";
import TextField from "../../../../../../../shared/components/forms/TextField/textField";
import WorkOrderSearchTable from "./WorkOrderSearchTable/workOrderSearchTable";
import "bootstrap/dist/css/bootstrap.min.css";
import "./completeRequest.scss";

const INITIAL_FORM_STATE = {
    formControls: {
        workOrderId: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        zycusId: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        sogId: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        name: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: true,
        },
        vendor: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: true,
        },
        country: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: true,
        }
    },
};

const CompleteRequest = (props) => {
    const [completeRequestState, setcompleteRequestState] = useState(INITIAL_FORM_STATE);
    const dropdownContainer = useRef();
    const [isDropdownOpen, setDropdownOpen] = useState(false);
    const { RequestId, RequestStatus, ResourceType, userParams, onHide, updateCompleteRequestExternal, updateCompleteStatus, bflexWorkOrder, getBflexWorkOrder, updateCompleteRequestExternalThunk } = props;
    const [checked, setChecked] = useState(false)
    let empId = localStorage.getItem('emplyoee_id')
    let id = empId ? empId : getFormattedUserId(userParams);
    const lanId = props.loggedInUser.isAuthenticated ? id : ''

    useEffect(() => {
        getBflexWorkOrder();
    }, []);

    const onCompleteRequestModalClose = () => {
        const { formControls } = completeRequestState;
        setChecked(false)
        props.onModalClose(true)
        setcompleteRequestState(INITIAL_FORM_STATE);
    }

    const onSubmit = () => {
        if (ResourceType == "Internal") {
            updateCompleteStatus(RequestId);
        }
        if (ResourceType == "External") {
            const payload = {
                requestId: RequestId,
                workOrderId: completeRequestState.formControls.workOrderId.value,
                zycusId: completeRequestState.formControls.zycusId.value,
                sogId: completeRequestState.formControls.sogId.value
            }
            updateCompleteRequestExternal(payload)
        }
        onCompleteRequestModalClose();
        props.updateReqIdDetails(lanId, RequestId);
    }

    const onInputChangeEvent = (event) => {
        const { formControls } = completeRequestState;
        const name = event.target.name;
        const value = event.target.value;
    
        setcompleteRequestState({
          formControls: {
            ...formControls,
            error: false,
            [name]: {
              ...formControls[name],
              error: false,
              value: value,
            },
          },
        });
    };

    const onInputChange = (name, value) => {
        setChecked(false)
        const { formControls } = completeRequestState;
        const requestDetail = bflexWorkOrder.filter(x => x.workOrderId === value)[0]
        if (value.length > 0) {
            setcompleteRequestState({
                ...completeRequestState,
                formControls: {
                    ...formControls,
                    [name]: {
                        ...formControls[name],
                        errorMsg: '',
                        error: false,
                        value: value,
                    },
                    name: {
                        ...formControls.name,
                        errorMsg: '',
                        error: false,
                        value: requestDetail.fullName,
                    },
                    vendor: {
                        ...formControls.vendor,
                        errorMsg: '',
                        error: false,
                        value: requestDetail.vendorName,
                    },
                    country: {
                        ...formControls.country,
                        errorMsg: '',
                        error: false,
                        value: requestDetail.country,
                    },
                },
            });
        } else {
            setcompleteRequestState({
                ...completeRequestState,
                formControls: {
                    ...formControls,
                    [name]: {
                        ...formControls[name],
                        errorMsg: '',
                        error: false,
                        value: value,
                    }
                }
            });
        }
    }

    const onWorkOrderSelect = (selectedVal) => {
        if (selectedVal === "outsideClick") {
            setDropdownOpen(false)
        } else {
            onInputChange("workOrderId", selectedVal)
            setDropdownOpen(false)
        }
    }


    return (
        <Modal
            // {...props}
            show={props.show}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            // centered
            backdrop="static"
            keyboard={false}
            dialogClassName = "complete_request-modal"
        >
            <ModalHeader style={{ border: "none", fontSize: "22px !important" }}>
                <span className={"rrc-details-title"}>
                    <span id="title" style={{ color: "black", marginLeft: "20px" }}>
                        <b>Complete Request - Request ID {RequestId && RequestId != null ? RequestId : "N/A"}   |</b> &nbsp; &nbsp;
                    </span>
                    <h4 style={{ color: "#3F66FB", marginTop: "10px", marginLeft: "-15px" }}>
                        {RequestStatus === "1" ? "Identifying Resource" :
                            RequestStatus === "2" ? "Resource Reserved" :
                                RequestStatus === "3" ? "Completed" :
                                    RequestStatus === "4" ? "Cancelled" :
                                        RequestStatus === "5" ? "External Blocker" : "N/A"}
                    </h4>
                </span>
                <div className="close-button" onClick={onCompleteRequestModalClose}>X</div>
            </ModalHeader>
            <div style={{ backgroundColor: "#F5F6FA", marginTop: "7px", width: "95%", borderRadius: "6px", marginLeft: "18px" }}>
                <ModalBody style={{ border: "none", paddingTop: "5px" }}>
                    {ResourceType == "Internal" || ResourceType == "Internal" ?
                        <Row>
                            <Col style={{ marginTop: "15px" }}>
                                <input onChange={() => setChecked(!checked)} defaultChecked={checked} type="checkbox" /><span style={{ display: "flex", marginLeft: "25px", justifyContent: "center", textAlign: "left", marginTop: "-23px", color: "gray" }}>I understand that completing this request means that this resource has been properly allocated in Spark and is ready to join the new team.</span>
                            </Col>
                        </Row> :
                        <>
                            <Row>
                                <Col style={{ paddingRight: "3px" }}>
                                    <Form>
                                        <Form.Row>
                                            <Form.Group as={Col} lg={4} >
                                                <div className="workorder-dropdown-container">
                                                    <label style={{ marginTop: "10px" }}>BFlex Work Order</label>
                                                    <div onClick={() => setDropdownOpen(!isDropdownOpen)} className="input-box" ref={dropdownContainer}>
                                                        <div className="selected-value">
                                                            {completeRequestState.formControls.workOrderId.value ?
                                                                <span className="value_N_clear_icon">
                                                                    <span className="value"> {completeRequestState.formControls.workOrderId.value} </span>
                                                                    <span onClick={(e) => {
                                                                        e.stopPropagation()
                                                                        onWorkOrderSelect("")
                                                                    }} className="clear-icon">
                                                                        <i className="fa fa-times" style={{ color: "#9394ad", marginRight: "8px", height: "12px", marginTop: "2px" }}></i>
                                                                    </span> </span>
                                                                : <span className="placeholder"> Select Work Order Id </span>}
                                                            <span onClick={() => setDropdownOpen(!isDropdownOpen)} ><i className="fa fa-caret-down" style={{ color: "#9394ad", height: "12px" }}></i></span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </Form.Group>
                                            <Form.Group as={Col}  lg={4}>
                                                <TextField
                                                    name="zycusId"
                                                    label="Zycus ID"
                                                    formObj={completeRequestState.formControls.zycusId}
                                                    onChange={ onInputChangeEvent}         
                                                />
                                            </Form.Group>
                                            <Form.Group as={Col}  lg={4} >
                                                <TextField
                                                    name="sogId"
                                                    label="SOG ID"
                                                    formObj={completeRequestState.formControls.sogId}
                                                    onChange={ onInputChangeEvent} 
                                                />
                                            </Form.Group>
                                        </Form.Row>
                                        {isDropdownOpen &&
                                            <WorkOrderSearchTable
                                                bflexWorkOrder={bflexWorkOrder}
                                                onWorkOrderSelect={onWorkOrderSelect}
                                                parentContainer={dropdownContainer}
                                            />}
                                    </Form>
                                </Col>
                                {completeRequestState.formControls.workOrderId.value !== '' && <><Col sm={12} md={12} lg={12} xl={12}>
                                    <Form>
                                        <Form.Row>
                                            <Form.Group as={Col}>
                                                <TextField
                                                    name="allocationPercentage"
                                                    label="Name"
                                                    formObj=""
                                                    className={"percentText"}
                                                    formObj={completeRequestState.formControls.name}
                                                />
                                            </Form.Group>
                                            <Form.Group as={Col}>
                                                <TextField
                                                    name="allocationPercentage"
                                                    label="Vendor"
                                                    formObj={completeRequestState.formControls.vendor}
                                                    className={"percentText"}
                                                />
                                            </Form.Group>
                                            <Form.Group as={Col}>
                                                <TextField
                                                    name="allocationPercentage"
                                                    label="Country"
                                                    formObj={completeRequestState.formControls.country}
                                                    className={"percentText"}
                                                />
                                            </Form.Group>
                                        </Form.Row>
                                    </Form>
                                </Col>
                                    {/* <Col sm={8} md={8} lg={8} xl={8} ></Col> */}
                                    <Col sm={12} md={12} lg={12} xl={12} className="complete_req-checkbox">
                                        <input onChange={() => setChecked(!checked)} type="checkbox" checked={checked} /><span style={{ color: "gray" }}>
                                            I understand that completing this request means that this resource is onboarded and ready to join their new team.</span>
                                    </Col></>}
                            </Row>
                        </>}
                </ModalBody>
            </div>

            <Row sm={2} md={2} lg={2} xl={2} className={checked && !isDropdownOpen  ? "pad-left complete-request-button" : "pad-left complete-request-button complete-button-disabled"} style={{ margin: "10px", width: "auto" }}>
                <Button onClick={checked ? onSubmit : null}>
                    <span style={{ border: "1px solid #fff", borderRadius: "50px" }}>
                        <Check size="14" strokeWidth="2" /></span>
                    <span className='mr-1'>Complete Request</span>
                </Button>
            </Row>
        </Modal>
    );
}

const mapStateToProps = (state, ownProps) => ({
  userParams: state.AuthReducer.user,
  loggedInUser: state.AuthReducer,
  bflexWorkOrder: state.RequestDetailsDataReducer.bflexWorkOrder,
});

const mapDispatchToProps = (dispatch) => ({
  updateCompleteStatus: (reqId) => dispatch(updateCompleteStatusThunk(reqId)),
  updateCompleteRequestExternal: (payload, callback) => dispatch(updateCompleteRequestExternalThunk(payload, callback)),
  updateReqIdDetails: (id, lanId) => dispatch(getRequestDetailsDataThunk(id, lanId)),
  getBflexWorkOrder: () => dispatch(getBflexWorkOrderThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(CompleteRequest);