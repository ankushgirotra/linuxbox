import csv from 'csv';
import roverURL from '../../../../../apis/rover_api';
import CSV from 'csv-string';

export const sanitizeColumnTitles = (expectedTitles, csvColumnTitles) => {
  const sanitizedColumns = [];
  let found;
  for (let columnIndex = 0; columnIndex < csvColumnTitles.length; columnIndex++) {
    found = false;
    for (let titleIndex = 0; titleIndex < expectedTitles.length; titleIndex++) {
      if (csvColumnTitles[columnIndex].replace(/[^A-Z\\(/):&]/gi, '') === (expectedTitles[titleIndex])) {
        sanitizedColumns.push(expectedTitles[titleIndex]);
        found = true;
        break;
      }
    }
    if (!found) {
      sanitizedColumns.push(csvColumnTitles[columnIndex].replace(/[^A-Z\\(/):&]/gi, ''));
    }
  }
  return sanitizedColumns;
};

export const convertCsvFileToJson = (file) => {
  const reader = new FileReader();
  return new Promise((resolve, reject) => {
    reader.onerror = () => {
      reader.abort();
      reject(new DOMException('There was an error parsing input file.'));
    };
    reader.onload = () => {
      csv.parse(reader.result, {
        delimiter: CSV.detect(reader.result)
      }, async (err, data) => {
        const columnTitles = data[0];
        let sanitizedTitles;
        let controlledTitles;
        let portfolioPayload;
        let productPayload;
        let applicationPayload;
        let skillsPayload;
        data.shift();
        switch (file.dataType) {
          case 'Portfolio':
            controlledTitles = ['PortfolioID', 'PortfolioName'];
            sanitizedTitles = sanitizeColumnTitles(controlledTitles, columnTitles);
            portfolioPayload = { portfolios: [] };
            data.forEach(item => {
              const payload = {};
              payload.id = item[sanitizedTitles.indexOf(controlledTitles[0])];
              payload.name = item[sanitizedTitles.indexOf(controlledTitles[1])];
              portfolioPayload.portfolios.push(payload);
            });
            resolve(portfolioPayload);
            break;
          case 'Product':
            controlledTitles = ['ID', 'Product', 'Active', 'OpenForTime', 'Description', 'Manager', 'Portfolio'];
            sanitizedTitles = sanitizeColumnTitles(controlledTitles, columnTitles);
            productPayload = { products: [] };
            data.forEach(item => {
              const payload = {};
              payload.id = item[sanitizedTitles.indexOf(controlledTitles[0])];
              payload.name = item[sanitizedTitles.indexOf(controlledTitles[1])];
              payload.isActive = item[sanitizedTitles.indexOf(controlledTitles[2])] === 'Yes';
              payload.openForTime = item[sanitizedTitles.indexOf(controlledTitles[3])] === 'Yes';
              payload.description = item[sanitizedTitles.indexOf(controlledTitles[4])];
              payload.managerName = item[sanitizedTitles.indexOf(controlledTitles[5])];
              payload.portfolioName = item[sanitizedTitles.indexOf(controlledTitles[6])];
              productPayload.products.push(payload);
            });
            resolve(productPayload);
            break;
          case 'Application':
            controlledTitles = ['ID', 'Application', 'ApplicationType', 'Active', 'OpenforTime', 'Portfolio', 'PortfolioOwner', 'Product', 'ProductID', 'Application/ProductManager', 'Application/ProductManager(Alternate)', 'CurrentStatus'];
            sanitizedTitles = sanitizeColumnTitles(controlledTitles, columnTitles);
            applicationPayload = { applications: [] };
            data.forEach((item) => {
              const payload = {};
              payload.id = item[sanitizedTitles.indexOf(controlledTitles[0])];
              payload.name = item[sanitizedTitles.indexOf(controlledTitles[1])];
              payload.type = item[sanitizedTitles.indexOf(controlledTitles[2])];
              payload.isActive = item[sanitizedTitles.indexOf(controlledTitles[3])] === 'Yes';
              payload.openForTime = item[sanitizedTitles.indexOf(controlledTitles[4])] === 'Yes';
              payload.portfolioName = item[sanitizedTitles.indexOf(controlledTitles[5])];
              payload.portfolioOwner = item[sanitizedTitles.indexOf(controlledTitles[6])];
              payload.productName = item[sanitizedTitles.indexOf(controlledTitles[7])];
              payload.productId = item[sanitizedTitles.indexOf(controlledTitles[8])];
              payload.managerName = item[sanitizedTitles.indexOf(controlledTitles[9])];
              payload.managerNameAlternate = item[sanitizedTitles.indexOf(controlledTitles[10])];
              payload.currentStatus = item[sanitizedTitles.indexOf(controlledTitles[11])];
              applicationPayload.applications.push(payload);
            });
            resolve(applicationPayload);
            break;
          case 'Skill':
            skillsPayload = { skills: [] };
            controlledTitles = ['SkillID', 'SkillName', 'SkillCategory', 'SkillsDescription', 'SpecializedSkills', 'MainTechnology', 'Created', 'CreatedBy',
              'Modified', 'ModifiedBy', 'ProfileName', 'ProfileName:ProfileID', 'Active'];
            sanitizedTitles = sanitizeColumnTitles(controlledTitles, columnTitles);
            data.forEach(item => {
              const payload = {};
              payload.skillId = item[sanitizedTitles.indexOf(controlledTitles[0])];
              payload.skillName = item[sanitizedTitles.indexOf(controlledTitles[1])];
              payload.skillCategory = item[sanitizedTitles.indexOf(controlledTitles[2])];
              payload.skillsDescription = item[sanitizedTitles.indexOf(controlledTitles[3])];
              payload.specializedSkills = item[sanitizedTitles.indexOf(controlledTitles[4])] === 'Yes';
              payload.mainTechnology = item[sanitizedTitles.indexOf(controlledTitles[5])] === 'Yes';
              payload.created = item[sanitizedTitles.indexOf(controlledTitles[6])];
              payload.createdBy = item[sanitizedTitles.indexOf(controlledTitles[7])];
              payload.modified = item[sanitizedTitles.indexOf(controlledTitles[8])];
              payload.modifiedBy = item[sanitizedTitles.indexOf(controlledTitles[9])];
              payload.profileName = item[sanitizedTitles.indexOf(controlledTitles[10])];
              payload.profileId = item[sanitizedTitles.indexOf(controlledTitles[11])];
              payload.active = item[sanitizedTitles.indexOf(controlledTitles[12])] === 'Yes';
              skillsPayload.skills.push(payload);
            });
            resolve(skillsPayload);
            break;
          default:
            break;
        }
      });
    };
    reader.readAsBinaryString(file);
  });
};

export const uploadDataThunk = file => async () => {
  let requestPayload = {};
  try {
    requestPayload = await convertCsvFileToJson(file);
  } catch (e) {
    console.warn(e.message);
  }
  try {
    const version = '/v1';
    let requestPath = '';
    switch (file.dataType) {
      case 'Portfolio':
        requestPath = '/uploadPortfolios';
        break;
      case 'Product':
        requestPath = '/uploadProducts';
        break;
      case 'Application':
        requestPath = '/uploadApplications';
        break;
      case 'Skill':
        requestPath = '/uploadSkills';
        break;
      default:
        break;
    }
    await roverURL.post(version + requestPath, requestPayload);
  } catch (error) {
    console.error(error);
  }
};

// REDUCERS
const UploadReducer = (state = []) => state;

export default UploadReducer;
