import ResourcesReducer from './ResourcesRRC';
import FieldsReducer from './FieldsRRC';
import UploadReducer from './UploadRRC';
import RequestResourceReducer from './requestForm.reducer';
import RequestDraftsReducer from './RequestDraftsRRC';
import RequestTemplatesReducer from './RequestTemplatesRRC';
import RequestStatusReducer from './requestStatus.reducer';
import RequestDashboardReducer from './requestDashboard.reducer';
import RequestDetailsDataReducer from './requestDetailsData.reducer';
import CustomFilterReducer from './customFilter.reducer';
import CancelRequestReducer from "./cancelRequest.reducer";
import RoverRequestAdmin from './admin.reducer';
import RequestsCommonReducer from './common.reducer';

const RRCreducer = {
  ResourcesReducer,
  FieldsReducer,
  UploadReducer,
  RequestResourceReducer,
  RequestDraftsReducer,
  RequestTemplatesReducer,
  RequestStatusReducer,
  RequestDashboardReducer,
  RequestDetailsDataReducer,
  CustomFilterReducer,
  CancelRequestReducer,
  RoverRequestAdmin,
  RequestsCommonReducer,
};

export * from './ResourcesRRC';
export * from './FieldsRRC';
export * from './UploadRRC';
export * from './requestForm.reducer';
export * from './requestStatus.reducer';
export * from './RequestDraftsRRC';
export * from './RequestTemplatesRRC';
export * from './requestDashboard.reducer';
export * from './requestDetailsData.reducer';
export * from './customFilter.reducer';
export * from './cancelRequest.reducer';
export * from './admin.reducer';
export default RRCreducer;
