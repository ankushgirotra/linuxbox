/* Request Form Dropdown URL */
import requestURL from "../../../../../apis/request_api";

/* Request Form Action Types */
export const GET_REQUEST_FORM_DROPDOWN_VALUES = "GET_REQUEST_FORM_VALUES";
export const GET_PRODUCTS_BY_PRODUCT_LINE_ID =
  "GET_PRODUCTS_BY_PRODUCT_LINE_ID";
export const GET_APPLICATIONS_BY_PRODUCT_ID = "GET_APPLICATIONS_BY_PRODUCT_ID";
export const SAVE_REQUEST_SUCCESS = "SAVE_REQUEST_SUCCESS";
export const GET_JOB_TITLE = "GET_JOB_TITLE";
export const GET_PRODUCT_LINE = "GET_PRODUCT_LINE";
export const GET_RM_LIST = "GET_RM_LIST";
export const SAVE_TEMPLATE = "SAVE_TEMPLATE";
export const GET_TEMPLATE = "GET_TEMPLATE";
export const CHECK_TEMPLATE= "CHECK_TEMPLATE";
export const UPDATE_TEMPLATE= "UPDATE_TEMPLATE";

/* Request Form Action Creators */
export const getReqeuestFormDropdownValues = (dropdownValues) => ({
  type: GET_REQUEST_FORM_DROPDOWN_VALUES,
  dropdownValues,
});

export const getProductsByProductLineId = (productsByProductLineId) => ({
  type: GET_PRODUCTS_BY_PRODUCT_LINE_ID,
  productsByProductLineId,
});

export const getApplicationsByProductId = (applicationsByProductId) => ({
  type: GET_APPLICATIONS_BY_PRODUCT_ID,
  applicationsByProductId,
});

export const saveRequest = (saveRequest) => ({
  type: SAVE_REQUEST_SUCCESS,
  saveRequest,
});

export const saveTemplate = (saveTemplate) => ({
  type: SAVE_TEMPLATE,
  saveTemplate,
});

export const getTemplates = (templates) => ({
  type: GET_TEMPLATE,
  templates,
});

export const checkTemplate = (checkTemplate) => ({
  type: CHECK_TEMPLATE,
  checkTemplate,
});
export const updateTemplate = (updateTemplate) => ({
  type: UPDATE_TEMPLATE,
  updateTemplate,
});

export const getJobTitle = (jobtitle) => ({
  type: GET_JOB_TITLE,
  jobtitle,
});

export const getProductLine = (productLine) => ({
  type: GET_PRODUCT_LINE,
  productLine,
});

export const getRMList = (rmList) => ({
  type: GET_RM_LIST,
  rmList,
});

/* Request Form Thunks */
export const getRequestDropdownValuesThunk = (lanId) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/${lanId}`);
    dispatch(getReqeuestFormDropdownValues(data[0]));
  } catch (error) {
    console.error(error);
  }
};

export const getProductsByProductLineIdThunk = (
  productLineId,
  callback
) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/prodLine/${productLineId}`);
    if (callback) {
      callback(GET_PRODUCTS_BY_PRODUCT_LINE_ID);
    }
    dispatch(getProductsByProductLineId(data));
  } catch (error) {
    console.error(error);
  }
};

export const getApplicationsByProductIdThunk = (productId, callback) => async (
  dispatch
) => {
  try {
    const { data } = await requestURL.get(
      `request/prodLine/product/${productId}`
    );
    if (callback) {
      callback(GET_APPLICATIONS_BY_PRODUCT_ID);
    }
    dispatch(getApplicationsByProductId(data));
  } catch (error) {
    console.error(error);
  }
};

export const saveRequestThunk = (payload, callback) => async (dispatch) => {
  try {
    const { data } = await requestURL.post("request/addRequests", payload);
    if (callback) {
      callback(SAVE_REQUEST_SUCCESS, data);
    }
    dispatch(saveRequest(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback("Failed", []);
    }
  }
};

export const saveTemplateThunk = (payload, callback) => async (dispatch) => {
  try {
    const { data } = await requestURL.post(
      "request/saveRequestTemplate",
      payload
    );
    if (callback) {
      callback(SAVE_TEMPLATE, data);
    }
    dispatch(saveTemplate(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback("Failed", []);
    }
  }
};

export const getSavedTemplatesThunk = (lanId) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(
      `request/${lanId}/getSavedTemplates`
    );
    dispatch(getTemplates(data));
  } catch (error) {
    console.error(error);
  }
};

export const checkTemplateThunk = (lanId, templateName, callback) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(
      `request/${lanId}/${templateName}/getTemplateNames`
    );
    if (callback) {
      callback("Success", data);
    }
    dispatch(checkTemplate(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback("Failed", "No Data Exist");
    }
  }
};

export const updateTemplateThunk = (templateId, payload, callback) => async (dispatch) => {
  try {
    const { data } = await requestURL.put(
      `request/${templateId}/editRequestTemplate`,
      payload
    );
    if (callback) {
      callback("Success", data);
    }
    dispatch(updateTemplate(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback("Failed", []);
    }
  }
};


export const getJobTitleThunk = (lanId) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/${lanId}`);
    dispatch(getJobTitle(data[0].finalRoles));
  } catch (error) {
    console.error(error);
  }
};

export const getProductLineThunk = (lanId) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/${lanId}`);
    dispatch(getProductLine(data[0].finalProductsLine));
  } catch (error) {
    console.error(error);
  }
};

export const getRMListThunk = (lanId) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/RMList/${lanId}`);
    dispatch(getRMList(data));
  } catch (error) {
    console.error(error);
  }
};

/* Request Form Initial State */
const initialState = {
  dropdownValues: {},
  productsByProductLineId: {
    data: [],
    response: {},
  },
  applicationsByProductId: {
    data: [],
    response: {},
  },
  saveRequestStatus: {
    status: "INITIAL",
    data: {},
    response: {},
  },
  jobtitle: [],
  productLine: [],
  rmList: [],
  saveTemplate: {},
  savedTemplates: [],
};

/* Request Form Reducer */
const RequestResourceReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_REQUEST_FORM_DROPDOWN_VALUES:
      return { ...state, dropdownValues: action.dropdownValues };
    case GET_PRODUCTS_BY_PRODUCT_LINE_ID:
      return {
        ...state,
        productsByProductLineId: {
          data:
            typeof action.productsByProductLineId === "string"
              ? []
              : [...action.productsByProductLineId],
        },
      };
    case GET_APPLICATIONS_BY_PRODUCT_ID:
      return {
        ...state,
        applicationsByProductId: {
          data:
            typeof action.applicationsByProductId === "string"
              ? []
              : [...action.applicationsByProductId],
        },
      };
    case SAVE_REQUEST_SUCCESS:
      return {
        ...state,
        saveRequestStatus: {
          ...state.saveRequestStatus,
          data: { ...action.saveRequest },
          status: "SUCCESS",
        },
      };
    case GET_JOB_TITLE:
      return {
        ...state,
        jobtitle: action.jobtitle,
      };
    case GET_TEMPLATE:
      return {
        ...state,
        savedTemplates: action.templates,
      };
    case CHECK_TEMPLATE:
      return {
        ...state,
        checkTemplate: action.checkTemplate,
      };
    case UPDATE_TEMPLATE:
    return {
      ...state,
      updateTemplate: action.updateTemplate,
    };
    case GET_PRODUCT_LINE:
      return { ...state, productLine: action.productLine };
    case GET_RM_LIST:
      return { ...state, rmList: action.rmList };
    case SAVE_TEMPLATE:
      return { ...state, saveTemplate: action.saveTemplate };
    default:
      return state;
  }
};

/* Export Request Form Reducer */
export default RequestResourceReducer;
