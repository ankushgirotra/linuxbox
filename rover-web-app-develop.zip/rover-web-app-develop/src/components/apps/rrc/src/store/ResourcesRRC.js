import roverURL from '../../../../../apis/rover_api';

// ACTION TYPES
export const ADD_RESOURCE = 'ADD_RESOURCE';
export const SET_RESOURCES = 'SET_RESOURCES';

// ACTION CREATORS
export const addResource = resource => ({
  type: ADD_RESOURCE, resource
});

export const setResources = resources => ({
  type: SET_RESOURCES, resources
});

// THUNK CREATORS
export const addResourceThunk = resource => async (dispatch) => {
  try {
    await roverURL.post('/v1/resources', resource);
    dispatch(addResource(resource));
  } catch (error) {
    console.error(error);
  }
};

export const setResourcesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/resources');
    dispatch(setResources(data.data));
  } catch (error) {
    console.error(error);
  }
};

// INITIAL STATE
const initialState = [];

// REDUCERS
const ResourcesReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_RESOURCE:
      return [...state];
    case SET_RESOURCES:
      return action.resources;
    default:
      return state;
  }
};

export default ResourcesReducer;
