import requestURL from '../../../../../apis/request_api';
import axios, { post } from "axios";
import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import { 
  getAdminExternalBlockersURL, 
  addAdminExternalBlockersURL, 
  deleteAdminExternalBlockersURL,
  getEmailNotificationStatusURL,
  updateEmailNotificationStatusURL,
} from './endpoints';

export const GET_EXTERNAL_BLOCKERS_LOADING = "GET_EXTERNAL_BLOCKERS_LOADING";
export const GET_EXTERNAL_BLOCKERS_SUCCESS = "GET_EXTERNAL_BLOCKERS_SUCCESS";
export const GET_EXTERNAL_BLOCKERS_ERROR = "GET_EXTERNAL_BLOCKERS_ERROR";

export const ADD_EXTERNAL_BLOCKERS_LOADING = "ADD_EXTERNAL_BLOCKERS_LOADING";
export const ADD_EXTERNAL_BLOCKERS_SUCCESS = "ADD_EXTERNAL_BLOCKERS_SUCCESS";
export const ADD_EXTERNAL_BLOCKERS_ERROR = "ADD_EXTERNAL_BLOCKERS_ERROR";

export const DELETE_EXTERNAL_BLOCKERS_LOADING = "DELETE_EXTERNAL_BLOCKERS_LOADING";
export const DELETE_EXTERNAL_BLOCKERS_SUCCESS = "DELETE_EXTERNAL_BLOCKERS_SUCCESS";
export const DELETE_EXTERNAL_BLOCKERS_ERROR = "DELETE_EXTERNAL_BLOCKERS_ERROR";

export const GET_EMAIL_NOTIFICATION_STATUS_LOADING = "GET_EMAIL_NOTIFICATION_STATUS_LOADING";
export const GET_EMAIL_NOTIFICATION_STATUS_SUCCESS = "GET_EMAIL_NOTIFICATION_STATUS_SUCCESS";
export const GET_EMAIL_NOTIFICATION_STATUS_ERROR = "GET_EMAIL_NOTIFICATION_STATUS_ERROR";

export const UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING = "UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING";
export const UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS = "UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS";
export const UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR = "UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR";

export const getExternalBlockersLoading = () => ({
  type: GET_EXTERNAL_BLOCKERS_LOADING,
});
export const getExternalBlockersSuccess = (externalBlockers) => ({
  type: GET_EXTERNAL_BLOCKERS_SUCCESS,
  externalBlockers,
});
export const getExternalBlockersError = (error) => ({
  type: GET_EXTERNAL_BLOCKERS_ERROR,
  error,
});

export const addExternalBlockersLoading = () => ({
  type: ADD_EXTERNAL_BLOCKERS_LOADING,
});
export const addExternalBlockersSuccess = (addVendor) => ({
  type: ADD_EXTERNAL_BLOCKERS_SUCCESS,
  addVendor,
});
export const addExternalBlockersError = (error) => ({
  type: ADD_EXTERNAL_BLOCKERS_ERROR,
  error,
});

export const deleteExternalBlockersLoading = () => ({
  type: DELETE_EXTERNAL_BLOCKERS_LOADING,
});
export const deleteExternalBlockersSuccess = (deleteVendor) => ({
  type: DELETE_EXTERNAL_BLOCKERS_SUCCESS,
  deleteVendor,
});
export const deleteExternalBlockersError = (error) => ({
  type: DELETE_EXTERNAL_BLOCKERS_ERROR,
  error,
});

export const getEmailNotificationStatusSuccess = (status) => ({
  type: GET_EMAIL_NOTIFICATION_STATUS_SUCCESS,
  status,
});

export const updateEmailNotificationStatusLoading = () => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING,
});
export const updateEmailNotificationStatusSuccess = (updateStatus) => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS,
  updateStatus,
});
export const updateEmailNotificationStatusError = (error) => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR,
  error,
});


export const getExternalBlockerThunk = () => async (dispatch) => {
  try {
    dispatch(getExternalBlockersLoading());
    const { data } = await requestURL.get(getAdminExternalBlockersURL());
    dispatch(getExternalBlockersSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getExternalBlockersError(error));
  }
};

export const addExternalBlockersThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addExternalBlockersLoading());
    const { data } = await requestURL.post(addAdminExternalBlockersURL(), payload);
    if (callback) {
      callback(ADD_EXTERNAL_BLOCKERS_SUCCESS, data);
    }
    dispatch(addExternalBlockersSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_EXTERNAL_BLOCKERS_ERROR, error.response);
    }
    dispatch(addExternalBlockersError(error.response));
  }
};

export const deleteExternalBlockersThunk = (blockerId, callback) => async (dispatch) => {
  try {
    dispatch(deleteExternalBlockersLoading());
    const { data } = await requestURL.delete(deleteAdminExternalBlockersURL(blockerId));
    if (callback) {
      callback(DELETE_EXTERNAL_BLOCKERS_SUCCESS, data);
    }
    dispatch(deleteExternalBlockersSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_EXTERNAL_BLOCKERS_ERROR, error.response);
    }
    dispatch(deleteExternalBlockersError(error.response));
  }
};

export const getEmailNotificationStatusThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get(getEmailNotificationStatusURL());
    dispatch(getEmailNotificationStatusSuccess(data));
  } catch (error) {
    console.error(error);
  }
};

export const updateEmailNotificationStatusThunk = (status, callback) => async (dispatch) => {
  try {
    dispatch(updateEmailNotificationStatusLoading());
    const { data } = await requestURL.put(updateEmailNotificationStatusURL(status));
    if (callback) {
      callback(UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS, status);
    }
    dispatch(updateEmailNotificationStatusSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR, error);
    }
    dispatch(updateEmailNotificationStatusError(error));
  }
};



const initialState = {
  externalBlockers: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  addExternalBlockersStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deleteExternalBlockersStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  emailNotificationStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  updateEmailNotificationStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
}

const RoverRequestAdmin = (state = initialState, action) => {
  switch (action.type) {
    case GET_EXTERNAL_BLOCKERS_LOADING:
      return {
        ...state,
        externalBlockers: {
          ...state.externalBlockers,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_EXTERNAL_BLOCKERS_SUCCESS:
      return {
        ...state,
        externalBlockers: {
          ...state.externalBlockers,
          data: action.externalBlockers,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_EXTERNAL_BLOCKERS_ERROR:
      return {
        ...state,
        externalBlockers: {
          ...state.externalBlockers,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_EXTERNAL_BLOCKERS_LOADING:
      return {
        ...state,
        addExternalBlockersStatus: {
          ...state.addExternalBlockersStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_EXTERNAL_BLOCKERS_SUCCESS:
      return {
        ...state,
        addExternalBlockersStatus: {
          data: action.addExternalBlockersStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_EXTERNAL_BLOCKERS_ERROR:
      return {
        ...state,
        addExternalBlockersStatus: {
          ...state.addExternalBlockersStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case DELETE_EXTERNAL_BLOCKERS_LOADING:
      return {
        ...state,
        deleteExternalBlockersStatus: {
          ...state.deleteExternalBlockersStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_EXTERNAL_BLOCKERS_SUCCESS:
      return {
        ...state,
        deleteExternalBlockersStatus: {
          data: action.deleteExternalBlockersStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_EXTERNAL_BLOCKERS_ERROR:
      return {
        ...state,
        deleteExternalBlockersStatus: {
          ...state.deleteExternalBlockersStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_EMAIL_NOTIFICATION_STATUS_SUCCESS:
      return {
        ...state,
        emailNotificationStatus: {
          ...state.emailNotificationStatus,
          data: action.status,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
}

export default RoverRequestAdmin