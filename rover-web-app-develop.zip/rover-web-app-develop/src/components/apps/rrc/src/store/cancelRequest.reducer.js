import requestURL from '../../../../../apis/request_api';
import axios, { post } from "axios";
import {
    uploadCancelRequestReasonURL,
    uploadCancelRequestDuplicateURL,
    cancelRequestURL,
} from "./endpoints";

// ACTION TYPES
export const UPLOAD_CANCEL_REQUEST_REASON_LOADING = 'UPLOAD_CANCEL_REQUEST_REASON_LOADING';
export const UPLOAD_CANCEL_REQUEST_REASON = 'UPLOAD_CANCEL_REQUEST_REASON';
export const UPLOAD_CANCEL_REQUEST_REASON_ERROR = 'UPLOAD_CANCEL_REQUEST_REASON_ERROR';
export const CANCEL_REQUEST_DUPLICATE = 'CANCEL_REQUEST_DUPLICATE';
export const CANCEL_REQUEST = 'CANCEL_REQUEST';

// ACTION CREATORS
export const onUploadCancelRequestReason = response => ({
    type: UPLOAD_CANCEL_REQUEST_REASON, response
});

export const onUploadCancelRequestReasonLoading = () => ({
    type: UPLOAD_CANCEL_REQUEST_REASON_LOADING,
});

export const onUploadCancelRequestReasonError = (error) => ({
    type: UPLOAD_CANCEL_REQUEST_REASON_ERROR,
    error,
});

export const onCancelRequestDuplicate = (response) => ({
    type: CANCEL_REQUEST_DUPLICATE,
    response
})
export const onCancelRequest = (response) => ({
    type: CANCEL_REQUEST,
    response
})

// THUNK CREATORS
export const onUploadCancelRequestThunk = (rmId, reqId, formData, callback) => (dispatch) => {
    const token = localStorage.getItem('token');
    dispatch(onUploadCancelRequestReasonLoading());
    post(uploadCancelRequestReasonURL(rmId, reqId), formData, {
        headers: {
            "content-type": "multipart/form-data",
        },
    })
        .then((response) => {
            if (callback) {
                callback('success', response);
            }
            dispatch(onUploadCancelRequestReason(response));
        })
        .catch((error) => {
            console.error(error);
            if (callback) {
                callback('error', error);
            }
            dispatch(onUploadCancelRequestReasonError(error));
        });
};

export const onUploadCancelRequestDuplicateThunk = (rmId, reqId, dupliateId, callback) => async (dispatch) => {
    try {
        // const { data } = await requestURL.post(`request/cancellDuplicate/${rmId}/req/${reqId}/${dupliateId}`);
        const { data } = await requestURL.post(uploadCancelRequestDuplicateURL(rmId, reqId, dupliateId))
        dispatch(onCancelRequestDuplicate(data));
        if (callback) {
            callback('success', data);
        }
        dispatch(onCancelRequestDuplicate(data));
    } catch (error) {
        console.error(error);
        if (callback) {
            callback('error', '');
        }
    }
}
export const onCancelRequestThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(cancelRequestURL(), payload);
        dispatch(onCancelRequest(data));
        if (callback) {
            callback('success', data);
        }
    } catch (error) {
        console.error(error);
        if (callback) {
            callback('error', '');
        }
    }
}

// INITIAL STATE
const initialState = {
    cancelRequestResponse: {},
    cancellDuplicateResponse: {}
};

// REDUCERS
const CancelRequestReducer = (state = initialState, action) => {
    switch (action.type) {
        case UPLOAD_CANCEL_REQUEST_REASON:
            return { ...state, cancelRequestResponse: action.response };
        case CANCEL_REQUEST_DUPLICATE:
            return { ...state, cancellDuplicateResponse: action.response };
        case CANCEL_REQUEST:
            return { ...state, onCancelRequestResp: action.response };
        default:
            return state;
    }
};

export default CancelRequestReducer;
