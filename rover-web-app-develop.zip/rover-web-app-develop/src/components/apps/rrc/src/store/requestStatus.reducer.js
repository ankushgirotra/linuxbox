/* Request Form Dropdown URL */
import requestURL from '../../../../../apis/request_api';
import {
    getOpenRequestURL,
    getNotificationsURL,
    getNotificationsListURL,
    getLoggedInRmInfoURL,
} from "./endpoints";

/* Request Form Action Types */
export const GET_OPEN_REQUEST = "GET_OPEN_REQUEST";
export const GET_NOTIFICATIONS = "GET_NOTIFICATIONS";
export const GET_NOTIFICATIONS_LIST = "GET_NOTIFICATIONS_LIST";
export const GET_LOGGED_IN_RM_INFO = "GET_LOGGED_IN_RM_INFO";

/* Request Form Action Creators */
export const openRequests = openRequest => ({
    type: GET_OPEN_REQUEST, openRequest
});
export const notifications = notifications => ({
    type: GET_NOTIFICATIONS, notifications
});
export const notificationsList = notificationsList => ({
    type: GET_NOTIFICATIONS_LIST, notificationsList
});
export const getLoggedInRMInfo = rmInfo => ({
    type: GET_LOGGED_IN_RM_INFO, rmInfo
})

/* Request Status Thunks */
export const getOpenRequestThunk = (lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(getOpenRequestURL(lanId));
        dispatch(openRequests(data));
    } catch (error) {
        console.error(error);
    }
}

export const getNotificationsThunk = (lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(getNotificationsURL(lanId));
        dispatch(notifications(data));
    } catch (error) {
        console.error(error);
    }
}

export const getNotificationsListThunk = (lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(getNotificationsListURL(lanId));
        dispatch(notificationsList(data));
    } catch (error) {
        console.error(error);
    }
}

export const getLoggedInRmInfoThunk = (lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(getLoggedInRmInfoURL(lanId));
        dispatch(getLoggedInRMInfo(data));
    } catch (error) {
        console.error(error);
    }
}

/* Request Form Initial State */
const initialState = {
    openRequest: {},
    notifications: {},
    notificationsList: [],
    rmInfo: {}
};

/* Request Form Reducer */
const RequestStatusReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_OPEN_REQUEST:
            return { ...state, openRequest: action.openRequest }
        case GET_NOTIFICATIONS:
            return { ...state, notifications: action.notifications }
        case GET_NOTIFICATIONS_LIST:
            return { ...state, notificationsList: action.notificationsList }
        case GET_LOGGED_IN_RM_INFO:
            return { ...state, rmInfo: action.rmInfo }
        default:
            return state;
    }
};

/* Export Request Form Reducer */
export default RequestStatusReducer;