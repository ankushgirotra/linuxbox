/* Request URL */
import requestURL from '../../../../../apis/request_api';

/* Request Action Types */
export const GET_REQUEST_DETAILS_DATA = "GET_REQUEST_DETAILS_DATA";
export const GET_REQUEST_VENDORS = "GET_REQUEST_VENDORS";
export const GET_REQUEST_OPEN_VENDORS = "GET_REQUEST_OPEN_VENDORS";
export const ADD_COMMENTS = "ADD_COMMENTS";
export const ADD_CLONES = "ADD_CLONES";
export const GET_REQUEST_USED_VENDORS = "GET_REQUEST_USED_VENDORS";
export const PUT_REQUEST_DETAILS_DATA = "PUT_REQUEST_DETAILS_DATA";
export const ADD_VENDOR_ENGAGEMENT = "ADD_VENDOR_ENGAGEMENT";
export const GET_RESOURCE_NAMES = "GET_RESOURCE_NAMES";
export const GET_DUPLICATE_REQUESTS = "GET_DUPLICATE_REQUESTS";
export const GET_MATCH_PROFILES = "GET_MATCH_PROFILES";
export const GET_TOTAL_MATCHES_COUNT = "GET_TOTAL_MATCHES_COUNT"
export const GET_PRODUCT_MANAGER = "GET_PRODUCT_MANAGER";
export const GET_MAIL_RECIPIENTS = "GET_MAIL_RECIPIENTS";
export const GET_EXTERNAL_BLOCKERS = "GET_EXTERNAL_BLOCKERS";
export const REPORT_EXTERNAL_BLOCKER = "REPORT_EXTERNAL_BLOCKER";
export const UPDATE_COMPLETE_STATUS = "UPDATE_COMPLETE_STATUS";
export const UPDATE_EXTERNAL_COMPLETE_STATUS = "UPDATE_EXTERNAL_COMPLETE_STATUS";
export const CLOSE_VENDOR_ENGAGEMENT = "CLOSE_VENDOR_ENGAGEMENT";
export const ONBOARD_RESOURCE = "ONBOARD_RESOURCE";
export const ON_ONBOARD_RESOURCE_SUCCESS = "ON_ONBOARD_RESOURCE_SUCCESS";
export const ON_ONBOARD_VENDOR_RESOURCE_SUCCESS = "ON_ONBOARD_VENDOR_RESOURCE_SUCCESS";
export const CANCEL_ONBOARDING = "CANCEL_ONBOARDING";
export const CANCEL_ONBOARDING_VENDOR = "CANCEL_ONBOARDING_VENDOR";
export const GET_CANCELLED_REQUEST = "GET_CANCELLED_REQUEST";
export const ONBOARD_EXTERNAL_VENDOR_RESOURCE = "ONBOARD_EXTERNAL_VENDOR_RESOURCE";
export const GET_BFLEX_WORK_ORDER = "GET_BFLEX_WORK_ORDER";
export const GET_RM_EMAIL_AND_VENDOR = "GET_RM_EMAIL_AND_VENDOR";
export const GET_WORKFLOW_DETAILS = "GET_WORKFLOW_DETAILS";
export const GET_NEW_RM_LIST = "GET_NEW_RM_LIST";
export const REASSIGN_REQUEST = "REASSIGN_REQUEST";
export const SEARCH_MATCHING_PROFILES = "SEARCH_MATCHING_PROFILES";
export const SEARCH_MATCHING_PROFILES_COUNT = "SEARCH_MATCHING_PROFILES_COUNT";
export const GET_INTERNAL_RESOURCES = "GET_INTERNAL_RESOURCES"

/* Request Dashboard Action Creators */
export const getRequestDetailsData = requestDetailsData => ({
    type: GET_REQUEST_DETAILS_DATA, requestDetailsData
});

export const getDuplicateRequests = duplicateRequests => ({
    type: GET_DUPLICATE_REQUESTS, duplicateRequests
});

export const getRequestVendors = requestVendors => ({
    type: GET_REQUEST_VENDORS, requestVendors
});

export const getRequestOpenVendors = requestOpenVendors => ({
    type: GET_REQUEST_OPEN_VENDORS, requestOpenVendors
});

export const addComments = comments => ({
    type: ADD_COMMENTS, comments
});
export const addClones = clones => ({
    type: ADD_CLONES, clones
});

export const getRequestUsedVendors = requestUsedVendors => ({
    type: GET_REQUEST_USED_VENDORS, requestUsedVendors
})

export const putRequestDetailsData = putRequestDetailsData => ({
    type: PUT_REQUEST_DETAILS_DATA, putRequestDetailsData
});

export const addVendorEngagement = vendorDetails => ({
    type: ADD_VENDOR_ENGAGEMENT, vendorDetails
});

export const getResourceNames = resourceNames => ({
    type: GET_RESOURCE_NAMES, resourceNames
});

export const getMatchProfiles = matchProfiles => ({
    type: GET_MATCH_PROFILES, matchProfiles
});

export const getTotalMatchesCount = totalMatchesCount => ({
    type: GET_TOTAL_MATCHES_COUNT, totalMatchesCount
});

export const searchMatchingProfiles = matchProfiles => ({
    type: SEARCH_MATCHING_PROFILES, matchProfiles
});

export const searchMatchingProfilesCount = matchProfiles => ({
    type: SEARCH_MATCHING_PROFILES_COUNT, matchProfiles
});

export const getProductManager = productManager => ({
    type: GET_PRODUCT_MANAGER, productManager
});

export const getMailRecipients = mailRecipients => ({
    type: GET_MAIL_RECIPIENTS, mailRecipients
});

export const getExternalBlockers = externalBlockers => ({
    type: GET_EXTERNAL_BLOCKERS, externalBlockers
});

export const onReportExternalBlockers = response => ({
    type: REPORT_EXTERNAL_BLOCKER, response
});
export const updateCompleteStatus = response => ({
    type: UPDATE_COMPLETE_STATUS, response
});

export const updateCompleteRequestExternal = response => ({
    type: UPDATE_EXTERNAL_COMPLETE_STATUS, response
})

export const getRmEmailAndVendor = getRmEmailAndVendor => ({
    type: GET_RM_EMAIL_AND_VENDOR, getRmEmailAndVendor
})

export const onCloseVendorEngagement = response => ({
    type: CLOSE_VENDOR_ENGAGEMENT, response
});

export const onBoardResource = response => ({
    type: ONBOARD_RESOURCE, response
});

export const onBoardResourceSuccess = response => ({
    type: ON_ONBOARD_RESOURCE_SUCCESS, response
});

export const onBoardVendorResourceSuccess = response => ({
    type: ON_ONBOARD_VENDOR_RESOURCE_SUCCESS, response
});

export const onboardExternalVendorResource = response => ({
    type: ONBOARD_EXTERNAL_VENDOR_RESOURCE, response
})

export const cancelOnboarding = response => ({
    type: CANCEL_ONBOARDING, response
});

export const cancelOnboardingVendor = response => ({
    type: CANCEL_ONBOARDING_VENDOR, response
});

export const getCancelledRequest = response => ({
    type: GET_CANCELLED_REQUEST, response
});

export const getBflexWorkOrder = bflexWorkOrder => ({
    type: GET_BFLEX_WORK_ORDER, bflexWorkOrder
});

export const getWorkflowDetails = workflow => ({
    type: GET_WORKFLOW_DETAILS, workflow
});

export const getNewRMList = rmNewList => ({
    type: GET_NEW_RM_LIST, rmNewList
});

export const reassignRequest = reassignReqResponse => ({
    type: REASSIGN_REQUEST, reassignReqResponse
});

export const getInternalResources = internalResourcesList => ({
    type: GET_INTERNAL_RESOURCES, internalResourcesList
})

/* Request Dashboard Thunks */
export const getRequestDetailsDataThunk = (lanId, reqId ) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/getDetail/${lanId}/${reqId}`);
        dispatch(getRequestDetailsData(data));
    } catch (error) {
        console.error(error);
    }
}

export const getRequestVendorsThunk = () => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/vendors`);
        dispatch(getRequestVendors(data));
    } catch (error) {
        console.error(error);
    }
}

export const getRequestOpenVendorsThunk = (reqId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/openVendor/${reqId}`);
        dispatch(getRequestOpenVendors(data));
    } catch (error) {
        console.error(error);
    }
}

export const getDuplicateRequestsThunk = (reqId, lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/duplicates/${lanId}/${reqId}`);
        dispatch(getDuplicateRequests(data));
    } catch (error) {
        console.error(error);
    }
}

export const addCommentsThunk = (comments, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/updateRequestMessage`, comments);
        if (callback) {
            callback(data);
        }
        dispatch(addComments(data));
    } catch (error) {
        console.error(error);
    }
}

export const addClonesThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/cloningRequests`, payload);
        if (callback) {
            callback(data);
        }
        dispatch(addClones(data));
    } catch (error) {
        console.error(error);
    }
}

export const getRmEmailAndVendorThunk = (empId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/vendorName/${empId}`);
        dispatch(getRmEmailAndVendor(data));
    } catch (error) {
        console.error(error);
    }
}

export const getRequestUsedVendorsThunk = (requestId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/vendorsNotRequestId/${requestId}`);
        dispatch(getRequestUsedVendors(data));
    } catch (error) {
        console.error(error);
    }
}
export const getMatchProfilesThunk = (requestId, lanId, page) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/peopleskill/${lanId}/${requestId}/${page}/10`);
        dispatch(getMatchProfiles(data));
    } catch (error) {
        console.error(error);
        dispatch(getMatchProfiles([]));
    }
}
export const getTotalMatchesCountThunk = (requestId, lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/matchingResourceCount/${lanId}/${requestId}`);
        dispatch(getTotalMatchesCount(data));
    } catch (error) {
        console.error(error);
        dispatch(getTotalMatchesCount(0));
    }
}

export const searchMatchingProfilesThunk = (payload) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/matchingResourceSearch`, payload);
        dispatch(searchMatchingProfiles(data));
    } catch (error) {
        console.error(error);
        dispatch(searchMatchingProfiles([]));
    }
}

export const searchMatchingProfilesCountThunk = (payload) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/matchingResourceSearchCount`, payload);
        dispatch(getTotalMatchesCount(data));
    } catch (error) {
        console.error(error);
        dispatch(getTotalMatchesCount(0));
    }
}


export const putRequestDetailsDataThunk = (rmId, requestId, payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/updateRequests/${rmId}/${requestId}`, payload);
        if (callback) {
            callback(PUT_REQUEST_DETAILS_DATA, data);
        }
        dispatch(putRequestDetailsData(data));

    } catch (error) {
        console.error(error);
    }
};

export const addVendorEngagementThunk = (vendorDetails, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/addVendorEngagement`, vendorDetails);
        if (callback) {
            callback(data);
        }
        dispatch(addVendorEngagement(data));
    } catch (error) {
        console.error(error);
    }
}

export const getResourceNamesThunk = (lanId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/people/${lanId}`);
        dispatch(getResourceNames(data));
    } catch (error) {
        console.error(error);
    }
}
export const getMailRecipientsThunk = () => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/employeeList`);
        dispatch(getMailRecipients(data));
    } catch (error) {
        console.error(error);
    }
}
export const getExternalBlockersThunk = () => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/blockers`);
        dispatch(getExternalBlockers(data))
    } catch (error) {
        console.error(error);
    }
}

export const getProductManagerThunk = (reqId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/getProductManager/${reqId}`);
        dispatch(getProductManager(data));
    } catch (error) {
        console.error(error);
    }
}

export const onReportExternalBlockersThunk = (payload, lanId, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/externalBlocker/${lanId}`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(onReportExternalBlockers(data));
    } catch (error) {
        console.error(error);
    }
}

export const updateCompleteStatusThunk = (reqId) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/updateCompleteStatus/${reqId}`);
        dispatch(updateCompleteStatus(data));
    } catch (error) {
        console.error(error);
    }
}

export const updateCompleteRequestExternalThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/completeRequestExternal`, payload);
        if (callback) {
            callback(UPDATE_EXTERNAL_COMPLETE_STATUS, data);
        }
        dispatch(updateCompleteRequestExternal(data));
    } catch (error) {
        console.error(error);
    }
}


export const onCloseVendorEngagementThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/closeVendorEngagement`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(onCloseVendorEngagement(data));
    } catch (error) {
        console.error(error);
    }
}


export const onBoardResourceThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/insertOnBoardingRequest`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(onBoardResource(data));
    } catch (error) {
        console.error(error);
    }
}

export const onboardExternalVendorResourceThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.post(`request/onboardExternalVendorResource`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(onboardExternalVendorResource(data));
    } catch (error) {
        console.error(error);
    }
}


export const onBoardResourceSuccessThunk = (reqId, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/getOnboardedResource/${reqId}`);
        if (callback) {
            callback('success', data);
        }
        dispatch(onBoardResourceSuccess(data));
    } catch (error) {
        dispatch(onBoardResourceSuccess({}));
        console.error(error);
    }
}
export const onBoardVendorResourceSuccessThunk = (reqId, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/getOnboardedVendorResource/${reqId}`);
        if (callback) {
            callback('success', data);
        }
        dispatch(onBoardVendorResourceSuccess(data));
    } catch (error) {
        dispatch(onBoardVendorResourceSuccess({}));
        console.error(error);
    }
}

export const cancelOnboardingThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/updateCancelOnBoarding`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(cancelOnboarding(data));
    } catch (error) {
        console.error(error);
    }
}
export const cancelOnboardingVendorThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/cancelResourceRes`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(cancelOnboardingVendor(data));
    } catch (error) {
        console.error(error);
    }
}

export const getCancelledRequestThunk = (reqId, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/getCancelledResources/${reqId}`);
        if (callback) {
            callback('success', data);
        }
        dispatch(getCancelledRequest(data));
    } catch (error) {

        dispatch(getCancelledRequest({}));
        console.error(error);
    }
}
export const getBflexWorkOrderThunk = () => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/bFlexWorkOrder`);
        dispatch(getBflexWorkOrder(data));
    } catch (error) {
        console.error(error);
    }
}
export const getWorkflowDetailsThunk = (requestId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/getWorkFlow/${requestId}`);
        dispatch(getWorkflowDetails(data));
    } catch (error) {
        console.error(error);
    }
}

export const getNewRMListThunk = (rmId) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/managersList/${rmId}`);
        dispatch(getNewRMList(data));
    } catch (error) {
        console.log(error);
    }
}

export const reassignRequestThunk = (payload, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(`request/reAssignRequest`, payload);
        if (callback) {
            callback('success', data);
        }
        dispatch(reassignRequest(data));
    } catch (error) {
        console.log(error);
    }
}

export const getInternalResourcesThunk = (deptId, callback) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(`request/${deptId}/allResources`);
        if (callback) {
            callback('success', data);
        }
        dispatch(getInternalResources(data));
    } catch (error) {
        console.log(error);
    }
}

/* Request Dashboard Initial State */
const initialState = {
    requestDetailsData: [],
    requestVendors: [],
    requestOpenVendors: [],
    comments: [],
    clones: [],
    requestUsedVendors: [],
    putRequestDetailsData: [],
    duplicateRequests: [],
    resourceNames: [],
    matchProfiles: [],
    searchMatchingProfiless:[],
    productManager: [],
    mailRecipients: [],
    externalBlockers: [],
    reportExternalBlockers: [],
    closedVendorEngagements: [],
    onBoardResourceResponse: [],
    onBoardResourceResponseSuccess: {},
    onBoardVendorResourceResponseSuccess: {},
    cancelOnboardingSuccess: [],
    cancelOnboardingVendorSuccess: [],
    cancelledRequest: {},
    bflexWorkOrder: [],
    updateCompleteRequestExternal: [],
    getRmEmailAndVendor: [],
    workflowDetails: [],
    totalMatchesCount: 0,
    rmNewList: [],
    reassignRequest: [],
    internalResourcesList:[],
};

/* Request Dashboard Reducer */
const RequestDetailsDataReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_REQUEST_DETAILS_DATA:
            return { ...state, requestDetailsData: action.requestDetailsData }
        case GET_REQUEST_VENDORS:
            return { ...state, requestVendors: action.requestVendors }
        case GET_REQUEST_OPEN_VENDORS:
            return { ...state, requestOpenVendors: action.requestOpenVendors }
        case ADD_COMMENTS:
            return { ...state, comments: action.addComments }
        case ADD_CLONES:
            return { ...state, clones: action.addClones }
        case GET_REQUEST_USED_VENDORS:
            return { ...state, requestUsedVendors: action.requestUsedVendors }
        case PUT_REQUEST_DETAILS_DATA:
            return { ...state, requestDetailsData: action.putRequestDetailsData }
        case ADD_VENDOR_ENGAGEMENT:
            return { ...state, vendorDetails: action.addVendorEngagement }
        case GET_DUPLICATE_REQUESTS:
            return { ...state, duplicateRequests: action.duplicateRequests }
        case GET_RESOURCE_NAMES:
            return { ...state, resourceNames: action.resourceNames }
        case GET_MATCH_PROFILES:
            return { ...state, matchProfiles: action.matchProfiles }
        case SEARCH_MATCHING_PROFILES:
            return { ...state, searchMatchingProfiless: action.matchProfiles }
        case GET_TOTAL_MATCHES_COUNT:
            return { ...state, totalMatchesCount: action.totalMatchesCount }
        case GET_PRODUCT_MANAGER:
            return { ...state, productManager: action.productManager }
        case GET_MAIL_RECIPIENTS:
            return { ...state, mailRecipients: action.mailRecipients }
        case GET_EXTERNAL_BLOCKERS:
            return { ...state, externalBlockers: action.externalBlockers }
        case REPORT_EXTERNAL_BLOCKER:
            return { ...state, reportExternalBlockers: action.response }
        case UPDATE_COMPLETE_STATUS:
            return { ...state, updateCompleteStatus: action.response }
        case UPDATE_EXTERNAL_COMPLETE_STATUS:
            return { ...state, updateCompleteRequestExternal: action.response }
        case CLOSE_VENDOR_ENGAGEMENT:
            return { ...state, closedVendorEngagements: action.response }
        case ONBOARD_RESOURCE:
            return { ...state, onBoardResourceResponse: action.response }
        case ON_ONBOARD_RESOURCE_SUCCESS:
            return { ...state, onBoardResourceResponseSuccess: action.response }
        case ON_ONBOARD_VENDOR_RESOURCE_SUCCESS:
            return { ...state, onBoardVendorResourceResponseSuccess: action.response }
        case CANCEL_ONBOARDING:
            return { ...state, cancelOnboardingSuccess: action.response }
        case CANCEL_ONBOARDING_VENDOR:
            return { ...state, cancelOnboardingVendorSuccess: action.response }
        case GET_CANCELLED_REQUEST:
            return { ...state, cancelledRequest: action.response }
        case GET_BFLEX_WORK_ORDER:
            return { ...state, bflexWorkOrder: action.bflexWorkOrder }
        case GET_RM_EMAIL_AND_VENDOR:
            return { ...state, getRmEmailAndVendor: action.getRmEmailAndVendor }
        case GET_WORKFLOW_DETAILS:
            return { ...state, workflowDetails: action.workflow }
        case GET_NEW_RM_LIST:
            return { ...state, rmNewList: action.rmNewList }
        case REASSIGN_REQUEST:
            return { ...state, reassignRequest: action.reassignReqResponse }
        case GET_INTERNAL_RESOURCES:
            return { ...state, internalResourcesList: action.internalResourcesList }
        default:
            return state;
    }
};

/* Export Request Dashboard Reducer */
export default RequestDetailsDataReducer;