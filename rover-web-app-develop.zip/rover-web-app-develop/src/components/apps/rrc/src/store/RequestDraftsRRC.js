import roverURL from '../../../../../apis/rover_api';

// ACTION TYPES
export const SET_REQUEST_DRAFTS_BY_OWNER = 'SET_REQUEST_DRAFTS_BY_OWNER';
export const SET_REQUEST_DRAFT_BY_ID = 'SET_REQUEST_DRAFT_BY_ID';
export const UPDATE_REQUEST_DRAFT = 'UPDATE_REQUEST_DRAFT';
export const DELETE_REQUEST_DRAFT = 'DELETE_REQUEST_DRAFT';

// ACTION CREATORS
export const setRequestDraftsByOwner = requests => ({
  type: SET_REQUEST_DRAFTS_BY_OWNER, requests
});

export const setRequestDraftById = request => ({
  type: SET_REQUEST_DRAFT_BY_ID, request
});

export const updateRequestDraft = () => ({
  type: UPDATE_REQUEST_DRAFT
});

export const deleteRequestDraft = () => ({
  type: DELETE_REQUEST_DRAFT
});

// THUNK CREATORS
export const setRequestDraftsByOwnerThunk = (user) => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/requestdrafts', { params: { requestOwner: user } });
    dispatch(setRequestDraftsByOwner(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setRequestDraftByIdThunk = (draftId) => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/requestdrafts/' + draftId);
    dispatch(setRequestDraftById(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const updateRequestDraftThunk = (draftId, request) => async (dispatch) => {
  try {
    await roverURL.put('/v1/requestdrafts/' + draftId, request);
    dispatch(updateRequestDraft());
  } catch (error) {
    console.error(error);
  }
};

export const deleteRequestDraftThunk = (draftId) => async (dispatch) => {
  try {
    await roverURL.delete('/v1/requestdrafts/' + draftId);
    dispatch(deleteRequestDraft());
  } catch (error) {
    console.error(error);
  }
};

// INITIAL STATE
const initialState = {
  requests: [],
  request: {}
};

// REDUCERS
const RequestDraftsReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_REQUEST_DRAFTS_BY_OWNER:
      return { ...state, requests: action.requests };
    case SET_REQUEST_DRAFT_BY_ID:
      return { ...state, request: action.request };
    case UPDATE_REQUEST_DRAFT:
      return state;
    case DELETE_REQUEST_DRAFT:
      return state;
    default:
      return state;
  }
};

export default RequestDraftsReducer;
