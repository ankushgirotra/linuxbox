import roverURL from '../../../../../apis/rover_api';

// ACTION TYPES
export const SET_REQUEST_TEMPLATES_BY_OWNER = 'SET_REQUEST_TEMPLATES_BY_OWNER';
export const SET_REQUEST_TEMPLATE_BY_ID = 'SET_REQUEST_TEMPLATE_BY_ID';
export const UPDATE_REQUEST_TEMPLATE = 'UPDATE_REQUEST_TEMPLATE';
export const DELETE_REQUEST_TEMPLATE = 'DELETE_REQUEST_TEMPLATE';
export const CREATE_REQUEST_TEMPLATE = 'CREATE_REQUEST_TEMPLATE';

// ACTION CREATORS
export const setRequestTemplatesByOwner = templates => ({
  type: SET_REQUEST_TEMPLATES_BY_OWNER, templates
});

export const setRequestTemplateById = template => ({
  type: SET_REQUEST_TEMPLATE_BY_ID, template
});

export const updateRequestTemplate = () => ({
  type: UPDATE_REQUEST_TEMPLATE
});

export const deleteRequestTemplate = () => ({
  type: DELETE_REQUEST_TEMPLATE
});

export const createRequestTemplate = () => ({
  type: CREATE_REQUEST_TEMPLATE
});

// THUNK CREATORS
export const setRequestTemplatesByOwnerThunk = (user) => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/requesttemplates', { params: { templateOwner: user } });
    dispatch(setRequestTemplatesByOwner(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setRequestTemplateByIdThunk = (templateId) => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/requesttemplates/' + templateId);
    dispatch(setRequestTemplateById(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const updateRequestTemplateThunk = (templateId, template) => async (dispatch) => {
  try {
    await roverURL.put('/v1/requesttemplates/' + templateId, template);
    dispatch(updateRequestTemplate());
  } catch (error) {
    console.error(error);
  }
};

export const deleteRequestTemplateThunk = (templateId) => async (dispatch) => {
  try {
    await roverURL.delete('/v1/requesttemplates/' + templateId);
    dispatch(deleteRequestTemplate());
  } catch (error) {
    console.error(error);
  }
};

export const createRequestTemplateThunk = (template) => async (dispatch) => {
  try {
    await roverURL.post('/v1/requesttemplates', template);
    dispatch(createRequestTemplate());
  } catch (error) {
    console.error(error);
  }
};

// INITIAL STATE
const initialState = {
  templates: [],
  template: {}
};

// REDUCERS
const RequestTemplatesReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_REQUEST_TEMPLATES_BY_OWNER:
      return { ...state, templates: action.templates };
    case SET_REQUEST_TEMPLATE_BY_ID:
      return { ...state, template: action.template };
    case UPDATE_REQUEST_TEMPLATE:
      return state;
    case DELETE_REQUEST_TEMPLATE:
      return state;
    case CREATE_REQUEST_TEMPLATE:
      return state;
    default:
      return state;
  }
};

export default RequestTemplatesReducer;
