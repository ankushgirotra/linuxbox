import roverURL from '../../../../../apis/rover_api';

// ACTION TYPES
export const SET_LOCATIONS = 'SET_LOCATIONS';
export const SET_RESOURCE_TYPES = 'SET_RESOURCE_TYPES';
export const SET_ROLES = 'SET_ROLES';
export const SET_TITLES = 'SET_TITLES';
export const SET_DEGREES = 'SET_DEGREES';
export const SET_SKILLS = 'SET_SKILLS';

// ACTION CREATORS
export const setSkills = (skills) => ({
  type: SET_SKILLS, skills
});

export const setLocations = locations => ({
  type: SET_LOCATIONS, locations

});

export const setResourceTypes = resourceTypes => ({
  type: SET_RESOURCE_TYPES, resourceTypes

});

export const setRoles = roles => ({
  type: SET_ROLES, roles

});

export const setTitles = titles => ({
  type: SET_TITLES, titles

});

export const setDegrees = degrees => ({
  type: SET_DEGREES, degrees

});

// THUNK CREATORS

export const setSkillsThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/skills');
    dispatch(setSkills(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setLocationsThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/locations');
    dispatch(setLocations(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setResourceTypesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/resourcetypes');
    dispatch(setResourceTypes(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setRolesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/roles');
    dispatch(setRoles(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setTitlesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/titles');
    dispatch(setTitles(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setDegreesThunk = () => async (dispatch) => {
  try {
    const { data } = await roverURL.get('/v1/degrees');
    dispatch(setDegrees(data.data));
  } catch (error) {
    console.error(error);
  }
};

// INITIAL STATE
const initialState = {
  locations: [],
  resourceTypes: [],
  roles: [],
  titles: [],
  degrees: [],
  skills: []
};

// REDUCERS
const FieldsReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_LOCATIONS:
      return { ...state, locations: action.locations };
    case SET_RESOURCE_TYPES:
      return { ...state, resourceTypes: action.resourceTypes };
    case SET_ROLES:
      return { ...state, roles: action.roles };
    case SET_TITLES:
      return { ...state, titles: action.titles };
    case SET_DEGREES:
      return { ...state, degrees: action.degrees };
    case SET_SKILLS:
      return { ...state, skills: action.skills };
    default:
      return state;
  }
};

export default FieldsReducer;
