/* Request Dashboard URL */
import requestURL from '../../../../../apis/request_api';
import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
    getDashboardTableURL,
    getTableDataOnSearchURL,
    getRMByRequestURL,
    getRequestCountURL,
} from "./endpoints";

/* Request Dashboard Action Types */
export const GET_DASHBOARD_TABLE_DATA_LOADING = "GET_DASHBOARD_TABLE_DATA_LOADING";
export const GET_DASHBOARD_TABLE_DATA = "GET_DASHBOARD_TABLE_DATA";
export const GET_TABLE_DATA_ON_SEARCH = "GET_TABLE_DATA_ON_SEARCH";
export const GET_RM_BY_REQUEST = "GET_RM_BY_REQUEST";
export const GET_REQUEST_COUNT = "GET_REQUEST_COUNT";

/* Request Dashboard Action Creators */
export const getDashboardTableLoading = () => ({
    type: GET_DASHBOARD_TABLE_DATA_LOADING,
});
export const getDashboardTable = tableData => ({
    type: GET_DASHBOARD_TABLE_DATA, tableData
});
export const getTableDataOnSearch = tableData => ({
    type: GET_TABLE_DATA_ON_SEARCH, tableData
});
export const getRMByRequest = rmList => ({
    type: GET_RM_BY_REQUEST, rmList
});
export const getRequestCount = requestCount => ({
    type: GET_REQUEST_COUNT, requestCount
});

/* Map status code to status */
const getStatusInfo = (status) => {
    if (status === 1) {
        return 'Identifying Resource'
    } else if (status === 5) {
        return 'External Blocker'
    } else if (status === 3) {
        return 'Completed'
    } else if (status === 2) {
        return 'Resource Reserved'
    } else if (status === 4) {
        return 'Cancelled'
    }
}

/* Map date and status to desired format */
const mapTableData = (data) => {
    return data.map((tableData) => {
        return {
            ...tableData,
            status: getStatusInfo(tableData.status),
            request_id: tableData.request_id
        };
    });
}

/* Request Dashboard Thunks */
export const getDashboardTableThunk = (status, payload) => async (dispatch) => {
    try {
        dispatch(getDashboardTableLoading());
        const { data } = await requestURL.put(getDashboardTableURL(status), payload);
        dispatch(getDashboardTable(mapTableData(data)));
    } catch (error) {
        console.error(error);
    }
}

export const getTableDataOnSearchThunk = (payload) => async (dispatch) => {
    try {
        const { data } = await requestURL.put(getTableDataOnSearchURL(), payload);
        dispatch(getTableDataOnSearch(mapTableData(data)));
    } catch (error) {
        console.error(error);
    }
}

export const getRMByRequestThunk = () => async (dispatch) => {
    try {
        const { data } = await requestURL.get(getRMByRequestURL());
        dispatch(getRMByRequest(data));
    } catch (error) {
        console.error(error);
    }
}
export const getRequestCountThunk = (lanId, rmIds) => async (dispatch) => {
    try {
        const { data } = await requestURL.get(getRequestCountURL(lanId, rmIds));
        dispatch(getRequestCount(data));
    } catch (error) {
        console.error(error);
    }
}

/* Request Dashboard Initial State */
const initialState = {
    dashboardTableData: { data: [], status: DATA_STATUS.INITIAL, response: {} },
    tableDataAfterSearch: [],
    rmByRequestList: [],
    requestCount: {},
};

/* Request Dashboard Reducer */
const RequestDashboardReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_DASHBOARD_TABLE_DATA_LOADING:
            return {
                ...state,
                dashboardTableData: {
                    ...state.dashboardTableData,
                    status: DATA_STATUS.LOADING,
                },
            };
        case GET_DASHBOARD_TABLE_DATA:
            return {
                ...state,
                dashboardTableData: {
                    data: [...action.tableData],
                    status: DATA_STATUS.SUCCESS,
                },
            };
        case GET_TABLE_DATA_ON_SEARCH:
            return { ...state, tableDataAfterSearch: action.tableData }
        case GET_RM_BY_REQUEST:
            return { ...state, rmByRequestList: action.rmList }
        case GET_REQUEST_COUNT:
            return { ...state, requestCount: action.requestCount }
        default:
            return state;
    }
};

/* Export Request Dashboard Reducer */
export default RequestDashboardReducer;