import cookie from 'react-cookies';

const DOMAIN = cookie.load('ROVER_REQUEST_API');

//REQUEST HOME API"S
export const getDashboardTableURL = (status) => {
  return `request/requestByResourceManager/${status}`
};

export const getTableDataOnSearchURL = () => {
  return `request/resMan/search`
};

export const getRMByRequestURL = () => {
  return `request/allManagers`
};

export const getRequestCountURL = (lanId, rmIds) => {
  return `request/requestsCount/${lanId}/${rmIds}`
};

//Request Status API's
export const getOpenRequestURL = (lanId) => {
  return `request/statusCount/${lanId}`
};

export const getNotificationsURL = (lanId) => {
  return `request/chkNot/${lanId}`
};

export const getNotificationsListURL = (lanId) => {
  return `request/chkNotList/${lanId}`
};

export const getLoggedInRmInfoURL = (lanId) => {
  return `request/rm/${lanId}`
};

//Cancel Requests API's
export const uploadCancelRequestReasonURL = (rmId, reqId) => {
    return `${DOMAIN}/request/upload/${rmId}/${reqId}`;
};

export const uploadCancelRequestDuplicateURL = (rmId, reqId, dupliateId) => {
  return `request/cancellDuplicate/${rmId}/req/${reqId}/${dupliateId}`
};

export const cancelRequestURL = () => {
  return `request/cancelRequest`
};

//ADMIN APIS
export const getAdminExternalBlockersURL = () => {
  return `/request/blockers`;
};

export const addAdminExternalBlockersURL =() => {
  return `/request/addBlocker`;
}

export const deleteAdminExternalBlockersURL =(blockerId) => {
  return `/request/deleteBlocker/${blockerId}`;
}

export const getEmailNotificationStatusURL = () => {
  return `request/masterSwitch/getStatus`;
}

export const updateEmailNotificationStatusURL = (status) => {
  return `request/update/masterSwitch/${status}`;
}