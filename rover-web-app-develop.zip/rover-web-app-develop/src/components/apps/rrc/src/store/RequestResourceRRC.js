//import roverURL from '../../../../../apis/rover_api';
import requestURL from '../../../../../apis/request_api';

// ACTION TYPES
export const SET_PORTFOLIOS = 'SET_PORTFOLIOS';
export const SET_PRODUCTS = 'SET_PRODUCTS';
export const SET_APPLICATIONS = 'SET_APPLICATIONS';
export const CREATE_REQUEST_DRAFT = 'CREATE_REQUEST_DRAFT';
//GET
export const GET_PRODUCT_LINE = "GET_PRODUCT_LINE";
export const GET_PRODUCT = "GET_PRODUCT";
export const GET_APPLICATON = "GET_APPLICATON";
export const GET_ROLE = "GET_ROLE";
export const GET_BELT = "GET_BELT";
export const GET_TECHNOLOGIE = "GET_TECHNOLOGIE";
export const GET_LOCATION = "GET_LOCATION";
export const GET_JOB_TITLE = "GET_JOB_TITLE";
export const GET_PRODUCTS_BY_PRODUCT_LINE_ID = "GET_PRODUCTS_BY_PRODUCT_LINE_ID";
export const GET_APPLICATIONS_BY_PRODUCT_ID = "GET_APPLICATIONS_BY_PRODUCT_ID";
export const GET_OPEN_REQUEST = "GET_OPEN_REQUEST";
//SAVE
//export const SAVE_DOMAIN_RESET = "SAVE_DOMAIN_RESET";
//export const SAVE_DOMAIN_LOADING = "SAVE_DOMAIN_LOADING";
export const SAVE_REQUEST_SUCCESS = "SAVE_DOMAIN_SUCCESS";
//export const SAVE_DOMAIN_ERROR = "SAVE_DOMAIN_ERROR";
// export const GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_LOADING =
//   "GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_LOADING";
// export const GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR =
//   "GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR";

// ACTION CREATORS

export const openRequests = openRequest => ({
  type: GET_OPEN_REQUEST, openRequest
});

export const setPortfolios = portfolios => ({
  type: SET_PORTFOLIOS, portfolios
});

export const setProducts = products => ({
  type: SET_PRODUCTS, products
});

export const setApplications = applications => ({
  type: SET_APPLICATIONS, applications
});

export const saveRequest = saveRequest => ({
  type: SAVE_REQUEST_SUCCESS, saveRequest
});

export const createRequestDraft = request => ({
  type: CREATE_REQUEST_DRAFT, request
});

export const getProductLine = productLine => ({
  type: GET_PRODUCT_LINE, productLine
});

export const getProduct = product => ({
  type: GET_PRODUCT, product
});

export const getApplication = application => ({
  type: GET_APPLICATON, application
});

export const getRole = role => ({
  type: GET_ROLE, role
});

export const getBelt = belt => ({
  type: GET_BELT, belt
});

export const getTechnologie = technologie => ({
  type: GET_TECHNOLOGIE, technologie
});

export const getLocation = location => ({
  type: GET_LOCATION, location
});

export const getJobTitle = jobtitle => ({
  type: GET_JOB_TITLE, jobtitle
});

export const getProductsByProductLineId = productsByProductLineId => ({
  type: GET_PRODUCTS_BY_PRODUCT_LINE_ID,
  productsByProductLineId,
});

export const getApplicationsByProductId = applicationsByProductId => ({
  type: GET_APPLICATIONS_BY_PRODUCT_ID,
  applicationsByProductId,
});


// THUNK MIDDLEWARE

export const saveRequestThunk = (payload, callback) => async (dispatch) => {
  try {
    console.log(payload)
    const { data } = await requestURL.post("request/addRequests", payload);
    console.log(data)
    if (callback) {
      callback(SAVE_REQUEST_SUCCESS, data);
    }
    dispatch(saveRequest(data));
  } catch (error) {
    console.error(error);
    // if (callback) {
    //   callback(SAVE_DOMAIN_ERROR, error);
    // }
    // dispatch(saveDomainError(error));
  }
};


export const setPortfoliosThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('/v1/portfolios');
    dispatch(setPortfolios(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setProductsThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('/v1/products');
    dispatch(setProducts(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const setApplicationsThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('/v1/applications');
    dispatch(setApplications(data.data));
  } catch (error) {
    console.error(error);
  }
};

export const createRequestDraftThunk = (request) => async (dispatch) => {
  try {
    await requestURL.post('/v1/requestdrafts', request);
    dispatch(createRequestDraft(request));
  } catch (error) {
    console.error(error);
  }
};

export const getProductLineThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getProductLine(data[0].finalProductsLine));
    //console.log(data);
  } catch (error) {
    console.error(error);
  }
}

export const getProductThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    console.log(data);
    dispatch(getProduct(data[0].finalProds));
    console.log(data);
  } catch (error) {
    console.error(error);
  }
}


export const getApplicationThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getApplication(data[0].finalApps));
    //console.log(data[0].finalApps);
  } catch (error) {
    console.error(error);
  }
}

export const getRoleThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getRole(data[0].finalRolUn));
    //console.log(data[0].finalRoles);
  } catch (error) {
    console.error(error);
  }
}

export const getBeltThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getBelt(data[0].finalBelts));
    //console.log(data[0].finalBelts);
  } catch (error) {
    console.error(error);
  }
}

export const getTechnologieThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getTechnologie(data[0].finalSkills));
    //console.log(data[0].finalSkills);
  } catch (error) {
    console.error(error);
  }
}

export const getLocationThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getLocation(data[0].finalLocations));
    //console.log(data);
  } catch (error) {
    console.error(error);
  }
}

export const getProductsByProductLineIdThunk = (productLineId, callback) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/prodLine/${productLineId}`);
    if (callback) {
      callback(GET_PRODUCTS_BY_PRODUCT_LINE_ID);
    }
    console.log("Data from store: ", productLineId);
    console.log(data);
    dispatch(getProductsByProductLineId(data));
  } catch (error) {
    console.error(error);
  }
}

export const getApplicationsByProductIdThunk = (productId, callback) => async (dispatch) => {
  try {
    const { data } = await requestURL.get(`request/prodLine/product/${productId}`);
    if (callback) {
      callback(GET_APPLICATIONS_BY_PRODUCT_ID);
    }
    console.log("Data from store application: ", productId);
    console.log(data);
    dispatch(getApplicationsByProductId(data));
  } catch (error) {
    console.error(error);
  }
}
export const getJobTitleThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/303777');
    dispatch(getJobTitle(data[0].finalRoles));
    //console.log(data);
  } catch (error) {
    console.error(error);
  }
}

export const getOpenRequestThunk = () => async (dispatch) => {
  try {
    const { data } = await requestURL.get('request/statusCount');
    dispatch(openRequests(data));
  } catch (error) {
    console.error(error);
  }
}


const initialState = {
  portfolios: [],
  products: [],
  applications: [],
  //New Added
  productLine: [],
  product: [],
  application: [],
  role: [],
  jobtitle:[],
  belt: [],
  technologie: [],
  location: [],
  productsByProductLineId: {
    data: [],
    //status: DATA_STATUS,
    response: {},
  },
  applicationsByProductId: {
    data: [],
    //status: DATA_STATUS,
    response: {},
  },
  saveRequestStatus: {
    status: "INITIAL",
    response: {},
  },
  openRequest:{},
};

// REDUCER
const RequestResourceReducer = (state = initialState, action) => {
  
  switch (action.type) {
    case GET_OPEN_REQUEST:
      return { ...state, openRequest: action.openRequest }
    case SET_PORTFOLIOS:
      return { ...state, portfolios: action.portfolios };
    case SET_PRODUCTS:
      return { ...state, products: action.products };
    case SET_APPLICATIONS:
      return { ...state, applications: action.applications };
    case SAVE_REQUEST_SUCCESS:
      return {
        ...state,
        saveRequestStatus: {
          ...state.saveRequestStatus,
          response: action.saveRequest,
          //status: DATA_STATUS.SUCCESS,
        },
      };
    case CREATE_REQUEST_DRAFT:
      return state;
    case GET_PRODUCT_LINE:
      return { ...state, productLine: action.productLine };
    case GET_PRODUCT:
      return { ...state, product: action.product };
    case GET_APPLICATON:
      return { ...state, application: action.application };
    case GET_ROLE:
      return { ...state, role: action.role }
    case GET_JOB_TITLE:
      return { ...state, jobtitle: action.jobtitle }
    case GET_BELT:
      return { ...state, belt: action.belt }
    case GET_TECHNOLOGIE:
      return { ...state, technologie: action.technologie }
    case GET_LOCATION:
      return { ...state, location: action.location }
    case GET_PRODUCTS_BY_PRODUCT_LINE_ID:
      return {
        ...state,
        productsByProductLineId: {
          data:
            typeof action.productsByProductLineId === "string" ? [] : [...action.productsByProductLineId],
          //status: DATA_STATUS.SUCCESS,
        },
        // applicationsByProductId: {
        //   ...state.applicationsByProductId,
        //   data: []
        // }
      };
    case GET_APPLICATIONS_BY_PRODUCT_ID:
      return {
        ...state,
        applicationsByProductId: {
          data:
            typeof action.applicationsByProductId === "string" ? [] : [...action.applicationsByProductId],
          //status: DATA_STATUS.SUCCESS,
        },
        // applicationsByProductId: {
        //   ...state.applicationsByProductId,
        //   data: []
        // }
      };

    default:
      return state;
  }
};

export default RequestResourceReducer;
