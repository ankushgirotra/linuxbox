/* Custom Filter Action Types */
export const GET_REQUEST_ID_FILTER_STATUS = "GET_REQUEST_ID_FILTER_STATUS";
export const GET_CREATED_FILTER_STATUS = "GET_CREATED_FILTER_STATUS";
export const GET_START_DATE_FILTER_STATUS = "GET_START_DATE_FILTER_STATUS";
export const GET_CURRENT_STATUS_FILTER = "GET_CURRENT_STATUS_FILTER";
export const GET_PRODUCT_FILTER_STATUS = "GET_PRODUCT_FILTER_STATUS";
export const GET_ITPM_FILTER_STATUS = "GET_ITPM_FILTER_STATUS";
export const GET_SKILLS_FILTER_STATUS = "GET_SKILLS";
export const GET_RM_FILTER_STATUS = "GET_RM_FILTER_STATUS";

/* Custom Filter Action Creators */
export const getRequestIdFilterStatus = status => ({
    type: GET_REQUEST_ID_FILTER_STATUS, status
});

export const getRMFilterStatus = status => ({
    type: GET_RM_FILTER_STATUS, status
});

export const getCreatedFilterStatus = status => ({
    type: GET_CREATED_FILTER_STATUS, status
});

export const getStartDateFilterStatus = status => ({
    type: GET_START_DATE_FILTER_STATUS, status
});

export const getCurrentStatus = status => ({
    type: GET_CURRENT_STATUS_FILTER, status
});

export const getProductFilterStatus = status => ({
    type: GET_PRODUCT_FILTER_STATUS, status
});

export const getITPMFilterStatus = status => ({
    type: GET_ITPM_FILTER_STATUS, status
});

export const getSkillsFilterStatus = status => ({
    type: GET_SKILLS_FILTER_STATUS, status
});


/* Custom Filter Thunks */
export const getRMFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getRMFilterStatus(status));
}
export const getRequestIdFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getRequestIdFilterStatus(status));
}

export const getCreatedFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getCreatedFilterStatus(status));
}

export const getStartDateFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getStartDateFilterStatus(status));
}

export const getCurrentStatusFilterThunk = (status) => async (dispatch) => {
    dispatch(getCurrentStatus(status));
}

export const getProductFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getProductFilterStatus(status));
}

export const getITPMFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getITPMFilterStatus(status));
}
export const getSkillsFilterStatusThunk = (status) => async (dispatch) => {
    dispatch(getSkillsFilterStatus(status));
}

/* Custom Filter Initial State */
const initialState = {
    rm: {},
    requestId: {},
    created: {},
    startDate: {},
    status: {},
    product: {},
    itpm: {},
    skills: {}
};

/* Custom Filter Reducer */
const CustomFilterReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_REQUEST_ID_FILTER_STATUS:
            return { ...state, requestId: action.status }
        case GET_RM_FILTER_STATUS:
            return { ...state, rm: action.status }
        case GET_CREATED_FILTER_STATUS:
            return { ...state, created: action.status }
        case GET_START_DATE_FILTER_STATUS:
            return { ...state, startDate: action.status }
        case GET_CURRENT_STATUS_FILTER:
            return { ...state, status: action.status }
        case GET_PRODUCT_FILTER_STATUS:
            return { ...state, product: action.status }
        case GET_ITPM_FILTER_STATUS:
            return { ...state, itpm: action.status }
        case GET_SKILLS_FILTER_STATUS:
            return { ...state, skills: action.status }
        default:
            return state;
    }
};

/* Export Custom Filter Reducer */
export default CustomFilterReducer;