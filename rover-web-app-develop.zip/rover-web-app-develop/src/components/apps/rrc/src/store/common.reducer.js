import requestURL from '../../../../../apis/request_api';
import axios, { post } from "axios";

// ACTION TYPES
export const SET_SEARCH_WORD = 'SET_SEARCH_WORD';
export const SET_SELECTED_RMS = 'SET_SELECTED_RMS';
export const SET_CHECKBOX_FILTER = 'SET_CHECKBOX_FILTER';
export const SET_CHECKBOX_FILTER_STATUs = 'SET_CHECKBOX_FILTER_STATUs';
export const SET_REQUESTDETAILS_SELECT = 'SET_REQUESTDETAILS_SELECT';
// ACTION CREATORS
export const setSearchWord = response => ({
    type: SET_SEARCH_WORD, response
});

export const setSelectedRms = response => ({
    type: SET_SELECTED_RMS, response
});

export const setCheckboxFilter = response => ({
    type: SET_CHECKBOX_FILTER, response
});

export const setCheckboxFilterStatus = response => ({
    type: SET_CHECKBOX_FILTER_STATUs, response
});

export const setRequestDetailsSelectStatus = response => ({
    type: SET_REQUESTDETAILS_SELECT, response
});

// INITIAL STATE
const initialState = {
    searchWord: '',
    selectedRms: [],
    checkboxFilters: {
        open: true,
        completed: false,
        cancelled: false,
    },
    checkboxFiltersStatus: true,
    requuestDetailsSelectStatus: false,
};

// REDUCERS
const RequestsCommonReducer = (state = initialState, action) => {
    switch (action.type) {
        case SET_SEARCH_WORD:
            return { ...state, searchWord: action.response };
        case SET_SELECTED_RMS:
            return { ...state, selectedRms: action.response };
        case SET_CHECKBOX_FILTER:
            return { ...state, checkboxFilters: action.response };
        case SET_CHECKBOX_FILTER_STATUs:
            return { ...state, checkboxFiltersStatus: action.response };
        case SET_REQUESTDETAILS_SELECT:
            return { ...state, requuestDetailsSelectStatus: action.response };
        default:
            return state;
    }
};

export default RequestsCommonReducer;
