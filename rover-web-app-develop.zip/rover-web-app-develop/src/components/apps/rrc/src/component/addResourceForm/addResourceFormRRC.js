import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import {
  addResourceThunk
} from '../../../../../../store';

import './resourceFormRRC.css';

export class AddResourceFormRRC extends React.Component {
  constructor (props) {
    super(props);
    this.state = {
      resourceId: '',
      firstName: '',
      lastName: '',
      manager: '',
      isActive: false,
      email: '',
      phone: '',
      resourceType: '',
      location: '',
      role: '',
      title: '',
      degree: '',
      locations: [],
      resourceTypes: [],
      roles: [],
      titles: [],
      degrees: []
    };
  }

  handleSubmit = async (event) => {
    event.preventDefault();
    const resource = {
      resourceId: this.state.resourceId,
      firstName: this.state.firstName,
      lastName: this.state.lastName,
      manager: this.state.manager,
      isActive: this.state.isActive,
      email: this.state.email,
      phone: this.state.phone,
      resourceType: this.state.resourceType,
      location: this.state.location,
      role: this.state.role,
      title: this.state.title,
      degree: this.state.degree
    };
    await this.props.addResourceThunks(resource);
    this.setState({
      resourceId: '',
      firstName: '',
      lastName: '',
      manager: '',
      isActive: false,
      email: '',
      phone: '',
      resourceType: '',
      location: '',
      role: '',
      title: '',
      degree: ''
    });
  };

  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  handleCheckboxChange = (event) => {
    this.setState({
      [event.target.name]: event.target.checked
    });
  };

  setFields = (identifier) => {
    const inputFields = [
      {
        resourceId: 'Resources ID',
        type: 'text',
        id: 1
      },
      {
        firstName: 'First Name',
        type: 'text',
        id: 2
      },
      {
        lastName: 'Last Name',
        type: 'text',
        id: 3
      },
      {
        manager: 'Manager',
        type: 'text',
        id: 4
      },
      {
        email: 'Email',
        type: 'email',
        id: 5
      },
      {
        phone: 'Phone',
        type: 'text',
        id: 6
      }
    ];
    const selectFields = [
      {
        resourceType: 'Resource Type',
        array: 'resourceTypes',
        id: 1
      },
      {
        location: 'Location',
        array: 'locations',
        id: 3
      },
      {
        role: 'Role',
        array: 'roles',
        id: 4
      }
    ];
    switch (identifier) {
      case 'inputFields':
        return inputFields.map(item => (
          <div className='field' key={item.id}>
            <label className='label' key={item.id}>{item[Object.keys(item)[0]]}</label>
            <div className='control'>
              <input
                required
                className='input is-primary'
                type={item.type}
                key={item.id}
                name={Object.keys(item)[0]}
                id={Object.keys(item)[0]}
                value={this.state[Object.keys(item)[0]]}
                onChange={this.handleChange}
                placeholder={item[Object.keys(item)[0]]}
              />
            </div>
          </div>
        ));
      case 'selectFields':
        return selectFields.map(item => (
          <div className='field' key={item.id}>
            <label key={item.id} className='label'>{item[Object.keys(item)[0]]}</label>
            <div className='control'>
              <select
                required
                className='input is-primary'
                type={item.type}
                key={item.id}
                name={Object.keys(item)[0]}
                id={Object.keys(item)[0]}
                value={this.state[Object.keys(item)[0]]}
                onChange={this.handleChange}
                placeholder={item[Object.keys(item)[0]]}
              >
                <option value=''>--------Select--------</option>
                {this.setOptionsForDropdown(this.props[item.array])}
              </select>
            </div>
          </div>
        ));
      default:
        console.error('Identifier is unknown');
    }
  };

  setOptionsForDropdown = (array) => {
    if (array !== this.props.titles && array !== undefined) {
      return array.map(item => (
        <option
          key={item.id}
          value={item[Object.keys(item)[0]]}
        >
          {item.description}
        </option>
      ));
    }
    const result = this.props.titles.filter(item => (item.role === this.state.role));
    return result.map(item => (
      <option
        key={item.id}
        value={item[Object.keys(item)[0]]}
      >
        {item.description}
      </option>
    ));
  };

  render () {
    const isDeveloper = (this.state.role === 'DEVELOPER');
    const { user } = this.props;
    return (
      <div className='container'>
        <h1 className='title'>
          Hi, {user.id}! Welcome to Rover!
        </h1>
        <div className='box signup'>
          <h2 className='title has-text-centered'>Add Resource From</h2>
          <form onSubmit={this.handleSubmit}>

            {this.setFields('inputFields')}

            <div className='field'>
              <label className='label'>Is Active?</label>
              <div className='control'>
                <input
                  type='checkbox'
                  name='isActive'
                  id='isActive'
                  checked={this.state.isActive}
                  value={this.state.isActive}
                  onChange={this.handleCheckboxChange}
                />
              </div>
            </div>
            {this.setFields('selectFields')}

            {this.state.role && (
              <div className='field'>
                <label className='label'>Title</label>
                <div className='control'>
                  <select
                    required
                    className='input is-primary'
                    name='title'
                    id='title'
                    value={this.state.title}
                    onChange={this.handleChange}
                  >
                    <option value=''>--------Select--------</option>
                    {this.setOptionsForDropdown(this.props.titles)}
                  </select>
                </div>
              </div>
            )}

            {isDeveloper && (
              <div className='field'>
                <label className='label'>Degree</label>
                <div className='control'>
                  <select
                    required
                    className='input is-primary'
                    name='degree'
                    id='degree'
                    value={this.state.degree}
                    onChange={this.handleChange}
                  >
                    <option value=''>--------Select--------</option>
                    {this.setOptionsForDropdown(this.props.degrees)}
                  </select>
                </div>
              </div>
            )}
            <button className='btn btn-danger' type='submit'>Submit</button>
          </form>
        </div>
      </div>
    );
  }
}

export const mapStateToProps = state => ({
  locations: state.FieldsReducer.locations,
  resourceTypes: state.FieldsReducer.resourceTypes,
  roles: state.FieldsReducer.roles,
  titles: state.FieldsReducer.titles,
  degrees: state.FieldsReducer.degrees,
  user: state.AuthReducer.user
});

export const mapDispatchToProps = dispatch => ({
  addResourceThunks: resource => dispatch(addResourceThunk(resource)), });

AddResourceFormRRC.propTypes = {
  addResourceThunks: PropTypes.func,
  titles: PropTypes.array,
  degrees: PropTypes.array,
  user: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(AddResourceFormRRC);
