// import React from 'react';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import selectEvent from 'react-select-event';
import React from 'react';
import { fireEvent, render, wait, cleanup, getByText } from '@testing-library/react';
import mockAxios from 'axios';
import { Provider } from 'react-redux';
import RequestTemplateDetailsRRC from './requestTemplateDetailsRRC';
// // Import Mock Data
import {
  applications,
  portfolios,
  products,
  resourceTypes,
  degrees,
  roles,
  titles,
  template,
  locations,
  templates,
  skills,
  updateTemplate
} from '../../../../../../../test_fixtures/mock_data';
import {
  DELETE_REQUEST_TEMPLATE,
  deleteRequestTemplate,
  deleteRequestTemplateThunk,
  UPDATE_REQUEST_TEMPLATE,
  updateRequestTemplate,
  updateRequestTemplateThunk
} from '../../../store';
import RequestTemplatesReducer from '../../../store/RequestTemplatesRRC';

const baseProps = {
  setRequestTemplatesByOwner: jest.fn(),
  setRequestTemplateById: jest.fn(),
  portfolios,
  products,
  template: template,
  applications,
  resourceTypes,
  user: {},
  templates: templates,
  degrees,
  roles,
  titles,
  locations,
  handleIsShow: jest.fn(),
  handleCloseView: jest.fn(),
  onUpdateToTemplate: jest.fn()
};
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore({ RequestResourceReducer: { portfolios, products, applications }, FieldsReducer: { locations, roles, titles, degrees, resourceTypes, skills }, RequestTemplatesReducer: templates });
const resetStore = () => store = mockStore();

let rendered = null;
describe('Request Template Detail Test', () => {
  beforeEach(() => {
    const { container } = render(
      <Provider store={store}>
        <RequestTemplateDetailsRRC {...baseProps} childProps={{ template: template }} />
      </Provider>
    );
    rendered = container;
  });
  afterEach(cleanup);

  it('can render and load the initial data', () => {
    // To check if the pre-selected fields got set correctly, so later we can check if the select will reset the other field.
    expect(rendered).toMatchSnapshot();
  });

  it('The product and application value got reset when the user change the portfolio value', async () => {
    await wait(() =>
      selectEvent.select(getByText(rendered, 'Claims and Product & Benefit Administration'), 'DevOps')
    );
    expect(getByText(rendered, 'DevOps').textContent).toBe('DevOps');
    // Check to see if the useEffect works by checking the product value is there or not
    expect(getByText(rendered, '-------- Select Product --------').textContent).toBe('-------- Select Product --------');
    expect(getByText(rendered, '-------- Select Application --------').textContent).toBe('-------- Select Application --------');
    // The select action
  });
  it('The application value got reset when the user change the product value', async () => {
    await wait(() => selectEvent.select(getByText(rendered, 'Product name1'), 'Product name2'));
    expect(getByText(rendered, 'Product name2').textContent).toBe('Product name2');
    // Check to see if the useEffect works by checking the product value is there or not
    expect(getByText(rendered, '-------- Select Application --------').textContent).toBe('-------- Select Application --------');
    // The select action
  });
  it('The Title and Degree value got reset when the user change the role value', async () => {
    await wait(() =>
      selectEvent.select(getByText(rendered, 'Developer'), 'DevOps Engineer')
    );
    // The select action
    expect(getByText(rendered, 'DevOps Engineer').textContent).toBe('DevOps Engineer');

    // Check to see if the useEffect works by checking the product value is there or not
    expect(getByText(rendered, '-------- Select Title --------').textContent).toBe('-------- Select Title --------');
    expect(getByText(rendered, '-------- Select Degree --------').textContent).toBe('-------- Select Degree --------');
  });
  it('The Degree value got reset when the user change the title value', async () => {
    await wait(() =>
      selectEvent.select(getByText(rendered, 'Assoc Developer'), 'Sr Developer')
    );
    // The select action
    expect(getByText(rendered, 'Sr Developer').textContent).toBe('Sr Developer');
    // Check to see if the useEffect works by checking the product value is there or not
    expect(getByText(rendered, '-------- Select Degree --------').textContent).toBe('-------- Select Degree --------');
  });
  it('After user click on the Delete Template Button', async () => {
    await wait(() =>
      fireEvent.click(getByText(rendered, 'Delete Template'))
    );
    expect(getByText(rendered, '-------- Select Portfolio --------').textContent).toBe('-------- Select Portfolio --------');
  });
});

describe('Redux Store for RequestTemplateDetails', () => {
  beforeEach(() => {
    resetStore();
    console.error = jest.fn();
  });
  describe('RequestTemplateDetails Store Actions', () => {
    it('should create an action to update a draft request by draft id', () => {
      const expectedAction = {
        type: UPDATE_REQUEST_TEMPLATE
      };
      expect(updateRequestTemplate()).toEqual(expectedAction);
    });
    it('should create an action to delete a draft request by draft id', () => {
      const expectedAction = {
        type: DELETE_REQUEST_TEMPLATE
      };
      expect(deleteRequestTemplate()).toEqual(expectedAction);
    });
  });
  describe('RequestTemplateDetails Thunk Middleware', () => {
    it('Axios PUT call should get the correct response for updateRequestTemplate', async () => {
      const templateId = '1';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve());
      const expectedActions = [
        {
          type: UPDATE_REQUEST_TEMPLATE
        }
      ];
      await store.dispatch(updateRequestTemplateThunk(templateId, updateTemplate));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.put).toHaveBeenCalledWith('/v1/requesttemplates/' + templateId, updateTemplate);
    });
    it('Axios DELETE call should get the correct response for deleteRequestTemplate', async () => {
      const templateId = '2';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve());
      const expectedActions = [
        {
          type: DELETE_REQUEST_TEMPLATE
        }
      ];
      await store.dispatch(deleteRequestTemplateThunk(templateId));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.delete).toHaveBeenCalledWith('/v1/requesttemplates/' + templateId);
    });
  });

  describe('RequestTemplates Reducer', () => {
    it('should return the initial state', () => {
      expect(RequestTemplatesReducer(undefined, {})).toEqual({ templates: [], template: {} });
    });
    it('should handle UPDATE_REQUEST_TEMPLATE appropriately', () => {
      expect(RequestTemplatesReducer([], {
        type: UPDATE_REQUEST_TEMPLATE
      }))
        .toEqual([]);
    });
    it('should handle DELETE_REQUEST_TEMPLATE appropriately', () => {
      expect(RequestTemplatesReducer([], {
        type: DELETE_REQUEST_TEMPLATE
      }))
        .toEqual([]);
    });
  });
});
