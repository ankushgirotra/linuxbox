import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { Form, Button, Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types';
import {
  setUserInfoThunk,
  createRequestDraftThunk,
  setRequestDraftsByOwnerThunk,
  setRequestTemplatesByOwnerThunk,
  setRequestTemplateByIdThunk
} from '../../../../../../store';
import UserInput from '../../../../../../shared/components/form/UserInput';
import DateField from '../../../../../../shared/components/form/UserInput/DateField';
import InputField from '../../../../../../shared/components/form/UserInput/InputField';
import TextAreaField from '../../../../../../shared/components/form/UserInput/TextAreaField';
import PromptedInputModalRRC from './promptedInputModalRRC';

export function RequestResourceFormRRC (props) {
  const { user, setRequestTemplatesByOwner, setUserInfo, setRequestTemplateById } = props;
  const initialState = {
    draftName: '',
    requestOwner: props.user.id || '',
    startDate: '',
    endDate: '',
    notes: '',
    templateOwner: props.templateById.templateOwner || '',
    portfolio: props.templateById.portfolioIdentifier || '',
    product: props.templateById.productIdentifier || '',
    application: props.templateById.applicationIdentifier || '',
    allocation: props.templateById.allocation || '',
    role: props.templateById.role || '',
    skills: props.templateById.skills || [],
    resourceType: props.templateById.resourceType || '',
    title: props.templateById.title || '',
    degree: props.templateById.degree || '',
    locations: props.templateById.locations || [],
    requestCount: props.templateById.requestCount || '1',
    showPromptModal: false,
    template: ''
  };

  const [state, setState] = useState(initialState);
  const [requestEdit, setRequestEdit] = useState(false);
  const [disableButton, setDisableButton] = useState(false);

  useEffect(() => {
    setRequestTemplatesByOwner(user.id);
    setUserInfo();
  }, [setRequestTemplatesByOwner, setUserInfo, user.id]);

  useEffect(() => {
    if (!state.template) {
      setState({
        draftName: '',
        requestOwner: '',
        startDate: '',
        endDate: '',
        notes: '',
        templateOwner: '',
        portfolio: '',
        product: '',
        application: '',
        allocation: '',
        role: '',
        skills: [],
        resourceType: '',
        title: '',
        degree: '',
        locations: [],
        requestCount: '1',
        showPromptModal: false,
        template: ''
      });
      return;
    }

    setRequestTemplateById(state.template);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.template]);

  useEffect(() => {
    setState({
      ...initialState,
      template: state.template
    });
    setRequestEdit(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.templateById]);

  useEffect(() => {
    if (requestEdit) {
      setState({
        ...state,
        product: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.portfolio]);

  useEffect(() => {
    if (requestEdit) {
      setState({
        ...state,
        application: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.product]);

  useEffect(() => {
    if (requestEdit) {
      setState({
        ...state,
        title: '',
        degree: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.role]);

  useEffect(() => {
    if (requestEdit) {
      setState({
        ...state,
        degree: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.title]);

  useEffect(() => {
    setState({
      draftName: '',
      requestOwner: props.user.id,
      startDate: '',
      endDate: '',
      notes: '',
      templateOwner: props.user.id,
      portfolio: '',
      product: '',
      application: '',
      allocation: '',
      role: '',
      skills: [],
      resourceType: '',
      title: '',
      degree: '',
      locations: [],
      requestCount: '1',
      showPromptModal: false,
      template: ''
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleHide = () => {
    setState({
      ...state,
      showPromptModal: !state.showPromptModal
    });
  };

  const setDomainOwner = (array) => {
    const currentApplication = state.application;
    if (currentApplication.length) {
      return array.reduce((acc, application) => {
        if (application.id === currentApplication) {
          acc += application.managerIdentifier;
        }
        return acc;
      }, '');
    }
  };

  const handleSubmit = async (event) => {
    setDisableButton(true);
    event.preventDefault();
    const request = {
      request: {
        requestOwner: state.requestOwner || null,
        draftName: state.draftName || null,
        portfolio: state.portfolio || null,
        product: state.product || null,
        application: state.application || null,
        startDate: state.startDate || null,
        endDate: state.endDate || null,
        allocation: state.allocation || null,
        role: state.role || null,
        title: state.title || null,
        degree: state.degree || null,
        skills: state.skills || null,
        notes: state.notes || null,
        locations: state.locations ? state.locations.filter(location => (state.resourceType === 'EMPLOYEE' ? location !== 'OFFSHORE' : location)) : null,
        resourceType: state.resourceType || null,
        requestCount: state.requestCount || null
      }
    };
    await props.createRequestDraft(request);
    await props.setRequestDraftsByOwner(props.user.id);
    setState(initialState);
    handleHide();
    props.toggle();
  };

  const handleChange = (value, action) => {
    const field = action.name;
    if (value) {
      setRequestEdit(true);
      setState({
        ...state,
        [field]: value.value
      });
    } else {
      setRequestEdit(true);
      setState({
        ...state,
        [field]: ''
      });
    }
  };

  const handleEventOnChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.value
    });
  };

  const handleMultiSelectChange = (skills) => {
    if (skills) {
      skills = skills.map(skill => {
        return skill.label;
      });
    } else {
      skills = [];
    }
    setState({
      ...state,
      skills
    });
  };

  const handleCheckboxChange = (event) => {
    let data = state.locations.slice();
    if (state.locations.includes(event.target.value)) {
      data = state.locations.filter(item => item !== event.target.value);
    } else {
      data.push(event.target.value);
    }
    setState({
      ...state,
      [event.target.name]: data
    });
  };
  const isDeveloper = (state.role === 'DEVELOPER' && state.title);
  return (
    <div>
      <Form>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Template</Form.Label>
              <UserInput
                id='template' type='template' onChange={handleChange} initialValue={state.template}
                isSorted
              />
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Portfolio</Form.Label>
              <UserInput
                id='portfolio' type='portfolio' onChange={handleChange} initialValue={state.portfolio}
                isSorted
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Product</Form.Label>
              <UserInput
                id='product' type='product' onChange={handleChange} initialValue={state.product}
                isSorted refValue={state.portfolio}
              />
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Application</Form.Label>
              <UserInput
                id='application' type='application' onChange={handleChange}
                initialValue={state.application} isSorted refValue={state.product}
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Skills</Form.Label>
              <UserInput
                id='skills' type='skills' onChange={handleMultiSelectChange}
                initialValue={state.skills} isSorted isMulti
              />
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            {state.product && (
              <Form.Group>
                <Form.Label className='label' id='PRD_Code'>Product Code</Form.Label>
                <div>
                  <b>
                    {state.product}
                  </b>
                </div>
              </Form.Group>
            )}
          </Col>
          <Col>
            {state.application && (
              <Form.Group>
                <Form.Label className='label' id='domainOwner'>Product/Domain Owner</Form.Label>
                <div>
                  <b>
                    {setDomainOwner(props.applications)}
                  </b>
                </div>
              </Form.Group>
            )}
          </Col>
        </Row>

        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Start Date</Form.Label>
              <DateField
                id='startDate' type='startDate' value={state.startDate}
                onChange={handleEventOnChange}
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>End Date</Form.Label>
              <DateField
                id='endDate' type='endDate' value={state.endDate} onChange={handleEventOnChange}
                startDate={state.startDate}
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Allocation %</Form.Label>
              <InputField
                id='allocation' type='allocation' initialValue={state.allocation}
                onChange={handleEventOnChange} inputType='number' maxValue='100'
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'># of Resources Needed</Form.Label>
              <InputField
                id='requestCount' type='requestCount' initialValue={state.requestCount}
                onChange={handleEventOnChange} inputType='number' maxValue='20'
              />
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            <Form.Group>
              <label className='label'>Role</label>
              <UserInput
                id='role' type='role' onChange={handleChange} initialValue={state.role}
                isSorted
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Resource Type</Form.Label>
              <UserInput
                id='resourceType' type='resourceType' onChange={handleChange}
                initialValue={state.resourceType} isSorted
              />
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Title</Form.Label>
              <UserInput
                id='title' type='title' onChange={handleChange} initialValue={state.title}
                isSorted refValue={state.role}
              />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Degree</Form.Label>
              <UserInput
                id='degree' type='degree' onChange={handleChange} initialValue={state.degree}
                isSorted refValue={isDeveloper}
              />
            </Form.Group>
          </Col>
        </Row>

        <Row>
          <Col>
            <label className='label'>Locations</label>
            <UserInput
              id='locations' type='locations' initialValue={state.locations}
              onChange={handleCheckboxChange} refValue={state.resourceType}
            />
          </Col>
        </Row>

        <Form.Group>
          <Form.Label className='label'>Notes</Form.Label>
          <TextAreaField id='notes' type='notes' onBlur={handleEventOnChange} rows='3' />
        </Form.Group>

        <Button id='saveDraft' type='button' onClick={handleHide}>Save as Draft</Button>
      </Form>
      <PromptedInputModalRRC promptTitle='Name of Draft' onHide={handleHide} showPromptModal={state.showPromptModal} id='draftName' type='draftName' onBlur={handleEventOnChange} inputType='text' isRequired onSubmit={handleSubmit} disableButton={disableButton} />
    </div>

  );
}

export const mapStateToProps = state => ({
  applications: state.RequestResourceReducer.applications,
  templateById: state.RequestTemplatesReducer.template,
  user: state.AuthReducer.user
});

export const mapDispatchToProps = dispatch => ({
  setUserInfo: () => dispatch(setUserInfoThunk()),
  createRequestDraft: (request) => dispatch(createRequestDraftThunk(request)),
  setRequestDraftsByOwner: (user) => dispatch(setRequestDraftsByOwnerThunk(user)),
  setRequestTemplatesByOwner: (user) => dispatch(setRequestTemplatesByOwnerThunk(user)),
  setRequestTemplateById: (templateId) => dispatch(setRequestTemplateByIdThunk(templateId))
});

RequestResourceFormRRC.propTypes = {
  applications: PropTypes.array,
  setUserInfo: PropTypes.func,
  createRequestDraft: PropTypes.func,
  setRequestDraftsByOwner: PropTypes.func,
  setRequestTemplatesByOwner: PropTypes.func,
  setRequestTemplateById: PropTypes.func,
  templateById: PropTypes.object,
  user: PropTypes.object,
  toggle: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RequestResourceFormRRC);
