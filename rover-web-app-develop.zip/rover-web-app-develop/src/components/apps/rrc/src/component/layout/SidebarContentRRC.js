import SidebarLink from "../../../../../layout/sidebar/SidebarLink";
import SidebarCategory from "../../../../../layout/sidebar/SidebarCategory";
import SidebarCreateRequest from "../../../../../layout/sidebar/SidebarCreateRequest";
import React from "react";
import PropTypes from "prop-types";
import { properties } from "../../../../../../properties";
import { connect } from "react-redux";
import { User, Grid, Home, Settings, LogOut, Layers } from "react-feather";

export const SidebarRRC = (props) => {
  const { hideSidebar, logout, user } = props;
  return (
    <div className="sidebar__content">
      <ul className="sidebar__block">
        <SidebarLink
          title="Dashboard"
          icon={() => <Home size="20" strokeWidth={1} />}
          route="/rrc"
          onClick={hideSidebar}
        />
      </ul>
      <ul className="sidebar__block">
        <SidebarLink
          title="My Resources"
          icon={() => <User size="20" strokeWidth={1} />}
          route="/rrc/viewresources"
          onClick={hideSidebar}
        />
      </ul>
      <ul className="sidebar__block">
        <SidebarCategory title="Request" icon={() => <Layers size="20" strokeWidth={1} />}>
          <SidebarCreateRequest />
          <SidebarLink title="Request Drafts" route="/rrc/requestdrafts" onClick={hideSidebar} />
          <SidebarLink
            title="Request Templates"
            route="/rrc/requesttemplates"
            onClick={hideSidebar}
          />
        </SidebarCategory>
      </ul>
      {user && properties.authorizedUploaders.includes(user.id) && (
        <ul className="sidebar__block" id="dataUpload">
          <SidebarLink
            title="Data Upload"
            icon="license"
            route="/rrc/admin/upload"
            onClick={hideSidebar}
          />
        </ul>
      )}
      {/* Do condition render for following tag */}
      <ul className="sidebar__block">
        <SidebarCategory title="Apps" icon={() => <Grid size="20" strokeWidth={1} />}>
          <SidebarLink title="Rover Suite" route="/" onClick={hideSidebar} />
          <SidebarLink title="Rover SOG" route="/sog" onClick={hideSidebar} />
          <SidebarLink title="Rover Skills Central" route="/skillscentral" onClick={hideSidebar} />
          <SidebarLink title="Rover PCDM" route="/pcdm" onClick={hideSidebar} />
        </SidebarCategory>
      </ul>
      <ul className="sidebar__block">
        <SidebarLink
          title="Theme"
          icon={() => <Settings size="20" strokeWidth={1} />}
          route="/setting/theme"
          onClick={hideSidebar}
        />
      </ul>
      <ul className="sidebar__block">
        <SidebarLink
          title="Log Out"
          icon={() => <LogOut size="20" strokeWidth={1}></LogOut>}
          onClick={logout}
        />
      </ul>
    </div>
  );
};

export const mapStateToProps = (state) => ({
  user: state.AuthReducer.user,
});

SidebarRRC.propTypes = {
  logout: PropTypes.func.isRequired,
  hideSidebar: PropTypes.func.isRequired,
  user: PropTypes.object,
};

export default connect(mapStateToProps)(SidebarRRC);
