import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Col, Form, Modal, Row } from 'react-bootstrap';
import InputField from '../../../../../../../shared/components/form/UserInput/InputField';
import UserInput from '../../../../../../../shared/components/form/UserInput';
import { updateRequestTemplateThunk, deleteRequestTemplateThunk } from '../../../store';
import { connect } from 'react-redux';
import ButtonToolbar from 'react-bootstrap/ButtonToolbar';

const RequestTemplateDetailsRRC = (props) => {
  const initialState = {
    id: props.childProps.template.id || '',
    templateOwner: props.childProps.template.templateOwner || '',
    templateName: props.childProps.template.templateName || '',
    portfolio: props.childProps.template.portfolioIdentifier || '',
    product: props.childProps.template.productIdentifier || '',
    application: props.childProps.template.applicationIdentifier || '',
    allocation: props.childProps.template.allocation || '',
    role: props.childProps.template.role || '',
    skills: props.childProps.template.skills || [],
    resourceType: props.childProps.template.resourceType || '',
    title: props.childProps.template.title || '',
    degree: props.childProps.template.degree || '',
    locations: props.childProps.template.locations || [],
    requestCount: props.childProps.template.requestCount || 1,
    showTemplateDetails: props.childProps.showTemplateDetails || ''
  };

  const [state, setState] = useState(initialState);
  /* React Hook (update state properties) */
  const [isEdit, setIsEdit] = useState(true);
  const [tempEdit, setTempEdit] = useState(false);

  useEffect(() => {
    setState(initialState);
    setTempEdit(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.childProps.template]);

  useEffect(() => {
    if (tempEdit) {
      setState({
        ...state,
        product: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.portfolio]);

  useEffect(() => {
    if (tempEdit) {
      setState({
        ...state,
        application: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.product]);

  useEffect(() => {
    if (tempEdit) {
      setState({
        ...state,
        title: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.role]);

  useEffect(() => {
    if (tempEdit) {
      setState(({
        ...state,
        degree: ''
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.title]);

  const handleIsEdit = () => {
    setIsEdit(!isEdit);
  };

  // Event Handler Methods
  const handleChange = async (value, action) => {
    const field = action.name;
    if (value) {
      setTempEdit(true);
      await setState({
        ...state,
        [field]: value.value
      });
    } else {
      setTempEdit(true);
      await setState({
        ...state,
        [field]: ''
      });
    }
  };
  const handleEventOnChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.value
    });
  };

  const handleMultiSelectChange = (skills) => {
    if (skills) {
      skills = skills.map(skill => {
        return skill.label;
      });
    } else {
      skills = [];
    }
    setState({
      ...state,
      skills
    });
  };

  // Checkbox need to push the selection to what we passed in, or the selection will be reset everytime.
  const handleCheckboxChange = (event) => {
    if (props.childProps.template.locations.includes(event.target.value)) {
      props.childProps.template.locations = props.childProps.template.locations.filter(item => item !== event.target.value);
    } else {
      props.childProps.template.locations.push(event.target.value);
    }
    setState({
      ...state,
      locations: props.childProps.template.locations
    });
  };

  const handleDelete = async () => {
    await props.deleteRequestTemplate(state.id);
    props.handleCloseView();
    props.onUpdateToTemplate();
    setState({
      id: '',
      templateOwner: '',
      templateName: '',
      portfolio: '',
      product: '',
      application: '',
      allocation: '',
      role: '',
      skills: [],
      resourceType: '',
      title: '',
      degree: '',
      locations: [],
      requestCount: 1,
      showTemplateDetails: ''
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const requestTemplate = {
      id: state.id,
      templateOwner: state.templateOwner || null,
      templateName: state.templateName || null,
      portfolioIdentifier: state.portfolio || null,
      productIdentifier: state.product || null,
      applicationIdentifier: state.application || null,
      allocation: state.allocation || null,
      role: state.role || null,
      title: state.title || null,
      degree: state.degree || null,
      skills: state.skills || null,
      locations: state.locations ? state.locations.filter(location => (state.resourceType === 'EMPLOYEE' ? location !== 'OFFSHORE' : location)) : null,
      resourceType: state.resourceType || null,
      requestCount: state.requestCount || null
    };
    await props.updateRequestTemplate(state.id, requestTemplate);
    props.onUpdateToTemplate();
  };

  const isDeveloper = (state.role === 'DEVELOPER' && state.title);
  return (
    <Form
      onSubmit={handleSubmit} onKeyPress={e => {
        if (e.key === 'Enter') e.preventDefault();
      }}
    >
      <div className='container'>
        <Modal.Header className='row'>
          <Modal.Title id='contained-modal-title-vcenter'>
            <Row>
              <Col xl>
                {((!state.templateName) || (isEdit)) ? <InputField id='templateName' type='templateName' inputType='text' initialValue={state.templateName} onChange={handleEventOnChange} onEnter={handleIsEdit} placeholder='Enter Template Name' isRequired /> : <div className='text-nowrap' onClick={handleIsEdit}>{state.templateName}</div>}
              </Col>
              <Col>
                <div onClick={handleIsEdit}>
                  <span className='fa fa-edit' />
                </div>
              </Col>
            </Row>
          </Modal.Title>
          <button type='button' className='close' aria-label='Close' onClick={props.handleCloseView}>
            <span aria-hidden='true'>&times;</span>
          </button>
        </Modal.Header>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Portfolio</Form.Label>
              <UserInput id='portfolio' type='portfolio' onChange={handleChange} initialValue={state.portfolio} isSorted />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Product</Form.Label>
              <UserInput id='product' type='product' onChange={handleChange} initialValue={state.product} isSorted refValue={state.portfolio} />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Application</Form.Label>
              <UserInput id='application' type='application' onChange={handleChange} initialValue={state.application} isSorted refValue={state.product} />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Skills</Form.Label>
              <UserInput id='skills' type='skills' onChange={handleMultiSelectChange} initialValue={state.skills} isSorted isMulti />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Allocation %</Form.Label>
              <InputField id='allocation' type='allocation' initialValue={state.allocation} onChange={handleEventOnChange} inputType='number' maxValue='100' />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'># of Resources Needed</Form.Label>
              <InputField id='requestCount' type='requestCount' initialValue={state.requestCount} onChange={handleEventOnChange} inputType='number' maxValue='20' />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <label className='label'>Role</label>
              <UserInput id='role' type='role' onChange={handleChange} initialValue={state.role} isSorted />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Resource Type</Form.Label>
              <UserInput id='resourceType' type='resourceType' onChange={handleChange} initialValue={state.resourceType} isSorted />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Title</Form.Label>
              <UserInput id='title' type='title' onChange={handleChange} initialValue={state.title} isSorted refValue={state.role} />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Degree</Form.Label>
              <UserInput id='degree' type='degree' onChange={handleChange} initialValue={state.degree} isSorted refValue={isDeveloper} />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <label className='label'>Locations</label>
            <UserInput id='locations' type='locations' initialValue={state.locations} onChange={handleCheckboxChange} refValue={state.resourceType} />
          </Col>
        </Row>
        <Modal.Footer />
        <ButtonToolbar className='justify-content-lg-between'>
          <div className='btn-group'>
            <Button variant='danger' type='button' onClick={handleDelete}>Delete Template</Button>
          </div>
          <div className='btn-group'>
            <Button className='btn' type='submit'>Update Template</Button>
          </div>
        </ButtonToolbar>
      </div>
    </Form>
  );
};

export const mapDispatchToProps = dispatch => ({
  updateRequestTemplate: (templateId, template) => dispatch(updateRequestTemplateThunk(templateId, template)),
  deleteRequestTemplate: (templateId) => dispatch(deleteRequestTemplateThunk(templateId))
});

RequestTemplateDetailsRRC.propTypes = {
  childProps: PropTypes.shape({
    template: PropTypes.object.isRequired,
    showTemplateDetails: PropTypes.bool
  }),
  handleCloseView: PropTypes.func,
  onUpdateToTemplate: PropTypes.func,
  deleteRequestTemplate: PropTypes.func,
  updateRequestTemplate: PropTypes.func
};

export default connect(null, mapDispatchToProps)(RequestTemplateDetailsRRC);
