import React from 'react';
import Enzyme, { shallow } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import mockAxios from 'axios';
import { AddResourceFormRRC, mapDispatchToProps, mapStateToProps } from './addResourceFormRRC';

// Import Mock Data
import { resource, locations, resourceTypes, degrees, roles, titles } from '../../../../../../test_fixtures/mock_data';
import { CHANGE } from '../../../../../../test_fixtures/test_constants';

// Redux store which includes Reducers, Action Creators, and Middleware
import ResourcesReducer, {
  ADD_RESOURCE,
  addResource,
  addResourceThunk
} from '../../store/ResourcesRRC';
import FieldsReducer, {
  SET_LOCATIONS,
  SET_RESOURCE_TYPES,
  SET_ROLES,
  SET_TITLES,
  SET_DEGREES,
  setLocations,
  setLocationsThunk,
  setResourceTypes,
  setResourceTypesThunk,
  setRoles,
  setRolesThunk,
  setTitles,
  setTitlesThunk,
  setDegrees,
  setDegreesThunk
} from '../../store/FieldsRRC';

// for enzyme to work with react 16 and up
Enzyme.configure({ adapter: new EnzymeAdapter() });

// This is to set up mock store for redux
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => store = mockStore();

const baseProps = {
  addResourceThunks: jest.fn(),
  locations: [],
  resourceTypes: [],
  roles: [],
  titles: [],
  degrees: [],
  user: {}
};

let component = null;

describe('addResourceForm component', () => {
  beforeEach(() => {
    component = shallow(<AddResourceFormRRC {...baseProps} />).setState({ role: 'DEVELOPER' });
  });

  describe('Renders with the correct data', () => {
    it('resourceForm renders in UI without crashing', async () => {
      const wrapper = shallow(
        <AddResourceFormRRC {...baseProps} />
      );
      expect(wrapper).toMatchSnapshot();
    });

    it('setFields renders correct fields on the form', () => {
      const inputLabels = component.find('.label');
      expect(inputLabels).toHaveLength(12);
    });

    it('correct number fields on the form render when the conditions for conditional rendering fields are met', () => {
      component.setState({
        selectedPortfolio: 'DevOps',
        selectedProduct: 'PRD00000123'
      });
      const updatedInputLabels = component.find('.label');
      expect(updatedInputLabels).toHaveLength(12);
    });
  });

  describe('Changes State Correctly', () => {
    it('Should capture resourceId correctly onChange', () => {
      const input = component.find('#resourceId');
      input.simulate(CHANGE, {
        target: {
          name: 'resourceId',
          value: 'resourceId'
        }
      });
      expect(component.state().resourceId).toEqual('resourceId');
    });

    it('Should capture firstName correctly onChange', () => {
      const input = component.find('#firstName');
      input.simulate(CHANGE, {
        target: {
          name: 'firstName',
          value: 'firstName'
        }
      });
      expect(component.state().firstName).toEqual('firstName');
    });

    it('Should capture lastName correctly onChange', () => {
      const input = component.find('#lastName');
      input.simulate(CHANGE, {
        target: {
          name: 'lastName',
          value: 'lastName'
        }
      });
      expect(component.state().lastName).toEqual('lastName');
    });

    it('Should capture manager correctly onChange', () => {
      const input = component.find('#manager');
      input.simulate(CHANGE, {
        target: {
          name: 'manager',
          value: 'manager'
        }
      });
      expect(component.state().manager).toEqual('manager');
    });

    it('Should capture isActive correctly onChange', () => {
      const input = component.find('#isActive');
      input.simulate(CHANGE, {
        target: {
          name: 'isActive',
          checked: true
        }
      });
      expect(component.state().isActive).toEqual(true);
    });

    it('Should capture email correctly onChange', () => {
      const input = component.find('#email');
      input.simulate(CHANGE, {
        target: {
          name: 'email',
          value: 'email@123.com'
        }
      });
      expect(component.state().email).toEqual('email@123.com');
    });

    it('Should capture phone correctly onChange', () => {
      const input = component.find('#phone');
      input.simulate(CHANGE, {
        target: {
          name: 'phone',
          value: '12345678'
        }
      });
      expect(component.state().phone).toEqual('12345678');
    });

    it('Should capture resourceType correctly onChange', () => {
      const input = component.find('#resourceType');
      const event = {
        target: {
          name: 'resourceType',
          value: 'CONTRACTOR'
        }
      };
      input.simulate(CHANGE, event);
      expect(component.state().resourceType).toEqual('CONTRACTOR');
    });

    it('Should capture location correctly onChange', () => {
      const input = component.find('#location');
      input.simulate(CHANGE, {
        target: {
          name: 'location',
          value: 'AUSTIN'
        }
      });
      expect(component.state().location).toEqual('AUSTIN');
    });

    it('Should capture role correctly onChange', () => {
      const input = component.find('#role');
      input.simulate(CHANGE, {
        target: {
          name: 'role',
          value: 'DEVELOPER'
        }
      });
      expect(component.state().role).toEqual('DEVELOPER');
    });

    it('Should capture title correctly onChange', () => {
      const input = component.find('#title');
      input.simulate(CHANGE, {
        target: {
          name: 'title',
          value: 'DEVELOPER'
        }
      });
      expect(component.state().title).toEqual('DEVELOPER');
    });

    it('Should capture degree correctly onChange', () => {
      const input = component.find('#degree');
      input.simulate(CHANGE, {
        target: {
          name: 'degree',
          value: '1'
        }
      });
      expect(component.state().degree).toEqual('1');
    });

    it('onSubmit should submit the current state and clear', async () => {
      const mockPreventDefault = jest.fn();
      const startingstate = {
        resourceId: 'X999998',
        firstName: 'firstName',
        lastName: 'lastName',
        manager: 'manager',
        isActive: true,
        email: 'email@gmail',
        phone: '1234567890',
        resourceType: '1',
        locations,
        resourceTypes,
        roles,
        degrees,
        titles,
        location: '1',
        role: '1',
        title: '1',
        degree: '1'
      };
      const expected = {
        resourceId: '',
        firstName: '',
        lastName: '',
        manager: '',
        isActive: false,
        email: '',
        phone: '',
        resourceType: '',
        locations,
        resourceTypes,
        roles,
        degrees,
        titles,
        location: '',
        role: '',
        title: '',
        degree: ''
      };
      component = shallow(<AddResourceFormRRC {...baseProps} />).setState(startingstate);
      await component.find('form').simulate('submit', { preventDefault: mockPreventDefault });
      expect(component.state()).toEqual(expected);
    });
  });
});

describe('Redux Store for Resources', () => {
  beforeEach(() => {
    resetStore();
  });
  describe('Resources Store Actions', () => {
    it('should create an action to add a resource', () => {
      const expectedAction = {
        type: ADD_RESOURCE,
        resource
      };
      expect(addResource(resource)).toEqual(expectedAction);
    });

    it('should create an action to set resource types', () => {
      const expectedAction = {
        type: SET_RESOURCE_TYPES,
        resourceTypes
      };
      expect(setResourceTypes(resourceTypes)).toEqual(expectedAction);
    });
  });

  describe('Resources Thunk Middleware', () => {
    it('Axios POST call should get the correct response for add resource', async () => {
      mockAxios.post.mockImplementationOnce(() => Promise.resolve({ data: resource }));
      const expectedActions = [
        {
          type: ADD_RESOURCE,
          resource
        }
      ];
      await store.dispatch(addResourceThunk(resource));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.post).toHaveBeenCalledWith('/v1/resources', resource);
    });

    it('handleSubmit calls addResourceThunks middleware', async () => {
      const mockEvent = {
        preventDefault: jest.fn()
      };
      const wrapper = shallow(<AddResourceFormRRC {...baseProps} />);
      const expected = {
        resourceId: 'X999998',
        firstName: 'firstName',
        lastName: 'lastName',
        manager: 'manager',
        isActive: true,
        email: 'email@gmail',
        phone: '1234567890',
        resourceType: '1',
        location: '1',
        role: '1',
        title: '1',
        degree: '1'
      };
      wrapper.setState({
        resourceId: 'X999998',
        firstName: 'firstName',
        lastName: 'lastName',
        manager: 'manager',
        isActive: true,
        email: 'email@gmail',
        phone: '1234567890',
        resourceType: '1',
        location: '1',
        role: '1',
        title: '1',
        degree: '1'
      });
      wrapper.instance().handleSubmit(mockEvent);
      expect(baseProps.addResourceThunks).toHaveBeenCalledWith(expected);
    });
  });

  describe('Resources Reducer', () => {
    it('should return the initial state', () => {
      expect(ResourcesReducer([], {})).toEqual([]);
    });

    it('should handle ADD_RESOURCE', () => {
      expect(ResourcesReducer([], {
        type: ADD_RESOURCE,
        resource
      }))
        .toEqual([]);
    });
  });
});

describe('Redux Store for addResourceForm Fields', () => {
  beforeEach(() => {
    resetStore();
  });

  describe('Field Store Actions', () => {
    it('should create an action to set locations', () => {
      const expectedAction = {
        type: SET_LOCATIONS,
        locations
      };
      expect(setLocations(locations)).toEqual(expectedAction);
    });

    it('should create an action to set roles', () => {
      const expectedAction = {
        type: SET_ROLES,
        roles
      };
      expect(setRoles(roles)).toEqual(expectedAction);
    });

    it('should create an action to set titles', () => {
      const expectedAction = {
        type: SET_TITLES,
        titles
      };
      expect(setTitles(titles)).toEqual(expectedAction);
    });

    it('should create an action to set degrees', () => {
      const expectedAction = {
        type: SET_DEGREES,
        degrees
      };
      expect(setDegrees(degrees)).toEqual(expectedAction);
    });
  });

  describe('Fields Thunk Middleware', () => {
    it('Axios GET call should get the correct response for set locations', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: locations } }));
      const expectedActions = [
        {
          type: SET_LOCATIONS,
          locations
        }
      ];
      await store.dispatch(setLocationsThunk(locations.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/locations');
    });

    it('Axios GET call should get the correct response for set roles', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: roles } }));
      const expectedActions = [
        {
          type: SET_ROLES,
          roles
        }
      ];
      await store.dispatch(setRolesThunk(roles.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/roles');
    });

    it('Axios GET call should get the correct response for set resource types', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: resourceTypes } }));
      const expectedActions = [
        {
          type: SET_RESOURCE_TYPES,
          resourceTypes
        }
      ];
      await store.dispatch(setResourceTypesThunk(resourceTypes.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/resourcetypes');
    });

    it('Axios GET call should get the correct response for set titles', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: titles } }));
      const expectedActions = [
        {
          type: SET_TITLES,
          titles
        }
      ];
      await store.dispatch(setTitlesThunk(titles.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/titles');
    });

    it('Axios GET call should get the correct response for set degrees', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: degrees } }));
      const expectedActions = [
        {
          type: SET_DEGREES,
          degrees
        }
      ];
      await store.dispatch(setDegreesThunk(degrees.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/degrees');
    });
  });

  describe('Fields Reducer', () => {
    const initialState = {
      resourceTypes: [], locations: [], roles: [], titles: [], degrees: []
    };

    it('should return the initial state', () => {
      expect(FieldsReducer(initialState, {})).toEqual({
        resourceTypes: [],
        locations: [],
        roles: [],
        titles: [],
        degrees: []
      });
    });

    it('should handle SET_RESOURCE_TYPES', () => {
      expect(FieldsReducer({ resourceTypes: [] }, {
        type: SET_RESOURCE_TYPES,
        resourceTypes
      }))
        .toEqual({
          resourceTypes
        });
    });

    it('should handle SET_LOCATIONS', () => {
      expect(FieldsReducer({ locations: [] }, {
        type: SET_LOCATIONS,
        locations
      }))
        .toEqual({
          locations
        });
    });

    it('should handle SET_ROLES', () => {
      expect(FieldsReducer({ roles: [] }, {
        type: SET_ROLES,
        roles
      }))
        .toEqual({
          roles
        });
    });

    it('should handle SET_TITLES', () => {
      expect(FieldsReducer({ titles: [] }, {
        type: SET_TITLES,
        titles
      }))
        .toEqual({
          titles
        });
    });

    it('should handle SET_DEGREES', () => {
      expect(FieldsReducer({ degrees: [] }, {
        type: SET_DEGREES,
        degrees
      }))
        .toEqual({
          degrees
        });
    });
  });
});

describe('mapStateToProps, mapDispatchToProps, setOptionsForDropdown', () => {
  it('mapStateToProps should have correct initial state', () => {
    const initialState = {
      FieldsReducer: {
        locations: [],
        roles: [],
        titles: [],
        degrees: []
      },
      AuthReducer: {
        user: {}
      }
    };

    expect(mapStateToProps(initialState)).toEqual = ({
      locations: [],
      roles: [],
      titles: [],
      degrees: [],
      user: {}
    });
  });

  it('mapDispatchToProps should dispatch action when form submit', () => {
    const dispatch = jest.fn();

    const props = mapDispatchToProps(dispatch);

    props.addResourceThunks(resource);

    expect(dispatch).toHaveBeenCalledTimes(1);
  });
});
