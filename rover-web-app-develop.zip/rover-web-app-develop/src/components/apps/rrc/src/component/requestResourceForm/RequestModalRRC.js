import React from 'react';
import { Modal } from 'react-bootstrap';
import RequestResourceForm from './requestResourceFormRRC';
import PropTypes from 'prop-types';
import CreateRequestTemplate from '../requestTemplates/createRequestTemplate/createRequestTemplateRRC';

const RequestModalRRC = (props) => {
  const { show, toggle, type } = props;
  return (
    <Modal
      show={show}
      size='lg'
      aria-labelledby='contained-modal-title-vcenter'
      centered
      onHide={toggle}
      backdrop='static'
      keyboard={false}
    >
      <Modal.Header closeButton>
        <Modal.Title id='contained-modal-title-vcenter'>
          {type === 'template' ? 'Create Request Template' : 'Create Request'}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {type === 'template' ? <CreateRequestTemplate toggle={toggle} /> : <RequestResourceForm toggle={toggle} />}
      </Modal.Body>
    </Modal>
  );
};

RequestModalRRC.propTypes = {
  show: PropTypes.bool,
  toggle: PropTypes.func,
  type: PropTypes.string
};

export default RequestModalRRC;
