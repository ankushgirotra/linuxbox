import React from 'react';
import { configure, shallow } from 'enzyme/build';
import Adapter from 'enzyme-adapter-react-16/build';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import RequestModalRRC from './RequestModalRRC';

// for enzyme to work
configure({ adapter: new Adapter() });

let component = null;

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
const store = mockStore();

describe('RequestModal component', () => {
  beforeEach(() => {
    component = shallow(<RequestModalRRC />);
  });

  describe('Have the request modal generate', () => {
    it('Should have request render correctly', () => {
      expect(component.debug()).toMatchSnapshot();
    });
  });
});
