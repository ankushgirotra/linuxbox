import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Dropzone from 'react-dropzone';

import { uploadDataThunk } from '../../../../../../store';

export class AdminUploadRRC extends Component {
  constructor (props) {
    super(props);
    this.state = {
      files: [],
      dataUploadDropdownOptions: ['Portfolio', 'Product', 'Application', 'Skill']
    };
  }

  handleFileUpload = (files) => {
    this.setState({ files });
  };

  handleSubmit = async () => {
    const { uploadDataThunks } = this.props;
    await this.state.files.forEach(file => uploadDataThunks(file));
    this.setState({
      files: []
    });
  };

  setOptionsForDropdown = array => (
    array.map(item => (
      <option
        key={item}
        value={item}
      >
        {item}
      </option>
    )));

  handleChange = async (event) => {
    if (event.target.name.toLowerCase().includes(event.target.value.toLowerCase())) {
      await this.setState({
        files: this.state.files.map((item) => {
          if (item.name === event.target.name) {
            item.dataType = event.target.value;
            return item;
          }
          return item;
        })
      });
    } else {
      console.error('Please check that the file name(s) match the data type(s) selected.');
      this.setState({
        files: []
      });
    }
  };

  render () {
    const files = this.state.files.map(file => (
      <div key={file}>
        <li key={file.name}>
          {file.name}
        </li>
        <div className='control'>
          <select
            required
            className='input is-primary'
            name={file.name}
            id='uploadData'
            value={file.dataType}
            onChange={this.handleChange}
          >
            <option value=''>--- Please Select the Data Type ---</option>
            {this.setOptionsForDropdown(this.state.dataUploadDropdownOptions)}
          </select>
        </div>
      </div>
    ));
    return (
      <div>
        <Dropzone
          onDrop={this.handleFileUpload} style={{
            width: '50px',
            height: '20%',
            border: '1px solid black'
          }}
        >
          {({ getRootProps, getInputProps }) => (
            <section className='container has-text-centered' style={{ marginTop: '20%' }}>
              <div {...getRootProps({ className: 'dropzone' })}>
                <input {...getInputProps({ accept: '.csv' })} />
                <button className='button is-primary is-large' id='uploadButton'>Upload Files</button>
              </div>
            </section>
          )}
        </Dropzone>
        <div className='columns is-centered'>
          <div className='column has-text-centered is-3'>
            <aside className='box' style={{ marginTop: '30px' }}>
              <h4 className='is-size-5'><b>Files Uploaded</b></h4>
              <ul>{files}</ul>
            </aside>
          </div>
        </div>
        <div className='columns has-text-centered'>
          <div className='column is-centered'>
            <button className='button is-danger is-large' id='confirmUploadButton' onClick={this.handleSubmit}>Confirm
              Upload
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export const mapDispatchToProps = dispatch => ({
  uploadDataThunks: file => dispatch(uploadDataThunk(file))
});

AdminUploadRRC.propTypes = {
  uploadDataThunks: PropTypes.func
};

export default connect(null, mapDispatchToProps)(AdminUploadRRC);
