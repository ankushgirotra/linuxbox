import React from 'react';
import Enzyme, { shallow } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import mockAxios from 'axios';

// Import Mock Data
import { resources, tableHeaders, keysFromData } from '../../../../../../test_fixtures/mock_data';

// Redux store which includes Reducers, Action Creators, and Middleware
import ResourcesReducer, {
  SET_RESOURCES,
  setResources,
  setResourcesThunk
} from '../../store/ResourcesRRC';

import ViewResources, { mapStateToProps } from './viewResourcesRRC';
import Table from '../../../../../../shared/components/view/Table';

// for enzyme to work with react 16 and up
Enzyme.configure({ adapter: new EnzymeAdapter() });

// This is to set up mock store for redux
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => store = mockStore();

let component = null;
let table = null;

describe('View Resource component', () => {
  beforeEach(() => {
    component = shallow(<ViewResources store={store} />);
    table = shallow(
      <Table
        store={store}
        data={resources}
        headers={tableHeaders}
        keys={keysFromData}
      />);
  });

  it('renders correctly', () => {
    expect(component).toMatchSnapshot();
  });
});

describe('Redux Store for Resources', () => {
  beforeEach(() => {
    resetStore();
  });
  describe('Resources Store Actions', () => {
    it('should create an action to set resources', () => {
      const expectedAction = {
        type: SET_RESOURCES,
        resources
      };
      expect(setResources(resources)).toEqual(expectedAction);
    });
  });

  describe('Resources Thunk Middleware', () => {
    it('Axios GET call should get the correct response for set resource', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: resources } }));
      const expectedActions = [
        {
          type: SET_RESOURCES,
          resources
        }
      ];
      await store.dispatch(setResourcesThunk(resources.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/resources');
    });
  });

  describe('Resources Reducer', () => {
    it('should return the initial state', () => {
      expect(ResourcesReducer(undefined, {})).toEqual([]);
    });

    it('should handle SET_RESOURCES appropriately', () => {
      expect(ResourcesReducer([], {
        type: SET_RESOURCES,
        resources
      }))
        .toEqual(resources);
    });
  });
});

describe('table mapStateToProps should have correct initial state', () => {
  it('renders correctly', () => {
    const initialState = { ResourcesReducer: [] };

    expect(mapStateToProps(initialState)).toEqual = ([]);
  });
});
