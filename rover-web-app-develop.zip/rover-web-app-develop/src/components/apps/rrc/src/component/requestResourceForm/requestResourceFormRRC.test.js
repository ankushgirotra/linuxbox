import React from 'react';
import Enzyme, { shallow } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import mockAxios from 'axios';

// Import Mock Data
import {
  portfolios,
  products,
  applications,
  skills,
  request,
  requestTemplate
} from '../../../../../../test_fixtures/mock_data';
import { CHANGE } from '../../../../../../test_fixtures/test_constants';

// Redux store which includes Reducers, Action Creators, and Middleware
import RequestResourceReducer, { createRequestDraft, createRequestDraftThunk } from '../../store/RequestResourceRRC';
import FieldsReducer from '../../store/FieldsRRC';

import {
  SET_APPLICATIONS,
  SET_PORTFOLIOS,
  SET_PRODUCTS,
  SET_SKILLS,
  CREATE_REQUEST_DRAFT,
  setSkills,
  setApplications,
  setApplicationsThunk,
  setPortfolios,
  setSkillsThunk,
  setPortfoliosThunk,
  setProducts,
  setProductsThunk
} from '../../../../../../store';
import { RequestResourceFormRRC, mapStateToProps } from './requestResourceFormRRC';
import ShallowRenderer from 'react-test-renderer/shallow';

// for enzyme to work with react 16 and up
Enzyme.configure({ adapter: new EnzymeAdapter() });

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => store = mockStore();

const baseProps = {
  requestOwner: '',
  applications: applications,
  locations: '',
  setApplications: jest.fn(),
  createRequestDraft: jest.fn(),
  user: { id: 'user' },
  setUserInfo: jest.fn()
};

let component = null;
describe('requestResourceForm React component', () => {
  beforeEach(() => {
    component = shallow(<RequestResourceFormRRC {...baseProps} store={store} templateById={requestTemplate} />);
  });

  it('requestResourceForm renders in UI without crashing', async () => {
    const renderer = new ShallowRenderer();
    const result = renderer.render(<RequestResourceFormRRC {...baseProps} templateById={requestTemplate} store={store} />);
    expect(result).toMatchSnapshot();
  });

  describe('Helper Method: handleChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestResourceFormRRC {...baseProps} store={store} templateById={requestTemplate} />);
    });
    it('properly changes state for portfolio', () => {
      const input = component.find('#portfolio');
      input.simulate(CHANGE, { value: '3' }, { name: '3' });
      expect(input.props().initialValue).toEqual('3');
    });
    it('properly changes state for product', () => {
      const input = component.find('#product');
      input.simulate(CHANGE, { value: 'PRD00000195' }, { name: 'product' });
      expect(input.props().initialValue).toEqual('PRD00000195');
    });
    it('properly changes state for application', () => {
      const input = component.find('#application');
      input.simulate(CHANGE, { value: 'APP00006038' }, { name: 'application' });
      expect(input.props().initialValue).toEqual('APP00006038');
    });
    it('Should capture role correctly onChange', () => {
      const input = component.find('#role');
      input.simulate(CHANGE, { value: 'DEVELOPER' }, { name: 'role' });
      expect(input.props().initialValue).toEqual('DEVELOPER');
    });
    it('Should capture title correctly onChange', () => {
      const input = component.find('#title');
      input.simulate(CHANGE, { value: 'ASSOC_DEVELOPER' }, { name: 'title' });
      expect(input.props().initialValue).toEqual('ASSOC_DEVELOPER');
    });
    it('Should capture degree correctly onChange', () => {
      const input = component.find('#degree');
      input.simulate(CHANGE, { value: 'SECOND_DEGREE' }, { name: 'degree' });
      expect(input.props().initialValue).toEqual('SECOND_DEGREE');
    });
    it('Should capture resourceType correctly', () => {
      const input = component.find('#resourceType');
      input.simulate(CHANGE, { value: 'EMPLOYEE' }, { name: 'resourceType' });
      expect(input.props().initialValue).toEqual('EMPLOYEE');
    });
  });
  describe('Helper method: handleMultiSelectChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestResourceFormRRC {...baseProps} store={store} templateById={requestTemplate} />);
    });
    it('Should capture skills correctly onChange', () => {
      const expectedState = ['JAVA', 'Python'];
      const selectElement = component.find('#skills');
      selectElement.simulate(CHANGE, [{ value: '001', label: 'JAVA' }, { value: '002', label: 'Python' }]);
      expect(selectElement.props().initialValue).toEqual(expectedState);
    });
  });
  describe('Helper method: handleCheckboxChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestResourceFormRRC {...baseProps} store={store} templateById={requestTemplate} />);
    });
    it('Should capture locations correctly onChange', () => {
      const input = component.find('#locations');
      input.simulate(CHANGE, { target: { name: 'locations', value: 'CHICAGO' } });
      expect(input.props().initialValue).toEqual(['CHICAGO', 'TELECOMMUTER', 'TULSA']);
    });
  });
});

describe('Redux Store for RequestResourceForm', () => {
  beforeEach(() => {
    resetStore();
  });
  describe('RequestResource Store Actions', () => {
    it('should create an action to set portfolios', () => {
      const expectedAction = {
        type: SET_PORTFOLIOS,
        portfolios
      };
      expect(setPortfolios(portfolios)).toEqual(expectedAction);
    });

    it('should create an action to set products', () => {
      const expectedAction = {
        type: SET_PRODUCTS,
        products
      };
      expect(setProducts(products)).toEqual(expectedAction);
    });

    it('should create an action to set applications', () => {
      const expectedAction = {
        type: SET_APPLICATIONS,
        applications
      };
      expect(setApplications(applications)).toEqual(expectedAction);
    });
    it('should create an action to set skills', () => {
      const expectedAction = {
        type: SET_SKILLS, skills
      };
      expect(setSkills(skills)).toEqual(expectedAction);
    });
    it('should create an action for create request draft', () => {
      const expectedAction = {
        type: CREATE_REQUEST_DRAFT, request
      };
      expect(createRequestDraft(request)).toEqual(expectedAction);
    });
  });

  describe('RequestResource Thunk Middleware', () => {
    it('Axios GET request should get correct response for set portfolios', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: portfolios } }));
      const expectedActions = [
        {
          type: SET_PORTFOLIOS,
          portfolios
        }
      ];
      await store.dispatch(setPortfoliosThunk(portfolios.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/portfolios');
    });

    it('Axios GET request should get correct response for set products', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: products } }));
      const expectedActions = [
        {
          type: SET_PRODUCTS,
          products
        }
      ];
      await store.dispatch(setProductsThunk(products.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/products');
    });

    it('Axios GET request should get correct response for set applications', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: applications } }));
      const expectedActions = [
        {
          type: SET_APPLICATIONS,
          applications
        }
      ];
      await store.dispatch(setApplicationsThunk(applications.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/applications');
    });
    it('Axios GET request should get correct response for set skills', async () => {
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: skills } }));
      const expectedActions = [
        { type: SET_SKILLS, skills }
      ];
      await store.dispatch(setSkillsThunk(skills.data));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/skills');
    });
    it('Axios POST request should get the correct response for create request draft', async () => {
      mockAxios.post.mockImplementationOnce(() => Promise.resolve({ request }));
      const expectedActions = [
        {
          type: CREATE_REQUEST_DRAFT,
          request
        }
      ];
      await store.dispatch(createRequestDraftThunk(request));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.post).toHaveBeenCalledWith('/v1/requestdrafts', request);
    });
  });

  describe('RequestResource Reducer', () => {
    const initialState = {
      portfolios: [],
      products: [],
      applications: []
    };

    it('should return the initial state', () => {
      expect(RequestResourceReducer(initialState, {})).toEqual({
        portfolios: [],
        products: [],
        applications: []
      });
    });

    it('should handle SET_PORTFOLIOS', () => {
      expect(RequestResourceReducer({ portfolios: [] }, {
        type: SET_PORTFOLIOS,
        portfolios
      }))
        .toEqual({
          portfolios
        });
    });

    it('should handle SET_PRODUCTS', () => {
      expect(RequestResourceReducer({ products: [] }, {
        type: SET_PRODUCTS,
        products
      }))
        .toEqual({
          products
        });
    });

    it('should handle SET_APPLICATIONS', () => {
      expect(RequestResourceReducer({ applications: [] }, {
        type: SET_APPLICATIONS,
        applications
      }))
        .toEqual({
          applications
        });
    });

    it('should handle SET_SKILLS', () => {
      expect(FieldsReducer({ skills: [] }, { type: SET_SKILLS, skills }))
        .toEqual({
          skills
        });
    });
  });
});

describe('mapStateToProps', () => {
  it('mapStateToProps should have correct initial state', () => {
    const initialState = {
      RequestResourceReducer: {
        applications: []
      },
      AuthReducer: {
        user: { id: '' }
      },
      RequestTemplatesReducer: {
        template: {}
      }
    };
    expect(mapStateToProps(initialState)).toEqual({
      applications: [],
      user: { id: '' },
      templateById: {}
    });
  });
});
