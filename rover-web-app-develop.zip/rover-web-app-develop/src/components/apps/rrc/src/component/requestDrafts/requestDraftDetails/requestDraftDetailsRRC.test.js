import React from 'react';
import Enzyme, { shallow } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import ShallowRenderer from 'react-test-renderer/shallow';

// Import Mock Data
import {
  requestDraft, updateDraft
} from '../../../../../../../test_fixtures/mock_data';

import { RequestDraftDetailsRRC } from './requestDraftDetailsRRC';
import {
  DELETE_REQUEST_DRAFT,
  deleteRequestDraft,
  deleteRequestDraftThunk,
  UPDATE_REQUEST_DRAFT,
  updateRequestDraft,
  updateRequestDraftThunk
} from '../../../store';
import mockAxios from 'axios';
import RequestDraftsReducer from '../../../store/RequestDraftsRRC';
import { CHANGE } from '../../../../../../../test_fixtures/test_constants';
// for enzyme to work with react 16 and up
Enzyme.configure({ adapter: new EnzymeAdapter() });

// This is to set up mock store for redux
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => store = mockStore();

let component = null;

const childProps = {
  request: requestDraft
};

describe('RequestDraftDetails React component', () => {
  beforeEach(() => {
    console.error = jest.fn();
    component = shallow(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
  });

  it('renders correctly and has all initial values from request draft payload', () => {
    const renderer = new ShallowRenderer();
    const result = renderer.render(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
    expect(result).toMatchSnapshot();
  });

  describe('displays all fields from draft request payload', () => {
    beforeEach(() => {
      console.error = jest.fn();
      component = shallow(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
    });
    it('correct number of label fields appear on the side panel initially', () => {
      const labels = component.find('.label');
      expect(labels).toHaveLength(14);
    });
    it('correct number fields render when request is an empty object', () => {
      const childPropsWithEmptyRequest = {
        request: {}
      };
      component = shallow(<RequestDraftDetailsRRC childProps={childPropsWithEmptyRequest} store={store} />);
      const labels = component.find('.label');
      expect(labels).toHaveLength(14);
    });
  });
  describe('Helper Method: handleChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
    });
    it('properly changes state for portfolio', () => {
      const input = component.find('#portfolio');
      input.simulate(CHANGE, { value: '3' }, { name: '3' });
      expect(input.props().initialValue).toEqual('3');
    });
    it('properly changes state for product', () => {
      const input = component.find('#product');
      input.simulate(CHANGE, { value: 'PRD00000195' }, { name: 'product' });
      expect(input.props().initialValue).toEqual('PRD00000195');
    });
    it('properly changes state for application', () => {
      const input = component.find('#application');
      input.simulate(CHANGE, { value: 'APP00006038' }, { name: 'application' });
      expect(input.props().initialValue).toEqual('APP00006038');
    });
    it('Should capture role correctly onChange', () => {
      const input = component.find('#role');
      input.simulate(CHANGE, { value: 'DEVELOPER' }, { name: 'role' });
      expect(input.props().initialValue).toEqual('DEVELOPER');
    });
    it('Should capture title correctly onChange', () => {
      const input = component.find('#title');
      input.simulate(CHANGE, { value: 'ASSOC_DEVELOPER' }, { name: 'title' });
      expect(input.props().initialValue).toEqual('ASSOC_DEVELOPER');
    });
    it('Should capture degree correctly onChange', () => {
      const input = component.find('#degree');
      input.simulate(CHANGE, { value: 'SECOND_DEGREE' }, { name: 'degree' });
      expect(input.props().initialValue).toEqual('SECOND_DEGREE');
    });
    it('Should capture resourceType correctly', () => {
      const input = component.find('#resourceType');
      input.simulate(CHANGE, { value: 'EMPLOYEE' }, { name: 'resourceType' });
      expect(input.props().initialValue).toEqual('EMPLOYEE');
    });
  });
  describe('Helper method: handleMultiSelectChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
    });
    it('Should capture skills correctly onChange', () => {
      const expectedState = ['JAVA', 'Python'];
      const selectElement = component.find('#skills');
      selectElement.simulate(CHANGE, [{ value: '001', label: 'JAVA' }, { value: '002', label: 'Python' }]);
      expect(selectElement.props().initialValue).toEqual(expectedState);
    });
  });
  describe('Helper method: handleCheckboxChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
    });
    it('Should capture locations correctly onChange', () => {
      const input = component.find('#locations');
      input.simulate(CHANGE, { target: { name: 'locations', value: 'OFFSHORE' } });
      expect(input.props().initialValue).toEqual([ 'CHICAGO', 'TELECOMMUTER', 'TULSA', 'OFFSHORE' ]);
    });
  });
  describe('Helper method: handleEventOnChange()', () => {
    beforeEach(() => {
      component = shallow(<RequestDraftDetailsRRC childProps={childProps} store={store} />);
    });
    it('Should capture startDate correctly onChange', () => {
      const input = component.find('#startDate');
      input.simulate(CHANGE, { target: { name: 'startDate', value: '2019-12-01' } });
      expect(input.props().value).toEqual('2019-12-01');
    });
    it('Should capture endDate correctly onChange', () => {
      const input = component.find('#endDate');
      input.simulate(CHANGE, { target: { name: 'endDate', value: '2020-12-01' } });
      expect(input.props().value).toEqual('2020-12-01');
    });
    it('Should capture draftName correctly onChange', () => {
      const input = component.find('#draftName');
      input.simulate(CHANGE, { target: { name: 'draftName', value: 'DRAFT_1' } });
      expect(input.props().initialValue).toEqual('DRAFT_1');
    });
  });
});

describe('Redux Store for RequestDraftDetails', () => {
  beforeEach(() => {
    resetStore();
    console.error = jest.fn();
  });
  describe('RequestDraftDetails Store Actions', () => {
    it('should create an action to update a draft request by draft id', () => {
      const expectedAction = {
        type: UPDATE_REQUEST_DRAFT
      };
      expect(updateRequestDraft()).toEqual(expectedAction);
    });
    it('should create an action to delete a draft request by draft id', () => {
      const expectedAction = {
        type: DELETE_REQUEST_DRAFT
      };
      expect(deleteRequestDraft()).toEqual(expectedAction);
    });
  });
  describe('RequestDraftDetails Thunk Middleware', () => {
    it('Axios PUT call should get the correct response for updateRequestDraft', async () => {
      const draftId = '1';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve());
      const expectedActions = [
        {
          type: UPDATE_REQUEST_DRAFT
        }
      ];
      await store.dispatch(updateRequestDraftThunk(draftId, updateDraft));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.put).toHaveBeenCalledWith('/v1/requestdrafts/' + draftId, updateDraft);
    });
    it('Axios DELETE call should get the correct response for deleteRequestDraft', async () => {
      const draftId = '2';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve());
      const expectedActions = [
        {
          type: DELETE_REQUEST_DRAFT
        }
      ];
      await store.dispatch(deleteRequestDraftThunk(draftId));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.delete).toHaveBeenCalledWith('/v1/requestdrafts/' + draftId);
    });
  });

  describe('RequestDrafts Reducer', () => {
    it('should return the initial state', () => {
      expect(RequestDraftsReducer(undefined, {})).toEqual({ requests: [], request: {} });
    });
    it('should handle UPDATE_REQUEST_DRAFT appropriately', () => {
      expect(RequestDraftsReducer([], {
        type: UPDATE_REQUEST_DRAFT
      }))
        .toEqual([]);
    });
    it('should handle DELETE_REQUEST_DRAFT appropriately', () => {
      expect(RequestDraftsReducer([], {
        type: DELETE_REQUEST_DRAFT
      }))
        .toEqual([]);
    });
  });
});
