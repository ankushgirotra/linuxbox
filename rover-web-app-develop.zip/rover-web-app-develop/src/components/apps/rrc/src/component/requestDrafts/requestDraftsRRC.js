import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import Table from '../../../../../../shared/components/view/Table';
import PropTypes from 'prop-types';
import {
  setRequestDraftsByOwnerThunk,
  setRequestDraftByIdThunk
} from '../../../../../../store';
import SplitterLayout from 'react-splitter-layout';
import 'react-splitter-layout/lib/index.css';
import RequestDraftDetailsRRC from './requestDraftDetails/requestDraftDetailsRRC';
import { SanitizePayloadFields } from '../helperFunctions/SanitizePayloadFields';

export function RequestDraftsRRC (props) {
  const initialState = {
    requests: props.requests.sort((a, b) => (a.id > b.id) ? 1 : -1) || [],
    request: {},
    showDraftDetails: false
  };
  const [state, setState] = useState(initialState);

  useEffect(() => {
    if (props.user.id) {
      props.setRequestDraftsByOwner(props.user.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.user.id]);
  useEffect(() => {
    if (props.user.id) {
      setState({
        ...state, requests: props.requests
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.requests]);

  const handleClick = async (draftId) => {
    try {
      const { setRequestDraftById } = props;
      await setRequestDraftById(draftId);
    } catch (error) {
      console.error(error);
    }
    setState({
      ...state, showDraftDetails: true
    });
  };

  const closeView = () => {
    setState({
      ...state, showDraftDetails: false
    });
  };

  const handleUpdatesToDrafts = async () => {
    try {
      await props.setRequestDraftsByOwner(props.user.id);
    } catch (error) {
      console.error(error);
    }

    if (props.requests) {
      setState({
        requests: props.requests.sort((a, b) => (a.id > b.id) ? 1 : -1) // ordered by draft ID
      });
    }
  };

  const childProps = {
    request: props.request
  };
  const tableHeaders = ['Draft Name', 'Draft ID', 'Resource Type', 'Portfolio', 'Product', 'Application', 'Requested Start Date', 'Requested End Date'];
  const keysFromData = ['draftName', 'id', 'resourceType', 'portfolioIdentifier', 'productIdentifier', 'applicationIdentifier', 'startDate', 'endDate'];

  return (
    <div>
      <SplitterLayout percentage secondaryInitialSize={40} primaryMinSize={40} secondaryMinSize={35}>
        <Table
          dataType='Request Drafts'
          data={SanitizePayloadFields(state.requests, props) || []}
          headers={tableHeaders}
          keys={keysFromData}
          onRowClick={handleClick}
        />
        {state.showDraftDetails &&
          <RequestDraftDetailsRRC childProps={childProps} handleCloseView={closeView} onUpdateToDraft={handleUpdatesToDrafts} />}
      </SplitterLayout>
    </div>

  );
}

export const mapStateToProps = state => ({
  requests: state.RequestDraftsReducer.requests,
  portfolios: state.RequestResourceReducer.portfolios,
  products: state.RequestResourceReducer.products,
  applications: state.RequestResourceReducer.applications,
  resourceTypes: state.FieldsReducer.resourceTypes,
  user: state.AuthReducer.user,
  request: state.RequestDraftsReducer.request
});

export const mapDispatchToProps = dispatch => ({
  setRequestDraftsByOwner: (user) => dispatch(setRequestDraftsByOwnerThunk(user)),
  setRequestDraftById: (draftId) => dispatch(setRequestDraftByIdThunk(draftId))
});

RequestDraftsRRC.propTypes = {
  requests: PropTypes.array,
  request: PropTypes.object,
  // eslint-disable-next-line react/no-unused-prop-types
  portfolios: PropTypes.array,
  // eslint-disable-next-line react/no-unused-prop-types
  products: PropTypes.array,
  // eslint-disable-next-line react/no-unused-prop-types
  applications: PropTypes.array,
  resourceTypes: PropTypes.array,
  user: PropTypes.object,
  setRequestDraftsByOwner: PropTypes.func,
  setRequestDraftById: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RequestDraftsRRC);
