import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import Table from '../../../../../../shared/components/view/Table';
import PropTypes from 'prop-types';
import SplitterLayout from 'react-splitter-layout';
import 'react-splitter-layout/lib/index.css';
import RequestTemplateDetailsRRC from './requestTemplateDetails/requestTemplateDetailsRRC';
import { setRequestTemplateByIdThunk, setRequestTemplatesByOwnerThunk } from '../../store';
import { Button } from 'react-bootstrap';
import RequestModalRrc from '../requestResourceForm/RequestModalRRC';
import { SanitizePayloadFields } from '../helperFunctions/SanitizePayloadFields';

export function RequestTemplatesRRC (props) {
  const initialState = {
    templates: props.templates ? props.templates.sort((a, b) => (a.id > b.id) ? 1 : -1) : [],
    template: {},
    showTemplateDetails: false
  };
  const [state, setState] = useState(initialState);
  const [isShow, setIsShow] = useState(false);

  useEffect(() => {
    if (props.user.id) {
      props.setRequestTemplatesByOwner(props.user.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (props.templates.length !== 0) {
      setState({
        ...state,
        templates: props.templates
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.templates]);

  const handleClick = async (draftId) => {
    try {
      const { setRequestTemplateById } = props;
      await setRequestTemplateById(draftId);
    } catch (error) {
      console.error(error);
    }
    setState({
      ...state, showTemplateDetails: true
    });
  };

  const handleIsShow = () => {
    setIsShow(prevIsShow => !prevIsShow);
  };

  const closeView = () => {
    setState({
      ...state, showTemplateDetails: false
    });
  };

  const handleUpdatesToTemplates = async () => {
    try {
      await props.setRequestTemplatesByOwner(props.user.id);
    } catch (error) {
      console.error(error);
    }
  };

  const childProps = {
    template: props.template
  };
  const tableHeaders = ['Template Name', 'Template ID', 'Resource Type', 'Portfolio', 'Product', 'Application'];
  const keysFromData = ['templateName', 'id', 'resourceType', 'portfolioIdentifier', 'productIdentifier', 'applicationIdentifier'];

  return (
    <div>
      <SplitterLayout percentage secondaryInitialSize={40} primaryMinSize={40} secondaryMinSize={35}>
        <Table
          dataType='Request Templates'
          data={SanitizePayloadFields(state.templates, props) || []}
          headers={tableHeaders}
          keys={keysFromData}
          onRowClick={handleClick}
        />
        {state.showTemplateDetails &&
          <RequestTemplateDetailsRRC
            childProps={childProps}
            handleCloseView={closeView}
            onUpdateToTemplate={handleUpdatesToTemplates}
          />}
      </SplitterLayout>
      <Button
        id='createTemplate'
        type='button'
        onClick={handleIsShow}
      >
        Create Template
      </Button>
      <RequestModalRrc
        show={isShow}
        toggle={handleIsShow}
        type='template'
      />
    </div>

  );
}

export const mapStateToProps = state => ({
  templates: state.RequestTemplatesReducer.templates,
  portfolios: state.RequestResourceReducer.portfolios,
  products: state.RequestResourceReducer.products,
  applications: state.RequestResourceReducer.applications,
  resourceTypes: state.FieldsReducer.resourceTypes,
  user: state.AuthReducer.user,
  template: state.RequestTemplatesReducer.template
});

export const mapDispatchToProps = dispatch => ({
  setRequestTemplatesByOwner: (user) => dispatch(setRequestTemplatesByOwnerThunk(user)),
  setRequestTemplateById: (draftId) => dispatch(setRequestTemplateByIdThunk(draftId))
});

RequestTemplatesRRC.propTypes = {
  templates: PropTypes.array,
  template: PropTypes.object,
  // eslint-disable-next-line react/no-unused-prop-types
  portfolios: PropTypes.array,
  // eslint-disable-next-line react/no-unused-prop-types
  products: PropTypes.array,
  // eslint-disable-next-line react/no-unused-prop-types
  applications: PropTypes.array,
  resourceTypes: PropTypes.array,
  user: PropTypes.object,
  setRequestTemplatesByOwner: PropTypes.func,
  setRequestTemplateById: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RequestTemplatesRRC);
