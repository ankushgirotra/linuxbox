import React from "react";
import { Button } from "react-bootstrap";
import { Info, Edit3, Trash2 } from "react-feather"
import "./dataGrid.scss";
import {
    useTable,
    useFilters,
    useGlobalFilter,
    useAsyncDebounce,
    useSortBy,
    useExpanded,
} from "react-table";

export default function DataGrid(props) {


    return (
        <div className="rrc-data-grid">
        <table >
            <thead>
                <tr>
                    <th>
                        ID
                    </th>
                    <th>
                        Date Created
                    </th>
                    <th>
                        Requested Start Date
                    </th>
                    <th>Status</th>
                    <th>Product</th>
                    <th>ITPM</th>
                    <th>Requested Role</th>
                    <th>Requested Skills</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>2984</td>
                    <td>7/2/2021</td>
                    <td>8/2/2021</td>
                    <td><p className="status status-identifying">Identifying Resources</p></td>
                    <td>Retail Sales</td>
                    <td>Sarah Boysen</td>
                    <td>Developer</td>
                    <td>Java; Salesforce; CICS</td>
                    <td>
                        <div className="editTable">
                            <span>
                                <Edit3 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Info color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Trash2 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                        </div>

                    </td>
                </tr>
                <tr>
                    <td>2984</td>
                    <td>7/2/2021</td>
                    <td>8/2/2021</td>
                    <td><p className="status status-blocker">External Blocker</p></td>
                    <td>Retail Sales</td>
                    <td>Sarah Boysen</td>
                    <td>Developer</td>
                    <td>Java; Salesforce; CICS</td>
                    <td>
                        <div className="editTable">
                            <span>
                                <Edit3 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Info color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Trash2 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2984</td>
                    <td>7/2/2021</td>
                    <td>8/2/2021</td>
                    <td><p className="status status-identified">Resource Identified</p></td>
                    <td>Retail Sales</td>
                    <td>Sarah Boysen</td>
                    <td>Developer</td>
                    <td>Java; Salesforce; CICS</td>
                    <td>
                        <div className="editTable">
                            <span>
                                <Edit3 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Info color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Trash2 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2984</td>
                    <td>7/2/2021</td>
                    <td>8/2/2021</td>
                    <td className="identifying">Identifying Resources</td>
                    <td>Retail Sales</td>
                    <td>Sarah Boysen</td>
                    <td>Developer</td>
                    <td>Java; Salesforce; CICS</td>
                    <td>
                        <div className="editTable">
                            <span>
                                <Edit3 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Info color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Trash2 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2984</td>
                    <td>7/2/2021</td>
                    <td>8/2/2021</td>
                    <td className="identifying">Identifying Resources</td>
                    <td>Retail Sales</td>
                    <td>Sarah Boysen</td>
                    <td>Developer</td>
                    <td>Java; Salesforce; CICS</td>
                    <td>
                        <div className="editTable">
                            <span>
                                <Edit3 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Info color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Trash2 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2984</td>
                    <td>7/2/2021</td>
                    <td>8/2/2021</td>
                    <td className="identifying">Identifying Resources</td>
                    <td>Retail Sales</td>
                    <td>Sarah Boysen</td>
                    <td>Developer</td>
                    <td>Java; Salesforce; CICS</td>
                    <td>
                        <div className="editTable">
                            <span>
                                <Edit3 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Info color="#3F66FB" size="20" className="ml-4" />
                            </span>
                            <span>
                                <Trash2 color="#3F66FB" size="20" className="ml-4" />
                            </span>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        </div>)
}
