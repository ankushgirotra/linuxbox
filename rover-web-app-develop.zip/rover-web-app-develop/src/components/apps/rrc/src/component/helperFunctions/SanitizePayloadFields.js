export const SanitizePayloadFields = (payload, data) => {
  const mappedItems = ['portfolio', 'product', 'application'];

  if (payload !== undefined && data !== undefined) {
    mappedItems.forEach(mappedItem =>
      payload.forEach(item => data[mappedItem + 's'].forEach(key => {
        if (item[mappedItem + 'Identifier'] === key.id) {
          item[mappedItem + 'Identifier'] = key.name;
        }
      })));
  }

  if (payload !== undefined && data !== undefined) {
    payload.forEach(item => data.resourceTypes.forEach(key => {
      if (item.resourceType === key.resourceType) {
        item.resourceType = key.description;
      }
    }));
  }

  if (payload !== undefined && data !== undefined) {
    payload.forEach(item => {
      if (item.startDate) {
        item.startDate = new Date(item.startDate).toISOString().split('T')[0];
      }
      if (item.endDate) {
        item.endDate = new Date(item.endDate).toISOString().split('T')[0];
      }
      if (item.createdAt) {
        item.createdAt = new Date(item.createdAt).toISOString().split('T')[0];
      }
    });
  }
  return payload;
};
