import React, { Component } from 'react';
import { connect } from 'react-redux';
import Table from '../../../../../../shared/components/view/Table';
import PropTypes from 'prop-types';
import { setResourcesThunk } from '../../../../../../store';

class ViewResourcesRRC extends Component {
  constructor (props) {
    super(props);
    this.tableHeaders = ['ID', 'First Name', 'Last Name', 'Manager', 'Email', 'Phone', 'Resource Type', 'Location', 'Role'];
    this.keysFromData = ['resourceId', 'firstName', 'lastName', 'manager', 'email', 'phone', 'resourceType', 'location', 'role'];

    this.state = {
      resources: []
    };

    this._isMounted = false;
  }

  componentDidMount = async () => {
    this._isMounted = true;
    const { setResourcesThunks } = this.props;

    await setResourcesThunks();
    if (this._isMounted) {
      this.setState({
        resources: this.props.resources
      });
    }
  };

  componentWillUnmount () {
    this._isMounted = false;
  }

  render () {
    return (
      <div className='ui compact table'>
        <Table
          data-type='resource-table'
          data={this.state.resources}
          headers={this.tableHeaders}
          keys={this.keysFromData}
        />
      </div>
    );
  }
}

export const mapStateToProps = state => ({
  resources: state.ResourcesReducer
});

export const mapDispatchToProps = dispatch => ({
  setResourcesThunks: () => dispatch(setResourcesThunk())
});

ViewResourcesRRC.propTypes = {
  resources: PropTypes.array,
  setResourcesThunks: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(ViewResourcesRRC);
