import React, { useState } from "react";
import { Search } from "react-feather";
import "./searchBar.scss";

const SearchBar = ({ visible }) => {
    return (
        <div className="search-bar-wrapper">
            <span className="search-icon">
                <Search size="20" strokeWidth={2} />
            </span>
            <input className="search-bar" type="text" placeholder="Search" />
        </div>
    );
};

export default SearchBar;
