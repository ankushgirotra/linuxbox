import React, { useState, useEffect } from 'react';
import { Col, Row } from "react-bootstrap"
import { Plus, X } from "react-feather"
import DataGrid from "../DataGrid/dataGrid";
import SearchBar from "../SearchBar/searchBar";
import RequestForm from "../RequestForm/requestForm";
import "./dashboard.scss"
import {
  getOpenRequestThunk
} from "../../../src/store/RequestResourceRRC";
import { connect } from "react-redux";

function DashboardRRC(props) {
  const [showTable, setShowTable] = useState(true);
  const [showNewRequest, setNewRequest] = useState(false);

  useEffect(() => {
    getOpenRequest()
  }, []);
  
  const handleVisibleTable = () => {
    setNewRequest(true);
    setShowTable(false);;
  }

  const handleVisibleFormRequest = () => {
    setNewRequest(false);
    setShowTable(true);
  }

  const { getOpenRequest, openRequests } = props;
 
  return (
    <>
      <div className="container-fluid">
        <Row>
          <Col sm={2} md={2} lg={2} xl={2}>
            <div className="rrc-user-details">
              <div className="rrc-user-details-image">
                {/* <p>
                  image user
                </p> */}
              </div>
              <div className="rrc-user-details-name">
                <p className="rrc-user-details-name-color">
                  James Smith
                </p>
              </div>
              <div className="rrc-user-details-title">
                <p className="rrc-user-details-title-color">
                  Application Development Center
                </p>
              </div>
              <div className="rrc-user-details-location">
                <p className="rrc-user-details-location-color">
                  Chigago, IL
                </p>
              </div>
              <div className="rrc-user-details-manager">
                <p className="rrc-user-details-manager-color">Manager:</p>
                <p className="rrc-user-details-manager-name">
                  Darren Thompson
                </p>
              </div>
              <hr />
              <div>
                <div className="rrc-request">
                  <div className="rrc-request-open">
                    <p className="rrc-request-open-text">{openRequests.openRequests} Open Requests</p>
                  </div>
                </div>
                <div className="rrc-request-status">
                  <div>
                    <p className="rrc-request-status-description">
                      <span className="rrc-request-status-assigned">{openRequests.identifyResource}</span> Assigned Requests
                    </p>
                  </div>
                  <div>
                    <p className="rrc-request-status-description">
                      <span className="rrc-request-status-identified">{openRequests.resourceIdentified}</span> Resource Identified
                    </p>
                  </div>
                  <div>
                    <p className="rrc-request-status-description">
                      <span className="rrc-request-status-external">{openRequests.externalBlockers}</span> External Blocker
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </Col>
          <Col>
            <div className="rrc-container">
              <div className="rrc-details-wrapper">
                {showTable ? (
                  <>
                    <Row className="rrc-header-container">
                      <Col sm={4} md={4} lg={4} xl={4} className="adjust-padding">
                        <p className="rrc-header">Resource Request</p>
                      </Col>
                      <Col
                        sm={6}
                        md={6}
                        lg={6}
                        xl={6}
                        className="searchbar-outline adjust-padding"
                      >
                        <SearchBar visible={showTable} />
                      </Col>
                      <Col sm={2} md={2} lg={2} xl={2}>
                        <button className="new-request" onClick={() => handleVisibleTable()}>
                          <Plus size={20} />
                          <span className="align-txt">New Request</span>
                        </button>
                      </Col>
                    </Row>
                    <DataGrid />
                  </>
                ) : (
                    <>
                      <Row className="rrc-header-container">
                        <Col sm={4} md={4} lg={10} xl={10} className="adjust-padding">
                          <p className="rrc-header">Create new Request</p>
                        </Col>
                        <Col sm={2} md={2} lg={2} xl={2}>
                          <button className="close-request" onClick={() => handleVisibleFormRequest()}>
                            X
                        </button>
                        </Col>
                      </Row>
                      <RequestForm />
                    </>
                  )}

              </div>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );


}

const mapStateToProps = (state, ownProps) => ({
  openRequests: state.RequestResourceReducer.openRequest,
});

const mapDispatchToProps = (dispatch) => ({
  getOpenRequest: () => dispatch(getOpenRequestThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(DashboardRRC);

