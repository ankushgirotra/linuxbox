import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Col, Form, Modal, Row, Accordion, Card, ListGroup } from 'react-bootstrap';
import InputField from '../../../../../../../shared/components/form/UserInput/InputField';
import UserInput from '../../../../../../../shared/components/form/UserInput';
import DateField from '../../../../../../../shared/components/form/UserInput/DateField';
import { updateRequestDraftThunk, deleteRequestDraftThunk } from '../../../store';
import TextAreaField from '../../../../../../../shared/components/form/UserInput/TextAreaField';
import './requestDraftDetailsRRC.css';
import { connect } from 'react-redux';
import ButtonToolbar from 'react-bootstrap/ButtonToolbar';

export const RequestDraftDetailsRRC = (props) => {
  const initialState = {
    id: props.childProps.request.id || '',
    requestOwner: props.childProps.request.requestOwner || '',
    draftName: props.childProps.request.draftName || '',
    portfolio: props.childProps.request.portfolioIdentifier || '',
    product: props.childProps.request.productIdentifier || '',
    application: props.childProps.request.applicationIdentifier || '',
    startDate: cleanseDate(props.childProps.request.startDate) || '',
    endDate: cleanseDate(props.childProps.request.endDate) || '',
    allocation: props.childProps.request.allocation || '',
    role: props.childProps.request.role || '',
    skills: props.childProps.request.skills || [],
    resourceType: props.childProps.request.resourceType || '',
    notes: props.childProps.request.notes || '',
    title: props.childProps.request.title || '',
    degree: props.childProps.request.degree || '',
    locations: props.childProps.request.locations || [],
    requestCount: props.childProps.request.requestCount || 1,
    newNote: '',
    showDraftDetails: props.childProps.showDraftDetails || ''
  };

  /* React Hook (state initialization) */
  const [state, setState] = useState(initialState);
  const [isEdit, setIsEdit] = useState(true);
  const [isClick, setIsClick] = useState(false);
  const [isNoteEdit, setIsNoteEdit] = useState({ able: false, index: null });
  const [tempEdit, setTempEdit] = useState(false);

  /* React Hook (update state properties) */
  useEffect(() => {
    setState(initialState);
    setTempEdit(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.childProps.request]);

  useEffect(() => {
    if (tempEdit) {
      setState({
        ...state,
        product: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.portfolio]);

  useEffect(() => {
    if (tempEdit) {
      setState({
        ...state,
        application: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.product]);

  useEffect(() => {
    if (tempEdit) {
      setState({
        ...state,
        title: ''
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.role]);

  useEffect(() => {
    if (tempEdit) {
      setState(({
        ...state,
        degree: ''
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.title]);

  /* Helper Functions */
  function cleanseDate (date) {
    return (date ? new Date(date).toISOString().split('T')[0] : date);
  }

  const handleIsEdit = () => {
    setIsEdit(!isEdit);
  };

  const handleIsClick = () => {
    setIsClick(!isClick);
  };

  // Event Handler Methods
  const handleChange = async (value, action) => {
    const field = action.name;
    if (value) {
      setTempEdit(true);
      await setState({
        ...state,
        [field]: value.value
      });
    } else {
      setTempEdit(true);
      await setState({
        ...state,
        [field]: ''
      });
    }
  };

  const handleSetNote = () => {
    setState({
      ...state,
      notes: [...state.notes, { note: state.newNote }],
      newNote: ''
    });
  };

  const handleRemoveNote = (key) => {
    const noteArr = state.notes.filter((note, index) => index !== key);
    setState({
      ...state,
      notes: noteArr
    });
  };

  const handleAbleEditNote = (index) => {
    if (!isNoteEdit.able) {
      setIsNoteEdit({
        able: true,
        index: index
      });
    } else {
      setIsNoteEdit({
        able: false,
        index: null
      });
    }
  };

  const handleEditNote = (event) => {
    event.persist();
    const arr = state.notes.slice();
    arr[isNoteEdit.index].note = event.target.value;
    setState({
      ...state,
      notes: arr
    });
  };

  const handleEventOnChange = (event) => {
    setState({
      ...state,
      [event.target.name]: event.target.value
    });
  };

  const handleMultiSelectChange = (skills) => {
    if (skills) {
      skills = skills.map(skill => {
        return skill.label;
      });
    } else {
      skills = [];
    }
    setState({
      ...state,
      skills
    });
  };

  // Checkbox need to push the selection to what we passed in, or the selection will be reset everytime.
  const handleCheckboxChange = (event) => {
    if (props.childProps.request.locations.includes(event.target.value)) {
      props.childProps.request.locations = props.childProps.request.locations.filter(item => item !== event.target.value);
    } else {
      props.childProps.request.locations.push(event.target.value);
    }
    setState({
      ...state,
      locations: props.childProps.request.locations
    });
  };

  const handleDelete = async () => {
    await props.deleteRequestDraft(state.id);
    props.handleCloseView();
    props.onUpdateToDraft();
    setState({
      id: '',
      requestOwner: '',
      draftName: '',
      portfolio: '',
      product: '',
      application: '',
      startDate: '',
      endDate: '',
      allocation: '',
      role: '',
      skills: [],
      resourceType: '',
      notes: '',
      title: '',
      degree: '',
      locations: [],
      requestCount: 1,
      newNote: ''
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const requestDraft = {
      id: state.id,
      requestOwner: state.requestOwner || null,
      draftName: state.draftName || null,
      portfolioIdentifier: state.portfolio || null,
      productIdentifier: state.product || null,
      applicationIdentifier: state.application || null,
      startDate: state.startDate ? state.startDate + 'T00:00:00-06:00' : null,
      endDate: state.endDate ? state.endDate + 'T00:00:00-06:00' : null,
      allocation: state.allocation || null,
      role: state.role || null,
      title: state.title || null,
      degree: state.degree || null,
      skills: state.skills || null,
      notes: state.notes || null,
      locations: state.locations ? state.locations.filter(location => (state.resourceType === 'EMPLOYEE' ? location !== 'OFFSHORE' : location)) : null,
      resourceType: state.resourceType || null,
      requestCount: state.requestCount || null
    };
    await props.updateRequestDraft(state.id, requestDraft);
    props.onUpdateToDraft();
  };

  const isDeveloper = (state.role === 'DEVELOPER' && state.title);
  return (
    <Form
      onSubmit={handleSubmit} onKeyPress={e => {
        if (e.key === 'Enter') e.preventDefault();
      }}
    >
      <div className='container'>
        <Modal.Header className='row'>
          <Modal.Title id='contained-modal-title-vcenter'>
            <Row>
              <Col xl>
                {((!state.draftName) || (isEdit)) ? <InputField id='draftName' type='draftName' inputType='text' initialValue={state.draftName} onChange={handleEventOnChange} onEnter={handleIsEdit} placeholder='Enter Draft Name' isRequired /> : <div className='text-nowrap' onClick={handleIsEdit}>{state.draftName}</div>}
              </Col>
              <Col>
                <div onClick={handleIsEdit}>
                  <span className='fa fa-edit' />
                </div>
              </Col>
            </Row>
          </Modal.Title>
          <button type='button' className='close' aria-label='Close' onClick={props.handleCloseView}>
            <span aria-hidden='true'>&times;</span>
          </button>
        </Modal.Header>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Portfolio</Form.Label>
              <UserInput id='portfolio' type='portfolio' onChange={handleChange} initialValue={state.portfolio} isSorted />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Product</Form.Label>
              <UserInput id='product' type='product' onChange={handleChange} initialValue={state.product} isSorted refValue={state.portfolio} />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Application</Form.Label>
              <UserInput id='application' type='application' onChange={handleChange} initialValue={state.application} isSorted refValue={state.product} />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Skills</Form.Label>
              <UserInput id='skills' type='skills' onChange={handleMultiSelectChange} initialValue={state.skills} isSorted isMulti />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Start Date</Form.Label>
              <DateField id='startDate' type='startDate' value={state.startDate} onChange={handleEventOnChange} />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>End Date</Form.Label>
              <DateField id='endDate' type='endDate' value={state.endDate} onChange={handleEventOnChange} startDate={state.startDate} />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Allocation %</Form.Label>
              <InputField id='allocation' type='allocation' initialValue={state.allocation} onChange={handleEventOnChange} inputType='number' maxValue='100' />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'># of Resources Needed</Form.Label>
              <InputField id='requestCount' type='requestCount' initialValue={state.requestCount} onChange={handleEventOnChange} inputType='number' maxValue='20' />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <label className='label'>Role</label>
              <UserInput id='role' type='role' onChange={handleChange} initialValue={state.role} isSorted />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Resource Type</Form.Label>
              <UserInput id='resourceType' type='resourceType' onChange={handleChange} initialValue={state.resourceType} isSorted />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Title</Form.Label>
              <UserInput id='title' type='title' onChange={handleChange} initialValue={state.title} isSorted refValue={state.role} />
            </Form.Group>
          </Col>
          <Col>
            <Form.Group>
              <Form.Label className='label'>Degree</Form.Label>
              <UserInput id='degree' type='degree' onChange={handleChange} initialValue={state.degree} isSorted refValue={isDeveloper} />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <label className='label'>Locations</label>
            <UserInput id='locations' type='locations' initialValue={state.locations} onChange={handleCheckboxChange} refValue={state.resourceType} />
          </Col>
        </Row>
        <Form.Group>
          <Accordion>
            <Card>
              <Accordion.Toggle as={Card.Header} eventKey='0' className={isClick ? 'wrapper active' : 'wrapper'} onClick={handleIsClick}>
                <Form.Label className='label'>Notes ({state.notes ? state.notes.length : 0})</Form.Label>
                <span className='arrow' />
              </Accordion.Toggle>
              <ListGroup>
                {state.notes && state.notes.map((note, index) =>
                  <Accordion.Collapse eventKey='0' key={index}>
                    <ListGroup.Item>
                      <Row>
                        <Col>
                          {isNoteEdit.index === index && isNoteEdit.able
                            ? <InputField id='notes' type='notes' inputType='text' initialValue={note.note || ''} onChange={handleEditNote} onEnter={handleAbleEditNote} isRequired /> : <div>{note.note}</div>}
                        </Col>
                        <Col xs={1}>
                          <div onClick={() => handleAbleEditNote(index)}>
                            <span className='fa fa-edit' />
                          </div>
                        </Col>
                        <Col xs={1}>
                          <div onClick={() => handleRemoveNote(index)}>
                            <span className='fa fa-trash' />
                          </div>
                        </Col>
                      </Row>
                    </ListGroup.Item>
                  </Accordion.Collapse>)}
              </ListGroup>
            </Card>
          </Accordion>
          <TextAreaField id='newNote' type='newNote' onBlur={handleEventOnChange} rows='3' onEnter={handleSetNote} placeholder='(Press Enter to Save Note)' />
        </Form.Group>
        <Modal.Footer />
        <ButtonToolbar className='justify-content-lg-between'>
          <div className='btn-group'>
            <Button variant='danger' type='button' onClick={handleDelete}>Delete Draft</Button>
          </div>
          <div className='btn-group'>
            <Button className='btn' type='submit'>Update Draft</Button>
          </div>
        </ButtonToolbar>
      </div>
    </Form>
  );
};

export const mapDispatchToProps = dispatch => ({
  updateRequestDraft: (draftId, request) => dispatch(updateRequestDraftThunk(draftId, request)),
  deleteRequestDraft: (draftId) => dispatch(deleteRequestDraftThunk(draftId))
});

RequestDraftDetailsRRC.propTypes = {
  childProps: PropTypes.shape({
    request: PropTypes.object.isRequired,
    showDraftDetails: PropTypes.bool
  }),
  handleCloseView: PropTypes.func,
  onUpdateToDraft: PropTypes.func,
  deleteRequestDraft: PropTypes.func,
  updateRequestDraft: PropTypes.func
};

export default connect(null, mapDispatchToProps)(RequestDraftDetailsRRC);
