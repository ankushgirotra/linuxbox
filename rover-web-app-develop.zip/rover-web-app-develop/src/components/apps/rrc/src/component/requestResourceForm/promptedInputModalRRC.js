import React from 'react';
import { Button, Form, Modal, Col } from 'react-bootstrap';
import PropTypes from 'prop-types';
import InputField from '../../../../../../shared/components/form/UserInput/InputField';

const PromptedInputModalRRC = (props) => {
  const { showPromptModal, onHide, id, type, initialValue, onBlur, inputType, isRequired, promptTitle, onSubmit, disableButton } = props;
  return (
    <Modal
      show={showPromptModal}
      size='sm'
      aria-labelledby='contained-modal-title-vcenter'
      centered
      onHide={onHide}
      backdrop='static'
      keyboard={false}
      backdropClassName='modal-backdrop'
    >
      <Modal.Header closeButton>
        <Modal.Title id='contained-modal-title-vcenter'>
          <Form.Label className='label'>{promptTitle}</Form.Label>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={onSubmit}>
          <Form.Group className='text-center'>
            <InputField
              id={id} type={type} initialValue={initialValue === ' ' ? null : initialValue}
              onBlur={onBlur} inputType={inputType} isRequired={isRequired}
            />
          </Form.Group>
          <Col className='text-center'>
            <Button id='modalSaveButton' type='submit' disabled={disableButton || false}>Save</Button>
          </Col>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

PromptedInputModalRRC.propTypes = {
  showPromptModal: PropTypes.bool,
  promptTitle: PropTypes.string,
  onHide: PropTypes.func,
  onBlur: PropTypes.func,
  inputType: PropTypes.string.isRequired,
  isRequired: PropTypes.bool,
  type: PropTypes.string,
  initialValue: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  id: PropTypes.string,
  onSubmit: PropTypes.func,
  disableButton: PropTypes.bool
};

export default PromptedInputModalRRC;
