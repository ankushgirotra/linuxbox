import React from 'react';
import Enzyme, { mount, shallow } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import mockAxios from 'axios';
import renderer from 'react-test-renderer';

// Import Mock Data
import {
  applications,
  requestDrafts,
  draftTableHeaders,
  keysFromDraftData,
  portfolios,
  products,
  resourceTypes,
  degrees,
  roles,
  titles,
  locations,
  requests,
  requestDraft,
  updateDraft
} from '../../../../../../test_fixtures/mock_data';

// Redux store which includes Reducers, Action Creators, and Middleware
import RequestDraftsReducer, {
  SET_REQUEST_DRAFTS_BY_OWNER,
  SET_REQUEST_DRAFT_BY_ID,
  UPDATE_REQUEST_DRAFT,
  setRequestDraftsByOwner,
  setRequestDraftById,
  setRequestDraftsByOwnerThunk,
  setRequestDraftByIdThunk
} from '../../store/RequestDraftsRRC';

import { RequestDraftsRRC, mapStateToProps } from './requestDraftsRRC';

import Table from '../../../../../../shared/components/view/Table';
import { CLICK } from '../../../../../../test_fixtures/test_constants';

// for enzyme to work with react 16 and up
Enzyme.configure({ adapter: new EnzymeAdapter() });

// This is to set up mock store for redux
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => store = mockStore();

let component = null;
let table = null;
const request = requestDraft;
const updatedDraft = updateDraft;

const baseProps = {
  setRequestDraftsByOwner: jest.fn(),
  setRequestDraftById: jest.fn(),
  portfolios,
  products,
  applications,
  resourceTypes,
  user: {},
  requests,
  request: requestDraft,
  degrees,
  roles,
  titles,
  locations
};

const tableProps = {
  onRowClick: jest.fn()
};

describe('RequestDrafts React component', () => {
  beforeEach(() => {
    component = shallow(<RequestDraftsRRC store={store} {...baseProps} />);
    table = mount(
      <Table
        store={store}
        data={requestDrafts}
        headers={draftTableHeaders}
        keys={keysFromDraftData}
        {...tableProps}
      />);
    console.error = jest.fn();
  });

  it('renders correctly', () => {
    component = renderer.create(<RequestDraftsRRC {...baseProps}/>).toJSON();
    expect(component).toMatchSnapshot();
  });

  describe('Events are Triggered Correctly', () => {
    it('should call onClick when click event is triggered', () => {
      const input = table.find('.rt-tr').at(2)
      const draftId = 1;
      input.simulate(CLICK);
      expect(tableProps.onRowClick).toHaveBeenCalledWith(draftId);
    });
  });
});

describe('Redux Store for RequestDrafts', () => {
  beforeEach(() => {
    resetStore();
    console.error = jest.fn();
  });
  describe('RequestDrafts Store Actions', () => {
    it('should create an action to set draft requests by particular owner', () => {
      const expectedAction = {
        type: SET_REQUEST_DRAFTS_BY_OWNER,
        requests
      };
      expect(setRequestDraftsByOwner(requests)).toEqual(expectedAction);
    });
    it('should create an action to set draft request by draft id', () => {
      const expectedAction = {
        type: SET_REQUEST_DRAFT_BY_ID,
        request
      };
      expect(setRequestDraftById(request)).toEqual(expectedAction);
    });
  });

  describe('RequestDrafts Thunk Middleware', () => {
    it('Axios GET call should get the correct response for setRequestDraftsByOwner', async () => {
      const user = 'admin';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: requests } }));
      const expectedActions = [
        {
          type: SET_REQUEST_DRAFTS_BY_OWNER,
          requests
        }
      ];
      await store.dispatch(setRequestDraftsByOwnerThunk(user));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/requestdrafts', { params: { requestOwner: user } });
    });
    it('Axios GET call should get the correct response for setRequestDraftById', async () => {
      const draftId = '1';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: request } }));
      const expectedActions = [
        {
          type: SET_REQUEST_DRAFT_BY_ID,
          request
        }
      ];
      await store.dispatch(setRequestDraftByIdThunk(draftId));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/requestdrafts/' + draftId);
    });
  });

  describe('RequestDrafts Reducer', () => {
    it('should return the initial state', () => {
      expect(RequestDraftsReducer({
        requests: [],
        request: {}
      }, {})).toEqual({ requests: [], request: {} });
    });
    it('should handle SET_REQUEST_DRAFTS_BY_OWNER appropriately', () => {
      expect(RequestDraftsReducer({
        requests: [],
        request: {}
      }, {
        type: SET_REQUEST_DRAFTS_BY_OWNER,
        requests
      }))
        .toEqual({ request: {}, requests: requests });
    });
    it('should handle SET_REQUEST_DRAFT_BY_ID appropriately', () => {
      expect(RequestDraftsReducer({
        requests: [],
        request: {}
      }, {
        type: SET_REQUEST_DRAFT_BY_ID,
        request
      }))
        .toEqual({ requests: [], request: request });
    });
    it('should handle UPDATE_REQUEST_DRAFT appropriately', () => {
      expect(RequestDraftsReducer([], {
        type: UPDATE_REQUEST_DRAFT,
        updatedDraft
      }))
        .toEqual([]);
    });
  });
});

describe('mapStateToProps for RequestDrafts', () => {
  it('mapStateToProps should have correct initial state', () => {
    const initialState = {
      RequestResourceReducer: {
        portfolios: [],
        products: [],
        applications: []
      },
      FieldsReducer: {
        resourceTypes: []
      },
      AuthReducer: {
        user: { id: '' }
      },
      RequestDraftsReducer: {
        requests: [],
        request: {}
      }
    };
    expect(mapStateToProps(initialState)).toEqual({
      portfolios: [],
      products: [],
      applications: [],
      resourceTypes: [],
      user: { id: '' },
      requests: [],
      request: {}
    });
  });
});
