import React from 'react';
import { connect } from 'react-redux';
import { Form, Button, Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types';
import {
  setApplicationsThunk,
  setUserInfoThunk,
  createRequestTemplateThunk,
  setRequestTemplatesByOwnerThunk
} from '../../../../../../../store';
import UserInput from '../../../../../../../shared/components/form/UserInput';
import InputField from '../../../../../../../shared/components/form/UserInput/InputField';

export class CreateRequestTemplateRRC extends React.Component {
  constructor (props) {
    super(props);
    this.state = {
      templateName: '',
      templateOwner: '',
      portfolio: '',
      product: '',
      application: '',
      allocation: '',
      role: '',
      skills: [],
      resourceType: '',
      title: '',
      degree: '',
      locations: [],
      requestCount: '1',
      showPromptModal: false
    };
  }

  componentDidMount = async () => {
    try {
      const {
        setApplications
      } = this.props;

      await setApplications();
    } catch (error) {
      console.error(error);
    }

    this.setState({
      templateOwner: this.props.user.id
    });
  };

  componentDidUpdate (prevProps, prevState) {
    if (prevState.portfolio !== this.state.portfolio) {
      this.setState({
        product: '',
        application: ''
      });
    }
    if (prevState.product !== this.state.product) {
      this.setState({
        application: ''
      });
    }
    if (prevState.role !== this.state.role) {
      this.setState({
        title: '',
        degree: ''
      });
    }
    if (prevState.title !== this.state.title) {
      this.setState({
        degree: ''
      });
    }
  }

  handleHide = () => {
    this.setState(
      prevState => ({
        showPromptModal: !prevState.showPromptModal
      }));
  };

  setDomainOwner = (array) => {
    const currentApplication = this.state.application;
    if (currentApplication.length) {
      return array.reduce((acc, application) => {
        if (application.id === currentApplication) {
          acc += application.managerIdentifier;
        }
        return acc;
      }, '');
    }
  };

  handleSubmit = async (event) => {
    event.preventDefault();
    const request = {
      template: {
        templateOwner: this.state.templateOwner || null,
        templateName: this.state.templateName || null,
        portfolio: this.state.portfolio || null,
        product: this.state.product || null,
        application: this.state.application || null,
        allocation: this.state.allocation || null,
        role: this.state.role || null,
        title: this.state.title || null,
        degree: this.state.degree || null,
        skills: this.state.skills || null,
        locations: this.state.locations ? this.state.locations.filter(location => (this.state.resourceType === 'EMPLOYEE' ? location !== 'OFFSHORE' : location)) : null,
        resourceType: this.state.resourceType || null,
        requestCount: this.state.requestCount || null
      }
    };
    await this.props.createRequestTemplate(request);
    await this.props.setRequestTemplatesByOwner(this.props.user.id);
    this.setState({
      templateOwner: '',
      templateName: '',
      portfolio: '',
      product: '',
      application: '',
      allocation: '',
      role: '',
      skills: [],
      resourceType: '',
      notes: '',
      title: '',
      degree: '',
      locations: [],
      requestCount: '1'
    });
    this.handleHide();
    this.props.toggle();
  };

    handleChange = (value, action) => {
      const field = action.name;
      if (value) {
        this.setState({
          [field]: value.value
        });
      } else {
        this.setState({
          [field]: ''
        });
      }
    };

    handleEventOnChange = (event) => {
      this.setState({
        [event.target.name]: event.target.value
      });
    };

    handleMultiSelectChange = (skills) => {
      if (skills) {
        skills = skills.map(skill => {
          return skill.label;
        });
      } else {
        skills = [];
      }
      this.setState({
        skills
      });
    };

    handleCheckboxChange = (event) => {
      let data = this.state.locations.slice();
      if (this.state.locations.includes(event.target.value)) {
        data = this.state.locations.filter(item => item !== event.target.value);
      } else {
        data.push(event.target.value);
      }

      this.setState({
        [event.target.name]: data
      });
    };

    render () {
      const isDeveloper = (this.state.role === 'DEVELOPER' && this.state.title);
      return (
        <div>
          <Form
            onSubmit={this.handleSubmit} onKeyPress={e => {
              if (e.key === 'Enter') e.preventDefault();
            }}
          >
            <Row>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Template Name</Form.Label>
                  <InputField id='templateName' type='templateName' inputType='text' initialValue={this.state.templateName} onChange={this.handleEventOnChange} placeholder='Enter Template Name' isRequired />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Portfolio</Form.Label>
                  <UserInput
                    id='portfolio' type='portfolio' onChange={this.handleChange} initialValue={this.state.portfolio}
                    isSorted
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Product</Form.Label>
                  <UserInput
                    id='product' type='product' onChange={this.handleChange} initialValue={this.state.product}
                    isSorted refValue={this.state.portfolio}
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Application</Form.Label>
                  <UserInput
                    id='application' type='application' onChange={this.handleChange}
                    initialValue={this.state.application} isSorted refValue={this.state.product}
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Skills</Form.Label>
                  <UserInput
                    id='skills' type='skills' onChange={this.handleMultiSelectChange}
                    initialValue={this.state.skills} isSorted isMulti
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                {this.state.product && (
                  <Form.Group>
                    <Form.Label className='label' id='PRD_Code'>Product Code</Form.Label>
                    <div>
                      <b>
                        {this.state.product}
                      </b>
                    </div>
                  </Form.Group>
                )}
              </Col>
              <Col>
                {this.state.application && (
                  <Form.Group>
                    <Form.Label className='label' id='domainOwner'>Product/Domain Owner</Form.Label>
                    <div>
                      <b>
                        {this.setDomainOwner(this.props.applications)}
                      </b>
                    </div>
                  </Form.Group>
                )}
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Allocation %</Form.Label>
                  <InputField
                    id='allocation' type='allocation' initialValue={this.state.allocation}
                    onChange={this.handleEventOnChange} inputType='number' maxValue='100'
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label className='label'># of Resources Needed</Form.Label>
                  <InputField
                    id='requestCount' type='requestCount' initialValue={this.state.requestCount}
                    onChange={this.handleEventOnChange} inputType='number' maxValue='20'
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <label className='label'>Role</label>
                  <UserInput
                    id='role' type='role' onChange={this.handleChange} initialValue={this.state.role}
                    isSorted
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Resource Type</Form.Label>
                  <UserInput
                    id='resourceType' type='resourceType' onChange={this.handleChange}
                    initialValue={this.state.resourceType} isSorted
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Title</Form.Label>
                  <UserInput
                    id='title' type='title' onChange={this.handleChange} initialValue={this.state.title}
                    isSorted refValue={this.state.role}
                  />
                </Form.Group>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label className='label'>Degree</Form.Label>
                  <UserInput
                    id='degree' type='degree' onChange={this.handleChange} initialValue={this.state.degree}
                    isSorted refValue={isDeveloper}
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <label className='label'>Locations</label>
                <UserInput
                  id='locations' type='locations' initialValue={this.state.locations}
                  onChange={this.handleCheckboxChange} refValue={this.state.resourceType}
                />
              </Col>
            </Row>
            <Button id='createTemplate' type='submit' onClick={this.handleHide}>Create Template</Button>
          </Form>
        </div>

      );
    }
}

export const mapStateToProps = state => ({
  applications: state.RequestResourceReducer.applications,
  user: state.AuthReducer.user
});

export const mapDispatchToProps = dispatch => ({
  setApplications: () => dispatch(setApplicationsThunk()),
  setUserInfo: () => dispatch(setUserInfoThunk()),
  createRequestTemplate: (request) => dispatch(createRequestTemplateThunk(request)),
  setRequestTemplatesByOwner: (user) => dispatch(setRequestTemplatesByOwnerThunk(user))
});

CreateRequestTemplateRRC.propTypes = {
  applications: PropTypes.array,
  setApplications: PropTypes.func,
  setUserInfo: PropTypes.func,
  createRequestTemplate: PropTypes.func,
  setRequestTemplatesByOwner: PropTypes.func,
  user: PropTypes.object,
  toggle: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateRequestTemplateRRC);
