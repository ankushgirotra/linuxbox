import React, { useState, useEffect } from "react";
import { Row, Col, Form, Container } from "react-bootstrap";
import { connect } from "react-redux";
import moment from "moment";
import { getFormattedDate } from "../../services/requestForm.service"
import {
    getProductLineThunk, getApplicationThunk, getRoleThunk, getBeltThunk, getTechnologieThunk, getLocationThunk, getProductThunk, getProductsByProductLineIdThunk, getApplicationsByProductIdThunk, getJobTitleThunk, saveRequestThunk, getJobTitle
} from "../../../src/store/RequestResourceRRC"
import SelectDropdown from "../../../../../shared/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../shared/components/forms/TextField/textField";
//import Datepicker from "../../../../../shared/components/forms/Datepicker/datepicker";
//import DatePicker from "react-datepicker";
//import "react-datepicker/dist/react-datepicker.css";
import "./requestForm.scss";
import { validateRequestForm } from "../../services/requestForm.service";
import { FORM_DATE_FORMAT } from "../../constants/request.constans";
 import Datepicker from "../../../../pcdm/src/components/Datepicker/datepicker";
 import CustomSelect from "../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";

const INITIAL_FORM_STATE = {
    formControls: {
        selectTemplate: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        enterTemplateName: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: true,
        },
        productLine: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        product: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        application: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        role: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        titleOrBelt: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        degree: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        allocationPercentage: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        plannedStartDate: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
        plannedEndDate: {
            value: "",
            error: false,
            errorMsg: "",
            min: null,
            max: null,
            required: false,
            disabled: false,
        },
        technologies: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        // resourceType: {
        //     value: "",
        //     error: false,
        //     errorMsg: "",
        //     required: true,
        //     disable: false,
        // },
        location: {
            value: "",
            error: false,
            errorMsg: "",
            required: true,
            disable: false,
        },
        comments: {
            value: "",
            error: false,
            errorMsg: "",
            required: false,
            disable: false,
        },
    },
};
// export default function RequestForm(props) {
const RequestForm = (props) => {
    const [requestFormState, setRequestFormState] = useState(INITIAL_FORM_STATE);
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());

    const [roleOptions, setRoleOptions] = useState([]);

    const { getProductLines, getApplication, getRole, 
        getBelt, getTechnologie, getLocation, getProduct, 
        getProductsByProductLineId, getApplicationsByProductId, 
        getJobTitle, saveRequest, productLine, application, 
        role, belt, technologie, location, product, productsByProductLineId, 
        applicationsByProductId, jobtitle } = props;

    useEffect(() => {
        getProductLines();
        getProduct();
        getApplication();
        getRole();
        getBelt();
        getTechnologie();
        getLocation();
        getJobTitle();
    }, []);



    const onProductLineChange = async (selectedProductLine) => {
    
        await getProductsByProductLineId(selectedProductLine);
    }

    const onProductChange = async (selectedProduct) => {
        
        await getApplicationsByProductId(selectedProduct);
    }

    const onInputChange = (event) => {
        const { formControls } = requestFormState;
        const name = event.target.name;
        const value = event.target.value;

        if (name === "productLine") {
            onProductLineChange(value);
        }
        if (name === "product") {
            onProductChange(value);
        }

        setRequestFormState({
            formControls: {
                ...formControls,
                error: false,
                [name]: {
                    ...formControls[name],
                    error: false,
                    value: value,
                },
            },
        });
    };

   const manageMonthSelection = (type, date) => {
        let value = moment(date, FORM_DATE_FORMAT);
        const { formControls } = requestFormState;
        if (type === "plannedStartDate") {
            let ed = formControls.plannedEndDate.value,
                ed_disable = formControls.plannedEndDate.disabled,
                ed_min = value.add(1, "day").format(FORM_DATE_FORMAT);
            if (value.isValid() && !formControls.plannedEndDate.value) {
                // If start month is selected and end month is empty enable end month and update its min
                ed_disable = false;
            } else if (
                formControls.plannedEndDate.value &&
                value.isAfter(moment(formControls.plannedEndDate.value, FORM_DATE_FORMAT))
            ) {
                // If start month is after selected end month , then reset the end month and its min
                ed = "";
                ed_disable = false;
            }
            setRequestFormState({
                formControls: {
                    ...formControls,
                    isEdited: true,
                    plannedStartDate: {
                        ...formControls.plannedStartDate,
                        value: date,
                        error: false,
                    },
                    plannedEndDate: {
                        ...formControls.plannedEndDate,
                        value: ed,
                        disabled: ed_disable,
                        min: new Date(getFormattedDate(ed_min)),
                    },
                },
            });
        } else if (type === "plannedEndDate") {
            setRequestFormState({
                formControls: {
                    ...formControls,
                    isEdited: true,
                    plannedStartDate: {
                        ...formControls.plannedStartDate,
                        error: false,
                    },
                    plannedEndDate: {
                        ...formControls.plannedEndDate,
                        value: date,
                        error: false,
                    },
                },
            });
        }
    };

    const reqPayload = () => {
        const { formControls } = requestFormState;
        const { productsByProductLineId, applicationsByProductId, productLine } = props;

        let productOptions = productsByProductLineId.data;
        let applicationOptions = applicationsByProductId.data;

        let payload = {
            assignedRmId: "303777",
            productLineName: productLine.find((el) => el.productlineid === formControls.productLine.value).productlinename ||
                "",
            productLineId: formControls.productLine.value,
            productName: productOptions.find((el) => el.id === formControls.product.value).productName ||
                "",
            productId: formControls.product.value,
            roleId: formControls.role.value,
            beltId: formControls.titleOrBelt.value,
            allocation: formControls.allocationPercentage.value,
            plannedStart: "09-27-2021",
            endDate: "11-15-2021",
            departmentId: 765,
            // rscType: formControls.resourceType.value,
            locationIds: formControls.location.value,
            technologies: formControls.technologies.value
        };
        if (formControls.application.value && formControls.application.value != "") {
            payload = {
                ...payload,
                applicationName: applicationOptions.find((el) => el.id === formControls.application.value).applicationName ||
                    "",
                applicationId: formControls.application.value,
            }
        }


        return payload;
    }

    const onSubmit = (e) => {
        e.preventDefault();

        let payload = reqPayload();

        saveRequest(payload);

        let requestFormPostValidation = validateRequestForm(
            requestFormState.formControls
        );
        if (requestFormPostValidation.error) {
            setRequestFormState({ formControls: { ...requestFormPostValidation } });
            
        } else {
            let payload = reqPayload();
            //TODO: Save in Database
            
            props.saveRequest(payload);
        }
    };

    const options = {
        options: [
            {
                id: 1,
                desc: "Employees",
            },
            {
                id: 2,
                desc: "Onshore Contractors",
            },
            {
                id: 3,
                desc: "Offshore Contractors",
            },
        ],
        id: "desc",
        value: "desc",
    };

    const optionsResource = {
        options: [
            {
                id: 1,
                desc: "Employee",
            },
            {
                id: 2,
                desc: "External",
            },
        ],
        id: "desc",
        value: "desc",
    };

    const optionsDegree = {
        options: [
            {
                id: 1,
                desc: "1",
            },
            {
                id: 2,
                desc: "2",
            },
            {
                id: 3,
                desc: "3",
            },
        ],
        id: "desc",
        value: "desc",
    };

    return (
        <Container>
            <div className="rrc-request-background">
                <Form onSubmit={onSubmit}>
                    <Form.Row>
                        <Form.Group as={Col} lg={4}>
                            {/* <Form.Label className="rrc-label">Select Template</Form.Label> */}
                            <SelectDropdown
                                name="selectTemplate"
                                label="Select template"
                                formObj={requestFormState.formControls.selectTemplate}
                                isRequired={
                                    requestFormState.formControls.selectTemplate.required
                                }
                                config={options}
                                onChange={(e) => {
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                                }
                            />
                        </Form.Group>
                        <Form.Group as={Col} lg={4}>
                            {/* <Form.Label className="rrc-label">Enter template name</Form.Label>
                            <Form.Control type="text" name="template" placeholder="Enter Template Name" /> */}
                            <TextField
                                name="enterTemplateName"
                                label="Enter template name"
                                readonly
                                formObj={requestFormState.formControls.enterTemplateName}
                                isRequired={
                                    requestFormState.formControls.enterTemplateName.required
                                }
                                readOnly={true}
                                onChange={onInputChange}
                            />
                        </Form.Group>
                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col}>
                            <SelectDropdown
                                name="productLine"
                                label="Product Line"
                                formObj={requestFormState.formControls.productLine}
                                isRequired={requestFormState.formControls.productLine.required}
                                config={{
                                    options: [...productLine],
                                    id: "productlineid",
                                    value: "productlinename",
                                }}
                                onChange={(e) => {
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                                }
                            />
                            {/* <Form.Label className="rrc-label">Product Line</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                        <Form.Group as={Col}>
                            <SelectDropdown
                                name="product"
                                label="Product"
                                formObj={requestFormState.formControls.product}
                                isRequired={requestFormState.formControls.product.required}
                                //config={options}
                                config={{
                                    options: [...productsByProductLineId.data],
                                    id: "id",
                                    value: "productName",
                                }}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                            />
                            {/* <Form.Label className="rrc-label">Product</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                        <Form.Group as={Col}>
                            <SelectDropdown
                                name="application"
                                label="Application"
                                formObj={requestFormState.formControls.application}
                                isRequired={requestFormState.formControls.application.required}
                                //config={options}
                                config={{
                                    options: [...applicationsByProductId.data],
                                    id: "id",
                                    value: "applicationName",
                                }}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                            />
                            {/* <Form.Label className="rrc-label">Application</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col}>
                            <SelectDropdown
                                name="role"
                                label="Role"
                                formObj={requestFormState.formControls.role}
                                isRequired={requestFormState.formControls.role.required}
                                config={{
                                    options: role && role.length ? [...role] : [],
                                    id: "roleDesc",
                                    value: "roleDesc",
                                }}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                            />
                            {/* <Form.Label className="rrc-label">Role</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                        <Form.Group as={Col}>
                            <SelectDropdown
                                name="titleOrBelts"
                                label="Title / Belt"
                                formObj={requestFormState.formControls.titleOrBelt}
                                isRequired={requestFormState.formControls.titleOrBelt.required}
                                config={{
                                    options: jobtitle && jobtitle.length ? [...jobtitle] : [],
                                    id: "id",
                                    value: "jobTitle",
                                }}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                            />
                            {/* <Form.Label className="rrc-label">Belt</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                        <Form.Group as={Col}>
                            <SelectDropdown
                                name="degree"
                                label="Degree"
                                formObj={requestFormState.formControls.degree}
                                isRequired={requestFormState.formControls.degree.required}
                                config={optionsDegree}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                            />
                        </Form.Group>
                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col}>
                            <TextField
                                name="allocationPercentage"
                                label="Allocation %"
                                formObj={requestFormState.formControls.allocationPercentage}
                                isRequired={requestFormState.formControls.allocationPercentage.required}
                                type={"number"}
                                onChange={onInputChange}
                            />
                            {/* <Form.Label className="rrc-label">Allocation %</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                        <Form.Group as={Col} style={{padding: "10px"}}>
                            <Datepicker
                                name="plannedStartDate"
                                label="Planned Start Date"
                                formObj={requestFormState.formControls.plannedStartDate}
                                isRequired={requestFormState.formControls.plannedStartDate.required}
                                onChange={manageMonthSelection}
                                dateFormat={FORM_DATE_FORMAT}
                                className={"request-datepicker"}
                            />
                            {/* <Datepicker label="Planned Start & End Date" enableRange={true} onChange={onInputChange} /> */}
                            {/* <Form.Label className="rrc-label">Planned Start & End Date</Form.Label>
                            <Form.Control type="number" name="template" /> */}
                        </Form.Group>
                        <Form.Group as={Col} style={{padding: "10px"}}>
                            <Datepicker
                                name="plannedEndDate"
                                label="Planned End Date"
                                formObj={requestFormState.formControls.plannedEndDate}
                                isRequired={requestFormState.formControls.plannedEndDate.required}
                                onChange={manageMonthSelection}
                                dateFormat={FORM_DATE_FORMAT}
                                className={"request-datepicker"}
                            />
                            {/* <Datepicker label="Planned Start & End Date" enableRange={true} onChange={onInputChange} /> */}
                            {/* <Form.Label className="rrc-label">Planned Start & End Date</Form.Label>
                            <Form.Control type="number" name="template" /> */}
                        </Form.Group>


                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col}>
                            <CustomSelect
                                name="technologies"
                                label="Technologies"
                                formObj={requestFormState.formControls.technologies}
                                isRequired={requestFormState.formControls.technologies.required}
                                isMulti={true}
                                config={{
                                    options: [...technologie],
                                    id: "id",
                                    value: "skillName",
                                }}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                                placeholder=""
                            />
                        </Form.Group>
                        <Form.Group as={Col}>
                            <CustomSelect
                                name="location"
                                label="Location"
                                formObj={requestFormState.formControls.location}
                                isRequired={requestFormState.formControls.location.required}
                                isMulti={true}
                                config={{
                                    options: [...location],
                                    id: "id",
                                    value: "stateDesc",
                                }}
                                onChange={(e) =>
                                    onInputChange({
                                        target: { name: e.name, value: e.value },
                                    })
                                }
                                placeholder=""
                                />
                            {/* <Form.Label className="rrc-label">Location</Form.Label>
                            <Form.Control as="select" name="template">
                            </Form.Control> */}
                        </Form.Group>
                        <Form.Group as={Col}>
                            <TextField
                                name="comments"
                                label="Comments"
                                formObj={requestFormState.formControls.comments}
                                isRequired={requestFormState.formControls.comments.required}
                                onChange={onInputChange}
                            />
                            {/* <Form.Label className="rrc-label">Comments</Form.Label>
                            <Form.Control type="text" name="template" placeholder="Comments" /> */}
                        </Form.Group>
                    </Form.Row>
                    <Row>
                        <Col>
                            <div className="rcc-buttons">
                                <button className="rcc-buttons-submit">Submit</button>
                            </div>
                        </Col>
                    </Row>
                </Form>
            </div>
        </Container>
    );
};

const mapStateToProps = (state, ownProps) => ({
    productLine: state.RequestResourceReducer.productLine,
    product: state.RequestResourceReducer.product,
    application: state.RequestResourceReducer.application,
    role: state.RequestResourceReducer.role,
    belt: state.RequestResourceReducer.belt,
    technologie: state.RequestResourceReducer.technologie,
    location: state.RequestResourceReducer.location,
    jobtitle: state.RequestResourceReducer.jobtitle,
    productsByProductLineId: state.RequestResourceReducer.productsByProductLineId,
    applicationsByProductId: state.RequestResourceReducer.applicationsByProductId,
    saveRequestStatus: state.RequestResourceReducer.saveRequestStatus,
});

const mapDispatchToProps = (dispatch) => ({
    getProductLines: () => dispatch(getProductLineThunk()),
    getApplication: () => dispatch(getApplicationThunk()),
    getRole: () => dispatch(getRoleThunk()),
    getBelt: () => dispatch(getBeltThunk()),
    getTechnologie: () => dispatch(getTechnologieThunk()),
    getLocation: () => dispatch(getLocationThunk()),
    getProduct: () => dispatch(getProductThunk()),
    getJobTitle: () => dispatch(getJobTitleThunk()),
    getProductsByProductLineId: (productLineId, callback) => dispatch(getProductsByProductLineIdThunk(productLineId, callback)),
    getApplicationsByProductId: (productId, callback) => dispatch(getApplicationsByProductIdThunk(productId, callback)),
    saveRequest: (requestForm, callback) => dispatch(saveRequestThunk(requestForm, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(RequestForm);
