// import React from 'react';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import React from 'react';
import { fireEvent, render, cleanup, wait, screen, getByText } from '@testing-library/react';
import { Provider } from 'react-redux';
import RequestTemplatesRRC, { mapStateToProps } from './requestTemplatesRRC';
import mockAxios from 'axios';
import RequestTemplatesReducer from '../../store/RequestTemplatesRRC';

// Import Mock Data
import {
  applications,
  portfolios,
  products,
  resourceTypes,
  degrees,
  roles,
  titles,
  template,
  locations,
  templates,
  skills,
  updateTemplate
} from '../../../../../../test_fixtures/mock_data';

import {
  SET_REQUEST_TEMPLATE_BY_ID,
  SET_REQUEST_TEMPLATES_BY_OWNER,
  setRequestTemplateById,
  setRequestTemplateByIdThunk,
  setRequestTemplatesByOwner,
  setRequestTemplatesByOwnerThunk,
  UPDATE_REQUEST_TEMPLATE
} from '../../store';

const baseProps = {
  setRequestTemplatesByOwner: jest.fn(),
  setRequestTemplateById: jest.fn(),
  portfolios,
  products,
  template: template,
  applications,
  resourceTypes,
  user: {},
  templates: templates,
  degrees,
  roles,
  titles,
  locations,
  handleIsShow: jest.fn()
};
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore({ RequestResourceReducer: { portfolios, products, applications }, FieldsReducer: { locations, roles, titles, degrees, resourceTypes, skills }, RequestTemplatesReducer: { templates }, AuthReducer: { user: { id: 'admin' } } });
const resetStore = () => store = mockStore({ RequestResourceReducer: { portfolios, products, applications }, FieldsReducer: { locations, roles, titles, degrees, resourceTypes, skills }, RequestTemplatesReducer: { templates }, AuthReducer: { user: { id: 'admin' } } });
const updatedTemplate = updateTemplate;

let rendered;
beforeEach(() => {
  const { container } = render(
    <Provider store={store}>
      <RequestTemplatesRRC {...baseProps} childProps={{ template: template }} />
    </Provider>
  );
  rendered = container;
});
afterEach(cleanup);

it('can render and load the initial data', () => {
  // To check if the pre-selected fields got set correctly, so later we can check if the select will reset the other field.
  expect(rendered).toMatchSnapshot();
});
it('The modal will appear when the user click the Create Template button', async () => {
  await wait(() =>
    fireEvent.click(getByText(rendered, 'Create Template'))
  );
  expect(screen.getByText('Create Request Template').textContent).toBe('Create Request Template');
});

describe('Redux Store for RequestTemplates', () => {
  beforeEach(() => {
    resetStore();
    console.error = jest.fn();
  });
  describe('RequestTemplates Store Actions', () => {
    it('should create an action to set request templates by particular owner', () => {
      const expectedAction = {
        type: SET_REQUEST_TEMPLATES_BY_OWNER,
        templates
      };
      expect(setRequestTemplatesByOwner(templates)).toEqual(expectedAction);
    });
    it('should create an action to set request template by draft id', () => {
      const expectedAction = {
        type: SET_REQUEST_TEMPLATE_BY_ID,
        template
      };
      expect(setRequestTemplateById(template)).toEqual(expectedAction);
    });
  });

  describe('RequestTemplates Thunk Middleware', () => {
    it('Axios GET call should get the correct response for setRequestTemplatesByOwner', async () => {
      const user = 'admin';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: templates } }));
      const expectedActions = [
        {
          type: SET_REQUEST_TEMPLATES_BY_OWNER,
          templates
        }
      ];
      await store.dispatch(setRequestTemplatesByOwnerThunk(user));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/requesttemplates', { params: { templateOwner: user } });
    });
    it('Axios GET call should get the correct response for setRequestTemplateById', async () => {
      const templateId = '1';
      mockAxios.get.mockImplementationOnce(() => Promise.resolve({ data: { data: template } }));
      const expectedActions = [
        {
          type: SET_REQUEST_TEMPLATE_BY_ID,
          template
        }
      ];
      await store.dispatch(setRequestTemplateByIdThunk(templateId));
      expect(store.getActions()).toEqual(expectedActions);
      expect(mockAxios.get).toHaveBeenCalledWith('/v1/requesttemplates/' + templateId);
    });
  });

  describe('RequestTemplates Reducer', () => {
    it('should return the initial state', () => {
      expect(RequestTemplatesReducer({ templates: [], template: {} }, {})).toEqual({ templates: [], template: {} });
    });
    it('should handle SET_REQUEST_TEMPLATES_BY_OWNER appropriately', () => {
      expect(RequestTemplatesReducer({ templates: [], template: {} }, {
        type: SET_REQUEST_TEMPLATES_BY_OWNER,
        templates
      }))
        .toEqual({ templates: templates, template: {} });
    });
    it('should handle SET_REQUEST_TEMPLATE_BY_ID appropriately', () => {
      expect(RequestTemplatesReducer({ templates: [], template: {} }, {
        type: SET_REQUEST_TEMPLATE_BY_ID,
        template
      }))
        .toEqual({ templates: [], template: template });
    });
    it('should handle UPDATE_REQUEST_TEMPLATE appropriately', () => {
      expect(RequestTemplatesReducer({ templates: [], template: {} }, {
        type: UPDATE_REQUEST_TEMPLATE,
        updatedTemplate
      }))
        .toEqual({ templates: [], template: {} });
    });
    it('should handle DELETE_REQUEST_TEMPLATE appropriately', () => {
      expect(RequestTemplatesReducer({ templates: [], template: {} }, {
        type: UPDATE_REQUEST_TEMPLATE,
        updatedTemplate
      }))
        .toEqual({ templates: [], template: {} });
    });
  });
  describe('mapStateToProps for RequestTemplates', () => {
    it('mapStateToProps should have correct initial state', () => {
      const initialState = {
        RequestResourceReducer: {
          portfolios: [],
          products: [],
          applications: []
        },
        FieldsReducer: {
          resourceTypes: []
        },
        AuthReducer: {
          user: { id: '' }
        },
        RequestTemplatesReducer: {
          templates: [],
          template: {}
        }
      };
      expect(mapStateToProps(initialState)).toEqual({
        portfolios: [],
        products: [],
        applications: [],
        resourceTypes: [],
        user: { id: '' },
        templates: [],
        template: {}
      });
    });
  });
});
