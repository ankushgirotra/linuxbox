import React from 'react';
import { configure, shallow } from 'enzyme/build';
import EnzymeAdapter from 'enzyme-adapter-react-16/build';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import mockAxios from 'axios';

import { AdminUploadRRC, mapDispatchToProps } from './adminUploadRRC';
import { Routes } from '../../../../../app/Route/Routes';

import UploadReducer, { uploadDataThunk, sanitizeColumnTitles } from '../../store/UploadRRC';

// for enzyme to work
configure({ adapter: new EnzymeAdapter() });

let component = null;
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
let store = mockStore();
const resetStore = () => store = mockStore();
const mockFile = new File(['Test', 'Data'], 'Portfolio.csv', { type: 'text/csv' });

const baseProps = {
  uploadDataThunks: jest.fn(),
  files: [mockFile],
  dataUploadDropdownOptions: ['Portfolio', 'Product', 'Application', 'Skill'],
  username: 'admin'
};

describe('adminUpload component', () => {
  beforeEach(() => {
    component = shallow(<AdminUploadRRC {...baseProps} />).setState({ files: baseProps.files });
  });

  it('AdminUpload renders in UI without crashing', async () => {
    const wrapper = shallow(<AdminUploadRRC {...baseProps} />);
    expect(wrapper).toMatchSnapshot();
  });

  describe('Component handlers and alerts', () => {
    it('Should capture the file.dataType correctly onChange', () => {
      const input = component.find('select');
      input.simulate('change', {
        target: {
          name: 'Portfolio.csv',
          value: 'Portfolio'
        }
      });
      expect(component.state().files[0].dataType).toEqual('Portfolio');
    });
    it('Should call handleSubmit correctly when button clicked', async () => {
      const expected = {
        files: [],
        dataUploadDropdownOptions: ['Portfolio', 'Product', 'Application', 'Skill']
      };
      await component.find('#confirmUploadButton').simulate('click');
      expect(baseProps.uploadDataThunks).toHaveBeenCalled();
      expect(component.state()).toEqual(expected);
    });
    it('Should alert user if the file.dataType attribute does not match the file.name attribute', async () => {
      jest.spyOn(console, 'error').mockImplementation(() => {
      });
      const input = component.find('select');
      input.simulate('change', {
        target: {
          name: 'Portfolio.csv',
          value: 'Product'
        }
      });
      expect(console.error).toHaveBeenCalledTimes(1);
    });
    it('handleFileUpload should set state properly', async () => {
      const files = [mockFile];
      const expectedState = {
        files,
        dataUploadDropdownOptions: ['Portfolio', 'Product', 'Application', 'Skill']
      };
      component.instance().handleFileUpload(files);
      expect(component.state()).toEqual(expectedState);
    });
  });
});

describe('Redux store for Configs', () => {
  beforeEach(() => {
    resetStore();
  });

  describe('Configs Thunk Middleware', () => {
    it('uploadDataThunks should transform Portfolios CSV file data, convert it to JSON payload, and make a request to /v1/uploadPortfolios', async () => {
      const fileData = ['ï»¿PortfolioID,PortfolioName\n' +
      '20,Claims & Benefit Administration - Keystone\n' +
      '3,Corporate Services\n' +
      '4,Customer Engagement\n' +
      '6,EMPCO\n' +
      '7,Enterprise Architecture Services\n' +
      '8,Enterprise Services Portfolio\n' +
      '11,Finance and Actuarial\n' +
      '12,Government\n' +
      '13,Group\n' +
      '14,Infrastructure\n' +
      '16,Provider & Network\n' +
      '17,Retail\n' +
      '18,Security\n' +
      '5,Claims and Product & Benefit Administration\n' +
      '19,Digital Delivery\n' +
      '22,Health Analytics\n' +
      '23,DevOps'];
      const portfolioFile = new File(fileData, 'Portfolio.csv', { type: 'text/csv' });
      portfolioFile.dataType = 'Portfolio';
      const portfolioDataPayload = {
        portfolios: [
          {
            id: '20',
            name: 'Claims & Benefit Administration - Keystone'
          },
          {
            id: '3',
            name: 'Corporate Services'
          },
          {
            id: '4',
            name: 'Customer Engagement'
          },
          {
            id: '6',
            name: 'EMPCO'
          },
          {
            id: '7',
            name: 'Enterprise Architecture Services'
          },
          {
            id: '8',
            name: 'Enterprise Services Portfolio'
          },
          {
            id: '11',
            name: 'Finance and Actuarial'
          },
          {
            id: '12',
            name: 'Government'
          },
          {
            id: '13',
            name: 'Group'
          },
          {
            id: '14',
            name: 'Infrastructure'
          },
          {
            id: '16',
            name: 'Provider & Network'
          },
          {
            id: '17',
            name: 'Retail'
          },
          {
            id: '18',
            name: 'Security'
          },
          {
            id: '5',
            name: 'Claims and Product & Benefit Administration'
          },
          {
            id: '19',
            name: 'Digital Delivery'
          },
          {
            id: '22',
            name: 'Health Analytics'
          },
          {
            id: '23',
            name: 'DevOps'
          }
        ]
      };
      mockAxios.post.mockImplementationOnce(() => Promise.resolve());
      await store.dispatch(uploadDataThunk(portfolioFile));
      expect(mockAxios.post).toHaveBeenCalledWith('/v1/uploadPortfolios', portfolioDataPayload);
    });

    it('uploadDataThunks should transform Product CSV file data, convert it to a JSON payload, and make a request to /v1/uploadProducts', async () => {
      const fileData = ['ï»¿ID,Product,Active,Open For Time,Description,Manager,Portfolio\n' +
      'PRD00000183,PRODUCT Business - SSO,Yes,No,,,Business\n' +
      'PRD00000150,Cross-product - Enterprise Services Portfolio: EIS,Yes,No,Cross-product - Enterprise Services Portfolio: EIS,,\n' +
      'PRD00000337,PRODUCT Digital Information & Experience Service Layer (DIESL),Yes,No,,"Fields, Marshall",Digital Delivery\n' +
      'PRD00000230,PRODUCT Product Management,Yes,No,,"Becker, Donald",Government\n' +
      'PRD00000050,SUSTAIN Business - Finance,Yes,Yes,,,Business\n' +
      'PRD00000248,PRODUCT Business - GPD,Yes,No,,,Business\n' +
      'PRD00000206,PRODUCT Enrollment & Eligibility,Yes,Yes,,"Kumar, Nimit",Group\n'];
      const productFile = new File(fileData, 'Product.csv', { type: 'text/csv' });
      productFile.dataType = 'Product';
      const productDataPayload = {
        products:
          [{
            id: 'PRD00000183',
            name: 'PRODUCT Business - SSO',
            isActive: true,
            openForTime: false,
            description: '',
            managerName: '',
            portfolioName: 'Business'
          },
          {
            id: 'PRD00000150',
            name: 'Cross-product - Enterprise Services Portfolio: EIS',
            isActive: true,
            openForTime: false,
            description: 'Cross-product - Enterprise Services Portfolio: EIS',
            managerName: '',
            portfolioName: ''
          },
          {
            id: 'PRD00000337',
            name:
                'PRODUCT Digital Information & Experience Service Layer (DIESL)',
            isActive: true,
            openForTime: false,
            description: '',
            managerName: 'Fields, Marshall',
            portfolioName: 'Digital Delivery'
          },
          {
            id: 'PRD00000230',
            name: 'PRODUCT Product Management',
            isActive: true,
            openForTime: false,
            description: '',
            managerName: 'Becker, Donald',
            portfolioName: 'Government'
          },
          {
            id: 'PRD00000050',
            name: 'SUSTAIN Business - Finance',
            isActive: true,
            openForTime: true,
            description: '',
            managerName: '',
            portfolioName: 'Business'
          },
          {
            id: 'PRD00000248',
            name: 'PRODUCT Business - GPD',
            isActive: true,
            openForTime: false,
            description: '',
            managerName: '',
            portfolioName: 'Business'
          },
          {
            id: 'PRD00000206',
            name: 'PRODUCT Enrollment & Eligibility',
            isActive: true,
            openForTime: true,
            description: '',
            managerName: 'Kumar, Nimit',
            portfolioName: 'Group'
          }]
      };
      mockAxios.post.mockImplementationOnce(() => Promise.resolve());
      await store.dispatch(uploadDataThunk(productFile));
      expect(mockAxios.post).toHaveBeenCalledWith('/v1/uploadProducts', productDataPayload);
    });

    it('uploadDataThunks should transform Application CSV file data, convert it to a JSON payload, and make a request to /v1/uploadApplications', async () => {
      const fileData = ['ï»¿ID,Application,Application Type,Active,Open for Time,Portfolio,Portfolio Owner,Product,Product ID,Application / Product Manager,Application / Product Manager (Alternate),Current Status\n' +
      'APP00007020,NetIQ Sentinel,Tool,Yes,No,Infrastructure,"Petrassi, Vincenzo",PRODUCT Infrastructure,PRD00000221,"Abraham, Randl","Khan, Syed",Production\n' +
      'APP00005940,Virtual Directory Service,Application Service,Yes,Yes,Infrastructure,"Petrassi, Vincenzo",PRODUCT Infrastructure,PRD00000221,"Abraham, Randl","Khan, Syed",Production\n' +
      'APP00005669,LDAP,Application Service,Yes,Yes,Security,"Charest, Kevin",PRODUCT Security,PRD00000242,"Abraham, Randl","Khan, Syed",Production\n' +
      'APP00006946,Health Analytics Membership Gold,Data Repository,Yes,No,Health Analytics,"Low, Robert",PRODUCT Domain Membership Data,PRD00000299,"Addanki, Srinivasu",,Production\n' +
      'APP00006844,GPD Consumption,Data Repository,Yes,No,Health Analytics,"Low, Robert",PRODUCT Consumption Government Data,PRD00000217,"Aeschleman, Paul","Gafney, Christopher",Production\n' +
      'APP00006014,eHealthInsurance,Application,Yes,Yes,Health Analytics,"Low, Robert",PRODUCT Consumption Government Data,PRD00000217,"Aeschleman, Paul",,Retired\n' +
      'APP00007105,Government Pricing,Data Repository,Yes,No,Business,,PRODUCT Business - GPD,PRD00000248,"Amaram, Rakesh",,Production\n' +
      'APP00005674,eDirectory,Application,Yes,Yes,Infrastructure,"Petrassi, Vincenzo",PRODUCT Infrastructure,PRD00000221,"Anders, Todd","Giambalvo, William",Scheduled For Retirement\n' +
      'APP00006293,Enterprise Reporting Enviornment,Data Repository,Yes,Yes,EMPCO,"Bauernfreund, Brian",PRODUCT Case / Condition Management,PRD00000188,"Arabie, Janet","Hood, Patricia",Production\n' +
      'APP00006957,Livongo,Application,Yes,No,EMPCO,"Bauernfreund, Brian",PRODUCT Case / Condition Management,PRD00000188,"Arabie, Janet","Hood, Patricia",Production'];
      const applicationsFile = new File(fileData, 'Application.csv', { type: 'text/csv' });
      applicationsFile.dataType = 'Application';
      const applicationsDataPayload = {
        applications:
          [{
            id: 'APP00007020',
            name: 'NetIQ Sentinel',
            type: 'Tool',
            isActive: true,
            openForTime: false,
            portfolioName: 'Infrastructure',
            portfolioOwner: 'Petrassi, Vincenzo',
            productName: 'PRODUCT Infrastructure',
            productId: 'PRD00000221',
            managerName: 'Abraham, Randl',
            managerNameAlternate: 'Khan, Syed',
            currentStatus: 'Production'
          },
          {
            id: 'APP00005940',
            name: 'Virtual Directory Service',
            type: 'Application Service',
            isActive: true,
            openForTime: true,
            portfolioName: 'Infrastructure',
            portfolioOwner: 'Petrassi, Vincenzo',
            productName: 'PRODUCT Infrastructure',
            productId: 'PRD00000221',
            managerName: 'Abraham, Randl',
            managerNameAlternate: 'Khan, Syed',
            currentStatus: 'Production'
          },
          {
            id: 'APP00005669',
            name: 'LDAP',
            type: 'Application Service',
            isActive: true,
            openForTime: true,
            portfolioName: 'Security',
            portfolioOwner: 'Charest, Kevin',
            productName: 'PRODUCT Security',
            productId: 'PRD00000242',
            managerName: 'Abraham, Randl',
            managerNameAlternate: 'Khan, Syed',
            currentStatus: 'Production'
          },
          {
            id: 'APP00006946',
            name: 'Health Analytics Membership Gold',
            type: 'Data Repository',
            isActive: true,
            openForTime: false,
            portfolioName: 'Health Analytics',
            portfolioOwner: 'Low, Robert',
            productName: 'PRODUCT Domain Membership Data',
            productId: 'PRD00000299',
            managerName: 'Addanki, Srinivasu',
            managerNameAlternate: '',
            currentStatus: 'Production'
          },
          {
            id: 'APP00006844',
            name: 'GPD Consumption',
            type: 'Data Repository',
            isActive: true,
            openForTime: false,
            portfolioName: 'Health Analytics',
            portfolioOwner: 'Low, Robert',
            productName: 'PRODUCT Consumption Government Data',
            productId: 'PRD00000217',
            managerName: 'Aeschleman, Paul',
            managerNameAlternate: 'Gafney, Christopher',
            currentStatus: 'Production'
          },
          {
            id: 'APP00006014',
            name: 'eHealthInsurance',
            type: 'Application',
            isActive: true,
            openForTime: true,
            portfolioName: 'Health Analytics',
            portfolioOwner: 'Low, Robert',
            productName: 'PRODUCT Consumption Government Data',
            productId: 'PRD00000217',
            managerName: 'Aeschleman, Paul',
            managerNameAlternate: '',
            currentStatus: 'Retired'
          },
          {
            id: 'APP00007105',
            name: 'Government Pricing',
            type: 'Data Repository',
            isActive: true,
            openForTime: false,
            portfolioName: 'Business',
            portfolioOwner: '',
            productName: 'PRODUCT Business - GPD',
            productId: 'PRD00000248',
            managerName: 'Amaram, Rakesh',
            managerNameAlternate: '',
            currentStatus: 'Production'
          },
          {
            id: 'APP00005674',
            name: 'eDirectory',
            type: 'Application',
            isActive: true,
            openForTime: true,
            portfolioName: 'Infrastructure',
            portfolioOwner: 'Petrassi, Vincenzo',
            productName: 'PRODUCT Infrastructure',
            productId: 'PRD00000221',
            managerName: 'Anders, Todd',
            managerNameAlternate: 'Giambalvo, William',
            currentStatus: 'Scheduled For Retirement'
          },
          {
            id: 'APP00006293',
            name: 'Enterprise Reporting Enviornment',
            type: 'Data Repository',
            isActive: true,
            openForTime: true,
            portfolioName: 'EMPCO',
            portfolioOwner: 'Bauernfreund, Brian',
            productName: 'PRODUCT Case / Condition Management',
            productId: 'PRD00000188',
            managerName: 'Arabie, Janet',
            managerNameAlternate: 'Hood, Patricia',
            currentStatus: 'Production'
          },
          {
            id: 'APP00006957',
            name: 'Livongo',
            type: 'Application',
            isActive: true,
            openForTime: false,
            portfolioName: 'EMPCO',
            portfolioOwner: 'Bauernfreund, Brian',
            productName: 'PRODUCT Case / Condition Management',
            productId: 'PRD00000188',
            managerName: 'Arabie, Janet',
            managerNameAlternate: 'Hood, Patricia',
            currentStatus: 'Production'
          }]
      };
      mockAxios.post.mockImplementationOnce(() => Promise.resolve());
      await store.dispatch(uploadDataThunk(applicationsFile));
      expect(mockAxios.post).toHaveBeenCalledWith('/v1/uploadApplications', applicationsDataPayload);
    });
    it('uploadDataThunks should transform Skill CSV file data, convert it to a JSON payload, and make a request to /v1/uploadSkills', async () => {
      const fileData = ['ï»¿SkillID,SkillName,SkillCategory,SkillsDescription,SpecializedSkills,HighLevelTechName (Field is no longer used),MainTechnology,Created,Created By,Modified,Modified By,ProfileName,ProfileName:ProfileID,Active,Item Type,Path\n' +
      '1,Cobol,Cobol,,,MF Language,Yes,3/30/18 4:01,Rajesh kumar Sankaran,5/16/18 20:56,Patsy Trickel,Mainframe,6.00000000000000,,Item,teams/Rover/Lists/Skills\n' +
      '2,CICS,Cobol,,,MF Language,,3/30/18 4:01,Rajesh kumar Sankaran,3/30/18 4:01,Rajesh kumar Sankaran,,,,Item,teams/Rover/Lists/Skills\n' +
      '3,JCL,Cobol,,,MF Language,,3/30/18 4:01,Rajesh kumar Sankaran,3/30/18 4:01,Rajesh kumar Sankaran,,,,Item,teams/Rover/Lists/Skills\n'];
      const skillsFile = new File(fileData, 'Skills.csv', { type: 'text/csv' });
      skillsFile.dataType = 'Skill';
      const skillsDataPayload = {
        skills: [
          {
            skillId: '1',
            skillName: 'Cobol',
            skillCategory: 'Cobol',
            skillsDescription: '',
            specializedSkills: false,
            mainTechnology: true,
            created: '3/30/18 4:01',
            createdBy: 'Rajesh kumar Sankaran',
            modified: '5/16/18 20:56',
            modifiedBy: 'Patsy Trickel',
            profileName: 'Mainframe',
            profileId: '6.00000000000000',
            active: false
          },
          {
            skillId: '2',
            skillName: 'CICS',
            skillCategory: 'Cobol',
            skillsDescription: '',
            specializedSkills: false,
            mainTechnology: false,
            created: '3/30/18 4:01',
            createdBy: 'Rajesh kumar Sankaran',
            modified: '3/30/18 4:01',
            modifiedBy: 'Rajesh kumar Sankaran',
            profileName: '',
            profileId: '',
            active: false
          },
          {
            skillId: '3',
            skillName: 'JCL',
            skillCategory: 'Cobol',
            skillsDescription: '',
            specializedSkills: false,
            mainTechnology: false,
            created: '3/30/18 4:01',
            createdBy: 'Rajesh kumar Sankaran',
            modified: '3/30/18 4:01',
            modifiedBy: 'Rajesh kumar Sankaran',
            profileName: '',
            profileId: '',
            active: false
          }
        ]
      };
      mockAxios.post.mockImplementationOnce(() => Promise.resolve());
      await store.dispatch(uploadDataThunk(skillsFile));
      expect(mockAxios.post).toHaveBeenCalledWith('/v1/uploadSkills', skillsDataPayload);
    });
  });

  describe('UploadReducer', () => {
    it('should return the initial state', () => {
      expect(UploadReducer([], {})).toEqual([]);
    });
  });

  describe('Helper Functions in Upload (store)', () => {
    it('sanitizeColumnTitles should cleanse the column names and return a cleansed array', () => {
      const expectedTitles = ['PortfolioID', 'PortfolioName'];
      const csvColumnTitles = ['ï»¿PortfolioID', 'PortfolioName'];
      const sanitizedArray = sanitizeColumnTitles(expectedTitles, csvColumnTitles);
      expect(sanitizedArray).toEqual(expectedTitles);
    });
  });
});

describe('User Authorization', () => {
  it('If the user is an authorized uploader, then the NotFoundPage function is not called', async () => {
    const NotFoundPage = jest.fn();
    component = shallow(<Routes store={store} {...baseProps} />).setState({
      username: 'admin'
    });
    expect(NotFoundPage).toHaveBeenCalledTimes(0);
  });
});

describe('mapDispatchToProps', () => {
  it('mapDispatchToProps should dispatch action when button is clicked to submit file(s)', () => {
    const dispatch = jest.fn();
    const props = mapDispatchToProps(dispatch);
    props.uploadDataThunks(mockFile);
    expect(dispatch).toHaveBeenCalledTimes(1);
  });
});
