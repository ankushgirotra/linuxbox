export const ERROR_MSG = {
    REQUIRED_FIELD: "Please fill the required field",
    ALLOCATION_PERCENTAGE_ERROR: "Please enter a value greater than 0",
    ALLOCATION_DECIMAL_ERROR: "Please enter a non-decimal/complete number"
};
