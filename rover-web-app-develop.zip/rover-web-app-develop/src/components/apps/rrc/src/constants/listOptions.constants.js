export const RequestAdminfilterListOptions = [
    { id: 1, name: "External Blockers" },
    { id: 2, name: "Email Notification" },
  ];

  export const RequestVendorOptions = [
    { id: 1, name: "YES" },
    { id: 2, name: "NO" }
  ];
  