export const FORM_DATE_FORMAT = "MM/DD/YYYY";
export const DEFAULT_TECH_LIST = [];