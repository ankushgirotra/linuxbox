import moment from "moment";
import { ERROR_MSG } from "../constants/message.constants";

export const validateRequestForm = (formControls) => {
    let formState = {
        ...formControls,
        error: false,
    };
    for (const [key, valueObj] of Object.entries(formControls)) {
        if (
            valueObj.required &&
            (valueObj.value === null ||
                valueObj.value === undefined || valueObj.value === "" ||
                (typeof valueObj.value === "string" && valueObj.value.trim() === "") || valueObj.value.length === 0 )
                    
        ) {
            formState = {
                ...formState,
                error: true,
                [key]: {
                    ...formControls[key],
                    error: true,
                    errorMsg: ERROR_MSG.REQUIRED_FIELD,
                },
            };
        }
        else if (
            key === "allocationPercentage" || key === "numberOfClones"
        ) {
            if(parseInt(valueObj.value) < 1){
                formState = {
                    ...formState,
                    error: true,
                    [key]: {
                        ...formControls[key],
                        error: true,
                        errorMsg: ERROR_MSG.ALLOCATION_PERCENTAGE_ERROR,
                    },
                };
            } else if (parseFloat(valueObj.value) % 1 !== 0){
                
                formState = {
                    ...formState,
                    error: true,
                    [key]: {
                        ...formControls[key],
                        error: true,
                        errorMsg: ERROR_MSG.ALLOCATION_DECIMAL_ERROR,
                    },
                };
            }
        }
    }
    return formState;
};

export const getFormattedDate = (
    dateStr,
    resFormat = "MM/DD/YYYY",
    reqFormat = ""
  ) => {
    if (resFormat === "DATE") {
      return moment(dateStr, reqFormat).toDate();
    } else {
      return moment(dateStr, reqFormat).format(resFormat);
    }
  };
  
