import React from "react";
import LinkExtended from "../../../../shared/Link/linkExtended";
export const getExpertiseDropDownToolTip = () => {
	return (
		<React.Fragment>
			<LinkExtended
				onClick={() => {
					window.open("https://competency.fyiblue.com/");
				}}
			>
				Visit Competency Model
			</LinkExtended>
		</React.Fragment>
	);
};
