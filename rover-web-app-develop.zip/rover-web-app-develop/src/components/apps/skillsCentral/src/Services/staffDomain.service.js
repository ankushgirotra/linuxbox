import { ACTIONS } from "../../../pcdm/src/constants/action.constants";
import { ROLE_NAME_REG } from "../../../pcdm/src/constants/form.constants";
import { ERROR_MSG } from "../../../pcdm/src/constants/message.contants";
import { check } from "../../../pcdm/src/services/validation";
import {
  SAVE_STAFF_DOMAIN_SUCCESS,
  SAVE_STAFF_DOMAIN_ERROR,
  EDIT_STAFF_DOMAIN_ERROR,
  DELETE_STAFF_DOMAIN_SUCCESS,
  DELETE_STAFF_DOMAIN_ERROR,
  EDIT_STAFF_DOMAIN_SUCCESS,
} from "../store/staffDomain.reducer";
import {
  GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID,
  GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR,
  GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID,
  GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR,
} from "../store/domains.reducer";

export const handleStaffDomainAPIResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_STAFF_DOMAIN_SUCCESS || responseType === SAVE_STAFF_DOMAIN_ERROR) {
    return handleSaveResponse(props, state, responseType, responseData);
  } else if (
    responseType === EDIT_STAFF_DOMAIN_SUCCESS ||
    responseType === EDIT_STAFF_DOMAIN_ERROR
  ) {
    return handleEditResponse(props, state, responseType, responseData);
  } else if (
    responseType === DELETE_STAFF_DOMAIN_SUCCESS ||
    responseType === DELETE_STAFF_DOMAIN_ERROR
  ) {
    return handleDeleteResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_STAFF_DOMAIN_SUCCESS) {
    const propsToParent = {
      message: "Request sent to your Resource Manager for review",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
  if (responseType === EDIT_STAFF_DOMAIN_SUCCESS) {
    const propsToParent = {
      message: "Request sent to your Resource Manager for review",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
  if (responseType === DELETE_STAFF_DOMAIN_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: "Request sent to your Resource Manager for review",
        },
      },
    };
  } else {
    console.log(responseData);
    return { returnState: { savingProject: false } };
  }
};

export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const { flag, value } = check({
    path: "data",
    original: response,
    checkEmpty: true,
  });
  if ((response.status === 400 || response.status === 422) && flag) {
    let errors = value;
    for (let i = 0; i < errors.length; i++) {
      console.log(errors[i]);
      if (errors[i].code === "Skill Submission" && errors[i].field === "Domain") {
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            errorMessage: errors[i].message,
          },
        };
      } else {
        errState = {
          ...errState,
          formControls: {
            ...errState.formControls,
            error: true,
            [errors[i].field]: {
              ...errState.formControls[errors[i].field],
              error: true,
              errorMsg: ERROR_MSG.COMMON_ERR,
            },
            errorMessage: ERROR_MSG.COMMON_FORM_ERR,
          },
        };
      }
    }
  }
  return errState;
};

// export const errorState = (errorResponse, state) => {
//     const { response } = errorResponse;
//     let errState = { formControls: { ...state.formControls } };
//     const { flag, value } = check({
//         path: "data.errors",
//         original: response,
//         checkEmpty: true,
//     });
//     if (response.status === 400 && flag) {
//         const { errors } = response.data;
//         for (let i = 0; i < errors.length; i++) {
//             errState = {
//                 ...errState,
//                 formControls: {
//                     ...errState.formControls,
//                     error: true,
//                     [errors[i].field]: {
//                         ...errState.formControls[errors[i].field],
//                         error: true,
//                         errorMsg: ERROR_MSG.COMMON_ERR,
//                     },
//                 },
//             };
//         }
//     }
//     return errState;
// };

export const validateStaffDomainForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    }
    // else if (key === "sourceName" && valueObj.value.trim() !== "") {
    //     if (new RegExp(ROLE_NAME_REG).test(valueObj.value.trim())) {
    //     } else {
    //         formState = {
    //             ...formState,
    //             error: true,
    //             sourceName: {
    //                 ...formState.sourceName,
    //                 error: true,
    //                 errorMsg: ERROR_MSG.RESOURCE_NAME_ALLOW_CHAR,
    //             },
    //         };
    //     }
    // }
  }
  return formState;
};
export const modifiyFormForProductLineChange = (formState, selectedProductLine, status) => {
  if (status === GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID) {
    return {
      ...formState,
      productLine: {
        ...formState.productLine,
        value: selectedProductLine,
      },
      product: {
        ...formState.product,
        readOnly: false,
        value: null,
        error: false,
        errorMsg: "",
      },
      application: {
        ...formState.application,
        readOnly: true,
        value: null,
        error: false,
        errorMsg: "",
      },
    };
  } else if (status === GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR) {
    return {
      ...formState,
      productLine: {
        ...formState.productLine,
        value: selectedProductLine,
      },
      product: {
        ...formState.product,
        readOnly: true,
        value: null,
        error: true,
        errorMsg: "No Products found",
      },
      application: {
        ...formState.application,
        readOnly: true,
        value: null,
        error: true,
        errorMsg: "No Applications found",
      },
    };
  }
};
export const modifiyFormForProductChange = (formState, selectedProduct, status) => {
  if (status === GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID) {
    return {
      ...formState,
      product: {
        ...formState.product,
        value: selectedProduct,
      },
      application: {
        ...formState.application,
        readOnly: false,
        value: null,
      },
    };
  } else if (status === GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR) {
    return {
      ...formState,
      product: {
        ...formState.product,
        value: selectedProduct,
      },
      application: {
        ...formState.application,
        readOnly: true,
        value: null,
        error: true,
        errorMsg: "No Applications found",
      },
    };
  }
};
