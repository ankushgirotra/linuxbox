export const getSkillSubmissionList = (staffSubmissionList) => {
  const skillSubmissionList = staffSubmissionList.length
    ? staffSubmissionList.map((submission) => {
        return {
          id: submission.submissionId,
          submission: submission.submissionType,
          submittedOn: submission.submittedDate,
          skillType: submission.skillType,
          skillName: submission.skillName,
          currentRating: submission.currentExpertiseId,
          requestedRating: submission.proposedExpertiseId,
          justification: submission.submissionJustification,
          activeTech: submission.activeTech,
          mentor: submission.mentor,
        };
      })
    : [];
  return skillSubmissionList;
};

export const getDomainSubmissionList = (staffSubmissionList) => {
  const skillSubmissionList = staffSubmissionList.length
    ? staffSubmissionList.map((submission) => {
        return {
          id: submission.submissionId,
          submission: submission.submissionType,
          submittedOn: submission.submittedDate,
          skillType: submission.skillType ? submission.skillType : "Domain",
          productLineName: submission.domainProdLineName,
          productName: submission.domainProdName,
          applicationName: submission.domainAppName,
          currentRating: submission.currentExpertiseId,
          requestedRating: submission.proposedExpertiseId,
          justification: submission.submissionJustification,
          activeTech: submission.activeTech,
          mentor: submission.mentor,
        };
      })
    : [];
  return skillSubmissionList;
};
