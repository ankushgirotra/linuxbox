export const getSortedList = (inputList, keyProperty) => {
  const sortedList = inputList.sort(function (row1, row2) {
    let name1 = row1[keyProperty].toLowerCase(); //case-insenstive Comparsion
    let name2 = row2[keyProperty].toLowerCase();
    if (String(name1).trim() > String(name2).trim()) return 1;
    if (String(name2).trim() > String(name1).trim()) return -1;
    return 0;
  });
//   const sortedList = inputList.sort((a, b) =>
//     String(a[keyProperty]).trim().localeCompare(String(b[keyProperty]).trim())
//   );
  return sortedList;
};
