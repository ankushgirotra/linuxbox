import { ACTIONS } from "../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../pcdm/src/constants/message.contants";
import { check } from "../../../pcdm/src/services/validation";
import { SC_ADMIN_ACTION_TYPE } from "../Constants/action.constants";

export const handleAdminTechnologyAPIResponse = (props, state, responseType, responseData) => {
  if (
    responseType === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_TECHNOLOGY_SUCCESS ||
    responseType === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_TECHNOLOGY_ERROR
  ) {
    return handleTechnologySaveResponse(props, state, responseType, responseData);
  } else if (
    responseType === SC_ADMIN_ACTION_TYPE.UPDATE_ADMIN_TECHNOLOGY_SUCCESS ||
    responseType === SC_ADMIN_ACTION_TYPE.UPDATE_ADMIN_TECHNOLOGY_ERROR
  ) {
    return handleTechnologyEditResponse(props, state, responseType, responseData);
  }  else if (
    responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_TECHNOLOGY_SUCCESS ||
    responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_TECHNOLOGY_ERROR
  ) {
    return handleTechnologyDeleteResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleAdminMethodologyAPIResponse = (responseType, responseData) => {
  if (
    responseType === SC_ADMIN_ACTION_TYPE.SAVE_ADMIN_METHODOLOGY_SUCCESS ||
    responseType === SC_ADMIN_ACTION_TYPE.SAVE_ADMIN_METHODOLOGY_ERROR
  ) {
    return handleMethodologySaveResponse(responseType, responseData);
  } else if (
    responseType === SC_ADMIN_ACTION_TYPE.EDIT_ADMIN_METHODOLOGY_SUCCESS ||
    responseType === SC_ADMIN_ACTION_TYPE.EDIT_ADMIN_METHODOLOGY_ERROR
  ) {
    return handleMethodologyEditResponse(responseType, responseData);
  }  else if (
    responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_METHODOLOGY_SUCCESS ||
    responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_METHODOLOGY_ERROR
  ) {
    return handleMethodologyDeleteResponse(responseType, responseData);
  } else {
    return { modal: null };
  }
};

export const handleTechnologySaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_TECHNOLOGY_SUCCESS) {
    const propsToParent = {
      message: "Technology added successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleTechnologyEditResponse = (props, state, responseType, responseData) => {
  if (responseType === SC_ADMIN_ACTION_TYPE.UPDATE_ADMIN_TECHNOLOGY_SUCCESS) {
    const propsToParent = {
      message: "Technology updated successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleTechnologyDeleteResponse = (props, state, responseType, responseData) => {
  if (responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_TECHNOLOGY_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: "Technology deleted successfully",
        },
      },
    };
  } else if (responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_TECHNOLOGY_ERROR) {
    let errResponse = responseData && responseData.response && responseData.response.data
      ? responseData.response.data : "Error in deleting Technology";
    return {
      modal: {
        action: ACTIONS.ERROR,
        props: {
          message: errResponse,
        },
      },
    };
  }
};

export const handleMethodologySaveResponse = (responseType, responseData) => {
  if (responseType === SC_ADMIN_ACTION_TYPE.SAVE_ADMIN_METHODOLOGY_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: "Methodology added successfully",
        },
      },
    };
  } else if (responseType === SC_ADMIN_ACTION_TYPE.SAVE_ADMIN_METHODOLOGY_ERROR) {
    let errResponse = responseData && responseData.response && responseData.response.data
      ? responseData.response.data :  "Error in Adding Methodology";
    return {
      modal: {
        action: ACTIONS.ERROR,
        props: {
          message: errResponse,
        },
      },
    };
  }
};

export const handleMethodologyEditResponse = (responseType, responseData) => {
  if (responseType === SC_ADMIN_ACTION_TYPE.EDIT_ADMIN_METHODOLOGY_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: "Methodology edited successfully",
        },
      },
    };
  } else if (responseType === SC_ADMIN_ACTION_TYPE.EDIT_ADMIN_METHODOLOGY_ERROR) {
    let errResponse = responseData && responseData.response && responseData.response.data
      ? responseData.response.data :  "Error in Editing Methodology";
    return {
      modal: {
        action: ACTIONS.ERROR,
        props: {
          message: errResponse,
        },
      },
    };
  }
};

export const handleMethodologyDeleteResponse = (responseType, responseData) => {
  if (responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_METHODOLOGY_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message:  "Methodology Deleted Successfully",
        },
      },
    };
  } else if (responseType === SC_ADMIN_ACTION_TYPE.DELETE_ADMIN_METHODOLOGY_ERROR) {
    let errResponse = responseData && responseData.response && responseData.response.data
      ? responseData.response.data : "Error in Deleting Methodology";
    return {
      modal: {
        action: ACTIONS.ERROR,
        props: {
          message: errResponse,
        },
      },
    };
  }
};

export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const { flag, value } = check({
    path: "data",
    original: response,
    checkEmpty: true,
  });
  console.log(response.status);

  if (response.status && response.status === 409 && flag) {
    
    for (let i = 0; i < value.length; i++) {
      errState = {
        ...errState,
        formControls: {
          ...errState.formControls,
          error: true,
          [value[i].field]: {
            ...errState.formControls[value[i].field],
            error: true,
            errorMsg: value[i].message,
          },
        },
      };
    }
  } else {
    errState = {
      ...errState,
      formControls: {
        ...errState.formControls,
        error: true,
        errorMessage: ERROR_MSG.COMMON_FORM_ERR,
      },
    };
  }
  console.log(errState)
  return errState;
};

export const validateAdminForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };

  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    }
  }
  return formState;
};
