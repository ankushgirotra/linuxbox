import { ACTIONS } from "../../../pcdm/src/constants/action.constants";
import { ROLE_NAME_REG } from "../../../pcdm/src/constants/form.constants";
import { ERROR_MSG } from "../../../pcdm/src/constants/message.contants";
import { check } from "../../../pcdm/src/services/validation";
import {
    EDIT_STAFF_COMPETENCY_ERROR,
    EDIT_STAFF_COMPETENCY_SUCCESS,
} from "../store/staffCompetency.reducer";

export const handleStaffCompetencyAPIResponse = (props, state, responseType, responseData) => {
     if (responseType === EDIT_STAFF_COMPETENCY_SUCCESS || responseType === EDIT_STAFF_COMPETENCY_ERROR) {
        return handleEditResponse(props, state, responseType, responseData);
    }
    
    else {
        return { returnState: null, modal: null };
    }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
    if (responseType === EDIT_STAFF_COMPETENCY_SUCCESS) {
        const propsToParent = {
            message: "Request sent to your Resource Manager for review",
        };
        return {
            modal: { action: ACTIONS.SUCCESS, props: propsToParent },
        };
    } else {
        return {
            returnState: { ...errorState(responseData, state) },
        };
    }
};

export const errorState = (errorResponse, state) => {
    const { response } = errorResponse;
    let errState = { formControls: { ...state.formControls } };
    const { flag, value } = check({
        path: "data.errors",
        original: response,
        checkEmpty: true,
    });
    if (response.status === 400 && flag) {
        const { errors } = response.data;
        for (let i = 0; i < errors.length; i++) {
            errState = {
                ...errState,
                formControls: {
                    ...errState.formControls,
                    error: true,
                    [errors[i].field]: {
                        ...errState.formControls[errors[i].field],
                        error: true,
                        errorMsg: ERROR_MSG.COMMON_ERR,
                    },
                },
            };
        }
    }
    return errState;
};

export const validateStaffCompetencyForm = (formControls) => {
    let formState = {
        ...formControls,
        error: false,
        errorMessage: "",
    };
    for (const [key, valueObj] of Object.entries(formControls)) {
        if (
            valueObj.required &&
            (valueObj.value === null ||
                valueObj.value === undefined ||
                (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
        ) {
            formState = {
                ...formState,
                error: true,
                [key]: {
                    ...formControls[key],
                    error: true,
                    errorMsg: ERROR_MSG.REQUIRED_FIELD,
                },
            };
        }
        // else if (key === "sourceName" && valueObj.value.trim() !== "") {
        //     if (new RegExp(ROLE_NAME_REG).test(valueObj.value.trim())) {
        //     } else {
        //         formState = {
        //             ...formState,
        //             error: true,
        //             sourceName: {
        //                 ...formState.sourceName,
        //                 error: true,
        //                 errorMsg: ERROR_MSG.RESOURCE_NAME_ALLOW_CHAR,
        //             },
        //         };
        //     }
        // }
    }
    return formState;
};
