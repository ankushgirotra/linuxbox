import {
  SAVE_TECHNOLOGY_SUCCESS,
  SAVE_TECHNOLOGY_ERROR,
  EDIT_TECHNOLOGY_ERROR,
  DELETE_TECHNOLOGY_SUCCESS,
  DELETE_TECHNOLOGY_ERROR,
  EDIT_TECHNOLOGY_SUCCESS,
} from "../store/technologies.reducers";
import {
  UPDATE_ACTIVE_TECH_SUCCESS,
  UPDATE_ACTIVE_TECH_ERROR
} from "../store/common.reducers";
import { ACTIONS } from "../../../pcdm/src/constants/action.constants";
import { ROLE_NAME_REG } from "../../../pcdm/src/constants/form.constants";
import { ERROR_MSG } from "../../../pcdm/src/constants/message.contants";
import { check } from "../../../pcdm/src/services/validation";

export const handleTechnologyAPIResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_TECHNOLOGY_SUCCESS || responseType === SAVE_TECHNOLOGY_ERROR) {
    return handleSaveResponse(props, state, responseType, responseData);
  } else if (responseType === EDIT_TECHNOLOGY_SUCCESS || responseType === EDIT_TECHNOLOGY_ERROR
    || responseType === UPDATE_ACTIVE_TECH_SUCCESS || responseType === UPDATE_ACTIVE_TECH_ERROR) {
    return handleEditResponse(props, state, responseType, responseData);
  } else if (
    responseType === DELETE_TECHNOLOGY_SUCCESS ||
    responseType === DELETE_TECHNOLOGY_ERROR
  ) {
    return handleDeleteResponse(props, state, responseType, responseData);
  } else {
    return { returnState: null, modal: null };
  }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
  if (responseType === SAVE_TECHNOLOGY_SUCCESS) {
    const propsToParent = {
      message: "Technology added successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
  if (responseType === EDIT_TECHNOLOGY_SUCCESS || UPDATE_ACTIVE_TECH_SUCCESS) {
    const propsToParent = {
      message: "Technology updated successfully",
    };
    return {
      modal: { action: ACTIONS.SUCCESS, props: propsToParent },
    };
  } else {
    console.log(responseData);
    return {
      returnState: { ...errorState(responseData, state) },
    };
  }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
  if (responseType === DELETE_TECHNOLOGY_SUCCESS) {
    return {
      modal: {
        action: ACTIONS.SUCCESS,
        props: {
          message: "Technology deleted successfully",
        },
      },
    };
  } else {
    console.log(responseData);
    return { returnState: { savingProject: false } };
  }
};

export const errorState = (errorResponse, state) => {
  const { response } = errorResponse;
  let errState = { formControls: { ...state.formControls } };
  const { flag, value } = check({
    path: "data.errors",
    original: response,
    checkEmpty: true,
  });
  if (response.status === 400 && flag) {
    const { errors } = response.data;
    for (let i = 0; i < errors.length; i++) {
      errState = {
        ...errState,
        formControls: {
          ...errState.formControls,
          error: true,
          [errors[i].field]: {
            ...errState.formControls[errors[i].field],
            error: true,
            errorMsg: ERROR_MSG.COMMON_ERR,
          },
        },
      };
    }
  }
  return errState;
};

export const validateTechnologyForm = (formControls) => {
  let formState = {
    ...formControls,
    error: false,
    errorMessage: "",
  };
  for (const [key, valueObj] of Object.entries(formControls)) {
    if (
      valueObj.required &&
      (valueObj.value === null ||
        valueObj.value === undefined ||
        (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
    ) {
      formState = {
        ...formState,
        error: true,
        [key]: {
          ...formControls[key],
          error: true,
          errorMsg: ERROR_MSG.REQUIRED_FIELD,
        },
      };
    }
  }
  return formState;
};

export const getSortedEligibleTechnologies = (techArr) => {

  const eligibleTechnologies = techArr.filter((tech) => tech.expertiseLevel > 2);

  const sortTechnologiesByName = eligibleTechnologies.length
    ? eligibleTechnologies.sort((a, b) => {
      var name1 = a.skillName;
      var name2 = b.skillName;
      if (name1 < name2) return -1;
      if (name1 > name2) return 1;
      return 0;
    })
    : [];

  const sortTechnologiesByMentor = eligibleTechnologies.length
    ? eligibleTechnologies.sort((a, b) => {
      let name1 = a.mentor;
      let name2 = b.mentor;
      if (name1 < name2) return 1;
      if (name1 > name2) return -1;
      return 0;
    })
    : [];

  // console.log(sortTechnologiesByName ,sortTechnologiesByMentor ,eligibleTechnologies)
  
  return eligibleTechnologies;

};
