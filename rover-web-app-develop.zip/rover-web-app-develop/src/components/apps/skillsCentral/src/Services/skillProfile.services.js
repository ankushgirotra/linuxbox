export const getFeedbackRequestTableData = (gvnArr) => {
  let completedArr = gvnArr.filter((row) => row.status === "Completed");
  let viewedArr = gvnArr.filter((row) => row.status !== "Completed");
  const sortedCompletedArr = completedArr.sort((a, b) => {
    return a.requestId - b.requestId;
  });
  const sortedViewedArr = viewedArr.sort((a, b) => {
    return b.requestId - a.requestId;
  });

  return [...sortedCompletedArr, ...sortedViewedArr];
};
