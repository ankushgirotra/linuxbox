import { ACTIONS } from "../../../pcdm/src/constants/action.constants";
import { ROLE_NAME_REG } from "../../../pcdm/src/constants/form.constants";
import { ERROR_MSG } from "../../../pcdm/src/constants/message.contants";
import { check } from "../../../pcdm/src/services/validation";
import {
    SAVE_COMPETENCY_SUCCESS,
    SAVE_COMPETENCY_ERROR,
    EDIT_COMPETENCY_ERROR,
    DELETE_COMPETENCY_SUCCESS,
    DELETE_COMPETENCY_ERROR,
    EDIT_COMPETENCY_SUCCESS,
} from "../store/competencies.reducer";

export const handleCompetencyAPIResponse = (props, state, responseType, responseData) => {
    if (responseType === SAVE_COMPETENCY_SUCCESS || responseType === SAVE_COMPETENCY_ERROR) {
        return handleSaveResponse(props, state, responseType, responseData);
    } else if (responseType === EDIT_COMPETENCY_SUCCESS || responseType === EDIT_COMPETENCY_ERROR) {
        return handleEditResponse(props, state, responseType, responseData);
    } else if (
        responseType === DELETE_COMPETENCY_SUCCESS ||
        responseType === DELETE_COMPETENCY_ERROR
    ) {
        return handleDeleteResponse(props, state, responseType, responseData);
    } else {
        return { returnState: null, modal: null };
    }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
    if (responseType === SAVE_COMPETENCY_SUCCESS) {
        const propsToParent = {
            message: "Competency added successfully",
        };
        return {
            modal: { action: ACTIONS.SUCCESS, props: propsToParent },
        };
    } else {
        console.log(responseData);
        return {
            returnState: { ...errorState(responseData, state) },
        };
    }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
    if (responseType === EDIT_COMPETENCY_SUCCESS) {
        const propsToParent = {
            message: "Competency updated successfully",
        };
        return {
            modal: { action: ACTIONS.SUCCESS, props: propsToParent },
        };
    } else {
        console.log("competency service response: " + responseData);
        return {
            returnState: { ...errorState(responseData, state) },
        };
    }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
    if (responseType === DELETE_COMPETENCY_SUCCESS) {
        return {
            modal: {
                action: ACTIONS.SUCCESS,
                props: {
                    message: "Competency deleted successfully",
                },
            },
        };
    } else {
        console.log(responseData);
        return { returnState: { savingProject: false } };
    }
};

export const errorState = (errorResponse, state) => {
    const { response } = errorResponse;
    let errState = { formControls: { ...state.formControls } };
    const { flag, value } = check({
        path: "data.errors",
        original: response,
        checkEmpty: true,
    });
    if (response.status === 400 && flag) {
        const { errors } = response.data;
        for (let i = 0; i < errors.length; i++) {
            errState = {
                ...errState,
                formControls: {
                    ...errState.formControls,
                    error: true,
                    [errors[i].field]: {
                        ...errState.formControls[errors[i].field],
                        error: true,
                        errorMsg: ERROR_MSG.COMMON_ERR,
                    },
                },
            };
        }
    }
    return errState;
};

export const validateCompetencyForm = (formControls) => {
    let formState = {
        ...formControls,
        error: false,
        errorMessage: "",
    };
    for (const [key, valueObj] of Object.entries(formControls)) {
        if (
            valueObj.required &&
            (valueObj.value === null ||
                valueObj.value === undefined ||
                (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
        ) {
            formState = {
                ...formState,
                error: true,
                [key]: {
                    ...formControls[key],
                    error: true,
                    errorMsg: ERROR_MSG.REQUIRED_FIELD,
                },
            };
        }
    }
    return formState;
};
