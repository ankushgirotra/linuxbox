import { ACTIONS } from "../../../pcdm/src/constants/action.constants";
import { ROLE_NAME_REG } from "../../../pcdm/src/constants/form.constants";
import { ERROR_MSG } from "../../../pcdm/src/constants/message.contants";
import { check } from "../../../pcdm/src/services/validation";
import {
    SAVE_STAFF_METHODOLOGY_SUCCESS,
    SAVE_STAFF_METHODOLOGY_ERROR,
    EDIT_STAFF_METHODOLOGY_ERROR,
    DELETE_STAFF_METHODOLOGY_SUCCESS,
    DELETE_STAFF_METHODOLOGY_ERROR,
    EDIT_STAFF_METHODOLOGY_SUCCESS,
} from "../store/staffMethodology.reducer";

export const handleStaffMethodologyAPIResponse = (props, state, responseType, responseData) => {
    if (responseType === SAVE_STAFF_METHODOLOGY_SUCCESS || responseType === SAVE_STAFF_METHODOLOGY_ERROR) {
        return handleSaveResponse(props, state, responseType, responseData);
    } else if (responseType === EDIT_STAFF_METHODOLOGY_SUCCESS || responseType === EDIT_STAFF_METHODOLOGY_ERROR) {
        return handleEditResponse(props, state, responseType, responseData);
    }
    else if (
        responseType === DELETE_STAFF_METHODOLOGY_SUCCESS ||
        responseType === DELETE_STAFF_METHODOLOGY_ERROR
    ) {
        return handleDeleteResponse(props, state, responseType, responseData);
    }
    else {
        return { returnState: null, modal: null };
    }
};

export const handleSaveResponse = (props, state, responseType, responseData) => {
    if (responseType === SAVE_STAFF_METHODOLOGY_SUCCESS) {
        const propsToParent = {
            message: "Request sent to your Resource Manager for review",
        };
        return {
            modal: { action: ACTIONS.SUCCESS, props: propsToParent },
        };
    } else {
        console.log(responseData);
        return {
            returnState: { ...errorState(responseData, state) },
        };
    }
};

export const handleEditResponse = (props, state, responseType, responseData) => {
    if (responseType === EDIT_STAFF_METHODOLOGY_SUCCESS) {
        const propsToParent = {
            message: "Request sent to your Resource Manager for review",
        };
        return {
            modal: { action: ACTIONS.SUCCESS, props: propsToParent },
        };
    } else {
        return {
            returnState: { ...errorState(responseData, state) },
        };
    }
};

export const handleDeleteResponse = (props, state, responseType, responseData) => {
    if (responseType === DELETE_STAFF_METHODOLOGY_SUCCESS) {
        return {
            modal: {
                action: ACTIONS.SUCCESS,
                props: {
                    message: "Request sent to your Resource Manager for review",
                },
            },
        };
    } else {
        console.log(responseData);
        return { returnState: { savingProject: false } };
    }
};

export const errorState = (errorResponse, state) => {
    const { response } = errorResponse;
    let errState = { formControls: { ...state.formControls } };
    const { flag, value } = check({
        path: "data.errors",
        original: response,
        checkEmpty: true,
    });
    if (response.status === 400 && flag) {
        const { errors } = response.data;
        for (let i = 0; i < errors.length; i++) {
            errState = {
                ...errState,
                formControls: {
                    ...errState.formControls,
                    error: true,
                    [errors[i].field]: {
                        ...errState.formControls[errors[i].field],
                        error: true,
                        errorMsg: ERROR_MSG.COMMON_ERR,
                    },
                },
            };
        }
    }
    return errState;
};

export const validateStaffMethodologyForm = (formControls) => {
    let formState = {
        ...formControls,
        error: false,
        errorMessage: "",
    };
    for (const [key, valueObj] of Object.entries(formControls)) {
        if (
            valueObj.required &&
            (valueObj.value === null ||
                valueObj.value === undefined ||
                (typeof valueObj.value === "string" && valueObj.value.trim() === ""))
        ) {
            formState = {
                ...formState,
                error: true,
                [key]: {
                    ...formControls[key],
                    error: true,
                    errorMsg: ERROR_MSG.REQUIRED_FIELD,
                },
            };
        }
        // else if (key === "sourceName" && valueObj.value.trim() !== "") {
        //     if (new RegExp(ROLE_NAME_REG).test(valueObj.value.trim())) {
        //     } else {
        //         formState = {
        //             ...formState,
        //             error: true,
        //             sourceName: {
        //                 ...formState.sourceName,
        //                 error: true,
        //                 errorMsg: ERROR_MSG.RESOURCE_NAME_ALLOW_CHAR,
        //             },
        //         };
        //     }
        // }
    }
    return formState;
};
