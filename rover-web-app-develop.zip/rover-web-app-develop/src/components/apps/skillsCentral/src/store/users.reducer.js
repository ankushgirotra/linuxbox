import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  getResourcesURL,
  getDetailsByLanIdURL,
  getReporteesByLanIdURL,
  getEmployeeDetailsURL,
  getInactiveEmployeesURL,
  getAdminSKillURL,
  getPeopleAvailabilityURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE } from "../Constants/action.constants";

// ACTION TYPES
export const GET_TECHNOLOGIES = "GET_TECHNOLOGIES";
export const GET_TECHNOLOGIES_LOADING = "GET_TECHNOLOGIES_LOADING";
export const GET_TECHNOLOGIES_ERROR = "GET_TECHNOLOGIES_ERROR";

export const GET_RESOURCES_BY_OWNER = "GET_RESOURCES_BY_OWNER";
export const GET_RESOURCES_BY_OWNER_LOADING = "GET_RESOURCES_BY_OWNER_LOADING";
export const GET_RESOURCES_BY_OWNER_ERROR = "GET_RESOURCES_BY_OWNER_ERROR";

export const GET_DETAILS_BY_LANID = "GET_DETAILS_BY_LANID";
export const GET_DETAILS_BY_LANID_LOADING = "GET_DETAILS_BY_LANID_LOADING";
export const GET_DETAILS_BY_LANID_ERROR = "GET_DETAILS_BY_LANID_ERROR";

export const GET_REPORTEES_BY_LANID = "GET_REPORTEES_BY_LANID";
export const GET_REPORTEES_BY_LANID_LOADING = "GET_REPORTEES_BY_LANID_LOADING";
export const GET_REPORTEES_BY_LANID_ERROR = "GET_REPORTEES_BY_LANID_ERROR";

export const GET_EMPLOYEE_DETAILS_LOADING = "GET_EMPLOYEE_DETAILS_LOADING";
export const GET_EMPLOYEE_DETAILS_SUCCESS = "GET_EMPLOYEE_DETAILS_SUCCESS";
export const GET_EMPLOYEE_DETAILS_ERROR = "GET_EMPLOYEE_DETAILS_ERROR";

export const GET_PEOPLE_AVAILABILITY_LOADING = "GET_PEOPLE_AVAILABILITY_LOADING";
export const GET_PEOPLE_AVAILABILITY_SUCCESS = "GET_PEOPLE_AVAILABILITY_SUCCESS";
export const GET_PEOPLE_AVAILABILITY_ERROR = "GET_PEOPLE_AVAILABILITY_ERROR";

export const GET_INACTIVE_EMPLOYEES_LOADING = "GET_INACTIVE_EMPLOYEES_LOADING";
export const GET_INACTIVE_EMPLOYEES_SUCCESS = "GET_INACTIVE_EMPLOYEES_SUCCESS";
export const GET_INACTIVE_EMPLOYEES_ERROR = "GET_INACTIVE_EMPLOYEES_ERROR";

// ACTION CREATORS
export const getTechnologies = (technologies) => ({
  type: GET_TECHNOLOGIES,
  technologies,
});
export const getTechnologiesLoading = () => ({
  type: GET_TECHNOLOGIES_LOADING,
});
export const getTechnologiesError = (error) => ({
  type: GET_TECHNOLOGIES_ERROR,
  error,
});

export const getResourcesByOwner = (resources) => ({
  type: GET_RESOURCES_BY_OWNER,
  resources,
});
export const getResourcesByOwnerLoading = () => ({
  type: GET_RESOURCES_BY_OWNER_LOADING,
});
export const getResourcesByOwnerError = (error) => ({
  type: GET_RESOURCES_BY_OWNER_ERROR,
  error,
});

export const getDetailsByLanId = (details) => ({
  type: GET_DETAILS_BY_LANID,
  details,
});
export const getDetailsByLanIdLoading = () => ({
  type: GET_DETAILS_BY_LANID_LOADING,
});
export const getDetailsByLanIdError = (error) => ({
  type: GET_DETAILS_BY_LANID_ERROR,
  error,
});

export const getReporteesByLanId = (reportees) => ({
  type: GET_REPORTEES_BY_LANID,
  reportees,
});
export const getReporteesByLanIdLoading = () => ({
  type: GET_REPORTEES_BY_LANID_LOADING,
});
export const getReporteesByLanIdError = (error) => ({
  type: GET_REPORTEES_BY_LANID_ERROR,
  error,
});

export const getEmployeeDetailsLoading = () => ({
  type: GET_EMPLOYEE_DETAILS_LOADING,
});
export const getEmployeeDetailsSuccess = (empDetails) => ({
  type: GET_EMPLOYEE_DETAILS_SUCCESS,
  empDetails,
});
export const getEmployeeDetailsError = (error) => ({
  type: GET_EMPLOYEE_DETAILS_ERROR,
  error,
});

export const getPeopleAvailabilityLoading = () => ({
  type: GET_PEOPLE_AVAILABILITY_LOADING,
});
export const getPeopleAvailabilitySuccess = (data) => ({
  type: GET_PEOPLE_AVAILABILITY_SUCCESS,
  data,
});
export const getPeopleAvailabilityError = (error) => ({
  type: GET_PEOPLE_AVAILABILITY_ERROR,
  error,
});

export const getInactiveEmployeesLoading = () => ({
  type: GET_INACTIVE_EMPLOYEES_LOADING,
});
export const getInactiveEmployeesSuccess = (inactiveEmpList) => ({
  type: GET_INACTIVE_EMPLOYEES_SUCCESS,
  inactiveEmpList,
});
export const getInactiveEmployeesError = (error) => ({
  type: GET_INACTIVE_EMPLOYEES_ERROR,
  error,
});

// THUNK CREATORS
export const getTechnologiesThunk = () => async (dispatch) => {
  try {
    dispatch(getTechnologiesLoading());
    const { data } = await roverSkillcentralURL.get(getAdminSKillURL(SKILL_TYPE.TECH));
    dispatch(getTechnologies(data));
  } catch (error) {
    console.error(error);
    dispatch(getTechnologiesError(error));
  }
};

export const getResourcesByOwnerThunk = (lanID) => async (dispatch) => {
  try {
    dispatch(getResourcesByOwnerLoading());
    const { data } = await roverSkillcentralURL.get(getResourcesURL(lanID));
    dispatch(getResourcesByOwner(data));
  } catch (error) {
    console.error(error);
    dispatch(getResourcesByOwnerError(error));
  }
};

export const getDetailsByLanIdThunk = (lanID) => async (dispatch) => {
  try {
    dispatch(getDetailsByLanIdLoading());
    const { data } = await roverSkillcentralURL.get(getDetailsByLanIdURL(lanID));
    dispatch(getDetailsByLanId(data));
  } catch (error) {
    console.error(error);
    dispatch(getDetailsByLanIdError(error));
  }
};
export const getReporteesByLanIdThunk = (lanID) => async (dispatch) => {
  try {
    dispatch(getReporteesByLanIdLoading());
    const { data } = await roverSkillcentralURL.get(getReporteesByLanIdURL(lanID));
    dispatch(getReporteesByLanId(data));
  } catch (error) {
    console.error(error);
    dispatch(getReporteesByLanIdError(error));
  }
};
export const getEmployeeDetailsThunk = (empID, callback) => async (dispatch) => {
  try {
    dispatch(getEmployeeDetailsLoading());
    const { data } = await roverSkillcentralURL.get(getEmployeeDetailsURL(empID));
    // console.log(empID,  "-->", data)
    if(callback) callback(data)
    dispatch(getEmployeeDetailsSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getEmployeeDetailsError(error));
  }
};
export const getPeopleAvailabilityThunk = (empID) => async (dispatch) => {
  try {
    dispatch(getPeopleAvailabilityLoading());
    const { data } = await roverSkillcentralURL.get(getPeopleAvailabilityURL(empID));
    // console.log(data)
    dispatch(getPeopleAvailabilitySuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getPeopleAvailabilityError(error));
  }
};
export const getInactiveEmployeesThunk = (managerID) => async (dispatch) => {
  try {
    dispatch(getInactiveEmployeesLoading());
    const { data } = await roverSkillcentralURL.get(getInactiveEmployeesURL(managerID));
    dispatch(getInactiveEmployeesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getInactiveEmployeesError(error));
  }
};


// INITIAL STATE
export const initialState = {
  users: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  currentResource: { data: [], status: DATA_STATUS.INITIAL, response: {} },  //not using
  technologies: { data: [], status: DATA_STATUS.INITIAL },
  reportees: { data: [], status: DATA_STATUS.INITIAL, response: {} },  //manager roster 
  employeeDetails: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  peopleAvailability: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  inactiveEmployeeList: { data: [], status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCER
const SCUsersReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_TECHNOLOGIES:
      return {
        ...state,
        technologies: {
          data: [...action.technologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_TECHNOLOGIES_LOADING:
      return {
        ...state,
        technologies: {
          ...state.technologies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_TECHNOLOGIES_ERROR:
      return {
        ...state,
        technologies: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_RESOURCES_BY_OWNER:
      return {
        ...state,
        users: {
          data: [...action.resources],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_RESOURCES_BY_OWNER_LOADING:
      return {
        ...state,
        users: {
          ...state.users,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_RESOURCES_BY_OWNER_ERROR:
      return {
        ...state,
        users: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case GET_DETAILS_BY_LANID:
      return {
        ...state,
        currentResource: {
          data: { ...action.details },
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DETAILS_BY_LANID_LOADING:
      return {
        ...state,
        currentResource: {
          ...state.currentResource,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DETAILS_BY_LANID_ERROR:
      return {
        ...state,
        currentResource: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_REPORTEES_BY_LANID:
      return {
        ...state,
        reportees: {
          data:
            typeof action.reportees === "string" ? [] : [...action.reportees],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_REPORTEES_BY_LANID_LOADING:
      return {
        ...state,
        reportees: {
          ...state.reportees,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_REPORTEES_BY_LANID_ERROR:
      return {
        ...state,
        reportees: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_EMPLOYEE_DETAILS_LOADING:
      return {
        ...state,
        employeeDetails: {
          ...state.employeeDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_EMPLOYEE_DETAILS_SUCCESS:
      return {
        ...state,
        employeeDetails: {
          data: { ...action.empDetails },
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_EMPLOYEE_DETAILS_ERROR:
      return {
        ...state,
        employeeDetails: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
      case GET_PEOPLE_AVAILABILITY_LOADING:
        return {
          ...state,
          peopleAvailability: {
            ...state.peopleAvailability,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_PEOPLE_AVAILABILITY_SUCCESS:
        return {
          ...state,
          peopleAvailability: {
            data: { ...action.data},
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_PEOPLE_AVAILABILITY_ERROR:
        return {
          ...state,
          peopleAvailability: {
            data: [],
            status: DATA_STATUS.ERROR,
            response: action.error,
          },
        };  
    case GET_INACTIVE_EMPLOYEES_LOADING:
      return {
        ...state,
        inactiveEmployeeList: {
          ...state.inactiveEmployeeList,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_INACTIVE_EMPLOYEES_SUCCESS:
      return {
        ...state,
        inactiveEmployeeList: {
          data: [...action.inactiveEmpList],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_INACTIVE_EMPLOYEES_ERROR:
      return {
        ...state,
        inactiveEmployeeList: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    default:
      return state;
  }
};

export default SCUsersReducer;
