import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
    addSkillSubmissionURL,
    getSkillSubmissionURL,
    updateDeleteSkillSubmissionURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE_ID } from "../Constants/action.constants";

// ACTION TYPES
export const GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID = "GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID";
export const GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_LOADING = "GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_LOADING";
export const GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_ERROR = "GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_ERROR";
export const GET_STAFF_SKILLS_BY_ON_CLICK = "GET_STAFF_SKILLS_BY_ON_CLICK";

export const SAVE_STAFF_TECHNOLOGY_RESET = "SAVE_STAFF_TECHNOLOGY_RESET";
export const SAVE_STAFF_TECHNOLOGY_LOADING = "SAVE_STAFF_TECHNOLOGY_LOADING";
export const SAVE_STAFF_TECHNOLOGY_SUCCESS = "SAVE_STAFF_TECHNOLOGY_SUCCESS";
export const SAVE_STAFF_TECHNOLOGY_ERROR = "SAVE_STAFF_TECHNOLOGY_ERROR";

export const EDIT_STAFF_TECHNOLOGY_RESET = "EDIT_STAFF_TECHNOLOGY_RESET";
export const EDIT_STAFF_TECHNOLOGY_LOADING = "EDIT_STAFF_TECHNOLOGY_LOADING";
export const EDIT_STAFF_TECHNOLOGY_SUCCESS = "EDIT_STAFF_TECHNOLOGY_SUCCESS";
export const EDIT_STAFF_TECHNOLOGY_ERROR = "EDIT_STAFF_TECHNOLOGY_ERROR";

export const DELETE_STAFF_TECHNOLOGY_RESET = "DELETE_STAFF_TECHNOLOGY_RESET";
export const DELETE_STAFF_TECHNOLOGY_LOADING = "DELETE_STAFF_TECHNOLOGY_LOADING";
export const DELETE_STAFF_TECHNOLOGY_SUCCESS = "DELETE_STAFF_TECHNOLOGY_SUCCESS";
export const DELETE_STAFF_TECHNOLOGY_ERROR = "DELETE_STAFF_TECHNOLOGY_ERROR";

// ACTION CREATORS
export const getStaffTechnologiesByResourceId = (staffTechnologies) => ({
  type: GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID,
  staffTechnologies,
});
export const getStaffTechnologiesByResourceIdLoading = () => ({
  type: GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_LOADING,
});
export const getStaffTechnologiesByResourceIdError = (error) => ({
  type: GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const selectedSkillRow = (selectedSkill) => ({
  type: GET_STAFF_SKILLS_BY_ON_CLICK,
  selectedSkill,
});

export const saveStaffTechnologyReset = () => ({
  type: SAVE_STAFF_TECHNOLOGY_RESET,
});
export const saveStaffTechnologyLoading = () => ({
  type: SAVE_STAFF_TECHNOLOGY_LOADING,
});
export const saveStaffTechnologySuccess = (saveStaffTechnology) => ({
  type: SAVE_STAFF_TECHNOLOGY_SUCCESS,
  saveStaffTechnology,
});
export const saveStaffTechnologyError = (error) => ({
  type: SAVE_STAFF_TECHNOLOGY_ERROR,
  error,
});

export const editStaffTechnologyReset = () => ({
  type: EDIT_STAFF_TECHNOLOGY_RESET,
});
export const editStaffTechnologyLoading = () => ({
  type: EDIT_STAFF_TECHNOLOGY_LOADING,
});
export const editStaffTechnologySuccess = (editStaffTechnology) => ({
  type: EDIT_STAFF_TECHNOLOGY_SUCCESS,
  editStaffTechnology,
});
export const editStaffTechnologyError = (error) => ({
  type: EDIT_STAFF_TECHNOLOGY_ERROR,
  error,
});

export const deleteStaffTechnologyReset = () => ({
  type: DELETE_STAFF_TECHNOLOGY_RESET,
});
export const deleteStaffTechnologyLoading = () => ({
  type: DELETE_STAFF_TECHNOLOGY_LOADING,
});
export const deleteStaffTechnologySuccess = (deleteStaffTechnology) => ({
  type: DELETE_STAFF_TECHNOLOGY_SUCCESS,
  deleteStaffTechnology,
});
export const deleteStaffTechnologyError = (error) => ({
  type: DELETE_STAFF_TECHNOLOGY_ERROR,
  error,
});

// THUNK CREATORS
export const getStaffTechnologiesByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getStaffTechnologiesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillSubmissionURL(resourceLanId, SKILL_TYPE_ID.TECH));
    // console.log("satff tech -->", resourceLanId, data )
    dispatch(getStaffTechnologiesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getStaffTechnologiesByResourceIdError(error));
  }
};

export const saveStaffTechnologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveStaffTechnologyLoading());
    const { data } = await roverSkillcentralURL.post(addSkillSubmissionURL(), payload);
    if (callback) {
      callback(SAVE_STAFF_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(saveStaffTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_STAFF_TECHNOLOGY_ERROR, error);
    }
    dispatch(saveStaffTechnologyError(error));
  }
};

export const editStaffTechnologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editStaffTechnologyLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(EDIT_STAFF_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(editStaffTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_STAFF_TECHNOLOGY_ERROR, error);
    }
    dispatch(editStaffTechnologyError(error));
  }
};

export const deleteStaffTechnologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(deleteStaffTechnologyLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(DELETE_STAFF_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(deleteStaffTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_STAFF_TECHNOLOGY_ERROR, error);
    }
    dispatch(deleteStaffTechnologyError(error));
  }
};



// INITIAL STATE
 export const staffTechnologyInitialState = {
  staffTechnologies: { // all staffTechnologies for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  saveStaffTechnologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editStaffTechnologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteStaffTechnologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Basic Knowledge" },
    { id: 2, desc: "2 - Limited Experience" },
    { id: 3, desc: "3 - Practical Application" },
    { id: 4, desc: "4 - Applied Theory" },
    { id: 5, desc: "5 - Recognized Authority" },
  ],
};

// REDUCERS
const StaffTechnologyReducer = (state = staffTechnologyInitialState, action) => {
  switch (action.type) {
    case GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID:
      return {
        ...state,
        staffTechnologies: {
          data: typeof action.staffTechnologies === "string" ? [] : [...action.staffTechnologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        staffTechnologies: {
          ...state.staffTechnologies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_STAFF_TECHNOLOGIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        staffTechnologies: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };

    case GET_STAFF_SKILLS_BY_ON_CLICK:
      return {
        ...state,
        selectedSkill: {
          ...action.selectedSkill,
        },
      };
    
    case SAVE_STAFF_TECHNOLOGY_RESET:
      return {
        ...state,
        saveStaffTechnologyStatus: { ...staffTechnologyInitialState.saveStaffTechnologyStatus },
      };
    case SAVE_STAFF_TECHNOLOGY_LOADING:
      return {
        ...state,
        saveStaffTechnologyStatus: {
          ...state.saveStaffTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_STAFF_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        saveStaffTechnologyStatus: {
          ...state.saveStaffTechnologyStatus,
          response: action.saveStaffTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
     
    case SAVE_STAFF_TECHNOLOGY_ERROR:
      return {
        ...state,
        saveStaffTechnologyStatus: {
          ...state.saveStaffTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
      
    case EDIT_STAFF_TECHNOLOGY_RESET:
      return {
        ...state,
        editStaffTechnologyStatus: { ...staffTechnologyInitialState.editStaffTechnologyStatus },
      };
    case EDIT_STAFF_TECHNOLOGY_LOADING:
      return {
        ...state,
        editStaffTechnologyStatus: {
          ...state.editStaffTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_STAFF_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        editStaffTechnologyStatus: {
          ...state.editStaffTechnologyStatus,
          response: action.editStaffTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_STAFF_TECHNOLOGY_ERROR:
      return {
        ...state,
        editStaffTechnologyStatus: {
          ...state.editStaffTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_STAFF_TECHNOLOGY_RESET:
      return {
        ...state,
        deleteStaffTechnologyStatus: { ...staffTechnologyInitialState.deleteStaffTechnologyStatus },
      };
    case DELETE_STAFF_TECHNOLOGY_LOADING:
      return {
        ...state,
        deleteStaffTechnologyStatus: {
          ...state.deleteStaffTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_STAFF_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        deleteStaffTechnologyStatus: {
          ...state.deleteStaffTechnologyStatus,
          response: action.deleteStaffTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_STAFF_TECHNOLOGY_ERROR:
      return {
        ...state,
        deleteStaffTechnologyStatus: {
          ...state.deleteStaffTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default StaffTechnologyReducer;
