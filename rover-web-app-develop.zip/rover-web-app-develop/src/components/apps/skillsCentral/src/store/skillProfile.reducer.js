import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import { updateResourcedegreeURL, requestFeedbackURL, submitFeedbackURL, getSubmittedFeedbackURL, updateRMViewStatusURL } from "./endpoints";

// ACTION TYPES
export const UPDATE_RESOURCE_DEGREE_SUCCESS = "UPDATE_RESOURCE_DEGREE_SUCCESS";
export const UPDATE_RESOURCE_DEGREE_ERROR = "UPDATE_RESOURCE_DEGREE_ERROR";

export const RM_REQUEST_FEEDBACK_LOADING = "RM_REQUEST_FEEDBACK_LOADING";
export const RM_REQUEST_FEEDBACK_SUCCESS = "RM_REQUEST_FEEDBACK_SUCCESS";
export const RM_REQUEST_FEEDBACK_ERROR = "RM_REQUEST_FEEDBACK_ERROR";

export const RM_SUBMIT_FEEDBACK_LOADING = "RM_SUBMIT_FEEDBACK_LOADING";
export const RM_SUBMIT_FEEDBACK_SUCCESS = "RM_SUBMIT_FEEDBACK_SUCCESS";
export const RM_SUBMIT_FEEDBACK_ERROR = "RM_SUBMIT_FEEDBACK_ERROR";

export const GET_SUBMITTED_FEEDBACK_LOADING = "GET_SUBMITTED_FEEDBACK_LOADING";
export const GET_SUBMITTED_FEEDBACK_SUCCESS = "GET_SUBMITTED_FEEDBACK_SUCCESS";
export const GET_SUBMITTED_FEEDBACK_ERROR = "GET_SUBMITTED_FEEDBACK_ERROR";

export const UPDATE_RM_VIEW_STATUS_LOADING = "UPDATE_RM_VIEW_STATUS_LOADING";
export const UPDATE_RM_VIEW_STATUS_SUCCESS = "UPDATE_RM_VIEW_STATUS_SUCCESS";
export const UPDATE_RM_VIEW_STATUS_ERROR = "UPDATE_RM_VIEW_STATUS_ERROR";


// ACTION CREATORS
export const updateResourcedegreeSuccess = (updateDegree) => ({
  type: UPDATE_RESOURCE_DEGREE_SUCCESS,
  updateDegree,
});
export const updateResourcedegreeError = (error) => ({
  type: UPDATE_RESOURCE_DEGREE_ERROR,
  error,
});

export const requestFeedbackLoading = () => ({
  type: RM_REQUEST_FEEDBACK_LOADING,
});
export const requestFeedbackSuccess = (feedbackStatus) => ({
  type: RM_REQUEST_FEEDBACK_SUCCESS,
  feedbackStatus,
});
export const requestFeedbackError = (error) => ({
  type: RM_REQUEST_FEEDBACK_ERROR,
  error,
});

export const submitFeedbackLoading = () => ({
  type: RM_SUBMIT_FEEDBACK_LOADING,
});
export const submitFeedbackSuccess = (submitFeedbackStatus) => ({
  type: RM_SUBMIT_FEEDBACK_SUCCESS,
  submitFeedbackStatus,
});
export const submitFeedbackError = (error) => ({
  type: RM_SUBMIT_FEEDBACK_ERROR,
  error,
});

export const getSubmittedFeedbackLoading = () => ({
  type: GET_SUBMITTED_FEEDBACK_LOADING,
});
export const getSubmittedFeedbackSuccess = (submittedData) => ({
  type: GET_SUBMITTED_FEEDBACK_SUCCESS,
  submittedData,
});
export const getSubmittedFeedbackError = (error) => ({
  type: GET_SUBMITTED_FEEDBACK_ERROR,
  error,
});

export const updateRMViewStatusLoading = () => ({
  type: UPDATE_RM_VIEW_STATUS_LOADING,
});
export const updateRMViewStatusSuccess = (status) => ({
  type: UPDATE_RM_VIEW_STATUS_SUCCESS,
  status,
});
export const updateRMViewStatusError = (error) => ({
  type: UPDATE_RM_VIEW_STATUS_ERROR,
  error,
});


// THUNK CREATORS
export const updateResourcedegreeThunk = (payload) => async (dispatch) => {
  try {
    const { data } = await roverSkillcentralURL.post(updateResourcedegreeURL(),payload);
    dispatch(updateResourcedegreeSuccess(data));
  } catch (error) {
    dispatch(updateResourcedegreeError(error));
  }
};

export const requestFeedbackThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(requestFeedbackLoading());
    const { data } = await roverSkillcentralURL.post(requestFeedbackURL(), payload);
    if (callback) {
      callback(RM_REQUEST_FEEDBACK_SUCCESS, data);
    }
    dispatch(requestFeedbackSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(RM_REQUEST_FEEDBACK_ERROR, error.response);
    }
    dispatch(requestFeedbackError(error));
  }
};

export const submitFeedbackThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(submitFeedbackLoading());
    const { data } = await roverSkillcentralURL.post(submitFeedbackURL(), payload);
    if (callback) {
      callback(RM_SUBMIT_FEEDBACK_SUCCESS, data);
    }
    dispatch(submitFeedbackSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(RM_SUBMIT_FEEDBACK_ERROR, error.response);
    }
    dispatch(submitFeedbackError(error));
  }
};

export const getSubmittedFeedbackThunk = (lanId, callback) => async (dispatch) => {
  try {
    dispatch(getSubmittedFeedbackLoading());
    const { data } = await roverSkillcentralURL.get(getSubmittedFeedbackURL(lanId));
    if (callback) callback("SUCCESS", data)
    dispatch(getSubmittedFeedbackSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) callback("ERROR", error)
    dispatch(getSubmittedFeedbackError(error));
  }
};

export const updateRMViewStatusThunk = (requestID, callback) => async (dispatch) => {
  try {
    dispatch(updateRMViewStatusLoading());
    const { data } = await roverSkillcentralURL.put(updateRMViewStatusURL(requestID));
    dispatch(updateRMViewStatusSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(updateRMViewStatusError(error));
  }
};

// INITIAL STATE
const initialState = {
  updateResourcedegreeStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  RMrequestFeedbackStatus: { status: DATA_STATUS.INITIAL, response: {} },
  RMsubmitFeedbackStatus: { status: DATA_STATUS.INITIAL, response: {} },
  RMsubmittedFeedbackData: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  RMviewFeedbackStatus: { status: DATA_STATUS.INITIAL, response: {} }
};

// REDUCERS
const SkillProfileReducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_RESOURCE_DEGREE_SUCCESS:
      return {
        ...state,
        updateResourcedegreeStatus: {
          ...state.updateResourcedegreeStatus,
          response: action.updateDegree,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_RESOURCE_DEGREE_ERROR:
      return {
        ...state,
        updateResourcedegreeStatus: {
          ...state.updateResourcedegreeStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case RM_REQUEST_FEEDBACK_LOADING:
      return {
        ...state,
        RMrequestFeedbackStatus: {
          ...state.RMrequestFeedbackStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case RM_REQUEST_FEEDBACK_SUCCESS:
      return {
        ...state,
        RMrequestFeedbackStatus: {
          ...state.RMrequestFeedbackStatus,
          response: action.feedbackStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case RM_REQUEST_FEEDBACK_ERROR:
      return {
        ...state,
        RMrequestFeedbackStatus: {
          ...state.RMrequestFeedbackStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case RM_SUBMIT_FEEDBACK_LOADING:
      return {
        ...state,
        RMsubmitFeedbackStatus: {
          ...state.RMsubmitFeedbackStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case RM_SUBMIT_FEEDBACK_SUCCESS:
      return {
        ...state,
        RMsubmitFeedbackStatus: {
          ...state.RMsubmitFeedbackStatus,
          response: action.submitFeedbackStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case RM_SUBMIT_FEEDBACK_ERROR:
      return {
        ...state,
        RMsubmitFeedbackStatus: {
          ...state.RMsubmitFeedbackStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_SUBMITTED_FEEDBACK_LOADING:
      return {
        ...state,
        RMsubmittedFeedbackData: {
          ...state.RMsubmittedFeedbackData,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_SUBMITTED_FEEDBACK_SUCCESS:
      return {
        ...state,
        RMsubmittedFeedbackData: {
          ...state.RMsubmittedFeedbackData,
          data: typeof action.submittedData === "string" ? [] : [...action.submittedData],
          status: DATA_STATUS.SUCCESS,
          response: {},
        },
      };
    case GET_SUBMITTED_FEEDBACK_ERROR:
      return {
        ...state,
        RMsubmittedFeedbackData: {
          ...state.RMsubmittedFeedbackData,
          response: action.error,
          status: DATA_STATUS.ERROR,
          data: [],
        },
      };
    case UPDATE_RM_VIEW_STATUS_LOADING:
      return {
        ...state,
        RMviewFeedbackStatus: {
          ...state.RMviewFeedbackStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_RM_VIEW_STATUS_SUCCESS:
      return {
        ...state,
        RMviewFeedbackStatus: {
          ...state.RMviewFeedbackStatus,
          status: DATA_STATUS.SUCCESS,
          response: action.status,
        },
      };
    case UPDATE_RM_VIEW_STATUS_ERROR:
      return {
        ...state,
        RMviewFeedbackStatus: {
          ...state.RMviewFeedbackStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default SkillProfileReducer;
