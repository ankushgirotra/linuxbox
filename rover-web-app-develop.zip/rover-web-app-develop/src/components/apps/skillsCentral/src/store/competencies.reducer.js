import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  saveRMSkillURL,
  getUniqueSkillsByUserURL,
  getSkillByUserURL,
  getAdminSKillURL,
  editRMSkillURL,
  deleteRMSkillURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE_ID, SKILL_TYPE } from "../Constants/action.constants";

// ACTION TYPES
export const GET_COMPETENCIES = "GET_COMPETENCIES";
export const GET_COMPETENCIES_LOADING = "GET_COMPETENCIES_LOADING";
export const GET_COMPETENCIES_ERROR = "GET_COMPETENCIES_ERROR";

export const GET_COMPETENCIES_BY_RESOURCE_ID = "GET_COMPETENCIES_BY_RESOURCE_ID";
export const GET_COMPETENCIES_BY_RESOURCE_ID_LOADING = "GET_COMPETENCIES_BY_RESOURCE_ID_LOADING";
export const GET_COMPETENCIES_BY_RESOURCE_ID_ERROR = "GET_COMPETENCIES_BY_RESOURCE_ID_ERROR";

export const GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID = "GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID";
export const GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_LOADING =
  "GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_LOADING";
export const GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_ERROR =
  "GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_ERROR";

export const SAVE_COMPETENCY_RESET = "SAVE_COMPETENCY_RESET";
export const SAVE_COMPETENCY_LOADING = "SAVE_COMPETENCY_LOADING";
export const SAVE_COMPETENCY_SUCCESS = "SAVE_COMPETENCY_SUCCESS";
export const SAVE_COMPETENCY_ERROR = "SAVE_COMPETENCY_ERROR";

export const EDIT_COMPETENCY_RESET = "EDIT_COMPETENCY_RESET";
export const EDIT_COMPETENCY_LOADING = "EDIT_COMPETENCY_LOADING";
export const EDIT_COMPETENCY_SUCCESS = "EDIT_COMPETENCY_SUCCESS";
export const EDIT_COMPETENCY_ERROR = "EDIT_COMPETENCY_ERROR";

export const DELETE_COMPETENCY_RESET = "DELETE_COMPETENCY_RESET";
export const DELETE_COMPETENCY_LOADING = "DELETE_COMPETENCY_LOADING";
export const DELETE_COMPETENCY_SUCCESS = "DELETE_COMPETENCY_SUCCESS";
export const DELETE_COMPETENCY_ERROR = "DELETE_COMPETENCY_ERROR";

// ACTION CREATORS
export const getCompetencies = (competencies) => ({
  type: GET_COMPETENCIES,
  competencies,
});
export const getCompetenciesLoading = () => ({
  type: GET_COMPETENCIES_LOADING,
});
export const getCompetenciesError = (error) => ({
  type: GET_COMPETENCIES_ERROR,
  error,
});

export const getCompetenciesByResourceId = (competencies) => ({
  type: GET_COMPETENCIES_BY_RESOURCE_ID,
  competencies,
});
export const getCompetenciesByResourceIdLoading = () => ({
  type: GET_COMPETENCIES_BY_RESOURCE_ID_LOADING,
});
export const getCompetenciesByResourceIdError = (error) => ({
  type: GET_COMPETENCIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const getUniqueCompetenciesByResourceId = (competencies) => ({
  type: GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID,
  competencies,
});
export const getUniqueCompetenciesByResourceIdLoading = () => ({
  type: GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_LOADING,
});
export const getUniqueCompetenciesByResourceIdError = (error) => ({
  type: GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const saveCompetencyReset = () => ({
  type: SAVE_COMPETENCY_RESET,
});
export const saveCompetencyLoading = () => ({
  type: SAVE_COMPETENCY_LOADING,
});
export const saveCompetencySuccess = (saveCompetency) => ({
  type: SAVE_COMPETENCY_SUCCESS,
  saveCompetency,
});
export const saveCompetencyError = (error) => ({
  type: SAVE_COMPETENCY_ERROR,
  error,
});

export const editCompetencyReset = () => ({
  type: EDIT_COMPETENCY_RESET,
});
export const editCompetencyLoading = () => ({
  type: EDIT_COMPETENCY_LOADING,
});
export const editCompetencySuccess = (editCompetency) => ({
  type: EDIT_COMPETENCY_SUCCESS,
  editCompetency,
});
export const editCompetencyError = (error) => ({
  type: EDIT_COMPETENCY_ERROR,
  error,
});

export const deleteCompetencyReset = () => ({
  type: DELETE_COMPETENCY_RESET,
});
export const deleteCompetencyLoading = () => ({
  type: DELETE_COMPETENCY_LOADING,
});
export const deleteCompetencySuccess = (deleteCompetency) => ({
  type: DELETE_COMPETENCY_SUCCESS,
  deleteCompetency,
});
export const deleteCompetencyError = (error) => ({
  type: DELETE_COMPETENCY_ERROR,
  error,
});

// THUNK CREATORS
export const getCompetenciesThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getCompetenciesLoading());
    const { data } = await roverSkillcentralURL.get(getAdminSKillURL(SKILL_TYPE.COMP));
    dispatch(getCompetencies(data));
  } catch (error) {
    console.log(error);
    dispatch(getCompetenciesError(error));
  }
};

export const getCompetenciesByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getCompetenciesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillByUserURL(resourceLanId, SKILL_TYPE_ID.COMP));
    // console.log("res comp -->", resourceLanId, data )
    dispatch(getCompetenciesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getCompetenciesByResourceIdError(error));
  }
};

export const getUniqueCompetenciesByResourceIdThunk = (resourceLanId,deptId) => async (dispatch) => {
  try {
    dispatch(getUniqueCompetenciesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getUniqueSkillsByUserURL(resourceLanId, SKILL_TYPE_ID.COMP,deptId));
    // console.log("uniq comp -->", resourceLanId, data, deptId)
    dispatch(getUniqueCompetenciesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getUniqueCompetenciesByResourceIdError(error));
  }
};

export const saveCompetencyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveCompetencyLoading());
    const { data } = await roverSkillcentralURL.post(saveRMSkillURL(), payload);
    if (callback) {
      callback(SAVE_COMPETENCY_SUCCESS, data);
    }
    dispatch(saveCompetencySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_COMPETENCY_ERROR, error);
    }
    dispatch(saveCompetencyError(error));
  }
};

export const editCompetencyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editCompetencyLoading());
    const { data } = await roverSkillcentralURL.put(editRMSkillURL(), payload);
    if (callback) {
      callback(EDIT_COMPETENCY_SUCCESS, data);
    }
    dispatch(editCompetencySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_COMPETENCY_ERROR, error);
    }
    dispatch(editCompetencyError(error));
  }
};

export const deleteCompetencyThunk = (peopleSkillId, managerId, callback) => async (dispatch) => {
  try {
    dispatch(deleteCompetencyLoading());
    const { data } = await roverSkillcentralURL.put(deleteRMSkillURL(peopleSkillId, managerId));
    if (callback) {
      callback(DELETE_COMPETENCY_SUCCESS, data);
    }
    dispatch(deleteCompetencySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_COMPETENCY_ERROR, error);
    }
    dispatch(deleteCompetencyError(error));
  }
};

// INITIAL STATE
export const competencyInitialState = {
  competencies: { // all competencides for dropdown --> not using (need to confirm n delete)
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  currentCompetencies: { // added competencides for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  uniqueCompetencies: { // unique competencides for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  saveCompetencyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editCompetencyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteCompetencyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Novice" },
    { id: 2, desc: "2 - Capable" },
    { id: 3, desc: "3 - Competent" },
    { id: 4, desc: "4 - Proficient" },
  ],
};

// REDUCERS
const CompetencyReducer = (state = competencyInitialState, action) => {
  switch (action.type) {
    case GET_COMPETENCIES:
      return {
        ...state,
        competencies: {
          data: typeof action.competencies === "string" ? [] : [...action.competencies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_COMPETENCIES_BY_RESOURCE_ID:
      return {
        ...state,
        currentCompetencies: {
          data: typeof action.competencies === "string" ? [] : [...action.competencies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_COMPETENCIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        currentCompetencies: {
          ...state.currentCompetencies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_COMPETENCIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        currentCompetencies: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID:
      return {
        ...state,
        uniqueCompetencies: {
          data: typeof action.competencies === "string" ? [] : [...action.competencies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        uniqueCompetencies: {
          ...state.uniqueCompetencies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_UNIQUECOMPETENCIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        uniqueCompetencies: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case SAVE_COMPETENCY_RESET:
      return {
        ...state,
        saveCompetencyStatus: { ...competencyInitialState.saveCompetencyStatus },
      };
    case SAVE_COMPETENCY_LOADING:
      return {
        ...state,
        saveCompetencyStatus: {
          ...state.saveCompetencyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_COMPETENCY_SUCCESS:
      return {
        ...state,
        saveCompetencyStatus: {
          ...state.saveCompetencyStatus,
          response: action.saveCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_COMPETENCY_ERROR:
      return {
        ...state,
        saveCompetencyStatus: {
          ...state.saveCompetencyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_COMPETENCY_RESET:
      return {
        ...state,
        editCompetencyStatus: { ...competencyInitialState.editCompetencyStatus },
      };
    case EDIT_COMPETENCY_LOADING:
      return {
        ...state,
        editCompetencyStatus: {
          ...state.editCompetencyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_COMPETENCY_SUCCESS:
      return {
        ...state,
        editCompetencyStatus: {
          ...state.editCompetencyStatus,
          response: action.editCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_COMPETENCY_ERROR:
      return {
        ...state,
        editCompetencyStatus: {
          ...state.editCompetencyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_COMPETENCY_RESET:
      return {
        ...state,
        deleteCompetencyStatus: { ...competencyInitialState.deleteCompetencyStatus },
      };
    case DELETE_COMPETENCY_LOADING:
      return {
        ...state,
        deleteCompetencyStatus: {
          ...state.deleteCompetencyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_COMPETENCY_SUCCESS:
      return {
        ...state,
        deleteCompetencyStatus: {
          ...state.deleteCompetencyStatus,
          response: action.deleteCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_COMPETENCY_ERROR:
      return {
        ...state,
        deleteCompetencyStatus: {
          ...state.deleteCompetencyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default CompetencyReducer;
