import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  addManagerApprovalURL,
  addManagerDenyURL,
  getSourceNamesURL,
  saveReportAttritionURL,
  getSkillsDropdownURL,
  getDomainDropdownURL,
  // getResourceDropdownURL,
  getRolesDropdownURL,
  getJobTitlesDropdownURL,
  getManagersDropdownURL,
  getSearchBySkillURL,
  getSearchByEmpDetailsyURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";

// ACTION TYPES
export const ADD_MANAGER_APPROVAL_LOADING = "ADD_MANAGER_APPROVAL_LOADING";
export const ADD_MANAGER_APPROVAL_SUCCESS = "ADD_MANAGER_APPROVAL_SUCCESS";
export const ADD_MANAGER_APPROVAL_ERROR = "ADD_MANAGER_APPROVAL_ERROR";

export const ADD_MANAGER_DENY_LOADING = "ADD_MANAGER_DENY_LOADING";
export const ADD_MANAGER_DENY_SUCCESS = "ADD_MANAGER_DENY_SUCCESS";
export const ADD_MANAGER_DENY_ERROR = "ADD_MANAGER_DENY_ERROR";

export const GET_SOURCE_NAMES_LOADING = "GET_SOURCE_NAMES_LOADING";
export const GET_SOURCE_NAMES_SUCCESS = "GET_SOURCE_NAMES_SUCCESS";
export const GET_SOURCE_NAMES_ERROR = "GET_SOURCE_NAMES_ERROR";

export const SAVE_REPORT_ATTRITION_LOADING = "SAVE_REPORT_ATTRITION_LOADING";
export const SAVE_REPORT_ATTRITION_SUCCESS = "SAVE_REPORT_ATTRITION_SUCCESS";
export const SAVE_REPORT_ATTRITION_ERROR = "SAVE_REPORT_ATTRITION_ERROR";

export const GET_SKILLS_DROPDOWN_LOADING = "GET_SKILLS_DROPDOWN_LOADING";
export const GET_SKILLS_DROPDOWN_SUCCESS = "GET_SKILLS_DROPDOWN_SUCCESS";
export const GET_SKILLS_DROPDOWN_ERROR = "GET_SKILLS_DROPDOWN_ERROR";

export const GET_DOMAIN_DROPDOWN_LOADING = "GET_DOMAIN_DROPDOWN_LOADING";
export const GET_DOMAIN_DROPDOWN_SUCCESS = "GET_DOMAIN_DROPDOWN_SUCCESS";
export const GET_DOMAIN_DROPDOWN_ERROR = "GET_DOMAIN_DROPDOWN_ERROR";

export const GET_ROLES_DROPDOWN_LOADING = "GET_ROLES_DROPDOWN_LOADING";
export const GET_ROLES_DROPDOWN_SUCCESS = "GET_ROLES_DROPDOWN_SUCCESS";
export const GET_ROLES_DROPDOWN_ERROR = "GET_ROLES_DROPDOWN_ERROR";

export const GET_JOB_TITLES_DROPDOWN_LOADING = "GET_JOB_TITLES_DROPDOWN_LOADING";
export const GET_JOB_TITLES_DROPDOWN_SUCCESS = "GET_JOB_TITLES_DROPDOWN_SUCCESS";
export const GET_JOB_TITLES_DROPDOWN_ERROR = "GET_JOB_TITLES_DROPDOWN_ERROR";

export const GET_MANAGER_DROPDOWN_LOADING = "GET_MANAGER_DROPDOWN_LOADING";
export const GET_MANAGER_DROPDOWN_SUCCESS = "GET_MANAGER_DROPDOWN_SUCCESS";
export const GET_MANAGER_DROPDOWN_ERROR = "GET_MANAGER_DROPDOWN_ERROR";

export const GET_SEARCH_BY_SKILL_LOADING = "GET_SEARCH_BY_SKILL_LOADING";
export const GET_SEARCH_BY_SKILL_SUCCESS = "GET_SEARCH_BY_SKILL_SUCCESS";
export const GET_SEARCH_BY_SKILL_ERROR = "GET_SEARCH_BY_SKILL_ERROR";

export const GET_SEARCH_BY_EMP_DETAILS_LOADING = "GET_SEARCH_BY_EMP_DETAILS_LOADING";
export const GET_SEARCH_BY_EMP_DETAILS_SUCCESS = "GET_SEARCH_BY_EMP_DETAILS_SUCCESS";
export const GET_SEARCH_BY_EMP_DETAILS_ERROR = "GET_SEARCH_BY_EMP_DETAILS_ERROR";

// ACTION CREATORS
export const addMangerApprovalLoading = () => ({
  type: ADD_MANAGER_APPROVAL_LOADING,
});
export const addManagerApprovalSuccess = (approvalDetails) => ({
  type: ADD_MANAGER_APPROVAL_SUCCESS,
  approvalDetails,
});
export const addMangerApprovalError = (error) => ({
  type: ADD_MANAGER_APPROVAL_ERROR,
  error,
});

export const addManagerDenyLoading = () => ({
  type: ADD_MANAGER_DENY_LOADING,
});
export const addManagerDenySuccess = (denyDetails) => ({
  type: ADD_MANAGER_DENY_SUCCESS,
  denyDetails,
});
export const addManagerDenyError = (error) => ({
  type: ADD_MANAGER_DENY_LOADING,
  error,
});

export const getSourceNamesLoading = () => ({
  type: GET_SOURCE_NAMES_LOADING,
});
export const getSourceNamesSuccess = (sourceNames) => ({
  type: GET_SOURCE_NAMES_SUCCESS,
  sourceNames,
});
export const getSourceNamesError = (error) => ({
  type: GET_SOURCE_NAMES_ERROR,
  error,
});

export const saveReportAttritionLoading = () => ({
  type: SAVE_REPORT_ATTRITION_LOADING,
});
export const saveReportAttritionSuccess = (reportAttrition) => ({
  type: SAVE_REPORT_ATTRITION_SUCCESS,
  reportAttrition,
});
export const saveReportAttritionError = (error) => ({
  type: SAVE_REPORT_ATTRITION_ERROR,
  error,
});

export const getSkillsDropdownLoading = () => ({
  type: GET_SKILLS_DROPDOWN_LOADING,
});
export const getSkillsDropdownSuccess = (skillsDropdown) => ({
  type: GET_SKILLS_DROPDOWN_SUCCESS,
  skillsDropdown,
});
export const getSkillsDropdownError = (error) => ({
  type: GET_SKILLS_DROPDOWN_ERROR,
  error,
});

export const getDomainDropdownLoading = () => ({
  type: GET_DOMAIN_DROPDOWN_LOADING,
});
export const getDomainDropdownSuccess = (domainDropdown) => ({
  type: GET_DOMAIN_DROPDOWN_SUCCESS,
  domainDropdown,
});
export const getDomainDropdownError = (error) => ({
  type: GET_DOMAIN_DROPDOWN_ERROR,
  error,
});

export const getRolesDropdownLoading = () => ({
  type: GET_ROLES_DROPDOWN_LOADING,
});
export const getRolesDropdownSuccess = (rolesDropdown) => ({
  type: GET_ROLES_DROPDOWN_SUCCESS,
  rolesDropdown,
});
export const getRolesDropdownError = (error) => ({
  type: GET_ROLES_DROPDOWN_ERROR,
  error,
});

export const getJobTitlesDropdownLoading = () => ({
  type: GET_JOB_TITLES_DROPDOWN_LOADING,
});
export const getJobTitlesDropdownSuccess = (jobTitlesDropdown) => ({
  type: GET_JOB_TITLES_DROPDOWN_SUCCESS,
  jobTitlesDropdown,
});
export const getJobTitlesDropdownError = (error) => ({
  type: GET_JOB_TITLES_DROPDOWN_ERROR,
  error,
});

export const getManagerDropdownLoading = () => ({
  type: GET_MANAGER_DROPDOWN_LOADING,
});
export const getManagerDropdownSuccess = (managerDropdown) => ({
  type: GET_MANAGER_DROPDOWN_SUCCESS,
  managerDropdown,
});
export const getManagerDropdownError = (error) => ({
  type: GET_MANAGER_DROPDOWN_ERROR,
  error,
});

export const getSearchBySkillLoading = () => ({
  type: GET_SEARCH_BY_SKILL_LOADING,
});
export const getSearchBySkillSuccess = (searchResultList) => ({
  type: GET_SEARCH_BY_SKILL_SUCCESS,
  searchResultList,
});
export const getSearchBySkillError = (error) => ({
  type: GET_SEARCH_BY_SKILL_ERROR,
  error,
});

export const getSearchByEmpDetailsLoading = () => ({
  type: GET_SEARCH_BY_EMP_DETAILS_LOADING,
});
export const getSearchByEmpDetailsSuccess = (searchResultList) => ({
  type: GET_SEARCH_BY_EMP_DETAILS_SUCCESS,
  searchResultList,
});
export const getSearchByEmpDetailsError = (error) => ({
  type: GET_SEARCH_BY_EMP_DETAILS_ERROR,
  error,
});

// THUNK CREATORS
export const addManagerApprovalThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addMangerApprovalLoading());
    const { data } = await roverSkillcentralURL.post(addManagerApprovalURL(), payload);
    if (callback) {
      callback(ADD_MANAGER_APPROVAL_SUCCESS, data);
    }
    dispatch(addManagerApprovalSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_MANAGER_APPROVAL_ERROR, error.response);
    }
    dispatch(addMangerApprovalError(error));
  }
};

export const addManagerDenyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addManagerDenyLoading());
    const { data } = await roverSkillcentralURL.post(addManagerDenyURL(), payload);
    if (callback) {
      callback(ADD_MANAGER_DENY_SUCCESS, data);
    }
    dispatch(addManagerDenySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_MANAGER_DENY_ERROR, error);
    }
    dispatch(addManagerDenyError(error));
  }

};

export const getSourceNamesThunk = () => async (dispatch) => {
  try {
    dispatch(getSourceNamesLoading());
    const { data } = await roverSkillcentralURL.get(getSourceNamesURL());
    dispatch(getSourceNamesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getSourceNamesError(error));
  }
};

export const getSkillsDropdownThunk = (skillTypeId, departmentId, callback) => async (dispatch) => {
  try {
    dispatch(getSkillsDropdownLoading());
    const { data } = await roverSkillcentralURL.get(getSkillsDropdownURL(skillTypeId, departmentId));
    if (callback) callback(data)
    dispatch(getSkillsDropdownSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getSkillsDropdownError(error));
  }
};

export const getDomainDropdownThunk = (skillTypeId, callback) => async (dispatch) => {
  try {
    dispatch(getDomainDropdownLoading());
    const { data } = await roverSkillcentralURL.get(getDomainDropdownURL(skillTypeId));
    if (callback) callback(data)
    dispatch(getDomainDropdownSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getDomainDropdownError(error));
  }
};

export const getRolesDropdownThunk = (departmentId, callback) => async (dispatch) => {
  try {
    dispatch(getRolesDropdownLoading());
    const { data } = await roverSkillcentralURL.get(getRolesDropdownURL(departmentId));
    if (callback) callback(data)
    dispatch(getRolesDropdownSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getRolesDropdownError(error));
  }
};

export const getJobTitlesDropdownThunk = (departmentId, callback) => async (dispatch) => {
  try {
    dispatch(getJobTitlesDropdownLoading());
    const { data } = await roverSkillcentralURL.get(getJobTitlesDropdownURL(departmentId));
    if (callback) callback(data)
    dispatch(getJobTitlesDropdownSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getJobTitlesDropdownError(error));
  }
};

export const getManagerDropdownThunk = (departmentId, callback) => async (dispatch) => {
  try {
    dispatch(getManagerDropdownLoading());
    const { data } = await roverSkillcentralURL.get(getManagersDropdownURL(departmentId));
    if (callback) callback(data)
    dispatch(getManagerDropdownSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getManagerDropdownError(error));
  }
};

export const getSearchBySkillThunk = (deptId, skillId, skillTypeId, payload) => async (dispatch) => {
  try {
    dispatch(getSearchBySkillLoading());
    const { data } = await roverSkillcentralURL.put(getSearchBySkillURL(deptId, skillId, skillTypeId), payload);
    dispatch(getSearchBySkillSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getSearchBySkillError(error));
  }
};

export const getSearchByEmpDetailsThunk = (lanID,payload) => async (dispatch) => {
  try {
    dispatch(getSearchByEmpDetailsLoading());
    const { data } = await roverSkillcentralURL.put(getSearchByEmpDetailsyURL(lanID),payload)
    dispatch(getSearchByEmpDetailsSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getSearchByEmpDetailsError(error));
  }
};

export const saveReportAttritionThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveReportAttritionLoading());
    const { data } = await roverSkillcentralURL.post(saveReportAttritionURL(), payload);
    if (callback) {
      callback(SAVE_REPORT_ATTRITION_SUCCESS, data);
    }
    dispatch(saveReportAttritionLoading(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_REPORT_ATTRITION_ERROR, error);
    }
    dispatch(saveReportAttritionError(error));
  }
};

export const initialState = {
  approvalDetails: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  denyDetails: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  sourceNames: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  skillsDropdown: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  domainDropdown: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  rolesDropdown: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  jobTitlesDropdown: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  managerDropdown: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  searchBySkillList: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  searchByEmpDetailsList: { data: [], status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
export const RMActionsReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_MANAGER_APPROVAL_SUCCESS:
      return {
        ...state,
        approvalDetails: {
          data: action.approvalDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_MANAGER_APPROVAL_LOADING:
      return {
        ...state,
        approvalDetails: {
          ...state.approvalDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_MANAGER_APPROVAL_ERROR:
      return {
        ...state,
        approvalDetails: {
          ...state.approvalDetails,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case ADD_MANAGER_DENY_SUCCESS:
      return {
        ...state,
        denyDetails: {
          data: action.denyDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_MANAGER_DENY_LOADING:
      return {
        ...state,
        denyDetails: {
          ...state.denyDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_MANAGER_DENY_ERROR:
      return {
        ...state,
        denyDetails: {
          ...state.denyDetails,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_SOURCE_NAMES_SUCCESS:
      return {
        ...state,
        sourceNames: {
          data: action.sourceNames,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_SOURCE_NAMES_ERROR:
      return {
        ...state,
        sourceNames: {
          ...state.sourceNames,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case SAVE_REPORT_ATTRITION_SUCCESS:
      return {
        ...state,
        reportAttrition: {
          data: action.reportAttrition,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_REPORT_ATTRITION_LOADING:
      return {
        ...state,
        reportAttrition: {
          ...state.reportAttrition,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_REPORT_ATTRITION_ERROR:
      return {
        ...state,
        reportAttrition: {
          ...state.reportAttrition,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_SKILLS_DROPDOWN_LOADING:
      return {
        ...state,
        skillsDropdown: {
          ...state.skillsDropdown,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_SKILLS_DROPDOWN_SUCCESS:
      return {
        ...state,
        skillsDropdown: {
          data: action.skillsDropdown,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_SKILLS_DROPDOWN_ERROR:
      return {
        ...state,
        skillsDropdown: {
          ...state.skillsDropdown,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_ROLES_DROPDOWN_LOADING:
      return {
        ...state,
        rolesDropdown: {
          ...state.rolesDropdown,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ROLES_DROPDOWN_SUCCESS:
      return {
        ...state,
        rolesDropdown: {
          data: action.rolesDropdown,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ROLES_DROPDOWN_ERROR:
      return {
        ...state,
        rolesDropdown: {
          ...state.rolesDropdown,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_JOB_TITLES_DROPDOWN_LOADING:
      return {
        ...state,
        jobTitlesDropdown: {
          ...state.jobTitlesDropdown,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_JOB_TITLES_DROPDOWN_SUCCESS:
      return {
        ...state,
        jobTitlesDropdown: {
          data: action.jobTitlesDropdown,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_JOB_TITLES_DROPDOWN_ERROR:
      return {
        ...state,
        jobTitlesDropdown: {
          ...state.jobTitlesDropdown,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_MANAGER_DROPDOWN_LOADING:
      return {
        ...state,
        managerDropdown: {
          ...state.managerDropdown,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_MANAGER_DROPDOWN_SUCCESS:
      return {
        ...state,
        managerDropdown: {
          data: action.managerDropdown,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_MANAGER_DROPDOWN_ERROR:
      return {
        ...state,
        managerDropdown: {
          ...state.managerDropdown,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_DOMAIN_DROPDOWN_LOADING:
      return {
        ...state,
        domainDropdown: {
          ...state.domainDropdown,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DOMAIN_DROPDOWN_SUCCESS:
      return {
        ...state,
        domainDropdown: {
          data: action.domainDropdown,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DOMAIN_DROPDOWN_ERROR:
      return {
        ...state,
        domainDropdown: {
          ...state.domainDropdown,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_SEARCH_BY_SKILL_LOADING:
      return {
        ...state,
        searchBySkillList: {
          ...state.searchBySkillList,
          status: DATA_STATUS.LOADING,
          data: [],
        },
      };
    case GET_SEARCH_BY_SKILL_SUCCESS:
      return {
        ...state,
        searchBySkillList: {
          data: typeof action.searchResultList === "string" ? [] : [...action.searchResultList],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_SEARCH_BY_SKILL_ERROR:
      return {
        ...state,
        searchBySkillList: {
          ...state.searchBySkillList,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_SEARCH_BY_EMP_DETAILS_LOADING:
      return {
        ...state,
        searchByEmpDetailsList: {
          ...state.searchByEmpDetailsList,
          status: DATA_STATUS.LOADING,
          data: [],
        },
      };
    case GET_SEARCH_BY_EMP_DETAILS_SUCCESS:
      return {
        ...state,
        searchByEmpDetailsList: {
          data: typeof action.searchResultList === "string" ? [] : [...action.searchResultList],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_SEARCH_BY_EMP_DETAILS_ERROR:
      return {
        ...state,
        searchByEmpDetailsList: {
          ...state.searchByEmpDetailsList,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    default:
      return state;
  }
};

export default RMActionsReducer;