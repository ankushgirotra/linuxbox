import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import { getIiqRolesURL } from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";

// ACTION TYPES
export const GET_IIQ_ROLES = "GET_IIQ_ROLES";
export const GET_IIQ_ROLES_LOADING = "GET_IIQ_ROLES_LOADING";
export const GET_IIQ_ROLES_ERROR = "GET_IIQ_ROLES_ERROR";

// ACTION CREATORS
export const getIiqRoles = (iiqRoles) => ({
  type: GET_IIQ_ROLES,
  iiqRoles,
});
export const getIiqRolesLoading = () => ({
  type: GET_IIQ_ROLES_LOADING,
});
export const getIiqRolesError = (error) => ({
  type: GET_IIQ_ROLES_ERROR,
  error,
});

// THUNK CREATORS
export const getIiqRolesThunk = (lanId, callback) => async (dispatch) => {
  try {
    dispatch(getIiqRolesLoading());
    const { data } = await roverSkillcentralURL.get(getIiqRolesURL(lanId));
    if (callback) callback(GET_IIQ_ROLES, data);
    dispatch(getIiqRoles(data));
  } catch (error) {
    console.error(error);
    if (callback) callback(GET_IIQ_ROLES_ERROR, error);
    dispatch(getIiqRolesError(error));
  }
};

// INITIAL STATE
export const initialState = {
  iiqRoles: { data: [], status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCER
const ScAuthReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_IIQ_ROLES:
      return {
        ...state,
        iiqRoles: {
          data: { ...action.iiqRoles },
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_IIQ_ROLES_LOADING:
      return {
        ...state,
        iiqRoles: {
          ...state.iiqRoles,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_IIQ_ROLES_ERROR:
      return {
        ...state,
        iiqRoles: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    default:
      return state;
  }
};

export default ScAuthReducer;
