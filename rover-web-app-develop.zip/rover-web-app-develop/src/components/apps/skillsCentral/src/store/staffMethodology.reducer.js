import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  addSkillSubmissionURL,
  getSkillSubmissionURL,
  updateDeleteSkillSubmissionURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE_ID } from "../Constants/action.constants";

// ACTION TYPES
export const GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID = "GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID";
export const GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_LOADING =
  "GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_LOADING";
export const GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_ERROR =
  "GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_ERROR";



export const SAVE_STAFF_METHODOLOGY_RESET = "SAVE_STAFF_METHODOLOGY_RESET";
export const SAVE_STAFF_METHODOLOGY_LOADING = "SAVE_STAFF_METHODOLOGY_LOADING";
export const SAVE_STAFF_METHODOLOGY_SUCCESS = "SAVE_STAFF_METHODOLOGY_SUCCESS";
export const SAVE_STAFF_METHODOLOGY_ERROR = "SAVE_STAFF_METHODOLOGY_ERROR";

export const EDIT_STAFF_METHODOLOGY_RESET = "EDIT_STAFF_METHODOLOGY_RESET";
export const EDIT_STAFF_METHODOLOGY_LOADING = "EDIT_STAFF_METHODOLOGY_LOADING";
export const EDIT_STAFF_METHODOLOGY_SUCCESS = "EDIT_STAFF_METHODOLOGY_SUCCESS";
export const EDIT_STAFF_METHODOLOGY_ERROR = "EDIT_STAFF_METHODOLOGY_ERROR";

export const DELETE_STAFF_METHODOLOGY_RESET = "DELETE_STAFF_METHODOLOGY_RESET";
export const DELETE_STAFF_METHODOLOGY_LOADING = "DELETE_STAFF_METHODOLOGY_LOADING";
export const DELETE_STAFF_METHODOLOGY_SUCCESS = "DELETE_STAFF_METHODOLOGY_SUCCESS";
export const DELETE_STAFF_METHODOLOGY_ERROR = "DELETE_STAFF_METHODOLOGY_ERROR";

// ACTION CREATORS
export const getStaffMethodologiesByResourceId = (staffMethodologies) => ({
  type: GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID,
  staffMethodologies,
});
export const getStaffMethodologiesByResourceIdLoading = () => ({
  type: GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_LOADING,
});
export const getStaffMethodologiesByResourceIdError = (error) => ({
  type: GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_ERROR,
  error,
});


export const saveStaffMethodologyReset = () => ({
  type: SAVE_STAFF_METHODOLOGY_RESET,
});
export const saveStaffMethodologyLoading = () => ({
  type: SAVE_STAFF_METHODOLOGY_LOADING,
});
export const saveStaffMethodologySuccess = (saveStaffMethodology) => ({
  type: SAVE_STAFF_METHODOLOGY_SUCCESS,
  saveStaffMethodology,
});
export const saveStaffMethodologyError = (error) => ({
  type: SAVE_STAFF_METHODOLOGY_ERROR,
  error,
});

export const editStaffMethodologyReset = () => ({
  type: EDIT_STAFF_METHODOLOGY_RESET,
});
export const editStaffMethodologyLoading = () => ({
  type: EDIT_STAFF_METHODOLOGY_LOADING,
});
export const editStaffMethodologySuccess = (editStaffMethodology) => ({
  type: EDIT_STAFF_METHODOLOGY_SUCCESS,
  editStaffMethodology,
});
export const editStaffMethodologyError = (error) => ({
  type: EDIT_STAFF_METHODOLOGY_ERROR,
  error,
});

export const deleteStaffMethodologyReset = () => ({
  type: DELETE_STAFF_METHODOLOGY_RESET,
});
export const deleteStaffMethodologyLoading = () => ({
  type: DELETE_STAFF_METHODOLOGY_LOADING,
});
export const deleteStaffMethodologySuccess = (deleteStaffMethodology) => ({
  type: DELETE_STAFF_METHODOLOGY_SUCCESS,
  deleteStaffMethodology,
});
export const deleteStaffMethodologyError = (error) => ({
  type: DELETE_STAFF_METHODOLOGY_ERROR,
  error,
});

// THUNK CREATORS
export const getStaffMethodologiesByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getStaffMethodologiesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillSubmissionURL(resourceLanId, SKILL_TYPE_ID.METH));
    // console.log("staff Meth -->", resourceLanId, data )
    dispatch(getStaffMethodologiesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getStaffMethodologiesByResourceIdError(error));
  }
};

export const saveStaffMethodologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveStaffMethodologyLoading());
    const { data } = await roverSkillcentralURL.post(addSkillSubmissionURL(), payload);
    if (callback) {
      callback(SAVE_STAFF_METHODOLOGY_SUCCESS, data);
    }
    dispatch(saveStaffMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_STAFF_METHODOLOGY_ERROR, error);
    }
    dispatch(saveStaffMethodologyError(error));
  }
};

export const editStaffMethodologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editStaffMethodologyLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(EDIT_STAFF_METHODOLOGY_SUCCESS, data);
    }
    dispatch(editStaffMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_STAFF_METHODOLOGY_ERROR, error);
    }
    dispatch(editStaffMethodologyError(error));
  }
};

export const deleteStaffMethodologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(deleteStaffMethodologyLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(DELETE_STAFF_METHODOLOGY_SUCCESS, data);
    }
    dispatch(deleteStaffMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_STAFF_METHODOLOGY_ERROR, error);
    }
    dispatch(deleteStaffMethodologyError(error));
  }
};

// INITIAL STATE
export const staffMethodologyInitialState = {
  staffMethodologies: {
    // all staffMethodologies for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  saveStaffMethodologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editStaffMethodologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteStaffMethodologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Basic Knowledge" },
    { id: 2, desc: "2 - Limited Experience" },
    { id: 3, desc: "3 - Practical Application" },
    { id: 4, desc: "4 - Applied Theory" },
    { id: 5, desc: "5 - Recognized Authority" },
  ],
};

// REDUCERS
const StaffMethodologyReducer = (state = staffMethodologyInitialState, action) => {
  switch (action.type) {
    case GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID:
      return {
        ...state,
        staffMethodologies: {
          data: typeof action.staffMethodologies === "string" ? [] : [...action.staffMethodologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        staffMethodologies: {
          ...state.staffMethodologies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_STAFF_METHODOLOGIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        staffMethodologies: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
      

    case SAVE_STAFF_METHODOLOGY_RESET:
      return {
        ...state,
        saveStaffMethodologyStatus: { ...staffMethodologyInitialState.saveStaffMethodologyStatus },
      };
    case SAVE_STAFF_METHODOLOGY_LOADING:
      return {
        ...state,
        saveStaffMethodologyStatus: {
          ...state.saveStaffMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_STAFF_METHODOLOGY_SUCCESS:
      return {
        ...state,
        saveStaffMethodologyStatus: {
          ...state.saveStaffMethodologyStatus,
          response: action.saveStaffMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };

    case SAVE_STAFF_METHODOLOGY_ERROR:
      return {
        ...state,
        saveStaffMethodologyStatus: {
          ...state.saveStaffMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };

    case EDIT_STAFF_METHODOLOGY_RESET:
      return {
        ...state,
        editStaffMethodologyStatus: { ...staffMethodologyInitialState.editStaffMethodologyStatus },
      };
    case EDIT_STAFF_METHODOLOGY_LOADING:
      return {
        ...state,
        editStaffMethodologyStatus: {
          ...state.editStaffMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_STAFF_METHODOLOGY_SUCCESS:
      return {
        ...state,
        editStaffMethodologyStatus: {
          ...state.editStaffMethodologyStatus,
          response: action.editStaffMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_STAFF_METHODOLOGY_ERROR:
      return {
        ...state,
        editStaffMethodologyStatus: {
          ...state.editStaffMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_STAFF_METHODOLOGY_RESET:
      return {
        ...state,
        deleteStaffMethodologyStatus: {
          ...staffMethodologyInitialState.deleteStaffMethodologyStatus,
        },
      };
    case DELETE_STAFF_METHODOLOGY_LOADING:
      return {
        ...state,
        deleteStaffMethodologyStatus: {
          ...state.deleteStaffMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_STAFF_METHODOLOGY_SUCCESS:
      return {
        ...state,
        deleteStaffMethodologyStatus: {
          ...state.deleteStaffMethodologyStatus,
          response: action.deleteStaffMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_STAFF_METHODOLOGY_ERROR:
      return {
        ...state,
        deleteStaffMethodologyStatus: {
          ...state.deleteStaffMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default StaffMethodologyReducer;
