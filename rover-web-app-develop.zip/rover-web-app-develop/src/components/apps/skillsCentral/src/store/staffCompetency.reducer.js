import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  getSkillSubmissionURL,
  updateDeleteSkillSubmissionURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE_ID } from "../Constants/action.constants";

// ACTION TYPES
export const GET_STAFF_COMPETENCIES_BY_RESOURCE_ID = "GET_STAFF_COMPETENCIES_BY_RESOURCE_ID";
export const GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_LOADING =
  "GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_LOADING";
export const GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_ERROR =
  "GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_ERROR";


export const EDIT_STAFF_COMPETENCY_RESET = "EDIT_STAFF_COMPETENCY_RESET";
export const EDIT_STAFF_COMPETENCY_LOADING = "EDIT_STAFF_COMPETENCY_LOADING";
export const EDIT_STAFF_COMPETENCY_SUCCESS = "EDIT_STAFF_COMPETENCY_SUCCESS";
export const EDIT_STAFF_COMPETENCY_ERROR = "EDIT_STAFF_COMPETENCY_ERROR";

// ACTION CREATORS
export const getStaffCompetenciesByResourceId = (staffCompetencies) => ({
  type: GET_STAFF_COMPETENCIES_BY_RESOURCE_ID,
  staffCompetencies,
});
export const getStaffCompetenciesByResourceIdLoading = () => ({
  type: GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_LOADING,
});
export const getStaffCompetenciesByResourceIdError = (error) => ({
  type: GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const editStaffCompetencyReset = () => ({
  type: EDIT_STAFF_COMPETENCY_RESET,
});
export const editStaffCompetencyLoading = () => ({
  type: EDIT_STAFF_COMPETENCY_LOADING,
});
export const editStaffCompetencySuccess = (editStaffCompetency) => ({
  type: EDIT_STAFF_COMPETENCY_SUCCESS,
  editStaffCompetency,
});
export const editStaffCompetencyError = (error) => ({
  type: EDIT_STAFF_COMPETENCY_ERROR,
  error,
});

// THUNK CREATORS
export const getStaffCompetenciesByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getStaffCompetenciesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillSubmissionURL(resourceLanId, SKILL_TYPE_ID.COMP));
    // console.log("staff comp -->", resourceLanId, data )
    dispatch(getStaffCompetenciesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getStaffCompetenciesByResourceIdError(error));
  }
};

export const editStaffCompetencyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editStaffCompetencyLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(EDIT_STAFF_COMPETENCY_SUCCESS, data);
    }
    dispatch(editStaffCompetencySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_STAFF_COMPETENCY_ERROR, error);
    }
    dispatch(editStaffCompetencyError(error));
  }
};

export const staffCompetencyInitialState = {
  staffCompetencies: {
    // all staffCompetencies
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  editStaffCompetencyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Novice" },
    { id: 2, desc: "2 - Capable" },
    { id: 3, desc: "3 - Competent" },
    { id: 4, desc: "4 - Proficient" },
  ],
};

const StaffCompetencyReducer = (state = staffCompetencyInitialState, action) => {
  switch (action.type) {
    case GET_STAFF_COMPETENCIES_BY_RESOURCE_ID:
      return {
        ...state,
        staffCompetencies: {
          data: typeof action.staffCompetencies === "string" ? [] : [...action.staffCompetencies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        staffCompetencies: {
          ...state.staffCompetencies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_STAFF_COMPETENCIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        staffCompetencies: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };

      
    case EDIT_STAFF_COMPETENCY_RESET:
      return {
        ...state,
        editStaffCompetencyStatus: { ...staffCompetencyInitialState.editStaffCompetencyStatus },
      };
    case EDIT_STAFF_COMPETENCY_LOADING:
      return {
        ...state,
        editStaffCompetencyStatus: {
          ...state.editStaffCompetencyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_STAFF_COMPETENCY_SUCCESS:
      return {
        ...state,
        editStaffCompetencyStatus: {
          ...state.editStaffCompetencyStatus,
          response: action.editStaffCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_STAFF_COMPETENCY_ERROR:
      return {
        ...state,
        editStaffCompetencyStatus: {
          ...state.editStaffCompetencyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default StaffCompetencyReducer;