import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import {
  getSkillExpirationURL,
  updateSkillExpirationURL,
  addAdminCategory,
  getAdminCategoryURL,
  getAttritionOptionsURL,
  addAttritionOptionURL,
  editAttritionOptionURL,
  deleteAttritionOptionURL,
  getDeptHeadsURL,
  getHeadNamesURL,
  addDepartmentHeadURL,
  editDepartmentHeadURL,
  deleteDepartmentHeadURL,
  getAdminManageVendorsURL,
  addAdminManageVendorURL,
  getAdminManageVendorNumNamesURL,
  editAdminManageVendorURL,
  deleteAdminManageVendorURL,
  getAdminSKillURL,
  saveAdminSkillURL,
  addAdminRoleURL,
  editAdminRoleURL,
  getRolesURL,
  deleteAdminRoleURL,
  getResourceTypeURL,
  getAttritionTypeURL,
  getJobTitlesURL,
  editJobTitlesURL,
  editAdminSkillURL,
  deleteAdminSkillURL,
  getDeptManagersURL,
  editDepartmentManagerURL,
  getAdminOneRateURL,
  addAdminOneRateURL,
  editAdminOneRateURL,
  getAutomationStatusURL,
  toggleAutomationStatusURL,
  updateSCEmailNotificationStatusURL,
} from "./endpoints";
import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import { SKILL_TYPE } from "../Constants/action.constants";

// ACTION TYPES
export const GET_SKILL_EXP_LOADING = "GET_SKILL_EXP_LOADING";
export const GET_SKILL_EXP_SUCCESS = "GET_SKILL_EXP_SUCCESS";
export const GET_SKILL_EXP_ERROR = "GET_SKILL_EXP_ERROR";

export const UPDATE_SKILL_EXP_LOADING = "UPDATE_SKILL_EXP_LOADING";
export const UPDATE_SKILL_EXP_SUCCESS = "UPDATE_SKILL_EXP_SUCCESS";
export const UPDATE_SKILL_EXP_ERROR = "UPDATE_SKILL_EXP_ERROR";

export const SAVE_ADMIN_METHODOLOGY_LOADING = "SAVE_ADMIN_METHODOLOGY_LOADING";
export const SAVE_ADMIN_METHODOLOGY_SUCCESS = "SAVE_ADMIN_METHODOLOGY_SUCCESS";
export const SAVE_ADMIN_METHODOLOGY_ERROR = "SAVE_ADMIN_METHODOLOGY_ERROR";

export const EDIT_ADMIN_METHODOLOGY_LOADING = "EDIT_ADMIN_METHODOLOGY_LOADING";
export const EDIT_ADMIN_METHODOLOGY_SUCCESS = "EDIT_ADMIN_METHODOLOGY_SUCCESS";
export const EDIT_ADMIN_METHODOLOGY_ERROR = "EDIT_ADMIN_METHODOLOGY_ERROR";

export const DELETE_ADMIN_METHODOLOGY_LOADING = "DELETE_ADMIN_METHODOLOGY_LOADING";
export const DELETE_ADMIN_METHODOLOGY_SUCCESS = "DELETE_ADMIN_METHODOLOGY_SUCCESS";
export const DELETE_ADMIN_METHODOLOGY_ERROR = "DELETE_ADMIN_METHODOLOGY_ERROR";

export const ADD_ADMIN_TECHNOLOGY_LOADING = "ADD_ADMIN_TECHNOLOGY_LOADING";
export const ADD_ADMIN_TECHNOLOGY_SUCCESS = "ADD_ADMIN_TECHNOLOGY_SUCCESS";
export const ADD_ADMIN_TECHNOLOGY_ERROR = "ADD_ADMIN_TECHNOLOGY_ERROR";

export const UPDATE_ADMIN_TECHNOLOGY_LOADING = "UPDATE_ADMIN_TECHNOLOGY_LOADING";
export const UPDATE_ADMIN_TECHNOLOGY_SUCCESS = "UPDATE_ADMIN_TECHNOLOGY_SUCCESS";
export const UPDATE_ADMIN_TECHNOLOGY_ERROR = "UPDATE_ADMIN_TECHNOLOGY_ERROR";

export const DELETE_ADMIN_TECHNOLOGY_LOADING = "DELETE_ADMIN_TECHNOLOGY_LOADING";
export const DELETE_ADMIN_TECHNOLOGY_SUCCESS = "DELETE_ADMIN_TECHNOLOGY_SUCCESS";
export const DELETE_ADMIN_TECHNOLOGY_ERROR = "DELETE_ADMIN_TECHNOLOGY_ERROR";

export const ADD_ADMIN_CATEGORY_LOADING = "ADD_ADMIN_CATEGORY_LOADING";
export const ADD_ADMIN_CATEGORY_SUCCESS = "ADD_ADMIN_CATEGORY_SUCCESS";
export const ADD_ADMIN_CATEGORY_ERROR = "ADD_ADMIN_CATEGORY_ERROR";

export const GET_ADMIN_CATEGORY_LOADING = "GET_ADMIN_CATEGORY_LOADING";
export const GET_ADMIN_CATEGORY_SUCCESS = "GET_ADMIN_CATEGORY_SUCCESS";
export const GET_ADMIN_CATEGORY_ERROR = "GET_ADMIN_CATEGORY_ERROR";

export const GET_ATTRITION_OPTIONS_LOADING = "GET_ATTRITION_OPTIONS_LOADING";
export const GET_ATTRITION_OPTIONS_SUCCESS = "GET_ATTRITION_OPTIONS_SUCCESS";
export const GET_ATTRITION_OPTIONS_ERROR = "GET_ATTRITION_OPTIONS_ERROR";

export const GET_RESOURCE_TYPE_LOADING = "GET_RESOURCE_TYPE_LOADING";
export const GET_RESOURCE_TYPE_SUCCESS = "GET_RESOURCE_TYPE_SUCCESS";
export const GET_RESOURCE_TYPE_ERROR = "GET_RESOURCE_TYPE_ERROR";

export const GET_ATTRITION_TYPE_LOADING = "GET_ATTRITION_TYPE_LOADING";
export const GET_ATTRITION_TYPE_SUCCESS = "GET_ATTRITION_TYPE_SUCCESS";
export const GET_ATTRITION_TYPE_ERROR = "GET_ATTRITION_TYPE_ERROR";

export const ADD_ATTRITION_OPTION_LOADING = "ADD_ATTRITION_OPTION_LOADING";
export const ADD_ATTRITION_OPTION_SUCCESS = "ADD_ATTRITION_OPTION_SUCCESS";
export const ADD_ATTRITION_OPTION_ERROR = "ADD_ATTRITION_OPTION_ERROR";

export const EDIT_ATTRITION_OPTION_LOADING = "EDIT_ATTRITION_OPTION_LOADING";
export const EDIT_ATTRITION_OPTION_SUCCESS = "EDIT_ATTRITION_OPTION_SUCCESS";
export const EDIT_ATTRITION_OPTION_ERROR = "EDIT_ATTRITION_OPTION_ERROR";

export const DELETE_ATTRITION_OPTION_LOADING = "DELETE_ATTRITION_OPTION_LOADING";
export const DELETE_ATTRITION_OPTION_SUCCESS = "DELETE_ATTRITION_OPTION_SUCCESS";
export const DELETE_ATTRITION_OPTION_ERROR = "DELETE_ATTRITION_OPTION_ERROR";

export const GET_DEPT_HEADS_LOADING = "GET_DEPT_HEADS_LOADING";
export const GET_DEPT_HEADS_SUCCESS = "GET_DEPT_HEADS_SUCCESS";
export const GET_DEPT_HEADS_ERROR = "GET_DEPT_HEADS_ERROR";

export const GET_HEAD_NAMES_LOADING = "GET_HEAD_NAMES_LOADING";
export const GET_HEAD_NAMES_SUCCESS = "GET_HEAD_NAMES_SUCCESS";
export const GET_HEAD_NAMES_ERROR = "GET_HEAD_NAMES_ERROR";

export const ADD_DEPT_HEAD_LOADING = "ADD_DEPT_HEAD_LOADING";
export const ADD_DEPT_HEAD_SUCCESS = "ADD_DEPT_HEAD_SUCCESS";
export const ADD_DEPT_HEAD_ERROR = "ADD_DEPT_HEAD_ERROR";

export const EDIT_DEPT_HEAD_LOADING = "EDIT_DEPT_HEAD_LOADING";
export const EDIT_DEPT_HEAD_SUCCESS = "EDIT_DEPT_HEAD_SUCCESS";
export const EDIT_DEPT_HEAD_ERROR = "EDIT_DEPT_HEAD_ERROR";

export const DELETE_DEPT_HEAD_LOADING = "DELETE_DEPT_HEAD_LOADING";
export const DELETE_DEPT_HEAD_SUCCESS = "DELETE_DEPT_HEAD_SUCCESS";
export const DELETE_DEPT_HEAD_ERROR = "DELETE_DEPT_HEAD_ERROR";

export const GET_ADMIN_COMPETENCY_LOADING = "GET_ADMIN_COMPETENCY_LOADING";
export const GET_ADMIN_COMPETENCY_SUCCESS = "GET_ADMIN_COMPETENCY_SUCCESS";
export const GET_ADMIN_COMPETENCY_ERROR = "GET_ADMIN_COMPETENCY_ERROR";

export const ADD_ADMIN_COMPETENCY_LOADING = "ADD_ADMIN_COMPETENCY_LOADING";
export const ADD_ADMIN_COMPETENCY_SUCCESS = "ADD_ADMIN_COMPETENCY_SUCCESS";
export const ADD_ADMIN_COMPETENCY_ERROR = "ADD_ADMIN_COMPETENCY_ERROR";

export const UPDATE_ADMIN_COMPETENCY_LOADING = "EDIT_ADMIN_COMPETENCY_LOADING";
export const UPDATE_ADMIN_COMPETENCY_SUCCESS = "EDIT_ADMIN_COMPETENCY_SUCCESS";
export const UPDATE_ADMIN_COMPETENCY_ERROR = "EDIT_ADMIN_COMPETENCY_ERROR";

export const GET_MANAGE_VENDORS_LOADING = "GET_MANAGE_VENDORS_LOADING";
export const GET_MANAGE_VENDORS_SUCCESS = "GET_MANAGE_VENDORS_SUCCESS";
export const GET_MANAGE_VENDORS_ERROR = "GET_MANAGE_VENDORS_ERROR";

export const GET_MANAGE_VENDORS_NUM_NAMES_LOADING = "GET_MANAGE_VENDORS_NUM_NAMES_LOADING";
export const GET_MANAGE_VENDORS_NUM_NAMES_SUCCESS = "GET_MANAGE_VENDORS_NUM_NAMES_SUCCESS";
export const GET_MANAGE_VENDORS_NUM_NAMES_ERROR = "GET_MANAGE_VENDORS_NUM_NAMES_ERROR";

export const ADD_MANAGE_VENDOR_LOADING = "ADD_MANAGE_VENDOR_LOADING";
export const ADD_MANAGE_VENDOR_SUCCESS = "ADD_MANAGE_VENDOR_SUCCESS";
export const ADD_MANAGE_VENDOR_ERROR = "ADD_MANAGE_VENDOR_ERROR";

export const EDIT_MANAGE_VENDOR_LOADING = "EDIT_MANAGE_VENDOR_LOADING";
export const EDIT_MANAGE_VENDOR_SUCCESS = "EDIT_MANAGE_VENDOR_SUCCESS";
export const EDIT_MANAGE_VENDOR_ERROR = "EDIT_MANAGE_VENDOR_ERROR";

export const DELETE_MANAGE_VENDOR_LOADING = "DELETE_MANAGE_VENDOR_LOADING";
export const DELETE_MANAGE_VENDOR_SUCCESS = "DELETE_MANAGE_VENDOR_SUCCESS";
export const DELETE_MANAGE_VENDOR_ERROR = "DELETE_MANAGE_VENDOR_ERROR";

export const ADD_ROLE_LOADING = "ADD_ROLE_LOADING";
export const ADD_ROLE_SUCCESS = "ADD_ROLE_SUCCESS";
export const ADD_ROLE_ERROR = "ADD_ROLE_ERROR";

export const EDIT_ROLE_LOADING = "EDIT_ROLE_LOADING";
export const EDIT_ROLE_SUCCESS = "EDIT_ROLE_SUCCESS";
export const EDIT_ROLE_ERROR = "EDIT_ROLE_ERROR";

export const GET_ROLES_LOADING = "GET_ROLES_LOADING";
export const GET_ROLES_SUCCESS = "GET_ROLES_SUCCESS";
export const GET_ROLES_ERROR = "GET_ROLES_ERROR";

export const DELETE_ROLE_LOADING = "DELETE_ROLE_LOADING";
export const DELETE_ROLE_SUCCESS = "DELETE_ROLE_SUCCESS";
export const DELETE_ROLE_ERROR = "DELETE_ROLE_ERROR";

export const GET_JOB_TITLES_LOADING = "GET_JOB_TITLES_LOADING";
export const GET_JOB_TITLES_SUCCESS = "GET_JOB_TITLES_SUCCESS";
export const GET_JOB_TITLES_ERROR = "GET_JOB_TITLES_ERROR";

export const EDIT_JOB_TITLE_LOADING = "EDIT_JOB_TITLE_LOADING";
export const EDIT_JOB_TITLE_SUCCESS = "EDIT_JOB_TITLE_SUCCESS";
export const EDIT_JOB_TITLE_ERROR = "EDIT_JOB_TITLE_ERROR";

export const GET_DEPT_MANAGERS_LOADING = "GET_DEPT_MANAGERS_LOADING";
export const GET_DEPT_MANAGERS_SUCCESS = "GET_DEPT_MANAGERS_SUCCESS";
export const GET_DEPT_MANAGERS_ERROR = "GET_DEPT_MANAGERS_ERROR";

export const EDIT_DEPT_MANAGER_LOADING = "EDIT_DEPT_MANAGER_LOADING";
export const EDIT_DEPT_MANAGER_SUCCESS = "EDIT_DEPT_MANAGER_SUCCESS";
export const EDIT_DEPT_MANAGER_ERROR = "EDIT_DEPT_MANAGER_ERROR";

export const GET_ONE_RATE_LOADING = "GET_ONE_RATE_LOADING";
export const GET_ONE_RATE_SUCCESS = "GET_ONE_RATE_SUCCESS";
export const GET_ONE_RATE_ERROR = "GET_ONE_RATE_ERROR";

export const ADD_ONE_RATE_LOADING = "ADD_ONE_RATE_LOADING";
export const ADD_ONE_RATE_SUCCESS = "ADD_ONE_RATE_SUCCESS";
export const ADD_ONE_RATE_ERROR = "ADD_ONE_RATE_ERROR";

export const EDIT_ONE_RATE_LOADING = "EDIT_ONE_RATE_LOADING";
export const EDIT_ONE_RATE_SUCCESS = "EDIT_ONE_RATE_SUCCESS";
export const EDIT_ONE_RATE_ERROR = "EDIT_ONE_RATE_ERROR";

export const GET_AUTOMATION_STATUS_LOADING = "GET_AUTOMATION_STATUS_LOADING";
export const GET_AUTOMATION_STATUS_SUCCESS = "GET_AUTOMATION_STATUS_SUCCESS";
export const GET_AUTOMATION_STATUS_ERROR = "GET_AUTOMATION_STATUS_ERROR";

export const TOGGLE_AUTOMATION_STATUS_LOADING = "TOGGLE_AUTOMATION_STATUS_LOADING";
export const TOGGLE_AUTOMATION_STATUS_SUCCESS = "TOGGLE_AUTOMATION_STATUS_SUCCESS";
export const TOGGLE_AUTOMATION_STATUS_ERROR = "TOGGLE_AUTOMATION_STATUS_ERROR";

export const UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING = "UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING";
export const UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS = "UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS";
export const UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR = "UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR";

// ACTION CREATORS
export const getSkillExpSuccess = (skillExp) => ({
  type: GET_SKILL_EXP_SUCCESS,
  skillExp,
});

export const updateSkillExpLoading = () => ({
  type: UPDATE_SKILL_EXP_LOADING,
});
export const updateSkillExpSuccess = (updateSkillExp) => ({
  type: UPDATE_SKILL_EXP_SUCCESS,
  updateSkillExp,
});
export const updateSkillExpError = (error) => ({
  type: UPDATE_SKILL_EXP_ERROR,
  error,
});

export const saveAdminMethodologyLoading = () => ({
  type: SAVE_ADMIN_METHODOLOGY_LOADING,
});
export const saveAdminMethodologySuccess = (saveMethodology) => ({
  type: SAVE_ADMIN_METHODOLOGY_SUCCESS,
  saveMethodology,
});
export const saveAdminMethodologyError = (error) => ({
  type: SAVE_ADMIN_METHODOLOGY_ERROR,
  error,
});

export const editAdminMethodologyLoading = () => ({
  type: EDIT_ADMIN_METHODOLOGY_LOADING,
});
export const editAdminMethodologySuccess = (editMethodology) => ({
  type: EDIT_ADMIN_METHODOLOGY_SUCCESS,
  editMethodology,
});
export const editAdminMethodologyError = (error) => ({
  type: EDIT_ADMIN_METHODOLOGY_ERROR,
  error,
});

export const deleteAdminMethodologyLoading = () => ({
  type: DELETE_ADMIN_METHODOLOGY_LOADING,
});
export const deleteAdminMethodologySuccess = (deleteMethodology) => ({
  type: DELETE_ADMIN_METHODOLOGY_SUCCESS,
  deleteMethodology,
});
export const deleteAdminMethodologyError = (error) => ({
  type: DELETE_ADMIN_METHODOLOGY_ERROR,
  error,
});

export const addAdminTechnologyLoading = () => ({
  type: ADD_ADMIN_TECHNOLOGY_LOADING,
});
export const addAdminTechnologySuccess = (addAdminTechnology) => ({
  type: ADD_ADMIN_TECHNOLOGY_SUCCESS,
  addAdminTechnology,
});
export const addAdminTechnologyError = (error) => ({
  type: ADD_ADMIN_TECHNOLOGY_ERROR,
  error,
});

export const updateAdminTechnologyLoading = () => ({
  type: UPDATE_ADMIN_TECHNOLOGY_LOADING,
});
export const updateAdminTechnologySuccess = (updateAdminTechnology) => ({
  type: UPDATE_ADMIN_TECHNOLOGY_SUCCESS,
  updateAdminTechnology,
});
export const updateAdminTechnologyError = (error) => ({
  type: UPDATE_ADMIN_TECHNOLOGY_ERROR,
  error,
});

export const deleteAdminTechnologyLoading = () => ({
  type: DELETE_ADMIN_TECHNOLOGY_LOADING,
});
export const deleteAdminTechnologySuccess = (deleteAdminTechnology) => ({
  type: DELETE_ADMIN_TECHNOLOGY_SUCCESS,
  deleteAdminTechnology,
});
export const deleteAdminTechnologyError = (error) => ({
  type: DELETE_ADMIN_TECHNOLOGY_ERROR,
  error,
});

export const addAdminCategoryLoading = () => ({
  type: ADD_ADMIN_CATEGORY_LOADING,
});
export const addAdminCategorySuccess = (addAdminCategory) => ({
  type: ADD_ADMIN_CATEGORY_SUCCESS,
  addAdminCategory,
});
export const addAdminCategoryError = (error) => ({
  type: ADD_ADMIN_CATEGORY_ERROR,
  error,
});

export const getAdminCategoryLoading = () => ({
  type: GET_ADMIN_CATEGORY_LOADING,
});
export const getAdminCategorySuccess = (categories) => ({
  type: GET_ADMIN_CATEGORY_SUCCESS,
  categories,
});
export const getAdminCategoryError = (error) => ({
  type: GET_ADMIN_CATEGORY_ERROR,
  error,
});

export const getAttritionOptionsLoading = () => ({
  type: GET_ATTRITION_OPTIONS_LOADING,
});
export const getAttritionOptionsSuccess = (attritionOptions) => ({
  type: GET_ATTRITION_OPTIONS_SUCCESS,
  attritionOptions,
});
export const getAttritionOptionsError = (error) => ({
  type: GET_ATTRITION_OPTIONS_ERROR,
  error,
});

export const getResourceTypeLoading = () => ({
  type: GET_RESOURCE_TYPE_LOADING,
});
export const getResourceTypeSuccess = (resType) => ({
  type: GET_RESOURCE_TYPE_SUCCESS,
  resType,
});
export const getResourceTypeError = (error) => ({
  type: GET_RESOURCE_TYPE_ERROR,
  error,
});

export const getAttritionTypeLoading = () => ({
  type: GET_ATTRITION_TYPE_LOADING,
});
export const getAttritionTypeSuccess = (attrType) => ({
  type: GET_ATTRITION_TYPE_SUCCESS,
  attrType,
});
export const getAttritionTypeError = (error) => ({
  type: GET_ATTRITION_TYPE_ERROR,
  error,
});

export const addAttritionOptionLoading = () => ({
  type: ADD_ATTRITION_OPTION_LOADING,
});
export const addAttritionOptionSuccess = (addAttritionOption) => ({
  type: ADD_ATTRITION_OPTION_SUCCESS,
  addAttritionOption,
});
export const addAttritionOptionError = (error) => ({
  type: ADD_ATTRITION_OPTION_ERROR,
  error,
});

export const editAttritionOptionLoading = () => ({
  type: EDIT_ATTRITION_OPTION_LOADING,
});
export const editAttritionOptionSuccess = (editAttritionOption) => ({
  type: EDIT_ATTRITION_OPTION_SUCCESS,
  editAttritionOption,
});
export const editAttritionOptionError = (error) => ({
  type: EDIT_ATTRITION_OPTION_ERROR,
  error,
});

export const deleteAttritionOptionLoading = () => ({
  type: DELETE_ATTRITION_OPTION_LOADING,
});
export const deleteAttritionOptionSuccess = (deleteAttrition) => ({
  type: DELETE_ATTRITION_OPTION_SUCCESS,
  deleteAttrition,
});
export const deleteAttritionOptionError = (error) => ({
  type: DELETE_ATTRITION_OPTION_ERROR,
  error,
});

export const getDeptHeadsLoading = () => ({
  type: GET_DEPT_HEADS_LOADING,
});
export const getDeptHeadsSuccess = (deptHeads) => ({
  type: GET_DEPT_HEADS_SUCCESS,
  deptHeads,
});
export const getDeptHeadsError = (error) => ({
  type: GET_DEPT_HEADS_ERROR,
  error,
});

export const getHeadNamesLoading = () => ({
  type: GET_HEAD_NAMES_LOADING,
});
export const getHeadNamesSuccess = (headNames) => ({
  type: GET_HEAD_NAMES_SUCCESS,
  headNames,
});
export const getHeadNamesError = (error) => ({
  type: GET_HEAD_NAMES_ERROR,
  error,
});

export const addDeptHeadLoading = () => ({
  type: ADD_DEPT_HEAD_LOADING,
});
export const addDeptHeadSuccess = (addDeptHead) => ({
  type: ADD_DEPT_HEAD_SUCCESS,
  addDeptHead,
});
export const addDeptHeadError = (error) => ({
  type: ADD_DEPT_HEAD_ERROR,
  error,
});

export const editDeptHeadLoading = () => ({
  type: EDIT_DEPT_HEAD_LOADING,
});
export const editDeptHeadSuccess = (editDeptHead) => ({
  type: EDIT_DEPT_HEAD_SUCCESS,
  editDeptHead,
});
export const editDeptHeadError = (error) => ({
  type: EDIT_DEPT_HEAD_ERROR,
  error,
});

export const deleteDeptHeadLoading = () => ({
  type: DELETE_DEPT_HEAD_LOADING,
});
export const deleteDeptHeadSuccess = (deleteDeptHead) => ({
  type: DELETE_DEPT_HEAD_SUCCESS,
  deleteDeptHead,
});
export const deleteDeptHeadError = (error) => ({
  type: DELETE_DEPT_HEAD_ERROR,
  error,
});

export const getAdminCompetenciesLoading = () => ({
  type: GET_ADMIN_COMPETENCY_LOADING,
});
export const getAdminCompetenciesSuccess = (getAdminCompetency) => ({
  type: GET_ADMIN_COMPETENCY_SUCCESS,
  getAdminCompetency,
});
export const getAdminCompetenciesError = (error) => ({
  type: GET_ADMIN_COMPETENCY_ERROR,
  error,
});

export const addAdminCompetenciesLoading = () => ({
  type: ADD_ADMIN_COMPETENCY_LOADING,
});
export const addAdminCompetenciesSuccess = (addAdminCompetency) => ({
  type: ADD_ADMIN_COMPETENCY_SUCCESS,
  addAdminCompetency,
});
export const addAdminCompetenciesError = (error) => ({
  type: ADD_ADMIN_COMPETENCY_ERROR,
  error,
});

export const editAdminCompetenciesLoading = () => ({
  type: UPDATE_ADMIN_COMPETENCY_LOADING,
});
export const editAdminCompetenciesSuccess = (editAdminCompetency) => ({
  type: UPDATE_ADMIN_COMPETENCY_SUCCESS,
  editAdminCompetency,
});
export const editAdminCompetenciesError = (error) => ({
  type: UPDATE_ADMIN_COMPETENCY_ERROR,
  error,
});

export const getManageVendorsLoading = () => ({
  type: GET_MANAGE_VENDORS_LOADING,
});
export const getManageVendorsSuccess = (vendors) => ({
  type: GET_MANAGE_VENDORS_SUCCESS,
  vendors,
});
export const getManageVendorsError = (error) => ({
  type: GET_MANAGE_VENDORS_ERROR,
  error,
});

export const getAdminManageVendorNumNamesLoading = () => ({
  type: GET_MANAGE_VENDORS_NUM_NAMES_LOADING,
});
export const getAdminManageVendorNumNamesSuccess = (vendorNames) => ({
  type: GET_MANAGE_VENDORS_NUM_NAMES_SUCCESS,
  vendorNames,
});
export const getAdminManageVendorNumNamesError = (error) => ({
  type: GET_MANAGE_VENDORS_NUM_NAMES_ERROR,
  error,
});

export const addManageVendorLoading = () => ({
  type: ADD_MANAGE_VENDOR_LOADING,
});
export const addManageVendorSuccess = (addVendor) => ({
  type: ADD_MANAGE_VENDOR_SUCCESS,
  addVendor,
});
export const addManageVendorError = (error) => ({
  type: ADD_MANAGE_VENDOR_ERROR,
  error,
});

export const editManageVendorLoading = () => ({
  type: EDIT_MANAGE_VENDOR_LOADING,
});
export const editManageVendorSuccess = (editVendor) => ({
  type: EDIT_MANAGE_VENDOR_SUCCESS,
  editVendor,
});
export const editManageVendorError = (error) => ({
  type: EDIT_MANAGE_VENDOR_ERROR,
  error,
});

export const deleteManageVendorLoading = () => ({
  type: DELETE_MANAGE_VENDOR_LOADING,
});
export const deleteManageVendorSuccess = (deleteVendor) => ({
  type: DELETE_MANAGE_VENDOR_SUCCESS,
  deleteVendor,
});
export const deleteManageVendorError = (error) => ({
  type: DELETE_MANAGE_VENDOR_ERROR,
  error,
});

export const addRoleLoading = () => ({
  type: ADD_ROLE_LOADING,
});
export const addRoleSuccess = (addRole) => ({
  type: ADD_ROLE_SUCCESS,
  addRole,
});
export const addRoleError = (error) => ({
  type: ADD_ROLE_ERROR,
  error,
});

export const editRoleLoading = () => ({
  type: EDIT_ROLE_LOADING,
});
export const editRoleSuccess = (editRole) => ({
  type: EDIT_ROLE_SUCCESS,
  editRole,
});
export const editRoleError = (error) => ({
  type: EDIT_ROLE_ERROR,
  error,
});

export const getRolesLoading = () => ({
  type: GET_ROLES_LOADING,
});
export const getRolesSuccess = (roles) => ({
  type: GET_ROLES_SUCCESS,
  roles,
});
export const getRolesError = (error) => ({
  type: GET_ROLES_ERROR,
  error,
});

export const deleteRoleLoading = () => ({
  type: DELETE_ROLE_LOADING,
});
export const deleteRoleSuccess = (deleteRole) => ({
  type: DELETE_ROLE_SUCCESS,
  deleteRole,
});
export const deleteRoleError = (error) => ({
  type: DELETE_ROLE_ERROR,
  error,
});

export const getJobTitlesLoading = () => ({
  type: GET_JOB_TITLES_LOADING,
});
export const getJobTitlesSuccess = (jobTitles) => ({
  type: GET_JOB_TITLES_SUCCESS,
  jobTitles,
});
export const getJobTitlesError = (error) => ({
  type: GET_JOB_TITLES_ERROR,
  error,
});

export const editJobTitleLoading = () => ({
  type: EDIT_JOB_TITLE_LOADING,
});
export const editJobTitleSuccess = (editJobTitle) => ({
  type: EDIT_JOB_TITLE_SUCCESS,
  editJobTitle,
});
export const editJobTitleError = (error) => ({
  type: EDIT_JOB_TITLE_ERROR,
  error,
});

export const getDeptManagersLoading = () => ({
  type: GET_DEPT_MANAGERS_LOADING,
});
export const getDeptManagersSuccess = (deptManagers) => ({
  type: GET_DEPT_MANAGERS_SUCCESS,
  deptManagers,
});
export const getDeptManagersError = (error) => ({
  type: GET_DEPT_HEADS_ERROR,
  error,
});

export const editDeptManagerLoading = () => ({
  type: EDIT_DEPT_MANAGER_LOADING,
});
export const editDeptManagerSuccess = (editDeptManager) => ({
  type: EDIT_DEPT_MANAGER_SUCCESS,
  editDeptManager,
});
export const editDeptManagerError = (error) => ({
  type: EDIT_DEPT_MANAGER_ERROR,
  error,
});

export const getOneRateLoading = () => ({
  type: GET_ONE_RATE_LOADING,
});
export const getOneRateSuccess = (oneRate) => ({
  type: GET_ONE_RATE_SUCCESS,
  oneRate,
});
export const getOneRateError = (error) => ({
  type: GET_ONE_RATE_ERROR,
  error,
});

export const addOneRateLoading = () => ({
  type: ADD_ONE_RATE_LOADING,
});
export const addOneRateSuccess = (addOneRate) => ({
  type: ADD_ONE_RATE_SUCCESS,
  addOneRate,
});
export const addOneRateError = (error) => ({
  type: ADD_ONE_RATE_ERROR,
  error,
});

export const editOneRateLoading = () => ({
  type: EDIT_ONE_RATE_LOADING,
});
export const editOneRateSuccess = (editOneRate) => ({
  type: EDIT_ONE_RATE_SUCCESS,
  editOneRate,
});
export const editOneRateError = (error) => ({
  type: EDIT_ONE_RATE_ERROR,
  error,
});

export const getAutomationStatusLoading = () => ({
  type: GET_AUTOMATION_STATUS_LOADING,
});
export const getAutomationStatusSuccess = (automationStatus) => ({
  type: GET_AUTOMATION_STATUS_SUCCESS,
  automationStatus,
});
export const getAutomationStatusError = (error) => ({
  type: GET_AUTOMATION_STATUS_ERROR,
  error,
});

export const toggleAutomationStatusLoading = () => ({
  type: TOGGLE_AUTOMATION_STATUS_LOADING,
});
export const toggleAutomationStatusSuccess = (toggleStatus) => ({
  type: TOGGLE_AUTOMATION_STATUS_SUCCESS,
  toggleStatus,
});
export const toggleAutomationStatusError = (error) => ({
  type: TOGGLE_AUTOMATION_STATUS_SUCCESS,
  error,
});

export const updateEmailNotificationStatusLoading = () => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING,
});
export const updateEmailNotificationStatusSuccess = (updateStatus) => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS,
  updateStatus,
});
export const updateEmailNotificationStatusError = (error) => ({
  type: UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR,
  error,
});


// THUNK CREATORS
export const getSkillExpThunk = () => async (dispatch) => {
  try {
    const { data } = await roverSkillcentralURL.get(getSkillExpirationURL());
    dispatch(getSkillExpSuccess(data));
  } catch (error) {
    console.error(error);
  }
};

export const updateSkillExpThunk = (noOfMonths, callback) => async (dispatch) => {
  try {
    dispatch(updateSkillExpLoading());
    const { data } = await roverSkillcentralURL.put(updateSkillExpirationURL(noOfMonths));
    if (callback) {
      callback(UPDATE_SKILL_EXP_SUCCESS, data);
    }
    dispatch(updateSkillExpSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_SKILL_EXP_ERROR, error);
    }
    dispatch(updateSkillExpError(error));
  }
};

export const saveAdminMethodologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveAdminMethodologyLoading());
    const { data } = await roverSkillcentralURL.post(saveAdminSkillURL(), payload);
    if (callback) {
      callback(SAVE_ADMIN_METHODOLOGY_SUCCESS, data);
    }
    dispatch(saveAdminMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_ADMIN_METHODOLOGY_ERROR, error);
    }
    dispatch(saveAdminMethodologyError(error));
  }
};

export const editAdminMethodologyThunk = (skillId,payload, callback) => async (dispatch) => {
  try {
    dispatch(editAdminMethodologyLoading());
    const { data } = await roverSkillcentralURL.put(editAdminSkillURL(skillId), payload);
    if (callback) {
      callback(EDIT_ADMIN_METHODOLOGY_SUCCESS, data);
    }
    dispatch(editAdminMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_ADMIN_METHODOLOGY_ERROR, error);
    }
    dispatch(editAdminMethodologyError(error));
  }
};

export const deleteAdminMethodologyThunk = (skillId,resourceId, callback) => async (dispatch) => {
  try {
    dispatch(deleteAdminMethodologyLoading());
    const { data } = await roverSkillcentralURL.put(deleteAdminSkillURL(skillId,resourceId));
    if (callback) {
      callback(DELETE_ADMIN_METHODOLOGY_SUCCESS, data);
    }
    dispatch(deleteAdminMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_ADMIN_METHODOLOGY_ERROR, error);
    }
    dispatch(deleteAdminMethodologyError(error));
  }
};

export const addAdminTechnologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addAdminTechnologyLoading());
    const { data } = await roverSkillcentralURL.post(saveAdminSkillURL(), payload);
    if (callback) {
      callback(ADD_ADMIN_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(addAdminTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_ADMIN_TECHNOLOGY_ERROR, error);
    }
    dispatch(addAdminTechnologyError(error));
  }
};

export const updateAdminTechnologyThunk = (skillId,payload, callback) => async (dispatch) => {
  try {
    dispatch(updateAdminTechnologyLoading());
    const { data } = await roverSkillcentralURL.put(editAdminSkillURL(skillId), payload);
    if (callback) {
      callback(UPDATE_ADMIN_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(updateAdminTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_ADMIN_TECHNOLOGY_ERROR, error);
    }
    dispatch(updateAdminTechnologyError(error));
  }
};

export const deleteAdminTechnologyThunk = (skillId,resourceId, callback) => async ( dispatch) => {
  try {
    dispatch(deleteAdminTechnologyLoading());
    const { data } = await roverSkillcentralURL.put(deleteAdminSkillURL(skillId,resourceId));
    if (callback) {
      callback(DELETE_ADMIN_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(deleteAdminTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_ADMIN_TECHNOLOGY_ERROR, error);
    }
    dispatch(deleteAdminTechnologyError(error));
  }
};

export const addAdminCategoryThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addAdminCategoryLoading());
    const { data } = await roverSkillcentralURL.post(addAdminCategory(), payload);
    if (callback) {
      callback(ADD_ADMIN_CATEGORY_SUCCESS);
    }
    dispatch(addAdminCategorySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_ADMIN_CATEGORY_ERROR, error);
    }
    dispatch(addAdminCategoryError(error));
  }
};

export const getAdminCategoryThunk = (callback) => async (dispatch) => {
  try {
    dispatch(getAdminCategoryLoading());
    const { data } = await roverSkillcentralURL.get(getAdminCategoryURL());
    if (callback) {
      callback(GET_ADMIN_CATEGORY_SUCCESS, data);
    }
    dispatch(getAdminCategorySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_ADMIN_CATEGORY_ERROR, error);
    }
    dispatch(getAdminCategoryError(error));
  }
};

export const getAttritionOptionsThunk = () => async (dispatch) => {
  try {
    dispatch(getAttritionOptionsLoading());
    const { data } = await roverSkillcentralURL.get(getAttritionOptionsURL());
    // console.log(data)
    dispatch(getAttritionOptionsSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getAttritionOptionsError(error));
  }
};

export const getResourceTypeThunk = () => async (dispatch) => {
  try {
    dispatch(getResourceTypeLoading());
    const { data } = await roverSkillcentralURL.get(getResourceTypeURL());
    dispatch(getResourceTypeSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getResourceTypeError(error));
  }
};

export const getAttritionTypeThunk = (resourceTypeId) => async (dispatch) => {
  try {
    dispatch(getAttritionTypeLoading());
    const { data } = await roverSkillcentralURL.get(getAttritionTypeURL(resourceTypeId));
    console.log(data)
    dispatch(getAttritionTypeSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getAttritionTypeError(error));
  }
};

export const addAttritionOptionThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addAttritionOptionLoading());
    const { data } = await roverSkillcentralURL.post(addAttritionOptionURL(), payload);
    if (callback) {
      callback(ADD_ATTRITION_OPTION_SUCCESS, data);
    }
    dispatch(addAttritionOptionSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_ATTRITION_OPTION_ERROR, error.response);
    }
    dispatch(addAttritionOptionError(error.response));
  }
};

export const editAttritionOptionThunk = (attritionId, payload, callback) => async (dispatch) => {
  try {
    dispatch(editAttritionOptionLoading());
    const { data } = await roverSkillcentralURL.put(editAttritionOptionURL(attritionId), payload);
    if (callback) {
      callback(EDIT_ATTRITION_OPTION_SUCCESS, data);
    }
    dispatch(editAttritionOptionSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_ATTRITION_OPTION_ERROR, error.response);
    }
    dispatch(editAttritionOptionError(error.response));
  }
};

export const deleteAttritionOptionThunk = (attritionId, callback) => async ( dispatch) => {
  try {
    dispatch(deleteAttritionOptionLoading());
    const { data } = await roverSkillcentralURL.put(deleteAttritionOptionURL(attritionId));
    if (callback) {
      callback(DELETE_ATTRITION_OPTION_SUCCESS, data);
    }
    dispatch(deleteAttritionOptionSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_ATTRITION_OPTION_ERROR, error);
    }
    dispatch(deleteAttritionOptionError(error));
  }
};

export const getDeptHeadsThunk = () => async (dispatch) => {
  try {
    dispatch(getDeptHeadsLoading())
    const { data } = await roverSkillcentralURL.get(getDeptHeadsURL());
    dispatch(getDeptHeadsSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getDeptHeadsError(error.response));
  }
};

export const getHeadNamesThunk = () => async (dispatch) => {
  try {
    dispatch(getHeadNamesLoading())
    const { data } = await roverSkillcentralURL.get(getHeadNamesURL());
    dispatch(getHeadNamesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getHeadNamesError(error.response));
  }
};

export const addDeptHeadThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addDeptHeadLoading());
    const { data } = await roverSkillcentralURL.post(addDepartmentHeadURL(), payload);
    if (callback) {
      callback(ADD_DEPT_HEAD_SUCCESS, data);
    }
    dispatch(addDeptHeadSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_DEPT_HEAD_ERROR, error.response);
    }
    dispatch(addDeptHeadError(error.response));
  }
};

export const editDeptHeadThunk = (deptId, payload, callback) => async (dispatch) => {
  try {
    dispatch(editDeptHeadLoading());
    const { data } = await roverSkillcentralURL.put(editDepartmentHeadURL(deptId), payload);
    if (callback) {
      callback(EDIT_DEPT_HEAD_SUCCESS, data);
    }
    dispatch(editDeptHeadSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_DEPT_HEAD_ERROR, error.response);
    }
    dispatch(editDeptHeadError(error.response));
  }
};

export const deleteDeptHeadThunk = (deptId, callback) => async ( dispatch) => {
  try {
    dispatch(deleteDeptHeadLoading());
    const { data } = await roverSkillcentralURL.put(deleteDepartmentHeadURL(deptId));
    if (callback) {
      callback(DELETE_DEPT_HEAD_SUCCESS, data);
    }
    dispatch(deleteDeptHeadSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_DEPT_HEAD_ERROR, error);
    }
    dispatch(deleteDeptHeadError(error));
  }
};

export const getAdminCompetenciesThunk = (callback) => async ( dispatch) => {
  try {
    dispatch(getAdminCompetenciesLoading());
    const { data } = await roverSkillcentralURL.get(getAdminSKillURL(SKILL_TYPE.COMP));
    if (callback) {
      callback(GET_ADMIN_COMPETENCY_SUCCESS, data);
    }
    dispatch(getAdminCompetenciesSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_ADMIN_COMPETENCY_ERROR, error);
    }
    dispatch(getAdminCompetenciesError(error));
  }
};

export const addAdminCompetenciesThunk = (payload,callback) => async ( dispatch) => {
  try {
    dispatch(addAdminCompetenciesLoading());
    const { data } = await roverSkillcentralURL.post(saveAdminSkillURL(),payload);
    if (callback) {
      callback(ADD_ADMIN_COMPETENCY_SUCCESS, data);
    }
    dispatch(addAdminCompetenciesSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_ADMIN_COMPETENCY_ERROR, error);
    }
    dispatch(addAdminCompetenciesError(error));
  }
};

export const editAdminCompetenciesThunk = (skillId,payload, callback) => async (dispatch) => {
  try {
    dispatch(editAdminCompetenciesLoading());
    const { data } = await roverSkillcentralURL.put(editAdminSkillURL(skillId), payload);
     if (callback) {
      callback(UPDATE_ADMIN_COMPETENCY_SUCCESS, data);
    }
    dispatch(editAdminCompetenciesSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_ADMIN_COMPETENCY_ERROR, error.response);
    }
    dispatch(editAdminCompetenciesError(error));
  }
};

export const getManageVendorsThunk = () => async (dispatch) => {
  try {
    dispatch(getManageVendorsLoading())
    const { data } = await roverSkillcentralURL.get(getAdminManageVendorsURL());
    dispatch(getManageVendorsSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getManageVendorsError(error.response));
  }
};

export const getAdminManageVendorNumNamesThunk = (vendorNumber) => async (dispatch) => {
  try {
    dispatch(getAdminManageVendorNumNamesLoading())
    const { data } = await roverSkillcentralURL.get(getAdminManageVendorNumNamesURL(vendorNumber));
    dispatch(getAdminManageVendorNumNamesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getAdminManageVendorNumNamesError(error.response));
  }
};

export const addManageVendorThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addManageVendorLoading());
    const { data } = await roverSkillcentralURL.post(addAdminManageVendorURL(), payload);
    if (callback) {
      callback(ADD_MANAGE_VENDOR_SUCCESS, data);
    }
    dispatch(addManageVendorSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_MANAGE_VENDOR_ERROR, error.response);
    }
    dispatch(addManageVendorError(error.response));
  }
};

export const editManageVendorThunk = (vendorId, payload, callback) => async (dispatch) => {
  try {
    dispatch(editManageVendorLoading());
    const { data } = await roverSkillcentralURL.put(editAdminManageVendorURL(vendorId), payload);
    if (callback) {
      callback(EDIT_MANAGE_VENDOR_SUCCESS, data);
    }
    dispatch(editManageVendorSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_MANAGE_VENDOR_ERROR, error.response);
    }
    dispatch(editManageVendorError(error.response));
  }
};

export const deleteManageVendorThunk = (vendorId, callback) => async ( dispatch) => {
  try {
    dispatch(deleteManageVendorLoading());
    const { data } = await roverSkillcentralURL.put(deleteAdminManageVendorURL(vendorId));
    if (callback) {
      callback(DELETE_MANAGE_VENDOR_SUCCESS, data);
    }
    dispatch(deleteManageVendorSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_MANAGE_VENDOR_ERROR, error);
    }
    dispatch(deleteManageVendorError(error));
  }
};

export const addRoleThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addRoleLoading());
    const { data } = await roverSkillcentralURL.post(addAdminRoleURL(), payload);
    if (callback) {
      callback(ADD_ROLE_SUCCESS, data);
    }
    dispatch(addRoleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_ROLE_ERROR, error.response);
    }
    dispatch(addRoleError(error.response));
  }
};

export const editRoleThunk = (roleId, payload, callback) => async (dispatch) => {
  try {
    dispatch(editRoleLoading());
    const { data } = await roverSkillcentralURL.put(editAdminRoleURL(roleId), payload);
    if (callback) {
      callback(EDIT_ROLE_SUCCESS, data);
    }
    dispatch(editRoleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_ROLE_ERROR, error.response);
    }
    dispatch(editRoleError(error.response));
  }
};

export const getRolesThunk = () => async (dispatch) => {
  try {
    dispatch(getRolesLoading())
    const { data } = await roverSkillcentralURL.get(getRolesURL());
    dispatch(getRolesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getRolesError(error.response));
  }
};

export const deleteRoleThunk = (roleId, callback) => async ( dispatch) => {
  try {
    dispatch(deleteRoleLoading());
    const { data } = await roverSkillcentralURL.put(deleteAdminRoleURL(roleId));
    if (callback) {
      callback(DELETE_ROLE_SUCCESS, data);
    }
    dispatch(deleteRoleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_ROLE_ERROR, error.response);
    }
    dispatch(deleteRoleError(error));
  }
};

export const getJobTitlesThunk = () => async (dispatch) => {
  try {
    dispatch(getJobTitlesLoading())
    const { data } = await roverSkillcentralURL.get(getJobTitlesURL());
    dispatch(getJobTitlesSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getJobTitlesError(error.response));
  }
};

export const editJobTitleThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editJobTitleLoading());
    const { data } = await roverSkillcentralURL.put(editJobTitlesURL(), payload);
    if (callback) {
      callback(EDIT_JOB_TITLE_SUCCESS, data);
    }
    dispatch(editJobTitleSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_JOB_TITLE_ERROR, error.response);
    }
    dispatch(editJobTitleError(error.response));
  }
};

export const getDeptManagersThunk = (deptId) => async (dispatch) => {
  try {
    dispatch(getDeptManagersLoading())
    const { data } = await roverSkillcentralURL.get(getDeptManagersURL(deptId));
    dispatch(getDeptManagersSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getDeptManagersError(error.response));
  }
};

export const editDepartmentManagerThunk = (deptRmId, isActive, callback) => async (dispatch) => {
  try {
    dispatch(editDeptManagerLoading());
    const { data } = await roverSkillcentralURL.put(editDepartmentManagerURL(deptRmId, isActive));
    if (callback) {
      callback(EDIT_DEPT_MANAGER_SUCCESS, data);
    }
    dispatch(editDeptManagerSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_DEPT_MANAGER_ERROR, error.response);
    }
    dispatch(editDeptManagerError(error.response));
  }
};

export const getOneRateThunk = () => async (dispatch) => {
  try {
    dispatch(getOneRateLoading());
    const { data } = await roverSkillcentralURL.get(getAdminOneRateURL());
    dispatch(getOneRateSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getOneRateError(error));
  }
};

export const addOneRateThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(addOneRateLoading());
    const { data } = await roverSkillcentralURL.post(addAdminOneRateURL(), payload);
    if (callback) {
      callback(ADD_ONE_RATE_SUCCESS, data);
    }
    dispatch(addOneRateSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(ADD_ONE_RATE_ERROR, error.response);
    }
    dispatch(addOneRateError(error.response));
  }
};

export const editOneRateThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editOneRateLoading());
    const { data } = await roverSkillcentralURL.put(editAdminOneRateURL(), payload);
    if (callback) {
      callback(EDIT_ONE_RATE_SUCCESS, data);
    }
    dispatch(editOneRateSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_ONE_RATE_ERROR, error.response);
    }
    dispatch(editOneRateError(error.response));
  }
};

export const getAutomationStatusThunk = () => async (dispatch) => {
  try {
    dispatch(getAutomationStatusLoading());
    const { data } = await roverSkillcentralURL.get(getAutomationStatusURL());
    dispatch(getAutomationStatusSuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getAutomationStatusError(error));
  }
};

export const toggleAutomationStatusThunk = (profileStatus, sendMailStatus, changeType, callback) => async (dispatch) => {
  try {
    dispatch(toggleAutomationStatusLoading());
    const { data } = await roverSkillcentralURL.put(toggleAutomationStatusURL(profileStatus, sendMailStatus));
    if (callback) {
      callback(TOGGLE_AUTOMATION_STATUS_SUCCESS, changeType, data, sendMailStatus);
    }
    dispatch(toggleAutomationStatusSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(TOGGLE_AUTOMATION_STATUS_ERROR, changeType, error.response, sendMailStatus);
    }
    dispatch(toggleAutomationStatusError(error.response));
  }
};

export const updateEmailNotificationStatusThunk = (status, callback) => async (dispatch) => {
  try {
    dispatch(updateEmailNotificationStatusLoading());
    const { data } = await roverSkillcentralURL.put(updateSCEmailNotificationStatusURL(status));
    if (callback) {
      callback(UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS, status);
    }
    dispatch(updateEmailNotificationStatusSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR, error);
    }
    dispatch(updateEmailNotificationStatusError(error));
  }
};

// INITIAL STATE
const initialState = {
  skillExpiration: { data: 0, status: DATA_STATUS.INITIAL, response: {} },
  updateSkillExpirationStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  saveAdminMethodologyStatus: { status: DATA_STATUS.INITIAL, response: {} },
  editAdminMethodologyStatus: { status: DATA_STATUS.INITIAL, response: {} },
  deleteAdminMethodologyStatus: { status: DATA_STATUS.INITIAL, response: {} },
  addAdminTechnologyStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  updateAdminTechnologyStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  deleteAdminTechnologyStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  addAdminCategoryStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  adminCategories: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  attritionOptions: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  resourceType: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  attritionType: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  addAttritionOptionStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editAttritionOptionStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deleteAttritionOptionStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  deptHeads: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  headNames: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  addDeptHeadStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editDeptHeadStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deleteDeptHeadStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  adminCompetencies: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  addAdminCompetenciesStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editAdminCompetenciesStatus: { status: DATA_STATUS.INITIAL, response: {} },
  vendors: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  vendorNumNames: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  addVendorStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editVendorStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deleteVendorStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  addRoleStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editRoleStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deleteRoleStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  roles: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  jobTitles: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  editJobTitleStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  deptManagers: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  editDeptManagerStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  oneRate: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  addOneRateStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  editOneRateStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  automationStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  toggleAutomationStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  updateEmailNotificationStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
const SkillsCentralAdmin = (state = initialState, action) => {
  switch (action.type) {
    case GET_SKILL_EXP_SUCCESS:
      return {
        ...state,
        skillExpiration: {
          ...state.addAdminTechnologyStatus,
          data: action.skillExp,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_SKILL_EXP_LOADING:
      return {
        ...state,
        updateSkillExpirationStatus: {
          ...state.updateSkillExpirationStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_SKILL_EXP_SUCCESS:
      return {
        ...state,
        updateSkillExpirationStatus: {
          ...state.updateSkillExpirationStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_SKILL_EXP_ERROR:
      return {
        ...state,
        updateSkillExpirationStatus: {
          ...state.updateSkillExpirationStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case SAVE_ADMIN_METHODOLOGY_LOADING:
      return {
        ...state,
        saveAdminMethodologyStatus: {
          ...state.saveAdminMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_ADMIN_METHODOLOGY_SUCCESS:
      return {
        ...state,
        saveAdminMethodologyStatus: {
          ...state.saveAdminMethodologyStatus,
          response: action.saveAdminMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_ADMIN_METHODOLOGY_ERROR:
      return {
        ...state,
        saveAdminMethodologyStatus: {
          ...state.saveAdminMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_ADMIN_METHODOLOGY_LOADING:
      return {
        ...state,
        editAdminMethodologyStatus: {
          ...state.editAdminMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_ADMIN_METHODOLOGY_SUCCESS:
      return {
        ...state,
        editAdminMethodologyStatus: {
          ...state.editAdminMethodologyStatus,
          response: action.editAdminMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_ADMIN_METHODOLOGY_ERROR:
      return {
        ...state,
        editAdminMethodologyStatus: {
          ...state.editAdminMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_ADMIN_METHODOLOGY_LOADING:
      return {
        ...state,
        deleteAdminMethodologyStatus: {
          ...state.deleteAdminMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_ADMIN_METHODOLOGY_SUCCESS:
      return {
        ...state,
        deleteAdminMethodologyStatus: {
          ...state.deleteAdminMethodologyStatus,
          response: action.deleteMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_ADMIN_METHODOLOGY_ERROR:
      return {
        ...state,
        deleteAdminMethodologyStatus: {
          ...state.deleteAdminMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_ADMIN_TECHNOLOGY_LOADING:
      return {
        ...state,
        addAdminTechnologyStatus: {
          ...state.addAdminTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_ADMIN_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        addAdminTechnologyStatus: {
          ...state.addAdminTechnologyStatus,
          response: action.saveCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_ADMIN_TECHNOLOGY_ERROR:
      return {
        ...state,
        addAdminTechnologyStatus: {
          ...state.addAdminTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case UPDATE_ADMIN_TECHNOLOGY_LOADING:
      return {
        ...state,
        updateAdminTechnologyStatus: {
          ...state.updateAdminTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_ADMIN_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        updateAdminTechnologyStatus: {
          ...state.updateAdminTechnologyStatus,
          response: action.saveCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_ADMIN_TECHNOLOGY_ERROR:
      return {
        ...state,
        updateAdminTechnologyStatus: {
          ...state.updateAdminTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_ADMIN_TECHNOLOGY_LOADING:
      return {
        ...state,
        deleteAdminTechnologyStatus: {
          ...state.deleteAdminTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_ADMIN_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        deleteAdminTechnologyStatus: {
          ...state.deleteAdminTechnologyStatus,
          response: action.deleteAdminTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_ADMIN_TECHNOLOGY_ERROR:
      return {
        ...state,
        deleteAdminTechnologyStatus: {
          ...state.deleteAdminTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_ADMIN_CATEGORY_LOADING:
      return {
        ...state,
        addAdminCategoryStatus: {
          ...state.addAdminCategoryStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_ADMIN_CATEGORY_SUCCESS:
      return {
        ...state,
        addAdminCategoryStatus: {
          ...state.addAdminCategoryStatus,
          response: action.saveCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_ADMIN_CATEGORY_ERROR:
      return {
        ...state,
        addAdminCategoryStatus: {
          ...state.addAdminCategoryStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_ADMIN_CATEGORY_LOADING:
      return {
        ...state,
        adminCategories: {
          ...state.adminCategories,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ADMIN_CATEGORY_SUCCESS:
      return {
        ...state,
        adminCategories: {
          ...state.adminCategories,
          data: action.categories,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ADMIN_CATEGORY_ERROR:
      return {
        ...state,
        adminCategories: {
          ...state.adminCategories,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_ATTRITION_OPTIONS_LOADING:
      return {
        ...state,
        attritionOptions: {
          ...state.attritionOptions,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ATTRITION_OPTIONS_SUCCESS:
      return {
        ...state,
        attritionOptions: {
          ...state.attritionOptions,
          data: action.attritionOptions,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ATTRITION_OPTIONS_ERROR:
      return {
        ...state,
        attritionOptions: {
          ...state.attritionOptions,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_RESOURCE_TYPE_LOADING:
      return {
        ...state,
        resourceType: {
          ...state.resourceType,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_RESOURCE_TYPE_SUCCESS:
      return {
        ...state,
        resourceType: {
          ...state.resourceType,
          data: typeof action.resType === "string" ? [] : [...action.resType],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_RESOURCE_TYPE_ERROR:
      return {
        ...state,
        resourceType: {
          ...state.resourceType,
          response: action.error,
          data: [],
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_ATTRITION_TYPE_LOADING:
      return {
        ...state,
        attritionType: {
          ...state.attritionType,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ATTRITION_TYPE_SUCCESS:
      return {
        ...state,
        attritionType: {
          ...state.attritionType,
          data: typeof action.attrType === "string" ? [] : [...action.attrType],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ATTRITION_TYPE_ERROR:
      return {
        ...state,
        attritionType: {
          ...state.attritionType,
          response: action.error,
          data: [],
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_ATTRITION_OPTION_LOADING:
      return {
        ...state,
        addAttritionOptionStatus: {
          ...state.addAttritionOptionStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_ATTRITION_OPTION_SUCCESS:
      return {
        ...state,
        addAttritionOptionStatus: {
          data: action.addAttritionOption,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_ATTRITION_OPTION_ERROR:
      return {
        ...state,
        addAttritionOptionStatus: {
          ...state.addAttritionOptionStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case EDIT_ATTRITION_OPTION_LOADING:
      return {
        ...state,
        editAttritionOptionStatus: {
          ...state.editAttritionOptionStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_ATTRITION_OPTION_SUCCESS:
      return {
        ...state,
        editAttritionOptionStatus: {
          data: action.editAttritionOption,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_ATTRITION_OPTION_ERROR:
      return {
        ...state,
        editAttritionOptionStatus: {
          ...state.editAttritionOptionStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case DELETE_ATTRITION_OPTION_LOADING:
      return {
        ...state,
        deleteAttritionOptionStatus: {
          ...state.deleteAttritionOptionStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_ATTRITION_OPTION_SUCCESS:
      return {
        ...state,
        deleteAttritionOptionStatus: {
          ...state.deleteAttritionOptionStatus,
          response: action.deleteAttrition,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_ATTRITION_OPTION_ERROR:
      return {
        ...state,
        deleteAttritionOptionStatus: {
          ...state.deleteAttritionOptionStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_DEPT_HEADS_LOADING:
      return {
        ...state,
        deptHeads: {
          ...state.deptHeads,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DEPT_HEADS_SUCCESS:
      return {
        ...state,
        deptHeads: {
          ...state.deptHeads,
          data: action.deptHeads,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DEPT_HEADS_ERROR:
      return {
        ...state,
        deptHeads: {
          ...state.deptHeads,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_HEAD_NAMES_LOADING:
      return {
        ...state,
        headNames: {
          ...state.headNames,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_HEAD_NAMES_SUCCESS:
      return {
        ...state,
        headNames: {
          ...state.headNames,
          data: action.headNames,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_HEAD_NAMES_ERROR:
      return {
        ...state,
        headNames: {
          ...state.headNames,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_DEPT_HEAD_LOADING:
      return {
        ...state,
        addDeptHeadStatus: {
          ...state.addDeptHeadStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_DEPT_HEAD_SUCCESS:
      return {
        ...state,
        addDeptHeadStatus: {
          data: action.addDeptHead,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_DEPT_HEAD_ERROR:
      return {
        ...state,
        addDeptHeadStatus: {
          ...state.addDeptHeadStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case EDIT_DEPT_HEAD_LOADING:
      return {
        ...state,
        editDeptHeadStatus: {
          ...state.editDeptHeadStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_DEPT_HEAD_SUCCESS:
      return {
        ...state,
        editDeptHeadStatus: {
          data: action.editDeptHeadStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_DEPT_HEAD_ERROR:
      return {
        ...state,
        editDeptHeadStatus: {
          ...state.editDeptHeadStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case DELETE_DEPT_HEAD_LOADING:
      return {
        ...state,
        deleteDeptHeadStatus: {
          ...state.deleteDeptHeadStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_DEPT_HEAD_SUCCESS:
      return {
        ...state,
        deleteDeptHeadStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
        deleteDeptHeadStatus: {
          ...state.deleteDeptHeadStatus,
          response: action.deleteDeptHead,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_DEPT_HEAD_ERROR:
      return {
        ...state,
        deleteDeptHeadStatus: {
          ...state.deleteDeptHeadStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case GET_ADMIN_COMPETENCY_LOADING:
      return {
        ...state,
        adminCompetencies: {
          ...state.adminCompetencies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ADMIN_COMPETENCY_SUCCESS:
      return {
        ...state,
        adminCompetencies: {
          ...state.adminCompetencies,
          data: action.getAdminCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ADMIN_COMPETENCY_ERROR:
      return {
        ...state,
        adminCompetencies: {
          ...state.adminCompetencies,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_ADMIN_COMPETENCY_LOADING:
      return {
        ...state,
        addAdminCompetenciesStatus: {
          ...state.addAdminCompetenciesStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_ADMIN_COMPETENCY_SUCCESS:
      return {
        ...state,
        addAdminCompetenciesStatus: {
          data: action.addAdminCompetency,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_ADMIN_COMPETENCY_ERROR:
      return {
        ...state,
        addAdminCompetenciesStatus: {
          ...state.addAdminCompetenciesStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
      case UPDATE_ADMIN_COMPETENCY_LOADING:
        return {
          ...state,
          editAdminCompetenciesStatus: {
            ...state.editAdminCompetenciesStatus,
            status: DATA_STATUS.LOADING,
          },
        };
      case UPDATE_ADMIN_COMPETENCY_SUCCESS:
        return {
          ...state,
          editAdminCompetenciesStatus: {
            ...state.editAdminCompetenciesStatus,
            response: action.editCompetency,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case UPDATE_ADMIN_COMPETENCY_ERROR:
        return {
          ...state,
          editAdminCompetenciesStatus: {
            ...state.editAdminCompetenciesStatus,
            response: action.error,
            status: DATA_STATUS.ERROR,
          },
        };      
    case GET_MANAGE_VENDORS_LOADING:
      return {
        ...state,
        vendors: {
          ...state.vendors,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_MANAGE_VENDORS_SUCCESS:
      return {
        ...state,
        vendors: {
          ...state.vendors,
          data: action.vendors,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_MANAGE_VENDORS_ERROR:
      return {
        ...state,
        vendors: {
          ...state.vendors,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
      case GET_MANAGE_VENDORS_NUM_NAMES_LOADING:
        return {
          ...state,
          vendorNumNames: {
            ...state.vendorNumNames,
            status: DATA_STATUS.LOADING,
          },
        };
      case GET_MANAGE_VENDORS_NUM_NAMES_SUCCESS:
        return {
          ...state,
          vendorNumNames: {
            ...state.vendorNumNames,
            data: action.vendorNames,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_MANAGE_VENDORS_NUM_NAMES_ERROR:
        return {
          ...state,
          vendorNumNames: {
            ...state.vendorNumNames,
            data: [],
            response: action.error,
            status: DATA_STATUS.ERROR,
          },
        };
    case ADD_MANAGE_VENDOR_LOADING:
      return {
        ...state,
        addVendorStatus: {
          ...state.addVendorStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_MANAGE_VENDOR_SUCCESS:
      return {
        ...state,
        addVendorStatus: {
          data: action.addVendorStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_MANAGE_VENDOR_ERROR:
      return {
        ...state,
        addVendorStatus: {
          ...state.addVendorStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case EDIT_MANAGE_VENDOR_LOADING:
      return {
        ...state,
        editVendorStatus: {
          ...state.editVendorStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_MANAGE_VENDOR_SUCCESS:
      return {
        ...state,
        editVendorStatus: {
          data: action.editVendorStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_MANAGE_VENDOR_ERROR:
      return {
        ...state,
        editVendorStatus: {
          ...state.editVendorStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case DELETE_MANAGE_VENDOR_LOADING:
      return {
        ...state,
        deleteVendorStatus: {
          ...state.deleteVendorStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_MANAGE_VENDOR_SUCCESS:
      return {
        ...state,
        deleteVendorStatus: { data: [], status: DATA_STATUS.INITIAL, response: {} },
        deleteVendorStatus: {
          ...state.deleteVendorStatus,
          response: action.deleteVendor,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_MANAGE_VENDOR_ERROR:
      return {
        ...state,
        deleteVendorStatus: {
          ...state.deleteVendorStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_ROLE_LOADING:
      return {
        ...state,
        addRoleStatus: {
          ...state.addRoleStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_ROLE_SUCCESS:
      return {
        ...state,
        addRoleStatus: {
          data: action.addRole,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_ROLE_ERROR:
      return {
        ...state,
        addRoleStatus: {
          ...state.addRoleStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case EDIT_ROLE_LOADING:
      return {
        ...state,
        editRoleStatus: {
          ...state.editRoleStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_ROLE_SUCCESS:
      return {
        ...state,
        editRoleStatus: {
          data: action.editRole,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_ROLE_ERROR:
      return {
        ...state,
        editRoleStatus: {
          ...state.editRoleStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_ROLES_LOADING:
      return {
        ...state,
        roles: {
          ...state.roles,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ROLES_SUCCESS:
      return {
        ...state,
        roles: {
          ...state.roles,
          data: action.roles,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ROLES_ERROR:
      return {
        ...state,
        roles: {
          ...state.roles,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
      case DELETE_ROLE_LOADING:
        return {
          ...state,
          deleteRoleStatus: {
            ...state.deleteRoleStatus,
            status: DATA_STATUS.LOADING,
          },
        };
      case DELETE_ROLE_SUCCESS:
        return {
          ...state,
          deleteRoleStatus: {
            ...state.deleteRoleStatus,
            response: action.deleteRole,
            status: DATA_STATUS.SUCCESS,
          },
        };
      case DELETE_ROLE_ERROR:
        return {
          ...state,
          deleteRoleStatus: {
            ...state.deleteRoleStatus,
            response: action.error,
            status: DATA_STATUS.ERROR,
          },
        };  
    case GET_JOB_TITLES_LOADING:
      return {
        ...state,
        jobTitles: {
          ...state.jobTitles,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_JOB_TITLES_SUCCESS:
      return {
        ...state,
        jobTitles: {
          ...state.jobTitles,
          data: action.jobTitles,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_JOB_TITLES_ERROR:
      return {
        ...state,
        jobTitles: {
          ...state.jobTitles,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_JOB_TITLE_LOADING:
      return {
        ...state,
        editJobTitleStatus: {
          ...state.editJobTitleStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_JOB_TITLE_SUCCESS:
      return {
        ...state,
        editJobTitleStatus: {
          data: action.editJobTitleStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_MANAGE_VENDOR_ERROR:
      return {
        ...state,
        editJobTitleStatus: {
          ...state.editJobTitleStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_DEPT_MANAGERS_LOADING:
      return {
        ...state,
        deptManagers: {
          ...state.deptManagers,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DEPT_MANAGERS_SUCCESS:
      return {
        ...state,
        deptManagers: {
          ...state.deptManagers,
          data: action.deptManagers,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DEPT_MANAGERS_ERROR:
      return {
        ...state,
        deptManagers: {
          ...state.deptManagers,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_DEPT_MANAGER_LOADING:
      return {
        ...state,
        editDeptManagerStatus: {
          ...state.editDeptManagerStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_DEPT_MANAGER_SUCCESS:
      return {
        ...state,
        editDeptManagerStatus: {
          data: action.editDeptManagerStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_DEPT_MANAGER_ERROR:
      return {
        ...state,
        editDeptManagerStatus: {
          ...state.editDeptManagerStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_ONE_RATE_LOADING:
      return {
        ...state,
        oneRate: {
          ...state.oneRate,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_ONE_RATE_SUCCESS:
      return {
        ...state,
        oneRate: {
          ...state.oneRate,
          data: action.oneRate,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_ONE_RATE_ERROR:
      return {
        ...state,
        oneRate: {
          ...state.oneRate,
          response: action.error,
          data: [],
          status: DATA_STATUS.ERROR,
        },
      };
    case ADD_ONE_RATE_LOADING:
      return {
        ...state,
        addOneRateStatus: {
          ...state.addOneRateStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case ADD_ONE_RATE_SUCCESS:
      return {
        ...state,
        addOneRateStatus: {
          data: action.addOneRate,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case ADD_ONE_RATE_ERROR:
      return {
        ...state,
        addOneRateStatus: {
          ...state.addOneRateStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
      case EDIT_ONE_RATE_LOADING:
      return {
        ...state,
        editOneRateStatus: {
          ...state.editOneRateStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_ONE_RATE_SUCCESS:
      return {
        ...state,
        editOneRateStatus: {
          data: action.editOneRate,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_ONE_RATE_ERROR:
      return {
        ...state,
        editOneRateStatus: {
          ...state.editOneRateStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_AUTOMATION_STATUS_LOADING:
      return {
        ...state,
        automationStatus: {
          ...state.automationStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_AUTOMATION_STATUS_SUCCESS:
      return {
        ...state,
        automationStatus: {
          ...state.automationStatus,
          data: typeof action.automationStatus === "string" ? [] : [...action.automationStatus],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_AUTOMATION_STATUS_ERROR:
      return {
        ...state,
        automationStatus: {
          ...state.automationStatus,
          response: action.error,
          data: [],
          status: DATA_STATUS.ERROR,
        },
      };
    case TOGGLE_AUTOMATION_STATUS_LOADING:
      return {
        ...state,
        toggleAutomationStatus: {
          ...state.toggleAutomationStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case TOGGLE_AUTOMATION_STATUS_SUCCESS:
      return {
        ...state,
        toggleAutomationStatus: {
          data: action.toggleAutomationStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case TOGGLE_AUTOMATION_STATUS_ERROR:
      return {
        ...state,
        toggleAutomationStatus: {
          ...state.toggleAutomationStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_LOADING:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_SUCCESS:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_EMAIL_NOTIFICATION_STATUS_ERROR:
      return {
        ...state,
        updateEmailNotificationStatus: {
          ...state.updateEmailNotificationStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default SkillsCentralAdmin;
