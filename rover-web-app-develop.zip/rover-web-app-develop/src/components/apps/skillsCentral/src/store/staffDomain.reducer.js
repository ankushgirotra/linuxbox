import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  getSkillSubmissionURL,
  addSkillSubmissionURL,
  updateDeleteSkillSubmissionURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE_ID } from "../Constants/action.constants";

// ACTION TYPES
export const GET_STAFF_DOMAINS_BY_RESOURCE_ID = "GET_STAFF_DOMAINS_BY_RESOURCE_ID";
export const GET_STAFF_DOMAINS_BY_RESOURCE_ID_LOADING =
  "GET_STAFF_DOMAINS_BY_RESOURCE_ID_LOADING";
export const GET_STAFF_DOMAINS_BY_RESOURCE_ID_ERROR =
  "GET_STAFF_DOMAINS_BY_RESOURCE_ID_ERROR";

export const SAVE_STAFF_DOMAIN_RESET = "SAVE_STAFF_DOMAIN_RESET";
export const SAVE_STAFF_DOMAIN_LOADING = "SAVE_STAFF_DOMAIN_LOADING";
export const SAVE_STAFF_DOMAIN_SUCCESS = "SAVE_STAFF_DOMAIN_SUCCESS";
export const SAVE_STAFF_DOMAIN_ERROR = "SAVE_STAFF_DOMAIN_ERROR";

export const EDIT_STAFF_DOMAIN_RESET = "EDIT_STAFF_DOMAIN_RESET";
export const EDIT_STAFF_DOMAIN_LOADING = "EDIT_STAFF_DOMAIN_LOADING";
export const EDIT_STAFF_DOMAIN_SUCCESS = "EDIT_STAFF_DOMAIN_SUCCESS";
export const EDIT_STAFF_DOMAIN_ERROR = "EDIT_STAFF_DOMAIN_ERROR";

export const DELETE_STAFF_DOMAIN_RESET = "DELETE_STAFF_DOMAIN_RESET";
export const DELETE_STAFF_DOMAIN_LOADING = "DELETE_STAFF_DOMAIN_LOADING";
export const DELETE_STAFF_DOMAIN_SUCCESS = "DELETE_STAFF_DOMAIN_SUCCESS";
export const DELETE_STAFF_DOMAIN_ERROR = "DELETE_STAFF_DOMAIN_ERROR";

// ACTION CREATORS
export const getStaffDomainsByResourceId = (staffDomains) => ({
  type: GET_STAFF_DOMAINS_BY_RESOURCE_ID,
  staffDomains,
});
export const getStaffDomainsByResourceIdLoading = () => ({
  type: GET_STAFF_DOMAINS_BY_RESOURCE_ID_LOADING,
});
export const getStaffDomainsByResourceIdError = (error) => ({
  type: GET_STAFF_DOMAINS_BY_RESOURCE_ID_ERROR,
  error,
});


export const saveStaffDomainReset = () => ({
  type: SAVE_STAFF_DOMAIN_RESET,
});
export const saveStaffDomainLoading = () => ({
  type: SAVE_STAFF_DOMAIN_LOADING,
});
export const saveStaffDomainSuccess = (saveStaffDomain) => ({
  type: SAVE_STAFF_DOMAIN_SUCCESS,
  saveStaffDomain,
});
export const saveStaffDomainError = (error) => ({
  type: SAVE_STAFF_DOMAIN_ERROR,
  error,
});

export const editStaffDomainReset = () => ({
  type: EDIT_STAFF_DOMAIN_RESET,
});
export const editStaffDomainLoading = () => ({
  type: EDIT_STAFF_DOMAIN_LOADING,
});
export const editStaffDomainSuccess = (editStaffDomain) => ({
  type: EDIT_STAFF_DOMAIN_SUCCESS,
  editStaffDomain,
});
export const editStaffDomainError = (error) => ({
  type: EDIT_STAFF_DOMAIN_ERROR,
  error,
});

export const deleteStaffDomainReset = () => ({
  type: DELETE_STAFF_DOMAIN_RESET,
});
export const deleteStaffDomainLoading = () => ({
  type: DELETE_STAFF_DOMAIN_LOADING,
});
export const deleteStaffDomainSuccess = (deleteStaffDomain) => ({
  type: DELETE_STAFF_DOMAIN_SUCCESS,
  deleteStaffDomain,
});
export const deleteStaffDomainError = (error) => ({
  type: DELETE_STAFF_DOMAIN_ERROR,
  error,
});

// THUNK CREATORS
export const getStaffDomainsByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getStaffDomainsByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillSubmissionURL(resourceLanId, SKILL_TYPE_ID.DOMAIN));
    // console.log("staff domain -->", resourceLanId, data )
    dispatch(getStaffDomainsByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getStaffDomainsByResourceIdError(error));
  }
};

export const saveStaffDomainThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveStaffDomainLoading());
    const { data } = await roverSkillcentralURL.post(addSkillSubmissionURL(), payload);
    if (callback) {
      callback(SAVE_STAFF_DOMAIN_SUCCESS, data);
    }
    dispatch(saveStaffDomainSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_STAFF_DOMAIN_ERROR, error);
    }
    dispatch(saveStaffDomainError(error));
  }
};

export const editStaffDomainThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editStaffDomainLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(EDIT_STAFF_DOMAIN_SUCCESS, data);
    }
    dispatch(editStaffDomainSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_STAFF_DOMAIN_ERROR, error);
    }
    dispatch(editStaffDomainError(error));
  }
};

export const deleteStaffDomainThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(deleteStaffDomainLoading());
    const { data } = await roverSkillcentralURL.put(updateDeleteSkillSubmissionURL(), payload);
    if (callback) {
      callback(DELETE_STAFF_DOMAIN_SUCCESS, data);
    }
    dispatch(deleteStaffDomainSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_STAFF_DOMAIN_ERROR, error);
    }
    dispatch(deleteStaffDomainError(error));
  }
};

// INITIAL STATE
export const staffDomainInitialState = {
  staffDomains: {
    // all staffDomains for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  saveStaffDomainStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editStaffDomainStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteStaffDomainStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Basic Knowledge" },
    { id: 2, desc: "2 - Limited Experience" },
    { id: 3, desc: "3 - Practical Application" },
    { id: 4, desc: "4 - Applied Theory" },
    { id: 5, desc: "5 - Recognized Authority" },
  ],
};

// REDUCERS
const StaffDomainReducer = (state = staffDomainInitialState, action) => {
  switch (action.type) {
    case GET_STAFF_DOMAINS_BY_RESOURCE_ID:
      return {
        ...state,
        staffDomains: {
          data: typeof action.staffDomains === "string" ? [] : [...action.staffDomains],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_STAFF_DOMAINS_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        staffDomains: {
          ...state.staffDomains,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_STAFF_DOMAINS_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        staffDomains: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };

    case SAVE_STAFF_DOMAIN_RESET:
      return {
        ...state,
        saveStaffDomainStatus: { ...staffDomainInitialState.saveStaffDomainStatus },
      };
    case SAVE_STAFF_DOMAIN_LOADING:
      return {
        ...state,
        saveStaffDomainStatus: {
          ...state.saveStaffDomainStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_STAFF_DOMAIN_SUCCESS:
      return {
        ...state,
        saveStaffDomainStatus: {
          ...state.saveStaffDomainStatus,
          response: action.saveStaffDomain,
          status: DATA_STATUS.SUCCESS,
        },
      };

    case SAVE_STAFF_DOMAIN_ERROR:
      return {
        ...state,
        saveStaffDomainStatus: {
          ...state.saveStaffDomainStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };

    case EDIT_STAFF_DOMAIN_RESET:
      return {
        ...state,
        editStaffDomainStatus: { ...staffDomainInitialState.editStaffDomainStatus },
      };
    case EDIT_STAFF_DOMAIN_LOADING:
      return {
        ...state,
        editStaffDomainStatus: {
          ...state.editStaffDomainStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_STAFF_DOMAIN_SUCCESS:
      return {
        ...state,
        editStaffDomainStatus: {
          ...state.editStaffDomainStatus,
          response: action.editStaffDomain,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_STAFF_DOMAIN_ERROR:
      return {
        ...state,
        editStaffDomainStatus: {
          ...state.editStaffDomainStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_STAFF_DOMAIN_RESET:
      return {
        ...state,
        deleteStaffDomainStatus: {
          ...staffDomainInitialState.deleteStaffDomainStatus,
        },
      };
    case DELETE_STAFF_DOMAIN_LOADING:
      return {
        ...state,
        deleteStaffDomainStatus: {
          ...state.deleteStaffDomainStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_STAFF_DOMAIN_SUCCESS:
      return {
        ...state,
        deleteStaffDomainStatus: {
          ...state.deleteStaffDomainStatus,
          response: action.deleteStaffDomain,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_STAFF_DOMAIN_ERROR:
      return {
        ...state,
        deleteStaffDomainStatus: {
          ...state.deleteStaffDomainStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default StaffDomainReducer;
