import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  saveRMSkillURL, getUniqueSkillsByUserURL, getSkillByUserURL,
  editRMSkillURL, deleteRMSkillURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE_ID } from "../Constants/action.constants";

// ACTION TYPES

export const GET_TECHNOLOGIES_BY_RESOURCE_ID = "GET_TECHNOLOGIES_BY_RESOURCE_ID";
export const GET_TECHNOLOGIES_BY_RESOURCE_ID_LOADING = "GET_TECHNOLOGIES_BY_RESOURCE_ID_LOADING";
export const GET_TECHNOLOGIES_BY_RESOURCE_ID_ERROR = "GET_TECHNOLOGIES_BY_RESOURCE_ID_ERROR";

export const GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID = "GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID";
export const GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_LOADING = "GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_LOADING";
export const GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_ERROR = "GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_ERROR";

export const SAVE_TECHNOLOGY_RESET = "SAVE_TECHNOLOGY_RESET";
export const SAVE_TECHNOLOGY_LOADING = "SAVE_TECHNOLOGY_LOADING";
export const SAVE_TECHNOLOGY_SUCCESS = "SAVE_TECHNOLOGY_SUCCESS";
export const SAVE_TECHNOLOGY_ERROR = "SAVE_TECHNOLOGY_ERROR";
export const EDIT_TECHNOLOGY_RESET = "EDIT_TECHNOLOGY_RESET";
export const EDIT_TECHNOLOGY_LOADING = "EDIT_TECHNOLOGY_LOADING";
export const EDIT_TECHNOLOGY_SUCCESS = "EDIT_TECHNOLOGY_SUCCESS";
export const EDIT_TECHNOLOGY_ERROR = "EDIT_TECHNOLOGY_ERROR";
export const DELETE_TECHNOLOGY_RESET = "DELETE_TECHNOLOGY_RESET";
export const DELETE_TECHNOLOGY_LOADING = "DELETE_TECHNOLOGY_LOADING";
export const DELETE_TECHNOLOGY_SUCCESS = "DELETE_TECHNOLOGY_SUCCESS";
export const DELETE_TECHNOLOGY_ERROR = "DELETE_TECHNOLOGY_ERROR";

// ACTION CREATORS

export const getTechnologiesByResourceId = (technologies) => ({
  type: GET_TECHNOLOGIES_BY_RESOURCE_ID,
  technologies,
});
export const getTechnologiesByResourceIdLoading = () => ({
  type: GET_TECHNOLOGIES_BY_RESOURCE_ID_LOADING,
});
export const getTechnologiesByResourceIdError = (error) => ({
  type: GET_TECHNOLOGIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const getUniqueTechnologiesByResourceId = (technologies) => ({
  type: GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID,
  technologies,
});
export const getUniqueTechnologiesByResourceIdLoading = () => ({
  type: GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_LOADING,
});
export const getUniqueTechnologiesByResourceIdError = (error) => ({
  type: GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const saveTechnologyReset = () => ({
  type: SAVE_TECHNOLOGY_RESET,
});
export const saveTechnologyLoading = () => ({
  type: SAVE_TECHNOLOGY_LOADING,
});
export const saveTechnologySuccess = (saveTechnology) => ({
  type: SAVE_TECHNOLOGY_SUCCESS,
  saveTechnology,
});
export const saveTechnologyError = (error) => ({
  type: SAVE_TECHNOLOGY_ERROR,
  error,
});
export const editTechnologyReset = () => ({
  type: EDIT_TECHNOLOGY_RESET,
});
export const editTechnologyLoading = () => ({
  type: EDIT_TECHNOLOGY_LOADING,
});
export const editTechnologySuccess = (editTechnology) => ({
  type: EDIT_TECHNOLOGY_SUCCESS,
  editTechnology,
});
export const editTechnologyError = (error) => ({
  type: EDIT_TECHNOLOGY_ERROR,
  error,
});

export const deleteTechnologyReset = () => ({
  type: DELETE_TECHNOLOGY_RESET,
});
export const deleteTechnologyLoading = () => ({
  type: DELETE_TECHNOLOGY_LOADING,
});
export const deleteTechnologySuccess = (deleteTechnology) => ({
  type: DELETE_TECHNOLOGY_SUCCESS,
  deleteTechnology,
});
export const deleteTechnologyError = (error) => ({
  type: DELETE_TECHNOLOGY_ERROR,
  error,
});

// THUNK CREATORS
export const getTechnologiesByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getTechnologiesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillByUserURL(resourceLanId, SKILL_TYPE_ID.TECH));
    // console.log("res tech -->", resourceLanId, data )
    dispatch(getTechnologiesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getTechnologiesByResourceIdError(error));
  }
};
export const getUniqueTechnologiesByResourceIdThunk = (resourceLanId,deptId) => async (dispatch) => {
  try {
    dispatch(getUniqueTechnologiesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getUniqueSkillsByUserURL(resourceLanId, SKILL_TYPE_ID.TECH,deptId));
    // console.log("uni tech -->", resourceLanId, data, deptId )
    dispatch(getUniqueTechnologiesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getUniqueTechnologiesByResourceIdError(error));
  }
};

export const saveTechnologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveTechnologyLoading());
    const { data } = await roverSkillcentralURL.post(saveRMSkillURL(), payload);
    if (callback) {
      callback(SAVE_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(saveTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_TECHNOLOGY_ERROR, error);
    }
    dispatch(saveTechnologyError(error));
  }
};
export const editTechnologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editTechnologyLoading());
    const { data } = await roverSkillcentralURL.put(editRMSkillURL(), payload);
    if (callback) {
      callback(EDIT_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(editTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_TECHNOLOGY_ERROR, error);
    }
    dispatch(editTechnologyError(error));
  }
};
export const deleteTechnologyThunk = (managerId, peopleSkillId, callback) => async (dispatch) => {
  try {
    dispatch(deleteTechnologyLoading());
    const { data } = await roverSkillcentralURL.put(deleteRMSkillURL(peopleSkillId, managerId));
    if (callback) {
      callback(DELETE_TECHNOLOGY_SUCCESS, data);
    }
    dispatch(deleteTechnologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_TECHNOLOGY_ERROR, error);
    }
    dispatch(deleteTechnologyError(error));
  }
};


// INITIAL STATE
export const technologyInitialState = {
  currentTechnologies: { data: [], status: DATA_STATUS, response: {} },
  uniqueTechnologies:{data: [], status: DATA_STATUS, response: {}},
  saveTechnologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editTechnologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteTechnologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Basic Knowledge" },
    { id: 2, desc: "2 - Limited Experience" },
    { id: 3, desc: "3 - Practical Application" },
    { id: 4, desc: "4 - Applied Theory" },
    { id: 5, desc: "5 - Recognized Authority" },
  ],
};

// REDUCERS
const TechnologyReducer = (state = technologyInitialState, action) => {
  switch (action.type) {
    case GET_TECHNOLOGIES_BY_RESOURCE_ID:
      return {
        ...state,
        currentTechnologies: {
          data: typeof action.technologies === "string" ? [] : [...action.technologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_TECHNOLOGIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        currentTechnologies: {
          ...state.currentTechnologies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_TECHNOLOGIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        currentTechnologies: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };

      case GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID:
        return {
          ...state,
          uniqueTechnologies: {
            data: typeof action.technologies === "string" ? [] : [...action.technologies],
            status: DATA_STATUS.SUCCESS,
          },
        };
      case GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_LOADING:
        return {
          ...state,
          uniqueTechnologies: {
            ...state.uniqueTechnologies,
            status: DATA_STATUS.LOADING,
          },
        };  
        case GET_UNIQUETECHNOLOGIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        uniqueTechnologies: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };  
    case SAVE_TECHNOLOGY_RESET:
      return {
        ...state,
        saveTechnologyStatus: { ...technologyInitialState.saveTechnologyStatus },
      };
    case SAVE_TECHNOLOGY_LOADING:
      return {
        ...state,
        saveTechnologyStatus: {
          ...state.saveTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        saveTechnologyStatus: {
          ...state.saveTechnologyStatus,
          response: action.saveTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_TECHNOLOGY_ERROR:
      return {
        ...state,
        saveTechnologyStatus: {
          ...state.saveTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_TECHNOLOGY_RESET:
      return {
        ...state,
        editTechnologyStatus: { ...technologyInitialState.editTechnologyStatus },
      };
    case EDIT_TECHNOLOGY_LOADING:
      return {
        ...state,
        editTechnologyStatus: {
          ...state.editTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        editTechnologyStatus: {
          ...state.editTechnologyStatus,
          response: action.editTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_TECHNOLOGY_ERROR:
      return {
        ...state,
        editTechnologyStatus: {
          ...state.editTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_TECHNOLOGY_RESET:
      return {
        ...state,
        deleteTechnologyStatus: { ...technologyInitialState.deleteTechnologyStatus },
      };
    case DELETE_TECHNOLOGY_LOADING:
      return {
        ...state,
        deleteTechnologyStatus: {
          ...state.deleteTechnologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_TECHNOLOGY_SUCCESS:
      return {
        ...state,
        deleteTechnologyStatus: {
          ...state.deleteTechnologyStatus,
          response: action.deleteTechnology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_TECHNOLOGY_ERROR:
      return {
        ...state,
        deleteTechnologyStatus: {
          ...state.deleteTechnologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default TechnologyReducer;
