import cookie from 'react-cookies';

// const ScDomain = "https://rover-skills-central-api-dev.cfaa.azr.hcsctest.net";
const ScDomain = cookie.load('ROVER_SC_API');

// const ScDomain = "http://localhost:8094"; //|| "http://10.142.67.110:8094";

/* SC Admin Endpoints */

// CRUD of Admin Skill Configuration
export const getSkillExpirationURL = () => {
  return `/v1/sc/admin/getSkillExpiration`;
};
export const updateSkillExpirationURL = (noOfMonths) => {
  return `/v1/sc/admin/${noOfMonths}/updateSkillExpiration`;
};
export const getAdminCategoryURL = () => {
  return `/v1/sc/admin/getSubcategories`;
};
export const addAdminCategory = () => {
  return `/v1/sc/admin/addSubCategories`;
};
export const getAdminSKillURL = (skillType) => {
  return `/v1/sc/admin/${skillType}/skills`;
};
export const saveAdminSkillURL = () => {
  return `/v1/sc/admin/skills/addSkills`;
};
export const editAdminSkillURL = (skillId) => {
  return `/v1/sc/admin/skills/${skillId}/editSkills`;
};
export const deleteAdminSkillURL = (skillId,resourceId) => {
  return `/v1/sc/admin/skills/${skillId}/${resourceId}/deleteSkills`;
};

// CRUD of Admin Attrition URL
export const getAttritionOptionsURL = () => {
  return `/v1/sc/admin/getAttritionOptions`;
};
export const getAttritionTypeURL = (resourceTypeId) => {
  return `/v1/sc/admin/${resourceTypeId}/attritionTypes`;
};
export const addAttritionOptionURL = () => {
  return `/v1/sc/admin/addAttrition`;
};
export const editAttritionOptionURL = (attritionId) => {
  return `/v1/sc/admin/${attritionId}/editAttrition`;
};
export const deleteAttritionOptionURL = (attritionId) => {
  return `/v1/sc/admin/${attritionId}/deleteAttritionOption`;
};

// CRUD of Admin Dept Heads URL
export const getHeadNamesURL = () => {
  return `/v1/sc/admin/getHeadNames`;
};
export const getDeptHeadsURL = () => {
  return `/v1/sc/admin/getDeptHeads`;
};
export const addDepartmentHeadURL = () => {
  return `/v1/sc/admin/addDepartmentHead`;
};
export const editDepartmentHeadURL = (deptId) => {
  return `/v1/sc/admin/${deptId}/editDepartmentHead`;
};
export const deleteDepartmentHeadURL = (deptId) => {
  return `/v1/sc/admin/${deptId}/deleteDepartmentHead`;
};
export const getDeptManagersURL = (deptId) => {
  return `/v1/sc/admin/${deptId}/getdepartmentRMs`;
};
export const editDepartmentManagerURL = (deptRmId, isActive) => {
  return `/v1/sc/admin/${deptRmId}/${isActive}/editDepartmentRMs`;
};

// CRUD of Admin Manage Vendors URL
export const getAdminManageVendorsURL = () => {
  return `/v1/sc/admin/getVendors`;
};
export const addAdminManageVendorURL = () => {
  return `/v1/sc/admin/addVendors`;
};
export const getAdminManageVendorNumNamesURL = (vendorNumber) => {
  return `/v1/sc/admin/numNames/${vendorNumber}/getVendor`;
};
export const editAdminManageVendorURL = (vendorId) => {
  return `/v1/sc/admin/${vendorId}/editVendors`;
};
export const deleteAdminManageVendorURL = (vendorId) => {
  return `/v1/sc/admin/${vendorId}/deleteVendors`;
};

// CRUD of Admin Manage Roles & JobTitles URL
export const getRolesURL = () => {
  return `/v1/sc/admin/getRoles`;
};
export const addAdminRoleURL = () => {
  return `/v1/sc/admin/addRoles`;
};
export const editAdminRoleURL = (roleId) => {
  return `/v1/sc/admin/${roleId}/editRoles`;
};
export const deleteAdminRoleURL = (roleId) => {
  return `/v1/sc/admin/${roleId}/deleteRoles`;
};
export const getJobTitlesURL = () => {
  return `/v1/sc/admin/getJobTitles`;
};
export const editJobTitlesURL = (deptId) => {
  return `/v1/sc/admin/editJobTitles`;
};

// Get & Update of Admin Automation Jobs & E-mails Notifications URL
export const getAutomationStatusURL = () => {
  return `/v1/sc/automation/getStatus`;
}
export const toggleAutomationStatusURL = (profileStatus, mailStatus) => {
  return `v1/sc/automation/profileCreation?active=${profileStatus}&isEmailSend=${mailStatus}`;
};
export const updateSCEmailNotificationStatusURL = (status) => {
  return `v1/sc/update/masterSwitch/${status}`;
};

// CRUD of Admin One-Rate URL
export const getAdminOneRateURL = () => {
  return `/v1/sc/admin/getOneRate`;
};
export const addAdminOneRateURL = () => {
  return `/v1/sc/admin/addOneRate`;
};
export const editAdminOneRateURL = () => {
  return `/v1/sc/admin/editOneRate`;
};

/* SC RM Endpoints */

// CRUD of RM Skill
export const getSkillByUserURL = (resourceLanId, skillTypeId) => {                  //returns the resources skills
  return `/v1/sc/people/${resourceLanId}/${skillTypeId}/skills`; 
};
export const getUniqueSkillsByUserURL = (resourceLanId,skillTypeId,deptId) => {            //returns the skill. excluding the resources skill
  return `/v1/sc/people/${skillTypeId}/${resourceLanId}/${deptId}/uniqueSkills`;
};
export const saveRMSkillURL = () => {
  return `/v1/sc/people/addPeopleSkills`;
};
export const editRMSkillURL = () => {   
  return `/v1/sc/people/update/peopleSkills`;
};
export const deleteRMSkillURL = (peopleSkillId, managerId) => {   
  return `/v1/sc/people/delete/${peopleSkillId}/${managerId}/peopleSkills`;
};

// Domain
export const getDomainsProductLinesURL = () => {
  return `/v1/sc/people/domains/productLine`;
};
export const getDomainsProductsByProductLineIdURL = (productLineId) => {        
  return `/v1/sc/people/domains/${productLineId}/product`;
};
export const getDomainsApplicationsByProductIdURL = (productId) => {            
  return `/v1/sc/people/domains/${productId}/application`;
};
export const getDomainsByUserURL = (resourceLanId) => {                      
  return `/v1/sc/people/${resourceLanId}/domains`;
};
export const saveDomainURL = () => {                                            
  return `/v1/sc/people/addPeopleDomains`;
};

// RM Actions
export const addManagerApprovalURL = () => {          
  return `/v1/sc/manager/approve`;
};
export const addManagerDenyURL = () => {              
  return `/v1/sc/manager/deny`;
};
export const saveReportAttritionURL = () => {         
  return `/v1/sc/people/attrition`;
};
export const updateResourcedegreeURL = () => {
  return `/v1/sc/manager/updateDegree`;
};
export const requestFeedbackURL = () => {
  return `/v1/sc/people/feedBack`;
};
export const submitFeedbackURL = () => {
  return `/v1/sc/people/submitFeedBack`;
};
export const getSubmittedFeedbackURL = (lanID) => {
  return `/v1/sc/people/${lanID}/feedBack`;
};
export const updateRMViewStatusURL = (requestID) => {
  return `/v1/sc/people/${requestID}/status/updateFeedback`;
};

// RM Advanced Search endpoints
export const getSkillsDropdownURL = (skillTypeId, departmentId) => {
  return `/v1/sc/advance/${skillTypeId}/${departmentId}/skillsDropdown`;
};
export const getDomainDropdownURL = (skillTypeId) => {
  return `/v1/sc/advance/${skillTypeId}/domainsDropdown`;
};
export const getResourceDropdownURL = (name, departmentId) => {
  return `/v1/sc/advance/${name}/${departmentId}/resourceDropdown`;
};
export const getRolesDropdownURL = (departmentId) => {
  return `/v1/sc/advance/${departmentId}/rolesDropdown`;
};
export const getJobTitlesDropdownURL = (departmentId) => {
  return `/v1/sc/advance/${departmentId}/jobTitleDropdown`;
};
export const getManagersDropdownURL = (departmentId) => {
  return `/v1/sc/advance/${departmentId}/managersDropdown`;
};
export const getSearchBySkillURL = (deptId, skillId, skillTypeId) => {
  return `/v1/sc/people/${deptId}/${skillId}/${skillTypeId}/peopleOnSkills`;
};
export const getSearchByEmpDetailsyURL = (lanID) => {
  return `/v1/sc/advance/${lanID}/search`;
};

/* SC IC or Staff Endpoints */

// CRUD of IC/Staff Skill submission
export const getSkillSubmissionURL = (resourceLanId, skillTypeId) => {
  return `/v1/sc/people/skillSubmissions/${resourceLanId}/${skillTypeId}`;
};
export const addSkillSubmissionURL = () => {
  return `/v1/sc/people/skillSubmissions/addSubmissions`;
};
export const updateDeleteSkillSubmissionURL = () => {
  return `/v1/sc/people/skillSubmissions/update_delete/Submissions`;
};

// IC Panel 
export const getMentorDetailsURL = (resourceLanId, skillId) => {
  return `/v1/sc/people/${resourceLanId}/${skillId}/mentors`;
};

/* SC User Common Endpoints (irrespective of RM/IC) */

// User Details & Role Endpoints
export const getDetailsByLanIdURL = (lanId) => {
  return `/v1/sc/people/${lanId}`;
};
export const getIiqRolesURL = (lanId) => {
  return `/v1/sc/people/${lanId}/role`;
};
export const getReporteesByLanIdURL = (managerId) => {            //For RM --> return the list of reportees | For others --> return 404
  return `/v1/sc/manager/${managerId}/roster`;
};
export const getInactiveEmployeesURL = (managerId) => {             
  return `/v1/sc/people/inActive/${managerId}/employee`;
};
export const getEmployeeDetailsURL = (empID) => {                  
  return `/v1/sc/people/${empID}/roster`;
};
export const getPeopleAvailabilityURL = (empID) => {                  
  return `/v1/sc/people/${empID}/availability`;
};

// Reuseable/Common Endpoints
export const getSourceNamesURL = () => {                          // Full name of resources
  return `/v1/sc/people/fullName`;
};
export const updateMentorStatusURL = (peopleSkillId) => {         // Nochange needed,Active Tech Change, Saving Mentor status
  return `/v1/sc/people/${peopleSkillId}/peopleDetails`;
};
export const getResourceTypeURL = () => {                         // Res Type Options (E/C)
  return `/v1/sc/admin/getResourceTypes`;
};
export const getSkillHistoryURL = (peopleId, peopleSkillId) => {  // Skill History for IC/RM's Skill [M/T/C/D]
  return `/v1/sc/people/${peopleId}/${peopleSkillId}/history`;
};

//Review n Delete 
export const getResourcesURL = (lanId) => {                       // old endpoint n replaced by getReporteesByLanIdURL        
  return `/v1/sc/people/${lanId}/reportees`;
};