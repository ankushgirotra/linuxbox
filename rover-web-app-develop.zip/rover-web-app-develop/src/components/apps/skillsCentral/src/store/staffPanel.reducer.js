import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import { getMentorDetailsURL, updateMentorStatusURL } from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";

// ACTION TYPES
export const GET_MENTOR_DETAILS_LOADING = "GET_MENTOR_DETAILS_LOADING";
export const GET_MENTOR_DETAILS_SUCCESS = "GET_MENTOR_DETAILS_SUCCESS";
export const GET_MENTOR_DETAILS_ERROR = "GET_MENTOR_DETAILS_ERROR";

export const UPDATE_MENTOR_STATUS_SUCCESS = "UPDATE_MENTOR_STATUS_SUCCESS";
export const UPDATE_MENTOR_STATUS_ERROR = "UPDATE_MENTOR_STATUS_ERROR";

// ACTION CREATORS
export const getMentorDetailsLoading = () => ({
  type: GET_MENTOR_DETAILS_LOADING,
});
export const getMentorDetailsSuccess = (mentorDetails) => ({
  type: GET_MENTOR_DETAILS_SUCCESS,
  mentorDetails,
});
export const getMentorDetailsError = (error) => ({
  type: GET_MENTOR_DETAILS_ERROR,
  error,
});

export const updateMentorStatusSuccess = (updateStatus) => ({
  type: UPDATE_MENTOR_STATUS_SUCCESS,
  updateStatus,
});
export const updateMentorStatusError = (error) => ({
  type: UPDATE_MENTOR_STATUS_ERROR,
  error,
});

// THUNK CREATORS
export const getMentorDetailsThunk = (resourceId, technologyId, callback) => async (dispatch) => {
  try {
    dispatch(getMentorDetailsLoading());
    const { data } = await roverSkillcentralURL.get(getMentorDetailsURL(resourceId, technologyId));
    if (callback) {
      callback(GET_MENTOR_DETAILS_SUCCESS, data);
    }
    dispatch(getMentorDetailsSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_MENTOR_DETAILS_ERROR, error);
    }
    dispatch(getMentorDetailsError(error));
  }
};

export const updateMentorStatusThunk = (peopleSkillId, payload) => async (dispatch) => {
  try {
    const { data } = await roverSkillcentralURL.put(updateMentorStatusURL(peopleSkillId), payload);
    dispatch(updateMentorStatusSuccess(data));
  } catch (error) {
    dispatch(updateMentorStatusError(error));
  }
};

// INITIAL STATE
export const initialState = {
  mentorDetails: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  mentorStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
export const StaffPanelReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_MENTOR_DETAILS_SUCCESS:
      return {
        ...state,
        mentorDetails: {
          data: typeof action.mentorDetails === "string" ? [] : [...action.mentorDetails],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_MENTOR_DETAILS_LOADING:
      return {
        ...state,
        mentorDetails: {
          ...state.mentorDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_MENTOR_DETAILS_ERROR:
      return {
        ...state,
        mentorDetails: {
          ...state.mentorDetails,
          status: DATA_STATUS.ERROR,
          response: action.error
        },
      };
    case UPDATE_MENTOR_STATUS_SUCCESS:
      return {
        ...state,
        mentorStatus: {
          ...state.mentorStatus,
          response: action.updateStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_MENTOR_STATUS_ERROR:
      return {
        ...state,
        mentorStatus: {
          ...state.mentorStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default StaffPanelReducer;

