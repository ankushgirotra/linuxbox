import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  getAdminSKillURL,
  getSkillByUserURL,
  getUniqueSkillsByUserURL,
  saveRMSkillURL,
  editRMSkillURL,
  deleteRMSkillURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { SKILL_TYPE, SKILL_TYPE_ID } from "../Constants/action.constants";

// ACTION TYPES
export const GET_METHODOLOGIES = "GET_METHODOLOGIES";
export const GET_METHODOLOGIES_LOADING = "GET_METHODOLOGIES_LOADING";
export const GET_METHODOLOGIES_ERROR = "GET_METHODOLOGIES_ERROR";

export const GET_METHODOLOGIES_BY_RESOURCE_ID = "GET_METHODOLOGIES_BY_RESOURCE_ID";
export const GET_METHODOLOGIES_BY_RESOURCE_ID_LOADING = "GET_METHODOLOGIES_BY_RESOURCE_ID_LOADING";
export const GET_METHODOLOGIES_BY_RESOURCE_ID_ERROR = "GET_METHODOLOGIES_BY_RESOURCE_ID_ERROR";

export const GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID = "GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID";
export const GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_LOADING =
  "GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_LOADING";
export const GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_ERROR =
  "GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_ERROR";

export const SAVE_METHODOLOGY_RESET = "SAVE_METHODOLOGY_RESET";
export const SAVE_METHODOLOGY_LOADING = "SAVE_METHODOLOGY_LOADING";
export const SAVE_METHODOLOGY_SUCCESS = "SAVE_METHODOLOGY_SUCCESS";
export const SAVE_METHODOLOGY_ERROR = "SAVE_METHODOLOGY_ERROR";

export const EDIT_METHODOLOGY_RESET = "EDIT_METHODOLOGY_RESET";
export const EDIT_METHODOLOGY_LOADING = "EDIT_METHODOLOGY_LOADING";
export const EDIT_METHODOLOGY_SUCCESS = "EDIT_METHODOLOGY_SUCCESS";
export const EDIT_METHODOLOGY_ERROR = "EDIT_METHODOLOGY_ERROR";

export const DELETE_METHODOLOGY_RESET = "DELETE_METHODOLOGY_RESET";
export const DELETE_METHODOLOGY_LOADING = "DELETE_METHODOLOGY_LOADING";
export const DELETE_METHODOLOGY_SUCCESS = "DELETE_METHODOLOGY_SUCCESS";
export const DELETE_METHODOLOGY_ERROR = "DELETE_METHODOLOGY_ERROR";

// ACTION CREATORS
export const getMethodologies = (methodologies) => ({
  type: GET_METHODOLOGIES,
  methodologies,
});
export const getMethodologiesLoading = () => ({
  type: GET_METHODOLOGIES_LOADING,
});
export const getMethodologiesError = (error) => ({
  type: GET_METHODOLOGIES_ERROR,
  error,
});

export const getMethodologiesByResourceId = (methodologies) => ({
  type: GET_METHODOLOGIES_BY_RESOURCE_ID,
  methodologies,
});
export const getMethodologiesByResourceIdLoading = () => ({
  type: GET_METHODOLOGIES_BY_RESOURCE_ID_LOADING,
});
export const getMethodologiesByResourceIdError = (error) => ({
  type: GET_METHODOLOGIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const getUniqueMethodologiesByResourceId = (methodologies) => ({
  type: GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID,
  methodologies,
});
export const getUniqueMethodologiesByResourceIdLoading = () => ({
  type: GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_LOADING,
});
export const getUniqueMethodologiesByResourceIdError = (error) => ({
  type: GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_ERROR,
  error,
});

export const saveMethodologyReset = () => ({
  type: SAVE_METHODOLOGY_RESET,
});
export const saveMethodologyLoading = () => ({
  type: SAVE_METHODOLOGY_LOADING,
});
export const saveMethodologySuccess = (saveMethodology) => ({
  type: SAVE_METHODOLOGY_SUCCESS,
  saveMethodology,
});
export const saveMethodologyError = (error) => ({
  type: SAVE_METHODOLOGY_ERROR,
  error,
});

export const editMethodologyReset = () => ({
  type: EDIT_METHODOLOGY_RESET,
});
export const editMethodologyLoading = () => ({
  type: EDIT_METHODOLOGY_LOADING,
});
export const editMethodologySuccess = (editMethodology) => ({
  type: EDIT_METHODOLOGY_SUCCESS,
  editMethodology,
});
export const editMethodologyError = (error) => ({
  type: EDIT_METHODOLOGY_ERROR,
  error,
});

export const deleteMethodologyReset = () => ({
  type: DELETE_METHODOLOGY_RESET,
});
export const deleteMethodologyLoading = () => ({
  type: DELETE_METHODOLOGY_LOADING,
});
export const deleteMethodologySuccess = (deleteMethodology) => ({
  type: DELETE_METHODOLOGY_SUCCESS,
  deleteMethodology,
});
export const deleteMethodologyError = (error) => ({
  type: DELETE_METHODOLOGY_ERROR,
  error,
});

// THUNK CREATORS
export const getMethodologiesThunk = () => async (dispatch) => {
  try {
    dispatch(getMethodologiesLoading());
    const { data } = await roverSkillcentralURL.get(getAdminSKillURL(SKILL_TYPE.METH));
    dispatch(getMethodologies(data));
  } catch (error) {
    console.log(error);
    dispatch(getMethodologiesError(error));
  }
};

export const getMethodologiesByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getMethodologiesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getSkillByUserURL(resourceLanId, SKILL_TYPE_ID.METH));
    // console.log("res Meth -->", resourceLanId, data )
    dispatch(getMethodologiesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getMethodologiesByResourceIdError(error));
  }
};

export const getUniqueMethodologiesByResourceIdThunk = (resourceLanId,deptId) => async (dispatch) => {
  try {
    dispatch(getUniqueMethodologiesByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getUniqueSkillsByUserURL(resourceLanId, SKILL_TYPE_ID.METH,deptId));
    // console.log("uniq Meth -->", resourceLanId, data, deptId )
    dispatch(getUniqueMethodologiesByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getUniqueMethodologiesByResourceIdError(error));
  }
};

export const saveMethodologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveMethodologyLoading());
    const { data } = await roverSkillcentralURL.post(saveRMSkillURL(), payload);
    if (callback) {
      callback(SAVE_METHODOLOGY_SUCCESS, data);
    }
    dispatch(saveMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_METHODOLOGY_ERROR, error);
    }
    dispatch(saveMethodologyError(error));
  }
};

export const editMethodologyThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editMethodologyLoading());
    const { data } = await roverSkillcentralURL.put(editRMSkillURL(), payload);
    if (callback) {
      callback(EDIT_METHODOLOGY_SUCCESS, data);
    }
    dispatch(editMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_METHODOLOGY_ERROR, error);
    }
    dispatch(editMethodologyError(error));
  }
};

export const deleteMethodologyThunk = (peopleSkillId, managerId, callback) => async (dispatch) => {
  try {
    dispatch(deleteMethodologyLoading());
    const { data } = await roverSkillcentralURL.put(deleteRMSkillURL(peopleSkillId, managerId));
    if (callback) {
      callback(DELETE_METHODOLOGY_SUCCESS, data);
    }
    dispatch(deleteMethodologySuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_METHODOLOGY_ERROR, error);
    }
    dispatch(deleteMethodologyError(error));
  }
};


// INITIAL STATE
export const methodologyInitialState = {
  methodologies: { // all methodologies for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  currentMethodologies: { // added methodologies for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  uniqueMethodologies: { // unique methodologies for dropdown
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  saveMethodologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editMethodologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteMethodologyStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Basic Knowledge" },
    { id: 2, desc: "2 - Limited Experience" },
    { id: 3, desc: "3 - Practical Application" },
    { id: 4, desc: "4 - Applied Theory" },
    { id: 5, desc: "5 - Recognized Authority" },
  ],
};

// REDUCERS
const MethodologyReducer = (state = methodologyInitialState, action) => {
  switch (action.type) {
    case GET_METHODOLOGIES:
      return {
        ...state,
        methodologies: {
          data: typeof action.methodologies === "string" ? [] : [...action.methodologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_METHODOLOGIES_BY_RESOURCE_ID:
      return {
        ...state,
        currentMethodologies: {
          data: typeof action.methodologies === "string" ? [] : [...action.methodologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_METHODOLOGIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        currentMethodologies: {
          ...state.currentMethodologies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_METHODOLOGIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        currentMethodologies: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID:
      return {
        ...state,
        uniqueMethodologies: {
          data: typeof action.methodologies === "string" ? [] : [...action.methodologies],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        uniqueMethodologies: {
          ...state.uniqueMethodologies,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_UNIQUEMETHODOLOGIES_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        uniqueMethodologies: { data: [], status: DATA_STATUS.ERROR, response: action.error },
      };
    case SAVE_METHODOLOGY_RESET:
      return {
        ...state,
        saveMethodologyStatus: { ...methodologyInitialState.saveMethodologyStatus },
      };
    case SAVE_METHODOLOGY_LOADING:
      return {
        ...state,
        saveMethodologyStatus: {
          ...state.saveMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_METHODOLOGY_ERROR:
      return {
        ...state,
        saveMethodologyStatus: {
          ...state.saveMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case SAVE_METHODOLOGY_SUCCESS:
      return {
        ...state,
        saveMethodologyStatus: {
          ...state.saveMethodologyStatus,
          response: action.saveMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_METHODOLOGY_RESET:
      return {
        ...state,
        editMethodologyStatus: { ...methodologyInitialState.editMethodologyStatus },
      };
    case EDIT_METHODOLOGY_LOADING:
      return {
        ...state,
        editMethodologyStatus: {
          ...state.editMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_METHODOLOGY_SUCCESS:
      return {
        ...state,
        editMethodologyStatus: {
          ...state.editMethodologyStatus,
          response: action.editMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_METHODOLOGY_ERROR:
      return {
        ...state,
        editMethodologyStatus: {
          ...state.editMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_METHODOLOGY_RESET:
      return {
        ...state,
        deleteMethodologyStatus: { ...methodologyInitialState.deleteMethodologyStatus },
      };
    case DELETE_METHODOLOGY_LOADING:
      return {
        ...state,
        deleteMethodologyStatus: {
          ...state.deleteMethodologyStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_METHODOLOGY_SUCCESS:
      return {
        ...state,
        deleteMethodologyStatus: {
          ...state.deleteMethodologyStatus,
          response: action.deleteMethodology,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_METHODOLOGY_ERROR:
      return {
        ...state,
        deleteMethodologyStatus: {
          ...state.deleteMethodologyStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };

    default:
      return state;
  }
};

export default MethodologyReducer;
