import SCUsersReducer from "./users.reducer";
import ScAuthReducer from './auth.reducer';
import SkillsCentralAdmin from './admin.reducer';
import TechnologyReducer from './technologies.reducers';
import CompetencyReducer from './competencies.reducer';
import DomainReducer from './domains.reducer';
import MethodologyReducer from './methodologies.reducer';
import RMActionsReducer from "./RMActions.reducer";
import StaffTechnologyReducer from './staffTechnology.reducer';
import StaffCompetencyReducer from './staffCompetency.reducer';
import StaffDomainReducer from './staffDomain.reducer';
import StaffMethodologyReducer from './staffMethodology.reducer';
import StaffPanelReducer from "./staffPanel.reducer";
import SkillProfileReducer from "./skillProfile.reducer";
import SkillCentralCommonReducers from "./common.reducers";

const SkillsCentralReducer = {
  SCUsersReducer,
  ScAuthReducer,
  SkillsCentralAdmin,
  TechnologyReducer,
  CompetencyReducer,
  DomainReducer,
  MethodologyReducer,
  RMActionsReducer,
  StaffTechnologyReducer,
  StaffCompetencyReducer,
  StaffDomainReducer,
  StaffMethodologyReducer,
  StaffPanelReducer,
  SkillProfileReducer,
  SkillCentralCommonReducers
};

export { SkillsCentralReducer };
