import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import { updateMentorStatusURL as updateActiveTechURL, getSkillHistoryURL } from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";

// ACTION TYPES
export const UPDATE_ACTIVE_TECH_LOADING = "UPDATE_ACTIVE_TECH_LOADING";
export const UPDATE_ACTIVE_TECH_SUCCESS = "UPDATE_ACTIVE_TECH_SUCCESS";
export const UPDATE_ACTIVE_TECH_ERROR = "UPDATE_ACTIVE_TECH_ERROR";

export const GET_SKILL_HISTORY_LOADING = "GET_SKILL_HISTORY_LOADING";
export const GET_SKILL_HISTORY_SUCCESS = "GET_SKILL_HISTORY_SUCCESS";
export const GET_SKILL_HISTORY_ERROR = "GET_SKILL_HISTORY_ERROR";

// ACTION CREATORS
export const updateActiveTechLoading = () => ({
  type: UPDATE_ACTIVE_TECH_LOADING,
});
export const updateActiveTechSuccess = (status) => ({
  type: UPDATE_ACTIVE_TECH_SUCCESS,
  status,
});
export const updateActiveTechError = (error) => ({
  type: UPDATE_ACTIVE_TECH_ERROR,
  error,
});

export const getSkillHistoryLoading = () => ({
  type: GET_SKILL_HISTORY_LOADING,
});
export const getSkillHistorySuccess = (skillHistory) => ({
  type: GET_SKILL_HISTORY_SUCCESS,
  skillHistory,
});
export const getSkillHistoryError = (error) => ({
  type: GET_SKILL_HISTORY_ERROR,
  error,
});

// THUNK CREATORS
export const updateActiveTechThunk = (peopleSkillId, payload, callback) => async (dispatch) => {
  try {
    dispatch(updateActiveTechLoading());
    const { data } = await roverSkillcentralURL.put(updateActiveTechURL(peopleSkillId), payload);
    if (callback) {
      callback(UPDATE_ACTIVE_TECH_SUCCESS, data);
    }
    dispatch(updateActiveTechSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(UPDATE_ACTIVE_TECH_ERROR, error);
    }
    dispatch(updateActiveTechError(error));
  }
};

export const getSkillHistoryThunk = (peopleId, peopleSkillId) => async (dispatch) => {
  try {
    dispatch(getSkillHistoryLoading());
    const { data } = await roverSkillcentralURL.get(getSkillHistoryURL(peopleId,peopleSkillId));
    dispatch(getSkillHistorySuccess(data));
  } catch (error) {
    console.error(error);
    dispatch(getSkillHistoryError(error.response));
  }
};

// INITIAL STATE
export const initialState = {
  updateActiveTechStatus: { data: {}, status: DATA_STATUS.INITIAL, response: {} },
  skillHistoryList: { data: [], status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
export const SkillCentralCommonReducers = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_ACTIVE_TECH_SUCCESS:
      return {
        ...state,
        updateActiveTechStatus: {
          data: action.updateActiveTechStatus,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case UPDATE_ACTIVE_TECH_LOADING:
      return {
        ...state,
        updateActiveTechStatus: {
          ...state.updateActiveTechStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case UPDATE_ACTIVE_TECH_ERROR:
      return {
        ...state,
        updateActiveTechStatus: {
          ...state.updateActiveTechStatus,
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case GET_SKILL_HISTORY_SUCCESS:
      return {
        ...state,
        skillHistoryList: {
          data: typeof action.skillHistory === "string" ? [] : [...action.skillHistory],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_SKILL_HISTORY_LOADING:
      return {
        ...state,
        skillHistoryList: {
          ...state.skillHistoryList,
          data: [],
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_SKILL_HISTORY_ERROR:
      return {
        ...state,
        skillHistoryList: {
          ...state.skillHistoryList,
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    default:
      return state;
  }
};

export default SkillCentralCommonReducers;

