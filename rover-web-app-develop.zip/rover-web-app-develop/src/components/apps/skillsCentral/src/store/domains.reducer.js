import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import {
  getDomainsApplicationsByProductIdURL,
  saveDomainURL,
  getDomainsByUserURL,
  getDomainsProductsByProductLineIdURL,
  getDomainsProductLinesURL,
  editRMSkillURL,
  deleteRMSkillURL,
} from "./endpoints";
import roverSkillcentralURL from "../../../../../apis/skillcentral_api";
import { errorState } from "./../../../pcdm/src/services/team.service";

// ACTION TYPES
export const GET_DOMAINS_PRODUCT_LINES = "GET_DOMAINS_PRODUCT_LINES";
export const GET_DOMAINS_PRODUCT_LINES_LOADING = "GET_DOMAINS_PRODUCT_LINES_LOADING";
export const GET_DOMAINS_PRODUCT_LINES_ERROR = "GET_DOMAINS_PRODUCT_LINES_ERROR";

export const GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID = "GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID";
export const GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_LOADING =
  "GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_LOADING";
export const GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR =
  "GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR";

export const GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID = "GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID";
export const GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_LOADING =
  "GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_LOADING";
export const GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR =
  "GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR";

export const GET_DOMAINS_BY_RESOURCE_ID = "GET_DOMAINS_BY_RESOURCE_ID";
export const GET_DOMAINS_BY_RESOURCE_ID_LOADING = "GET_DOMAINS_BY_RESOURCE_ID_LOADING";
export const GET_DOMAINS_BY_RESOURCE_ID_ERROR = "GET_DOMAINS_BY_RESOURCE_ID_ERROR";

export const SAVE_DOMAIN_RESET = "SAVE_DOMAIN_RESET";
export const SAVE_DOMAIN_LOADING = "SAVE_DOMAIN_LOADING";
export const SAVE_DOMAIN_SUCCESS = "SAVE_DOMAIN_SUCCESS";
export const SAVE_DOMAIN_ERROR = "SAVE_DOMAIN_ERROR";

export const EDIT_DOMAIN_RESET = "EDIT_DOMAIN_RESET";
export const EDIT_DOMAIN_LOADING = "EDIT_DOMAIN_LOADING";
export const EDIT_DOMAIN_SUCCESS = "EDIT_DOMAIN_SUCCESS";
export const EDIT_DOMAIN_ERROR = "EDIT_DOMAIN_ERROR";

export const DELETE_DOMAIN_RESET = "DELETE_DOMAIN_RESET";
export const DELETE_DOMAIN_LOADING = "DELETE_DOMAIN_LOADING";
export const DELETE_DOMAIN_SUCCESS = "DELETE_DOMAIN_SUCCESS";
export const DELETE_DOMAIN_ERROR = "DELETE_DOMAIN_ERROR";

// ACTION CREATORS
export const getDomainsProductLines = (domainsProductLines) => ({
  type: GET_DOMAINS_PRODUCT_LINES,
  domainsProductLines,
});
export const getDomainsProductLinesLoading = () => ({
  type: GET_DOMAINS_PRODUCT_LINES_LOADING,
});
export const getDomainsProductLinesError = (error) => ({
  type: GET_DOMAINS_PRODUCT_LINES_ERROR,
  error,
});

export const getDomainsProductsByProductLineId = (domainsProductsByProductLineId) => ({
  type: GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID,
  domainsProductsByProductLineId,
});
export const getDomainsProductsByProductLineIdLoading = () => ({
  type: GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_LOADING,
});
export const getDomainsProductsByProductLineIdError = (error) => ({
  type: GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR,
  error,
});

export const getDomainsApplicationsByProductId = (domainsApplicationsByProductId) => ({
  type: GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID,
  domainsApplicationsByProductId,
});
export const getDomainsApplicationsByProductIdLoading = () => ({
  type: GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_LOADING,
});
export const getDomainsApplicationsByProductIdError = (error) => ({
  type: GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR,
  error,
});

export const getDomainsByResourceId = (domains) => ({
  type: GET_DOMAINS_BY_RESOURCE_ID,
  domains,
});
export const getDomainsByResourceIdLoading = () => ({
  type: GET_DOMAINS_BY_RESOURCE_ID_LOADING,
});
export const getDomainsByResourceIdError = (error) => ({
  type: GET_DOMAINS_BY_RESOURCE_ID_ERROR,
  error,
});

export const saveDomainReset = () => ({
  type: SAVE_DOMAIN_RESET,
});
export const saveDomainLoading = () => ({
  type: SAVE_DOMAIN_LOADING,
});
export const saveDomainSuccess = (saveDomain) => ({
  type: SAVE_DOMAIN_SUCCESS,
  saveDomain,
});
export const saveDomainError = (error) => ({
  type: SAVE_DOMAIN_ERROR,
  error,
});

export const editDomainReset = () => ({
  type: EDIT_DOMAIN_RESET,
});
export const editDomainLoading = () => ({
  type: EDIT_DOMAIN_LOADING,
});
export const editDomainSuccess = (editDomain) => ({
  type: EDIT_DOMAIN_SUCCESS,
  editDomain,
});
export const editDomainError = (error) => ({
  type: EDIT_DOMAIN_ERROR,
  error,
});

export const deleteDomainReset = () => ({
  type: DELETE_DOMAIN_RESET,
});
export const deleteDomainLoading = () => ({
  type: DELETE_DOMAIN_LOADING,
});
export const deleteDomainSuccess = (deleteDomain) => ({
  type: DELETE_DOMAIN_SUCCESS,
  deleteDomain,
});
export const deleteDomainError = (error) => ({
  type: DELETE_DOMAIN_ERROR,
  error,
});

// THUNK CREATORS
export const getDomainsProductLinesThunk = () => async (dispatch) => {
  try {
    dispatch(getDomainsProductLinesLoading());
    const { data } = await roverSkillcentralURL.get(getDomainsProductLinesURL());
    dispatch(getDomainsProductLines(data));
  } catch (error) {
    console.log(error);
    dispatch(getDomainsProductLinesError(error));
  }
};

export const getDomainsProductsByProductLineIdThunk = (productLineId, callback) => async (
  dispatch
) => {
  try {
    dispatch(getDomainsProductsByProductLineIdLoading());
    const { data } = await roverSkillcentralURL.get(getDomainsProductsByProductLineIdURL(productLineId));
    if (callback) {
      callback(GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID);
    }
    dispatch(getDomainsProductsByProductLineId(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR);
    }
    dispatch(getDomainsProductsByProductLineIdError(error));
  }
};

export const getDomainsApplicationsByProductIdThunk = (productId,callback) => async (dispatch) => {
  try {
    dispatch(getDomainsApplicationsByProductIdLoading());
    const { data } = await roverSkillcentralURL.get(getDomainsApplicationsByProductIdURL(productId));
    if (callback) {
      callback(GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID);
    }
    dispatch(getDomainsApplicationsByProductId(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR);
    }
    dispatch(getDomainsApplicationsByProductIdError(error));
  }
};

export const getDomainsByResourceIdThunk = (resourceLanId) => async (dispatch) => {
  try {
    dispatch(getDomainsByResourceIdLoading());
    const { data } = await roverSkillcentralURL.get(getDomainsByUserURL(resourceLanId));
    // console.log("res domain -->", resourceLanId, data )
    dispatch(getDomainsByResourceId(data));
  } catch (error) {
    console.error(error);
    dispatch(getDomainsByResourceIdError(error));
  }
};

export const saveDomainThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(saveDomainLoading());
    const { data } = await roverSkillcentralURL.post(saveDomainURL(), payload);
    if (callback) {
      callback(SAVE_DOMAIN_SUCCESS, data);
    }
    dispatch(saveDomainSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(SAVE_DOMAIN_ERROR, error);
    }
    dispatch(saveDomainError(error));
  }
};

export const editDomainThunk = (payload, callback) => async (dispatch) => {
  try {
    dispatch(editDomainLoading());
    // const { data } = await roverSkillcentralURL.put(saveDomainURL(), payload);
    const { data } = await roverSkillcentralURL.put(editRMSkillURL(), payload);
    if (callback) {
      callback(EDIT_DOMAIN_SUCCESS, data);
    }
    dispatch(editDomainSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(EDIT_DOMAIN_ERROR, error);
    }
    dispatch(editDomainError(error));
  }
};

export const deleteDomainThunk = (peopleSkillId, managerId, callback) => async (dispatch) => {
  try {
    dispatch(deleteDomainLoading());
    const { data } = await roverSkillcentralURL.put(deleteRMSkillURL(peopleSkillId, managerId));
    if (callback) {
      callback(DELETE_DOMAIN_SUCCESS, data);
    }
    dispatch(deleteDomainSuccess(data));
  } catch (error) {
    console.error(error);
    if (callback) {
      callback(DELETE_DOMAIN_ERROR, error);
    }
    dispatch(deleteDomainError(error));
  }
};

// INITIAL STATE
export const domainInitialState = {
  domainsProductLines: {
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  domainsProductsByProductLineId: {
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  domainsApplicationsByProductId: {
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  currentDomains: {
    data: [],
    status: DATA_STATUS,
    response: {},
  },
  saveDomainStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  editDomainStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  deleteDomainStatus: {
    status: DATA_STATUS.INITIAL,
    response: {},
  },
  ratingOptions: [
    { id: 1, desc: "1 - Basic Knowledge" },
    { id: 2, desc: "2 - Limited Experience" },
    { id: 3, desc: "3 - Practical Application" },
    { id: 4, desc: "4 - Applied Theory" },
    { id: 5, desc: "5 - Recognized Authority" },
  ],
};

// REDUCERS
const DomainReducer = (state = domainInitialState, action) => {
  switch (action.type) {
    case GET_DOMAINS_PRODUCT_LINES_LOADING:
      return {
        ...state,
        domainsProductLines: {
          ...state.domainsProductLines,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DOMAINS_PRODUCT_LINES:
      return {
        ...state,
        domainsProductLines: {
          data:
            typeof action.domainsProductLines === "string" ? [] : [...action.domainsProductLines],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DOMAINS_PRODUCT_LINES_ERROR:
      return {
        ...state,
        domainsProductLines: {
          ...state.domainsProductLines,
          status: DATA_STATUS.errorState,
        },
      };
    case GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID:
      return {
        ...state,
        domainsProductsByProductLineId: {
          data:
            typeof action.domainsProductsByProductLineId === "string" ? [] : [...action.domainsProductsByProductLineId],
          status: DATA_STATUS.SUCCESS,
        },
        domainsApplicationsByProductId: {
          ...state.domainsApplicationsByProductId,
          data: []
        }
      };
    case GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_LOADING:
      return {
        ...state,
        domainsProductsByProductLineId: {
          ...state.domainsProductsByProductLineId,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DOMAINS_PRODUCTS_BY_PRODUCT_LINE_ID_ERROR:
      return {
        ...state,
        domainsProductsByProductLineId: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
        domainsApplicationsByProductId: {
          ...state.domainsApplicationsByProductId,
          data: []
        }
      };
    case GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID:
      // console.log(action.domainsApplicationsByProductId)
      return {
        ...state,
        domainsApplicationsByProductId: {
          data:
            typeof action.domainsApplicationsByProductId === "string" ? [] : [...action.domainsApplicationsByProductId],
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_LOADING:
      return {
        ...state,
        domainsApplicationsByProductId: {
          ...state.domainsApplicationsByProductId,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DOMAINS_APPLICATIONS_BY_PRODUCT_ID_ERROR:
      return {
        ...state,
        domainsApplicationsByProductId: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };

    case GET_DOMAINS_BY_RESOURCE_ID:
      return {
        ...state,
        currentDomains: {
          data: typeof action.domains === "string" ? [] : action.domains,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case GET_DOMAINS_BY_RESOURCE_ID_LOADING:
      return {
        ...state,
        currentDomains: {
          ...state.currentDomains,
          status: DATA_STATUS.LOADING,
        },
      };
    case GET_DOMAINS_BY_RESOURCE_ID_ERROR:
      return {
        ...state,
        currentDomains: {
          data: [],
          status: DATA_STATUS.ERROR,
          response: action.error,
        },
      };
    case SAVE_DOMAIN_RESET:
      return {
        ...state,
        saveDomainStatus: { ...domainInitialState.saveDomainStatus },
      };
    case SAVE_DOMAIN_LOADING:
      return {
        ...state,
        saveDomainStatus: {
          ...state.saveDomainStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case SAVE_DOMAIN_SUCCESS:
      return {
        ...state,
        saveDomainStatus: {
          ...state.saveDomainStatus,
          response: action.saveDomain,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case SAVE_DOMAIN_ERROR:
      return {
        ...state,
        saveDomainStatus: {
          ...state.saveDomainStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case EDIT_DOMAIN_RESET:
      return {
        ...state,
        editDomainStatus: { ...domainInitialState.editDomainStatus },
      };
    case EDIT_DOMAIN_LOADING:
      return {
        ...state,
        editDomainStatus: {
          ...state.editDomainStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case EDIT_DOMAIN_SUCCESS:
      return {
        ...state,
        editDomainStatus: {
          ...state.editDomainStatus,
          response: action.editDomain,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case EDIT_DOMAIN_ERROR:
      return {
        ...state,
        editDomainStatus: {
          ...state.editDomainStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    case DELETE_DOMAIN_RESET:
      return {
        ...state,
        deleteDomainStatus: { ...domainInitialState.deleteDomainStatus },
      };
    case DELETE_DOMAIN_LOADING:
      return {
        ...state,
        deleteDomainStatus: {
          ...state.deleteDomainStatus,
          status: DATA_STATUS.LOADING,
        },
      };
    case DELETE_DOMAIN_SUCCESS:
      return {
        ...state,
        deleteDomainStatus: {
          ...state.deleteDomainStatus,
          response: action.deleteDomain,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case DELETE_DOMAIN_ERROR:
      return {
        ...state,
        deleteDomainStatus: {
          ...state.deleteDomainStatus,
          response: action.error,
          status: DATA_STATUS.ERROR,
        },
      };
    default:
      return state;
  }
};

export default DomainReducer;
