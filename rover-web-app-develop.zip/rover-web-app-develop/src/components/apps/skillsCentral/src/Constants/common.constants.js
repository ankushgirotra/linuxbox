export const SC_SKILLS_TABS = {
    TECHNOLOGIES: "TECHNOLOGIES",
    COMPETENCIES: "COMPETENCIES",
    DOMAINS: "DOMAINS",
    METHODOLOGIES: "METHODOLOGIES",
  };
  
  export const SC_SKILLS_TABS_HASH_VALUE = [
  
    { key: "TECHNOLOGIES", hashValue: "technologies" },
  
    { key: "COMPETENCIES", hashValue: "competencies" },
  
    { key: "DOMAINS", hashValue: "domains" },
  
    { key: "METHODOLOGIES", hashValue: "methodologies" },
  
  ];