export const SKILL_CENTRAL_MESSAGES = {
  OUTDATE_SKILL: (period) =>
    `When a skill has not been modified in over ${period} month${
      Number(period) > 1 ? `s` : ``
    }, the skill is outdated. Click the skill to edit your expertise level or to confirm that no change needs to be made to your current expertise level.`,
};

export const NO_MENTOR_AVAILABLE_MESSAGE = {
  ERROR_MSG : (skillName) => `No mentors are available for ${skillName}, 
  please work with your Scrum Master and Resource Manager to get the help you need.`
};

