import React from "react";

export const NOTIFY_DELETED_SKILL_MSG = (skillName, expiryDate, skillType) => {
  return (
    <p style={{ textAlign: "justify" }}>
      {skillName === "" ? `This ${skillType}` : <b>{skillName}</b> } is no longer being tracked in 
      Skills Central. This record will be deleted from your profile on <b>{expiryDate}</b>. Please replace 
      this record with a new {skillType} if necessary.
    </p>
  )
};

export const ADMIN_DELETE_TECHNOLOGY_POPUP_MSG = (skillName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      Are you sure you want to delete {skillName ? <b>{skillName}</b> : "this Technology"}?
      This will remove this technology from any profile that has it saved.
    </p>
  )
};

export const ADMIN_DELETE_METHODOLOGY_POPUP_MSG = (skillName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      Are you sure you want to delete {skillName ? <b>{skillName}</b> : "this Methodology"}?
      This will remove this methodology from any profile that has it saved.
    </p>
  )
}

export const ADMIN_DELETE_ATTRITION_POPUP_MSG = (attritionName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      Are you sure you want to delete {attritionName ? <b>{attritionName}</b> : "this Attrition Option"}?
    </p>
  )
};

export const ADMIN_DELETE_DEPT_HEAD_POPUP_MSG = (deptName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      Are you sure you want to delete {deptName ? <b>{deptName}</b> : "this Department"}?
    </p>
  )
};

export const ADMIN_DELETE_VENDOR_POPUP_MSG = (vendorName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      Are you sure you want to delete {vendorName ? <b>{vendorName}</b> : "this Vendor"}?
    </p>
  )
};

export const SEARCH_HELP_MSG = () => {
  return (
    <p style={{ textAlign: "justify" }}>
      Select a technology in the dropdown below to receive a list of developers who have offered to help others with that technology.
    </p>
  )
};

export const MENTOR_MSG = () => {
  return (
    <p style={{ textAlign: "justify" }}>
      You are eligible to help others with any technology on your profile that has an expertise level of 3 or higher. Those technologies will appear in this list. If you want your name to appear when somebody seeks help with one of those technologies, check the box next to the technology name. Your name will not come up in search results for technologies that you leave unchecked.
      </p>
  )
};

export const ADMIN_DELETE_ROLE_POPUP_MSG = (roleName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      Are you sure you want to delete {roleName ? <b>{roleName}</b> : "this Role"}?
      This will remove this role from any profile that has it saved.
    </p>
  )
}

export const SKILL_CHANGE_SUBMISSION_MESSAGES = (resourceName, submissionType, skillType, skillName) => {
  return (
    <p style={{ textAlign: "justify" }}>
      {resourceName} has submitted an {submissionType} {skillType} request for {skillName}.
      Please review the submission in the <b>Pending Submissions</b> tab above to approve or deny.
    </p>
  )
}