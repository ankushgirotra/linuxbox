import GreenBelt from "../../../../../assets/images/belts/greenBelt@2x.png";
import BlueBelt from "../../../../../assets/images/belts/blueBelt@2x.png";
import BrownBelt from "../../../../../assets/images/belts/brownBelt@2x.png";
import BlackBelt from "../../../../../assets/images/belts/blackBelt@2x.png";

export const AdminfilterListOptions = [
  { id: 1, name: "Skills Configuration" },
  { id: 2, name: "Attrition Options" },
  { id: 3, name: "Departments" },
  { id: 4, name: "Manage Vendors" },
  { id: 5, name: "Manage Roles" },
  { id: 6, name: "Automation Jobs Control" },
  { id: 7, name: "Manage One-Rate" },
  { id: 8, name: "Manage Email Notification" },
  { id: 9, name: "Generate Reports" },
];

export const resourceTypeOptions = [
  { id: 1, name: "Employee" },
  { id: 2, name: "Contractor" },
];

export const attritionPenaltyOptions = [
  { id: 1, name: "Penalty Applicable" },
  { id: 2, name: "No Penalty Applicable" },
];

export const vendorTierOptions = [
  { id: 1, name: "Tier 1" },
  { id: 2, name: "Tier 2" },
  { id: 3, name: "Tier 3" },
];

export const sampleRoleData = [
  { role: 1, department: "ADC" },
  { role: 2, department: "ADC" },
  { role: 3, department: "ITQA" },
  { role: 4, department: "ITQA" },
  { role: 4, department: "DEVOPS" },
  { role: 6, department: "DEVOPS" },
];

export const sampleJobTitleData = [
  { jobTitleId: 1, jobTitle: "Developer",role: 1, department: "ADC", belt: "blue"},
  { jobTitleId: 2, jobTitle: "Senior Developer",role: 1, department: "ADC", belt: "brown"},
  { jobTitleId: 3, jobTitle: "Specialist Developer",role: 1, department: "ADC", belt: "black"},  
  { jobTitleId: 4, jobTitle: "Quality Analyst",role: 2, department: "ITQA", belt: "green"},
];

export const resourcesBeltOptions = [
  { id: 1, value: "N/A", src: "" },
  { id: 2, value: "Green", src: GreenBelt },
  { id: 3, value: "Blue", src: BlueBelt },
  { id: 4, value: "Brown", src: BrownBelt },
  { id: 5, value: "Black", src: BlackBelt },
];

export const isActiveOptions = [
  { id: 1, name: "Yes" },
  { id: 2, name: "No" },
];

export const expertiseLevelConditionOptions = [
  { id: 1, name: "Is equal to" },
  { id: 2, name: "Is at least" },
];

export const dummyAttritionData = [
  { employeeId: 1, employeeName: "ABC" },
  { employeeId: 2, employeeName: "DEF" },
  { employeeId: 3, employeeName: "GHI" },
  { employeeId: 4, employeeName: "JKL" },
  { employeeId: 5, employeeName: "MNO" },
  { employeeId: 6, employeeName: "PQR" },
  { employeeId: 7, employeeName: "STU" },
  { employeeId: 8, employeeName: "VWX" },
  { employeeId: 9, employeeName: "XYZ" },
];

export const dummyFeedbackRequestData =
{
  feedbackBy: "Donald Rich",
  date: "3/12/2022",
  status: "Completed",
  comments: "Please Provide Feedback for",
  commentsList: [
    { technology: "JavaScript", expertiseLevel: "3", comments: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua" },
    { technology: "Java", expertiseLevel: "2", comments: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua" },
    { technology: "MySQL", expertiseLevel: "1", comments: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua" }
  ],
};

export const advanceSearchKey = [
  { id: 1, value: "Technology", placeholderText: "technology", skillTypeId: 3 },
  { id: 2, value: "Methodology", placeholderText: "methodology", skillTypeId: 2 },
  { id: 3, value: "Domain", placeholderText: "product", skillTypeId: 4 },
  { id: 4, value: "Competency", placeholderText: "competency", skillTypeId: 1 },
  { id: 5, value: "Resource Type", placeholderText: "resource type", skillTypeId: null },
  { id: 6, value: "Resource Name", placeholderText: "", skillTypeId: null },
  { id: 7, value: "Role", placeholderText: "role", skillTypeId: null },
  { id: 8, value: "Job Title", placeholderText: "Job title", skillTypeId: null },
  { id: 9, value: "Manager", placeholderText: "manager", skillTypeId: null },
]

export const advanceSearchValue = [
  { id: 1, attrId: "skillId", attrValue: "skillName" },
  { id: 2, attrId: "skillId", attrValue: "skillName" },
  { id: 3, attrId: "id", attrValue: "name" },
  { id: 4, attrId: "skillId", attrValue: "skillName" },
  { id: 5, attrId: "id", attrValue: "name" },
  { id: 6, attrId: "id", attrValue: "name" },
  { id: 7, attrId: "roleId", attrValue: "roleName" },
  { id: 8, attrId: "jobTitleId", attrValue: "jobTitle" },
  { id: 9, attrId: "managerId", attrValue: "managerName" },
]