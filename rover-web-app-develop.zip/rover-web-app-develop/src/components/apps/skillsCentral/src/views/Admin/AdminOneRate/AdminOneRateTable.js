import React, { useMemo } from "react";
import { PlusCircle } from "react-feather";
import sortBy from "../../../../../../../services/helper.service";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { SC_ADMIN_ACTIONS } from "../../../Constants/action.constants";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../pcdm/src/components/DataGrid/dataGrid";

export default function AdminOneRateTable(props) {

  const { oneRate, onAddorEditAdminOneRate } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => yearHead(),
      accessor: "year",
      Cell: ({ row: { original } }) => showYear(original, "year"),
      disableFilters: true,
    },
    {
      Header: "One-Rate",
      accessor: "oneRate",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Blended Rate",
      accessor: "blendedRate",
      disableFilters: true,
      disableSortBy: true,
    },
  ]);

  const yearHead = () => {
    return (
      <div className="add-attrition-head">
        <p>Year</p>
        <CustomButton
          onClick={(e) => {
            e.stopPropagation(); // --> to disable sort on click of this button
            onAddorEditAdminOneRate(SC_ADMIN_ACTIONS.ADD_ONE_RATE, {});
          }}
          title={"Click to add One-Rate"}
          className="attrition-add-link"
        >
          <span className="mr-2">ADD</span>
          <PlusCircle size="15" strokeWidth={3} />
        </CustomButton>
      </div>
    );
  };

  const showYear = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() => {onAddorEditAdminOneRate(SC_ADMIN_ACTIONS.EDIT_ONE_RATE,{...row})}
        }
      >
        {row[key]}
      </LinkExtended>
    );
  };

const data = oneRate.data;

  return (
    <>
      <OverlayLoader
        loading={oneRate.status === DATA_STATUS.LOADING}
      />
      <div className="admin-attrition-table-container pcdm-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          noRowText={"Click + icon to add one-rate"}
        />
      </div>
    </>
  );
}

