import React, { Component } from "react";
import { connect } from "react-redux";
import {
  addManageVendorThunk,
  editManageVendorThunk,
  deleteManageVendorThunk,
  getAdminManageVendorNumNamesThunk,
} from "../../../store/admin.reducer";
import { validateAdminForm } from "../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, ACTIONS } from "../../../Constants/action.constants";
import { vendorTierOptions as tierOptions } from "../../../Constants/listOptions.constants";
import { ADMIN_DELETE_VENDOR_POPUP_MSG } from "../../../Constants/toolTip.messages";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import {
  DEFAULT_MSG_MODAL_CONFIG,
  MessageModal,
} from "../../../../../pcdm/src/components/MessageModal/messageModal";
import CustomButton, {
  BUTTON_VARIANTS,
} from "../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../pcdm/src/components/forms/textField/textField";
import CheckBox from "../../../../../pcdm/src/components/forms/Checkbox/checkbox";
import "../admin.scss";
import "./adminManageVendor.scss";
import SelectDropdown from "../../../../../../shared/components/forms/SelectDropdown/selectDropdown";

const ADMIN_VENDOR_INITIAL_STATE = {
  customValue: "",
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  isActive: false,
  isEdited: false,
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    vendor: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    tier: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
  },
};

class AdminManageVendorForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_VENDOR_INITIAL_STATE };
  }

  componentDidMount = async () => {
    const { formMode, selectedVendor, getVendorNumNames } = this.props;
    await getVendorNumNames(selectedVendor.vendorNumber)
    if (formMode === SC_ADMIN_ACTIONS.EDIT_VENDOR) {
      this.populateFileds(selectedVendor);
    }
  }

  populateFileds = (vendor) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        vendor: {
          ...formControls.vendor,
          value: vendor.vendorName,
        },
        tier: {
          ...formControls.tier,
          value: vendor.tier,
        },
      },
      isActive: vendor.active,
    });
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      isEdited: true,
      formControls: {
        ...formControls,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  onIsActiveCheck = (e) => {
    const { isActive } = this.state;
    this.setState({
      isActive: !isActive,
      isEdited: true,
    });
  };

  reqPayload = () => {
    const { formControls, isActive } = this.state;
    let payload = {
      vendorName: formControls.vendor.value,
      tier: formControls.tier.value,
      active: isActive ? 1 : 0,
    };
    return payload;
  };

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const {
      formMode,
      closeModal,
      addVendor,
      selectedVendor,
      editVendor,
    } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === SC_ADMIN_ACTIONS.ADD_VENDOR) {
        await addVendor(payload, closeModal);
      } else if (formMode === SC_ADMIN_ACTIONS.EDIT_VENDOR) {
        await editVendor(selectedVendor.vendorId, payload, closeModal);
      }
    }
  };

  onDeleteClick = () => {
    const { selectedVendor } = this.props;
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: ADMIN_DELETE_VENDOR_POPUP_MSG(selectedVendor.vendorName),
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };

  handleDelete = async (button, data) => {
    const { selectedVendor, closeModal } = this.props;
    const { messageModalConfig } = this.state;
    if (button === ACTIONS.YES) {
      await this.props.deleteVendor(selectedVendor.vendorId, closeModal);
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    }
  };

  getHeader = () => {
    const { formMode } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.ADD_VENDOR) {
      return "Add Vendor";
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_VENDOR) {
      return "Edit Vendor";
    }
  };

  handleInputChange = (val) => {
    if (val.length > 0) {
      this.setState({ customValue: val });
    }
  };
  getAdminManageVendorForm = () => {
    const { formControls, customValue } = this.state;
    const { formMode, selectedVendor, vendorNumNames } = this.props;
    // const newElement = customValue && 
    //   vendorNumNames.data.findIndex(ele => ele == customValue) < 0 && 
    //   selectedVendor.vendorName != customValue ? customValue  : null;
    const ele = vendorNumNames.data.findIndex(ele => ele == selectedVendor.vendorName)
    // const nameOptions = !ele ? [selectedVendor.vendorName, ...vendorNumNames.data] : [...vendorNumNames.data]
    const nameOptions = selectedVendor.numNames > 1 ? 
     ele < 0 ? [selectedVendor.vendorName, ...vendorNumNames.data] 
     : [...vendorNumNames.data] 
     : [selectedVendor.vendorName]
    nameOptions.sort()
    const newElement = customValue && 
      nameOptions.findIndex(ele => ele == customValue) < 0 ? customValue  : null;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          {formMode === SC_ADMIN_ACTIONS.ADD_VENDOR ? (
            <div className="pcdm-form__form-group-field">
              <TextField
                name="vendor"
                label={"Vendor"}
                type="text"
                formObj={formControls.vendor}
                isRequired={formControls.vendor.required}
                onChange={this.onInputChange}
              />
            </div>
          ) : (
            <div className={selectedVendor.numNames > 1 ? `pcdm-form__form-group-field`: 'pcdm-form__form-group-field pcdm-form__form-group-field-disabled'} >
              <SelectDropdown
                name="vendor"
                label={"Vendor"}
                formObj={formControls.vendor}
                isRequired={formControls.vendor.required}
                config={{
                  options: newElement
                    ? [newElement, ...nameOptions]
                    : [...nameOptions],
                }}
                onChange={(e) =>
                  this.onInputChange({
                    target: { name: e.name, value: e.value },
                  })
                }
                onInputChange={(val) => this.handleInputChange(val)}
              />
            </div>
          )}

          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="tier"
              label={"Tier"}
              formObj={formControls.tier}
              isRequired={formControls.tier.required}
              config={{
                options: newElement
                  ? [newElement, ...tierOptions]
                  : [...tierOptions],
                id: "id",
                value: "name",
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
          <div
            className={`pcdm-form__form-group-field admin-vendor_checkbox-container`}
          >
            <CheckBox
              className="admin-vendor_active-check"
              label={"Active"}
              checked={this.state.isActive}
              onChange={this.onIsActiveCheck}
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { isEdited } = this.state;
    const { closeModal, formMode } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!isEdited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        {formMode === SC_ADMIN_ACTIONS.EDIT_VENDOR ? (
          <CustomButton
            variant={BUTTON_VARIANTS.ERROR}
            onClick={this.onDeleteClick}
            size="md"
          >
            Delete
          </CustomButton>
        ) : (
          <CustomButton
            disable={false}
            loading={false}
            variant={BUTTON_VARIANTS.LIGHT}
            onClick={() => closeModal()}
            size="md"
            type={"button"}
          >
            Cancel
          </CustomButton>
        )}
      </div>
    );
  };

  render() {
    const {
      formVisible,
      closeModal,
      addVendorStatus,
      editVendorStatus,
      deleteVendorStatus,
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          className="sc-admin-manage_vendor-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={() => this.getAdminManageVendorForm()}
          footer={() => this.getFooter()}
          isLoading={
            addVendorStatus.status === DATA_STATUS.LOADING ||
            editVendorStatus.status === DATA_STATUS.LOADING ||
            deleteVendorStatus.status === DATA_STATUS.LOADING
          }
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  addVendorStatus: state.SkillsCentralAdmin.addVendorStatus,
  editVendorStatus: state.SkillsCentralAdmin.editVendorStatus,
  deleteVendorStatus: state.SkillsCentralAdmin.deleteVendorStatus,
  vendorNumNames: state.SkillsCentralAdmin.vendorNumNames,
});

const mapDispatchToProps = (dispatch) => ({
  addVendor: (addVendorFormData, callback) =>
    dispatch(addManageVendorThunk(addVendorFormData, callback)),
  editVendor: (vendorId, editVendorFormData, callback) =>
    dispatch(editManageVendorThunk(vendorId, editVendorFormData, callback)),
  deleteVendor: (vendorId, callback) =>
    dispatch(deleteManageVendorThunk(vendorId, callback)),
  getVendorNumNames: (vendorNumber) => dispatch(getAdminManageVendorNumNamesThunk(vendorNumber))  
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AdminManageVendorForm);
