import React, { Component } from "react";
import { connect } from "react-redux";
import { addAdminCategoryThunk } from "../../../../store/admin.reducer";
import { validateAdminForm } from "../../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, SC_ADMIN_ACTION_TYPE } from "../../../../Constants/action.constants";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { ACTIONS } from "../../../../../../pcdm/src/constants/action.constants";
import { FormModal } from "../../../../../../pcdm/src/components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../../pcdm/src/components/forms/Button/button";
import TextField from "../../../../../../pcdm/src/components/forms/textField/textField";
import ErrorMsg from "../../../../../../pcdm/src/components/forms/errorMsg/errorMsg";
import "../adminSkillConfiguration.scss";

const ADMIN_CATEGORY_INITIAL_STATE = {
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    category: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
  },
};

class AdminCategoryForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_CATEGORY_INITIAL_STATE };
  }

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };


  reqPayload = () => {
    const { formControls } = this.state;
    const { formMode } = this.props;
    let payload = {};
    if (formMode === SC_ADMIN_ACTIONS.ADD_CATEGORY) {
      payload = {
        description: formControls.category.value,
      };
    }
    return payload;
  };

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode } = this.props;
    let validation = validateAdminForm(formControls);

    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === SC_ADMIN_ACTIONS.ADD_CATEGORY) {
        await this.props.addAdminCategory(payload, (status, data) => {
          if (status === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_CATEGORY_SUCCESS) {
            this.props.closeModal(ACTIONS.SUCCESS, {
              message: "Add Category updated successfully",
            });
          } else if (status === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_CATEGORY_ERROR) {
            let errMsg = data && data.response && data.response.data ? data.response.data : "Error in adding Category"
            this.props.closeModal(ACTIONS.ERROR, {
              message: errMsg,
            });
          }
        });
      }
    }
  };

  getAdminCategoryForm = () => {
    const { formControls } = this.state;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="category"
              label={"Category Name"}
              formObj={formControls.category}
              isRequired={formControls.category.required}
              onChange={this.onInputChange}
            />
          </div>
        </div>
        {formControls.error ? (
          <ErrorMsg message={formControls.errorMessage} errorDetail={formControls.errorDetail} />
        ) : null}
      </form>
    );
  };

  getFooter = () => {
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          onClick={() => {
            this.onSubmit();
          }}
        >
          Save
        </CustomButton>
      </div>
    );
  };

  render() {
    const { formVisible, closeModal, header, addAdminCategoryStatus } = this.props;
    return (
      <>
        <FormModal
          isLoading={addAdminCategoryStatus.status === DATA_STATUS.LOADING}
          visible={formVisible}
          closeModal={() => closeModal()}
          header={header}
          footer={() => this.getFooter()}
          content={this.getAdminCategoryForm()}
          className="add-admin_category-form"
        />
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    addAdminCategoryStatus: state.SkillsCentralAdmin.addAdminCategoryStatus,
  };
};

const mapDispatchToProps = (dispatch) => ({
  addAdminCategory: (categoryAdminFormData, callback) =>
    dispatch(addAdminCategoryThunk(categoryAdminFormData, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminCategoryForm);
