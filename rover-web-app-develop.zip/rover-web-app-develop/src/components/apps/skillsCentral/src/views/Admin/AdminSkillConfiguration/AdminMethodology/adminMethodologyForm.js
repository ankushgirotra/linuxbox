import React, { Component } from "react";
import { connect } from "react-redux";
import { saveAdminMethodologyThunk } from "../../../../store/admin.reducer";
import { editAdminMethodologyThunk, deleteAdminMethodologyThunk } from "../../../../store/admin.reducer";
import { validateAdminForm, handleAdminMethodologyAPIResponse } from "../../../../Services/admin.service";
import sortBy from "../../../../../../../../services/helper.service";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import { FORM_CONTROL_DEFAULT } from "../../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, ACTIONS, SKILL_TYPE, RESOURCE_TYPE_ID } from "../../../../Constants/action.constants";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../../pcdm/src/components/FormModal/formModal";
import { DEFAULT_MSG_MODAL_CONFIG, MessageModal } from "../../../../../../pcdm/src/components/MessageModal/messageModal";
import { ADMIN_DELETE_METHODOLOGY_POPUP_MSG } from "../../../../Constants/toolTip.messages";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../../pcdm/src/components/forms/Button/button";
import TextField from "../../../../../../pcdm/src/components/forms/textField/textField";
import CustomSelect from "../../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import "./../adminSkillConfiguration.scss";


const ADMIN_METHODOLOGY_INITIAL_STATE = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    methodologyName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    departmentId: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
  },
};

class AdminMethodologyForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_METHODOLOGY_INITIAL_STATE };
  }

  componentDidMount() {
    const { formMode, selectedMethodology } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.EDIT_METHODOLOGY) {
      this.populateFileds(selectedMethodology);
    }
  }

  populateFileds = (selectedMethodology) => {
    const { formControls } = this.state;
    let departmentValue = this.getDeptFieldValue(selectedMethodology.department); 
    this.setState({
      formControls: {
        ...formControls,
        methodologyName: {
          ...formControls.methodologyName,
          value: selectedMethodology.skillName,
        },
        departmentId:{
          ...formControls.methodologyName,
          value: departmentValue,
        },
      },
    });
  };

  getDeptFieldValue = (deptList) => {
    let deptListValue = deptList && deptList.length ? deptList.map((dept) => ({
      label: dept.abbreviation,
      value: dept.departmentId
    })) : [];
    return deptListValue;
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    const { userParams } = this.props;
    let deptInfoList = formControls.departmentId.value
    let deptIdList = deptInfoList && deptInfoList.length ? deptInfoList.map((dept) => dept.value) : [];
    let empId = localStorage.getItem('emplyoee_id')
    let payload = {
      skillName: formControls.methodologyName.value,
      resourceTypeId: RESOURCE_TYPE_ID.BOTH_EMP_AND_CONTR,
      resourceId: empId ? empId : getFormattedUserId(userParams),
      skillType: SKILL_TYPE.METH,
      skillSubcategoryId: null,
      isSpecializedTechnology: false,
      isMainTechnology: false,
      departmentId: deptIdList,
    };
    return payload;
  };

  onSubmit = async (e) => {
    if (e) e.preventDefault();
    const { formControls } = this.state;
    const { formMode, addAdminMethodology, editAdminMethodology,selectedMethodology } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === SC_ADMIN_ACTIONS.ADD_METHODOLOGY) {
        await addAdminMethodology(payload, this.handleResponse);
      } else if (formMode === SC_ADMIN_ACTIONS.EDIT_METHODOLOGY) {
        await editAdminMethodology(selectedMethodology.skillId, payload, this.handleResponse);
      }
    }
  };

  onDeleteClick = () => {
    const { selectedMethodology } = this.props;
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: ADMIN_DELETE_METHODOLOGY_POPUP_MSG(selectedMethodology.skillName),
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };

  handleDelete = async (button) => {
    const { selectedMethodology,deleteAdminMethodology,userParams } = this.props;
    const { messageModalConfig } = this.state;
    if (button === ACTIONS.YES) {
      let empId = localStorage.getItem('emplyoee_id')
      let id = empId ? empId : getFormattedUserId(userParams)
      await deleteAdminMethodology(selectedMethodology.skillId, id, this.handleResponse);
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    }
  };

  handleResponse = (responseType, responseData) => {
    let { modal } = handleAdminMethodologyAPIResponse(responseType, responseData);
    if(modal) this.props.closeModal(modal.action, modal.props); 
  };

  getAdminMethodologForm = () => {
    const { formControls } = this.state;
    const { deptHeads } = this.props;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="methodologyName"
              label={"Methodology"}
              type="text"
              formObj={formControls.methodologyName}
              isRequired={formControls.methodologyName.required}
              onChange={this.onInputChange}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="departmentId"
              label={"Departments"}
              formObj={formControls.departmentId}
              isRequired={formControls.departmentId.required}
              isMulti={true}
              config={{
                options: deptHeads && deptHeads.length ? [...sortBy(deptHeads, "abbreviation")] : [],
                id: "departmentId",
                value: "abbreviation",
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formMode } = this.props;
    const { formControls } = this.state;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        {formMode === SC_ADMIN_ACTIONS.EDIT_METHODOLOGY ? (
          <CustomButton
            disable={formControls.edited}
            variant={BUTTON_VARIANTS.ERROR}
            onClick={this.onDeleteClick}
            size="md"
          >
            Delete
          </CustomButton>
        ) : null}
      </div>
    );
  };

  render() {
    const {
      formVisible,
      closeModal,
      header,
      saveAdminMethodologyStatus,
      editAdminMethodologyStatus,
      deleteAdminMethodologyStatus
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          className="add-admin_methodology-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          footer={() => this.getFooter()}
          header={header}
          content={this.getAdminMethodologForm()}
          isLoading = {
            saveAdminMethodologyStatus === DATA_STATUS.LOADING ||
            editAdminMethodologyStatus === DATA_STATUS.LOADING ||
            deleteAdminMethodologyStatus === DATA_STATUS.LOADING 
          }
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    saveAdminMethodologyStatus: state.SkillsCentralAdmin.saveAdminMethodologyStatus.status,
    editAdminMethodologyStatus: state.SkillsCentralAdmin.editAdminMethodologyStatus.status,
    deleteAdminMethodologyStatus: state.SkillsCentralAdmin.deleteAdminMethodologyStatus.status,
    deptHeads: state.SkillsCentralAdmin.deptHeads.data,
    userParams: state.AuthReducer.user,
  }
}

const mapDispatchToProps = (dispatch) => ({
  addAdminMethodology: (payload, callback) =>
    dispatch(saveAdminMethodologyThunk(payload, callback)),
  editAdminMethodology: (skillId,payload, callback) =>
    dispatch(editAdminMethodologyThunk(skillId,payload, callback)),
  deleteAdminMethodology: (skillId,resourceId, callback) =>
    dispatch(deleteAdminMethodologyThunk(skillId,resourceId, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminMethodologyForm);
