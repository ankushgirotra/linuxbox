import React, { useMemo } from "react";
import sortBy from "../../../../../../../services/helper.service";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import DataGrid from "../../../../../pcdm/src/components/DataGrid/dataGrid";
import "./adminDeptHeads.scss";
import { isActiveOptions } from "../../../Constants/listOptions.constants";

export default function AdminDeptManagersTable(props) {

    const { deptManagers, onEditAdminDeptManager } = props;

    const columns = useMemo(() => [
        {
            Header: "Name",
            accessor: "rmFullName",
            disableFilters: true,
            disableSortBy: true,
        },
        {
            Header: "isActive",
            Cell: ({ row: { original } }) => showIsActive(original, "active"),
            accessor: "active",
            disableFilters: true,
            disableSortBy: true,
        },
        {
            Header: "Action",
            Cell: ({ row: { original } }) => showActionMessage(original, "actionMessage"),
            accessor: "actionMessage",
            disableFilters: true,
            disableSortBy: true,
        },
    ]);

    const showActionMessage = (row, key) => {
        return (
            <LinkExtended
                className="td-product"
                onClick={() => { onEditAdminDeptManager(row) }
                }
            >
                {row.actionMessage}
            </LinkExtended>
        );
    };

    const showIsActive = (row, key) => {
        return row && row[key] ? isActiveOptions[0].name : isActiveOptions[1].name;
      };

      const data = useMemo(() => [...sortBy(deptManagers.data, "rmFullName")], [deptManagers]);

    return (
        <>
            <OverlayLoader
                loading={deptManagers.status === DATA_STATUS.LOADING}
            />
            <div className="admin-dept_heads-table-container pcdm-scroll-vertical">
                <DataGrid
                    data={data}
                    columns={columns}
                    noRowText={"No Data Found"}
                />
            </div>
        </>
    );
}

