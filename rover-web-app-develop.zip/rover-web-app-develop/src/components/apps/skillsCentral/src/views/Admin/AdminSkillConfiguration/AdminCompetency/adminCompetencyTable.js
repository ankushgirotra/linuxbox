import React, { useMemo } from "react";
import { PlusCircle } from "react-feather";
import { DATA_STATUS, SC_ADMIN_ACTIONS } from "../../../../Constants/action.constants";
import sortBy from "../../../../../../../../services/helper.service";
import { OverlayLoader } from "../../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../../pcdm/src/components/DataGrid/dataGrid";
import "../adminSkillConfiguration.scss";
import "./adminCompetency.scss";

export default function AdminCompetencyTable(props) {

  const { adminCompetenciesList, onAddorEditAdminCompetency } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => competencyHead(),
      accessor: "skillName",
      Cell: ({ row: { original } }) => showCompetency(original, "skillName"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Resource Type",
      accessor: "resourceType",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Departments",
      accessor: "department",
      Cell: ({ row: { original } }) => showDept(original, "department"),
      disableFilters: true,
      disableSortBy: true,
    },
  ]);

  const showDept = (row, key) => {
    let deptList = row && row[key] && row[key].length ? row[key].map((comp) => comp.abbreviation) : [];
    return <span title={deptList.toString()}> {deptList.join("; ")} </span>;
  };


  const competencyHead = () => {
    return (
      <div className="add-competency_skill-head">
        <p>Competency</p>
        <CustomButton
          onClick={() => onAddorEditAdminCompetency(SC_ADMIN_ACTIONS.ADD_COMP, {})}
          title={"Click to add competency"}
          className="add_skill-link"
        >
          <span className="mr-2">ADD</span>
          <PlusCircle size="15" strokeWidth={3} />
        </CustomButton>
      </div>
    );
  };

  const getCompetencyData = (arr) => {
    let result = arr.length ? arr : [];
    return result;
  }

  const showCompetency = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() =>
          onAddorEditAdminCompetency(SC_ADMIN_ACTIONS.EDIT_COMP, { ...row })
        }
      >
        {row[key]}
      </LinkExtended>
    );
  };

  const data = useMemo(() => [...sortBy(getCompetencyData(adminCompetenciesList.data), "skillName")], [adminCompetenciesList]);

  return (
    <>
      <OverlayLoader loading={adminCompetenciesList.status === DATA_STATUS.LOADING} />
      <div className="sc-admin-competency_table-container pcdm-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          hideObjectTitle={true}
          noRowText={"Click + icon to start adding Competency"}
        />
      </div>
    </>
  );
}
