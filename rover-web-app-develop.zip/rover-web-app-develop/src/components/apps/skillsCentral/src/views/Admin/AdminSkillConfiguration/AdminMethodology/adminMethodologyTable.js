import React, { useMemo } from "react";
import { PlusCircle } from "react-feather";
import sortBy from "../../../../../../../../services/helper.service";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { SC_ADMIN_ACTIONS } from "../../../../Constants/action.constants";
import { OverlayLoader } from "../../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../../pcdm/src/components/DataGrid/dataGrid";
import "./../adminSkillConfiguration.scss";
import "./adminMethodology.scss";

export default function AdminMethodologyTable(props) {

  const { methodologiesList ,onAddorEditAdminMethodology } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => methodologyHead(),
      accessor: "skillName",
      Cell: ({ row: { original } }) => showMethodology(original, "skillName"),
      disableFilters: true,
    },
    {
      Header: "Departments",
      accessor: "department",
      Cell: ({ row: { original } }) => showDept(original, "department"),
      disableFilters: true,
      disableSortBy: true,
    },  
  ]);

  const showDept = (row, key) => {
    let deptList = row && row[key] && row[key].length ? row[key].map((comp) => comp.abbreviation) : [];
    return <span title={deptList.toString()}> {deptList.join("; ")} </span>;
  };

  const methodologyHead = () => {
    return (
      <div className="add-methodology_skill-head">
        <p>Methodology</p>
        <CustomButton
          onClick={(e) => {
            e.stopPropagation()
            onAddorEditAdminMethodology(SC_ADMIN_ACTIONS.ADD_METHODOLOGY, {})
          }}
          title={"Click to add methodology"}
          className="add_skill-link"
        >
          <span className="mr-2">ADD</span>
          <PlusCircle size="15" strokeWidth={3} />
        </CustomButton>
      </div>
    );
  };

  const showMethodology = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() =>
          onAddorEditAdminMethodology(SC_ADMIN_ACTIONS.EDIT_METHODOLOGY, { ...row })
        }
      >
        {row[key]}
      </LinkExtended>
    );
  };

  const data = useMemo(() => [...sortBy(methodologiesList.data, "skillName")] , [methodologiesList]);

  return (
    <>
      <OverlayLoader
        loading={methodologiesList.status === DATA_STATUS.LOADING}
      />
      <div className="sc-admin-methodology_table-container pcdm-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          hideObjectTitle={true}
          noRowText={"Click + icon to start adding methodology"}
        />
      </div>
    </>
  );
}

