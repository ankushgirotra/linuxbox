import React, { useState } from "react";
import { connect } from "react-redux";
import { getOneRateThunk } from "../../../store/admin.reducer";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS, SC_ADMIN_ACTION_TYPE } from "../../../Constants/action.constants";
import { ACTIONS } from "../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../pcdm/src/constants/message.contants";
import Toaster from "../../../../../pcdm/src/components/Toaster/toaster";
import "../admin.scss";
import AdminOneRateTable from "./AdminOneRateTable";
import AdminOneRateForm from "./AdminOneRateForm";

function AdminOneRate(props) {

  const { showNotification, getOneRate, oneRate } = props;

  const [showAdminOneRateForm, setShowAdminOneRateForm] = useState(false);

  const [adminOneRateFormMode, setAdminOneRateFormMode] = useState("");

  const [selectedOneRate, setSelectedOneRate] = useState({})
 
  const onAddorEditAdminOneRate = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_ONE_RATE) {
      setShowAdminOneRateForm(true);
      setAdminOneRateFormMode(SC_ADMIN_ACTIONS.ADD_ONE_RATE);
      setSelectedOneRate({})
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ONE_RATE) {
      setShowAdminOneRateForm(true);
      setAdminOneRateFormMode(SC_ADMIN_ACTIONS.EDIT_ONE_RATE);
      setSelectedOneRate(data)
    }
  };

  const onModalClose = (status, responseData, keepModal = false) => {
    let isAddForm = adminOneRateFormMode === SC_ADMIN_ACTIONS.ADD_ONE_RATE;

    if (
      status === SC_ADMIN_ACTION_TYPE.ADD_ONE_RATE_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_ONE_RATE_SUCCESS
    ) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: isAddForm ? "One-Rate added successfully" : "One-Rate updated successfully",
      });
      getOneRate();
      setShowAdminOneRateForm(false);
    }else if (
      status === SC_ADMIN_ACTION_TYPE.ADD_ONE_RATE_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (!keepModal || showAdminOneRateForm) {
      setShowAdminOneRateForm(false);
    }
  };
  

  return (
    <div className='admin-container sc-admin-attrition-container'>
      <AdminOneRateTable
        onAddorEditAdminOneRate={onAddorEditAdminOneRate}
        oneRate={oneRate}
      />
      {showAdminOneRateForm ? (
        <AdminOneRateForm
          formVisible={showAdminOneRateForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          formMode={adminOneRateFormMode}
          selectedOneRate={selectedOneRate}
        />
      ) : null}
      <Toaster />
    </div>
  );
}

const mapStateToProps = (state) => ({
  oneRate: state.SkillsCentralAdmin.oneRate,
});

const mapDispatchToProps = (dispatch) => ({
    showNotification: (notification) => dispatch(addNotification(notification)),
    getOneRate: () => dispatch(getOneRateThunk()),  
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminOneRate);
