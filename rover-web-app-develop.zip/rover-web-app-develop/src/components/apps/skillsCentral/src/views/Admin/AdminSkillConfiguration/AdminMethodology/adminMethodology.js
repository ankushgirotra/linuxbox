import React, { useState } from "react";
import { connect } from "react-redux";
import { getMethodologiesThunk } from "../../../../store/methodologies.reducer";
import { addNotification } from "../../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS } from "../../../../Constants/action.constants";
import { ERROR_MSG } from "../../../../../../pcdm/src/constants/message.contants";
import { ACTIONS } from "../../../../../../pcdm/src/constants/action.constants";
import AdminMethodologyTable from "./adminMethodologyTable";
import AdminMethodologyForm from "./adminMethodologyForm";
import "./adminMethodology.scss";

function AdminMethodologyTab(props) {

  const { methodologies ,getAdminMethodology, showNotification} = props;

  const [skillCentralAdminFormMode, setSkillCentralAdminFormMode] = useState("");

  const [showAdminMethodologyForm, setShowAdminMethodologyForm] = useState(false);
  
  const [selectedMethodology, setSelectedMethodology ] = useState({});

  const onAddorEditAdminMethodology = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_METHODOLOGY) {
      setShowAdminMethodologyForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.ADD_METHODOLOGY);
      setSelectedMethodology({});
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_METHODOLOGY) {
      setShowAdminMethodologyForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.EDIT_METHODOLOGY);
      setSelectedMethodology({ ...data });
    }
  };

  const getMethodologyHeader = () => {
    if (skillCentralAdminFormMode === SC_ADMIN_ACTIONS.ADD_METHODOLOGY) {
      return "Add Methodology";
    } else if (skillCentralAdminFormMode === SC_ADMIN_ACTIONS.EDIT_METHODOLOGY) {
      return "Edit Methodology";
    }
  };

  const onModalClose = (status, data) => {
    if (status === ACTIONS.SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      if (showAdminMethodologyForm) {
        getAdminMethodology();
        setShowAdminMethodologyForm(false);
      }    
    } else if (status === ACTIONS.ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: data && data.message ? data.message : ERROR_MSG.COMMON_FORM_ERR,
      });
    } else {
      setShowAdminMethodologyForm(false);
    }
  };

  return (
    <div className="sc-admin-methodology_tab-container">
      <AdminMethodologyTable
        onAddorEditAdminMethodology={onAddorEditAdminMethodology}
        methodologiesList={methodologies}
      />
      {showAdminMethodologyForm ? (
        <AdminMethodologyForm
          formVisible={showAdminMethodologyForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          header={() => getMethodologyHeader()}
          formMode={skillCentralAdminFormMode}
          selectedMethodology={selectedMethodology}
        />
      ) : null}
    </div>
  );
}

const mapStateToProps = (state) => ({
  methodologies: state.MethodologyReducer.methodologies,
});

const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
  getAdminMethodology: () => dispatch(getMethodologiesThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminMethodologyTab);