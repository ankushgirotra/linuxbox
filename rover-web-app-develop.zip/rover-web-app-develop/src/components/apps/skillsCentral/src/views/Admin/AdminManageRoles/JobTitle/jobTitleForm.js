import React, { Component } from "react";
import { connect } from "react-redux";
import { editJobTitleThunk } from "../../../../store/admin.reducer";
import { validateAdminForm } from "../../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../../pcdm/src/constants/form.constants";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { resourcesBeltOptions as beltOptions } from "../../../../Constants/listOptions.constants";
import { FormModal } from "../../../../../../pcdm/src/components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../../pcdm/src/components/forms/textField/textField";
import "../../admin.scss";


const ADMIN_JOB_TITLE_INITIAL_STATE = {
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    jobTitleId: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      readOnly: true,
    },
    jobTitle: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      readOnly: true,
    },
    role: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    belt: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    deptName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      readOnly: true,
    },
  },
};

class AdminJobTitleForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_JOB_TITLE_INITIAL_STATE, roleOptions: [] };
  }

  componentDidMount() {
    const { selectedJobTitle } = this.props;
    this.populateRoleOptions();
    this.populateFileds(selectedJobTitle);
  }

  populateRoleOptions = () => {
    const uniqueRoles =
      this.props.roles &&
      this.props.roles.data &&
      this.props.roles.data.map((obj) => obj.roleName);
    const sortedRoles =
      uniqueRoles && uniqueRoles.sort((a, b) => a.localeCompare(b));
    this.setState({ roleOptions: sortedRoles });
  };

  populateFileds = (row) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        jobTitleId: {
          ...formControls.jobTitleId,
          value: row.jobTitleId,
        },
        jobTitle: {
          ...formControls.jobTitle,
          value: row.jobTitle,
        },
        role: {
          ...formControls.role,
          value: row.role,
        },
        belt: {
          ...formControls.belt,
          value: row.belt,
        },
        deptName: {
          ...formControls.deptName,
          value: row.departmentName,
        },
      },
    });
  };

  onRoleChange = (value) => {
    const { formControls } = this.state;
    const selectedRole =
      this.props.roles &&
      this.props.roles.data &&
      this.props.roles.data.filter((obj) => obj.roleName.match(value));
    const selectedDept =
      this.props.deptHeads &&
      this.props.deptHeads.data &&
      this.props.deptHeads.data.filter(
        (obj) => obj.departmentId === selectedRole[0].departmentId
      );
    const deptName = selectedDept[0] ? selectedDept[0].departmentName : "";
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        deptName: {
          ...formControls.deptName,
          error: false,
          value: deptName,
        },
        role: {
          ...formControls.role,
          error: false,
          value: value,
        },
      },
    });
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    const selectedRole =
      this.props.roles &&
      this.props.roles.data &&
      this.props.roles.data.filter((obj) =>
        obj.roleName.match(formControls.role.value)
      );
    let payload = {
      jobTitleId: formControls.jobTitleId.value,
      jobTitle: formControls.jobTitle.value,
      roleId: selectedRole[0].roleId,
      belt: formControls.belt.value,
    };
    return payload;
  };

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { closeModal, editJobTitle } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      await editJobTitle(payload, closeModal);
    }
  };

  getHeader = () => {
    return "Edit Job Title";
  };


  showLabelOptionsIcon = (e) => {
    let selectedBelt = beltOptions.filter((belt) => belt.value === e.label)[0];
    if (selectedBelt && selectedBelt.src) {
      return (
        <div className="label_belt_icon-container">
          {e.label} <span><img src={selectedBelt.src} className={"belt_icon"} /></span>
        </div>
      );
    } else {
      return e.label;
    }
  }

  getAdminJobTitleForm = () => {
    const { formControls, roleOptions } = this.state;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="jobTitleId"
              label={"Job Title ID"}
              type="text"
              formObj={formControls.jobTitleId}
              isRequired={formControls.jobTitleId.required}
              onChange={this.onInputChange}
              readOnly={formControls.jobTitleId.readOnly}
            />
          </div>
          <div className="pcdm-form__form-group-field">
            <TextField
              name="jobTitle"
              label={"Job Title"}
              type="text"
              formObj={formControls.jobTitle}
              isRequired={formControls.jobTitle.required}
              onChange={this.onInputChange}
              readOnly={formControls.jobTitle.readOnly}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="role"
              label={"Role"}
              formObj={formControls.role}
              isRequired={formControls.role.required}
              config={{
                options: [...roleOptions],
              }}
              onChange={(e) => this.onRoleChange(e.value)}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="belt"
              label={"Belt"}
              formatOptionLabel={(belt) => this.showLabelOptionsIcon(belt)}
              formObj={formControls.belt}
              isRequired={formControls.belt.required}
              config={{
                options: [...beltOptions],
                id: "value",
                value: "value",
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
          <div className="pcdm-form__form-group-field">
            <TextField
              name="department"
              label={"Dept"}
              type="text"
              formObj={formControls.deptName}
              isRequired={formControls.deptName.required}
              readOnly={formControls.deptName.readOnly}
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formControls } = this.state;
    const { closeModal } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        <CustomButton
          disable={false}
          loading={false}
          variant={BUTTON_VARIANTS.LIGHT}
          onClick={() => closeModal()}
          size="md"
          type={"button"}
        >
          Cancel
        </CustomButton>
      </div>
    );
  };

  render() {
    const { formVisible, closeModal, editJobTitleStatus } = this.props;
    return (
      <>
        <FormModal
          className="sc-admin-dept_heads-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={() => this.getAdminJobTitleForm()}
          footer={() => this.getFooter()}
          isLoading={editJobTitleStatus.status === DATA_STATUS.LOADING}
        />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  editJobTitleStatus: state.SkillsCentralAdmin.editJobTitleStatus,
  roles: state.SkillsCentralAdmin.roles,
  deptHeads: state.SkillsCentralAdmin.deptHeads,
});

const mapDispatchToProps = (dispatch) => ({
  editJobTitle: (editJobTitleFormData, callback) =>
    dispatch(editJobTitleThunk(editJobTitleFormData, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminJobTitleForm);
