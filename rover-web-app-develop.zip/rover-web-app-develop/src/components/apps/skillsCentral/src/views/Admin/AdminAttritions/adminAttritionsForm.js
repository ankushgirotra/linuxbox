import React, { Component } from "react";
import { connect } from "react-redux";
import { addAttritionOptionThunk, editAttritionOptionThunk, deleteAttritionOptionThunk, getAttritionTypeThunk } from "../../../store/admin.reducer";
import { validateAdminForm } from "../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, ACTIONS } from "../../../Constants/action.constants";
import { ADMIN_DELETE_ATTRITION_POPUP_MSG } from "../../../Constants/toolTip.messages";
import { attritionPenaltyOptions } from "../../../Constants/listOptions.constants";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import { DEFAULT_MSG_MODAL_CONFIG, MessageModal } from "../../../../../pcdm/src/components/MessageModal/messageModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../pcdm/src/components/forms/textField/textField";
import "../admin.scss";
import "./adminAttrition.scss";


const ADMIN_ATTRITION_OPTION_INITIAL_STATE = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    attritionName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    resourceType: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    attritionType: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      readOnly: true,
    },
    penaltyApplicable: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      readOnly: true,
    },
  },
};

class AdminAttritionForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_ATTRITION_OPTION_INITIAL_STATE };
  }

  componentDidMount() {
    const { formMode, selectedAttritionOptions } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.EDIT_ATTRITION) {
      this.populateFileds(selectedAttritionOptions);
    }
  }

  populateFileds = async (attritionOption) => {
    const { formControls } = this.state;
    await this.props.getAttritionType(attritionOption.resourceTypeId);
    
    const isEmployee =
      attritionOption &&
      attritionOption.resourceTypeId &&
      attritionOption.resourceTypeId === 1;

    const isPenaltyApplicable = attritionOption.penaltyApplicable ?
      attritionPenaltyOptions[0].name : attritionPenaltyOptions[1].name;

    this.setState({
      formControls: {
        ...formControls,
        attritionName: {
          ...formControls.attritionName,
          value: attritionOption.attritionName,
        },
        resourceType: {
          ...formControls.resourceType,
          value: attritionOption.resourceTypeId,
        },
        attritionType: {
          ...formControls.attritionType,
          value: attritionOption.attritionTypeId,
          readOnly: false,
        },
        penaltyApplicable: {
          ...formControls.penaltyApplicable,
          value: isPenaltyApplicable,
          readOnly: isEmployee,
        },
      },
    });
  };

  onResourceTypeChange = async (value) => {
    const { formControls } = this.state;
    const { getAttritionType } = this.props;
    const isEmployee = value === 1;
    await getAttritionType(value);
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        resourceType: {
          ...formControls.resourceType,
          error: false,
          value: value,
        },
        attritionType: {
          ...formControls.attritionType,
          value: "",
          readOnly: false,
        },
        penaltyApplicable: {
          ...formControls.penaltyApplicable,
          value: isEmployee ? attritionPenaltyOptions[1].name : "",
          readOnly: isEmployee ? true : false,
          error: false,
        },
      },
    });
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    let payload = {
      attritionOption: formControls.attritionName.value,
      attritionTypeId: formControls.attritionType.value,
      penaltyApplicable: formControls.penaltyApplicable.value === attritionPenaltyOptions[0].name,
    };
    return payload;
  };

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode, selectedAttritionOptions, closeModal, addAttritionOption, editAttritionOption } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload(formMode);
      if (formMode === SC_ADMIN_ACTIONS.ADD_ATTRITION) {
        await addAttritionOption(payload, closeModal);
      } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ATTRITION) {
        await editAttritionOption(selectedAttritionOptions.attritionID, payload, closeModal);
      }
    }
  };

  onDeleteClick = () => {
    const { selectedAttritionOptions } = this.props;
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: ADMIN_DELETE_ATTRITION_POPUP_MSG(selectedAttritionOptions.attritionName),
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };

  handleDelete = async (button, data) => {
    const { selectedAttritionOptions, closeModal } = this.props;
    const { messageModalConfig } = this.state;
    if (button === ACTIONS.YES) {
      await this.props.deleteAttritionOption(selectedAttritionOptions.attritionID, closeModal);
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    }
  };

  getHeader = () => {
    const { formMode } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.ADD_ATTRITION) {
      return "Add Attrition Options";
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ATTRITION) {
      return "Edit Attrition Options";
    }
  };

  getAdminAttritionForm = () => {
    const { formControls } = this.state;
    const { resourceType, attritionType } = this.props;
    const isEmployee = formControls.resourceType.value === 1;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="attritionName"
              label={"Attrition Option"}
              type="text"
              formObj={formControls.attritionName}
              isRequired={formControls.attritionName.required}
              onChange={this.onInputChange}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="resourceType"
              label={"Resource Type"}
              formObj={formControls.resourceType}
              isRequired={formControls.resourceType.required}
              config={{
                options: [...resourceType.data],
                id: "resourceTypeId",
                value: "description",
              }}
              onChange={(e) => this.onResourceTypeChange(e.value)}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="attritionType"
              label={"Attrition Type"}
              formObj={formControls.attritionType}
              isRequired={formControls.attritionType.required}
              config={{
                options: [...attritionType.data],
                id: "attritionTypeId",
                value: "attritionType",
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            {isEmployee ? (
              <TextField
                name="penaltyApplicable"
                label={"Penalty Applicable"}
                type="text"
                formObj={formControls.penaltyApplicable}
                isRequired={formControls.penaltyApplicable.required}
              />
            ) : (
              <CustomSelect
                name="penaltyApplicable"
                label={"Penalty Applicable"}
                formObj={formControls.penaltyApplicable}
                isRequired={formControls.penaltyApplicable.required}
                config={{
                  options: [...attritionPenaltyOptions],
                  id: "name",
                  value: "name",
                }}
                onChange={(e) =>
                  this.onInputChange({
                    target: { name: e.name, value: e.value },
                  })
                }
              />
            )}
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formControls } = this.state;
    const { closeModal, formMode } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        {formMode === SC_ADMIN_ACTIONS.EDIT_ATTRITION ? (
          <CustomButton
            //disable={edited || isCheckboxEdited}
            variant={BUTTON_VARIANTS.ERROR}
            onClick={this.onDeleteClick}
            size="md"
          >
            Delete
          </CustomButton>
        ) : (
          <CustomButton
            disable={false}
            loading={false}
            variant={BUTTON_VARIANTS.LIGHT}
            onClick={() => closeModal()}
            size="md"
            type={"button"}
          >
            Cancel
          </CustomButton>
        )}
      </div>
    );
  };

  render() {
    const {
      formVisible,
      closeModal,
      addAttritionOptionStatus,
      editAttritionOptionStatus,
      deleteAttritionOptionStatus,
      attritionType,
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          className="sc-admin-attrition-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={() => this.getAdminAttritionForm()}
          footer={() => this.getFooter()}
          isLoading={
            addAttritionOptionStatus.status === DATA_STATUS.LOADING ||
            editAttritionOptionStatus.status === DATA_STATUS.LOADING ||
            deleteAttritionOptionStatus.status === DATA_STATUS.LOADING ||
            attritionType.status === DATA_STATUS.LOADING
          }
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  addAttritionOptionStatus: state.SkillsCentralAdmin.addAttritionOptionStatus,
  editAttritionOptionStatus: state.SkillsCentralAdmin.editAttritionOptionStatus,
  deleteAttritionOptionStatus: state.SkillsCentralAdmin.deleteAttritionOptionStatus,
  resourceType: state.SkillsCentralAdmin.resourceType,
  attritionType: state.SkillsCentralAdmin.attritionType,
});

const mapDispatchToProps = (dispatch) => ({
  addAttritionOption: (adminAttritionFormData, callback) =>
    dispatch(addAttritionOptionThunk(adminAttritionFormData, callback)),
  editAttritionOption: (attritionId, adminAttritionFormData, callback) =>
    dispatch(editAttritionOptionThunk(attritionId, adminAttritionFormData, callback)),
  deleteAttritionOption: (attritionId, callback) =>
    dispatch(deleteAttritionOptionThunk(attritionId, callback)),
  getAttritionType: (resourceId, callback) =>
    dispatch(getAttritionTypeThunk(resourceId, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminAttritionForm);
