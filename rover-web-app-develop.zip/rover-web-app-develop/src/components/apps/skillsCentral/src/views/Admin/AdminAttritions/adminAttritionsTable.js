import React, { useMemo } from "react";
import { PlusCircle } from "react-feather";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { SC_ADMIN_ACTIONS } from "../../../Constants/action.constants";
import { attritionPenaltyOptions } from "../../../Constants/listOptions.constants";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../pcdm/src/components/DataGrid/dataGrid";
import "./adminAttrition.scss";

export default function AdminAttritionTable(props) {

  const { attritionOptions ,onAddorEditAdminAttrition } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => attritionHead(),
      accessor: "attritionName",
      Cell: ({ row: { original } }) => showAttrition(original, "attritionName"),
      disableFilters: true,
    },
    {
      Header: "Resource Type",
      accessor: "resourceType",
      // Cell: ({ row: { original } }) => showResAndAttType(original,"resourceType", "description"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Attrition Type",
      accessor: "attritionType",
      // Cell: ({ row: { original } }) => showResAndAttType(original,"attritionType", "attritionType"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Penalty Applicable",
      accessor: "penaltyApplicable",
      Cell: ({ row: { original } }) => showPenaltyApplicable(original, "penaltyApplicable"),
      disableFilters: true,
      disableSortBy: true,
    },
  ]);

  // const showResAndAttType = (row, key, property) => {
  //   let type = row && row[key] && row[key][property] ? row[key][property] : "";
  //   return type;
  // };

  const showPenaltyApplicable = (row, key) => {
    return row && row[key] ? attritionPenaltyOptions[0].name : attritionPenaltyOptions[1].name;
  };

  const attritionHead = () => {
    return (
      <div className="add-attrition-head">
        <p>Attrition Option</p>
        <CustomButton
          onClick={(e) => {
            e.stopPropagation(); // --> to disable sort on click of this button
            onAddorEditAdminAttrition(SC_ADMIN_ACTIONS.ADD_ATTRITION, {});
          }}
          title={"Click to add attrition"}
          className="attrition-add-link"
        >
          <span className="mr-2">ADD</span>
          <PlusCircle size="15" strokeWidth={3} />
        </CustomButton>
      </div>
    );
  };

  const showAttrition = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() =>
          onAddorEditAdminAttrition(SC_ADMIN_ACTIONS.EDIT_ATTRITION, { ...row })
        }
      >
        {row[key]}
      </LinkExtended>
    );
  };

  // const data = useMemo(() => [...sortBy(attritionOptions.data, "attritionName")] , [attritionOptions]);

  const data = useMemo(() => {
    return [
      ...attritionOptions.data.map((item, index) => ({
        attritionName: item.attritionOption,
        attritionType: item.attritionTypes && item.attritionTypes.attritionType
          ? item.attritionTypes.attritionType : "",
        resourceType: item.attritionTypes && item.attritionTypes.resourceType &&
          item.attritionTypes.resourceType.description ?
          item.attritionTypes.resourceType.description : "",
        penaltyApplicable: item.penalityApplicable,
        //For Attr. Form
        attritionID: item.attritionID,
        resourceTypeId: item.attritionTypes && item.attritionTypes.resourceType
          && item.attritionTypes.resourceType.resourceTypeId ?
          item.attritionTypes.resourceType.resourceTypeId : "",
        attritionTypeId: item.attritionTypes && item.attritionTypes.attritionTypeId
          ? item.attritionTypes.attritionTypeId : "",
      })),
    ];
  }, [attritionOptions])

  return (
    <>
      <OverlayLoader
        loading={attritionOptions.status === DATA_STATUS.LOADING}
      />
      <div className="admin-attrition-table-container pcdm-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          noRowText={"Click + icon to start adding attrition option"}
        />
      </div>
    </>
  );
}

