import React, { useState } from "react";
import { connect } from "react-redux";
import { getRolesThunk, getJobTitlesThunk } from "../../../store/admin.reducer";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS ,SC_ADMIN_ACTION_TYPE } from "../../../Constants/action.constants";
import { ACTIONS } from "../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../pcdm/src/constants/message.contants";
import Toaster from "../../../../../pcdm/src/components/Toaster/toaster";
import AdminRolesTable from "./Roles/rolesTable";
import AdminJobTitleTable from "./JobTitle/jobTitleTable";
import AdminRoleForm from "./Roles/adminRolesForm";
import AdminJobTitleForm from "./JobTitle/jobTitleForm";
import "./adminManageRoles.scss";
import "../admin.scss";

function AdminManageRoles(props) {

  const { showNotification, getRoles, roles, deptHeads, getJobTitles, jobTitles } = props;

  const [showAdminRoleForm, setShowAdminRoleForm] = useState(false);

  const [showAdminJobTitleForm, setShowAdminJobTitleForm] = useState(false);

  const [selectedJobTitle, setSelectedJobTitle] = useState({});

  const [selectedRole, setSelectedRole] = useState({});

  const [adminRoleFormMode, setAdminRoleFormMode] = useState("");

  const onAddorEditAdminRole = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_ROLE) {
      setShowAdminRoleForm(true);
      setAdminRoleFormMode(SC_ADMIN_ACTIONS.ADD_ROLE);
      setSelectedRole({});
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ROLE) {
      setShowAdminRoleForm(true);
      setAdminRoleFormMode(SC_ADMIN_ACTIONS.EDIT_ROLE);
      setSelectedRole({ ...data });
    }
  };

  const onEditAdminJobTitle = (data) => {
    setShowAdminJobTitleForm(true);
    setSelectedJobTitle({ ...data });
  };

  const onModalClose = (status, responseData, keepModal = false) => {
    if (
      status === SC_ADMIN_ACTION_TYPE.ADD_ROLE_SUCCESS || 
      status === SC_ADMIN_ACTION_TYPE.EDIT_ROLE_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_ROLE_SUCCESS
    ) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: adminRoleFormMode === SC_ADMIN_ACTIONS.ADD_ROLE ?
          "Role added successfully" : (SC_ADMIN_ACTIONS.DELETE_ROLE? "Role deleted successfully" : "Role updated successfully"),
      });
      getRoles();
      setShowAdminRoleForm(false);
    } else if (
      status === SC_ADMIN_ACTION_TYPE.ADD_ROLE_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_ROLE_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_ROLE_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_JOB_TITLE_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if( status === SC_ADMIN_ACTION_TYPE.EDIT_JOB_TITLE_SUCCESS ){
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Job Title edited successfully",
      });
      getJobTitles();
      getRoles();
      setShowAdminJobTitleForm(false);
    } else if (!keepModal || showAdminRoleForm || setShowAdminJobTitleForm) {
      setShowAdminRoleForm(false); 
      setShowAdminJobTitleForm(false) //close the form on click of cancel or close icon
    }
  };

  return (
    <div className="admin-container sc-admin-manage_roles-container">
      <div className="admin-roles_table-container pcdm-scroll-vertical">
        <AdminRolesTable
          onAddorEditAdminRole={onAddorEditAdminRole} 
          roles={roles}
          deptHeads={deptHeads}
        />
      </div>

      <div className="admin-jobTitle_table-container pcdm-scroll-vertical">
        <AdminJobTitleTable
          jobTitles={jobTitles}
          deptHeads={deptHeads}
          roles={roles}
          onEditAdminJobTitle={onEditAdminJobTitle}
        />
      </div>
      {showAdminRoleForm ? (
        <AdminRoleForm
          formVisible={showAdminRoleForm}
          selectedRole={selectedRole}
          formMode={adminRoleFormMode}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          roles={roles}
        />
      ) : null}
      {showAdminJobTitleForm ? (
        <AdminJobTitleForm
          formVisible={showAdminJobTitleForm}
          selectedJobTitle={selectedJobTitle}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
        />
      ) : null}
      <Toaster />
    </div>
  );
}

const mapStateToProps = (state) => ({
  roles: state.SkillsCentralAdmin.roles,
  deptHeads: state.SkillsCentralAdmin.deptHeads,
  jobTitles: state.SkillsCentralAdmin.jobTitles,
});

const mapDispatchToProps = (dispatch) => ({
  getRoles: () => dispatch(getRolesThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
  getJobTitles: () => dispatch(getJobTitlesThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminManageRoles);
