import React, { Component } from "react";
import { connect } from "react-redux";
import { addDeptHeadThunk, editDeptHeadThunk, deleteDeptHeadThunk } from "../../../store/admin.reducer";
import { validateAdminForm } from "../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, ACTIONS } from "../../../Constants/action.constants";
import { ADMIN_DELETE_DEPT_HEAD_POPUP_MSG } from "../../../Constants/toolTip.messages";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import {
  DEFAULT_MSG_MODAL_CONFIG,
  MessageModal,
} from "../../../../../pcdm/src/components/MessageModal/messageModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../pcdm/src/components/forms/textField/textField";
import "../admin.scss";
import "./adminDeptHeads.scss";

const ADMIN_DEPT_HEAD_INITIAL_STATE = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    deptName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    abbreviation: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    deptHeadName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    deptHeadId: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
      readOnly: true,
    },
  },
};

class AdminDeptHeadForm extends Component {
  constructor(props) {
    super(props);
    this.state = { headNamesOptions: [], ...ADMIN_DEPT_HEAD_INITIAL_STATE };
  }

  componentDidMount() {
    const { formMode, selectedDeptHead } = this.props;
    this.populateHeadNameOptions();
    if (formMode === SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD) {
      this.populateFileds(selectedDeptHead);
    }
  }

  populateHeadNameOptions = () => {
    const uniqueHeadNames = this.props.headNames && this.props.headNames.data && 
      this.props.headNames.data.map((obj) => obj.departmentHead );
    const sortedHeadNames = uniqueHeadNames && uniqueHeadNames.sort((a,b)=>a.localeCompare(b));
    this.setState({headNamesOptions: sortedHeadNames})
  }

  populateFileds = (deptHead) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        deptName: {
          ...formControls.deptName,
          value: deptHead.departmentName,
        },
        abbreviation: {
          ...formControls.abbreviation,
          value: deptHead.abbreviation,
        },
        deptHeadName: {
          ...formControls.deptHeadName,
          value: deptHead.departmentHead,
        },
        deptHeadId: {
          ...formControls.deptHeadId,
          value: deptHead.departmentHeadId,
        },
      },
    });
  };

  onHeadNameChange = (value) => {
    const { formControls } = this.state;
    const selectedHead = this.props.headNames && this.props.headNames.data && 
      this.props.headNames.data.filter((obj)=>obj.departmentHead.match(value));
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        deptHeadName: {
          ...formControls.deptHeadName,
          error: false,
          value: value,
        },
        deptHeadId: {
          ...formControls.deptHeadId,
          value: selectedHead[0].departmentHeadId,
          readOnly: true,
          error: false,
        },
      },
    });
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    let payload = {
      departmentName: formControls.deptName.value,
      abbreviation: formControls.abbreviation.value,
      departmentHead: formControls.deptHeadName.value,
      departmentHeadId: formControls.deptHeadId.value,
    };
    return payload;
  }

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode, closeModal, addDeptHead, selectedDeptHead, editDeptHead } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === SC_ADMIN_ACTIONS.ADD_DEPT_HEAD) {
        await addDeptHead(payload, closeModal);
      } else if (formMode === SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD) {
        await editDeptHead(selectedDeptHead.departmentId, payload, closeModal);
      }
    }
  };

  onDeleteClick = () => {
    const { selectedDeptHead } = this.props;
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: ADMIN_DELETE_DEPT_HEAD_POPUP_MSG(selectedDeptHead.departmentName),
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };

  handleDelete = async (button, data) => {
    const { selectedDeptHead, closeModal } = this.props;
    const { messageModalConfig } = this.state;
    if (button === ACTIONS.YES) {
      await this.props.deleteDeptHead(selectedDeptHead.departmentId, closeModal);
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    }
  };

  getHeader = () => {
    const { formMode } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.ADD_DEPT_HEAD) {
      return "Add Department";
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD) {
      return "Edit Department";
    }
  };

  getAdminDeptHeadForm = () => {
    const { formControls, headNamesOptions } = this.state;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="deptName"
              label={"Dept Name"}
              type="text"
              formObj={formControls.deptName}
              isRequired={formControls.deptName.required}
              onChange={this.onInputChange}
            />
          </div>
          <div className="pcdm-form__form-group-field">
            <TextField
              name="abbreviation"
              label={"Abbreviation"}
              type="text"
              formObj={formControls.abbreviation}
              isRequired={formControls.abbreviation.required}
              onChange={this.onInputChange}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="deptHeadName"
              label={"Dept Head Name"}
              formObj={formControls.deptHeadName}
              isRequired={formControls.deptHeadName.required}
              config={{
                options: [...headNamesOptions],
                
              }}
              onChange={(e) => this.onHeadNameChange(e.value)}
              isLoading={ 
                this.props.headNames.status === DATA_STATUS.LOADING && 
                this.props.formMode === SC_ADMIN_ACTIONS.ADD_DEPT_HEAD
              }
            />
          </div>
          <div className="pcdm-form__form-group-field">
            <TextField
              name="deptHeadId"
              label={"Dept Head ID"}
              type="text"
              formObj={formControls.deptHeadId}
              isRequired={formControls.deptHeadId.required}
              readOnly={formControls.deptHeadId.readOnly}
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formControls } = this.state;
    const { closeModal, formMode } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        {formMode === SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD ? (
          <CustomButton
            variant={BUTTON_VARIANTS.ERROR}
            onClick={this.onDeleteClick}
            size="md"
          >
            Delete
          </CustomButton>
        ):<CustomButton
          disable={false}
          loading={false}
          variant={BUTTON_VARIANTS.LIGHT}
          onClick={() => closeModal()}
          size="md"
          type={"button"}
        >
          Cancel
        </CustomButton>}
      </div>
    );
  }

  render() {
    const {
      formVisible,
      closeModal,
      addDeptHeadStatus,
      headNames,
      editDeptHeadStatus,
      formMode,
      deleteDeptHeadStatus,
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          className="sc-admin-dept_heads-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={() => this.getAdminDeptHeadForm()}
          footer={() => this.getFooter()}        
          isLoading={
            editDeptHeadStatus.status === DATA_STATUS.LOADING ||
            addDeptHeadStatus.status === DATA_STATUS.LOADING ||
            deleteDeptHeadStatus.status === DATA_STATUS.LOADING ||
            (headNames.status === DATA_STATUS.LOADING && 
              formMode === SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD)
          }
        />
        <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  addDeptHeadStatus: state.SkillsCentralAdmin.addDeptHeadStatus,
  editDeptHeadStatus: state.SkillsCentralAdmin.editDeptHeadStatus,
  headNames: state.SkillsCentralAdmin.headNames,
  deleteDeptHeadStatus: state.SkillsCentralAdmin.deleteDeptHeadStatus,
});

const mapDispatchToProps = (dispatch) => ({
  addDeptHead: (addDeptHeadFormData, callback) =>
    dispatch(addDeptHeadThunk(addDeptHeadFormData, callback)),
  editDeptHead: (deptId, editDeptHeadFormData, callback) =>
    dispatch(editDeptHeadThunk(deptId, editDeptHeadFormData, callback)),
  deleteDeptHead: (deptId, callback) => 
    dispatch(deleteDeptHeadThunk(deptId, callback))
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminDeptHeadForm);
