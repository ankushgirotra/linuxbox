import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { toggleAutomationStatusThunk, getAutomationStatusThunk } from "../../../store/admin.reducer";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { ACTIONS } from "../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../pcdm/src/constants/message.contants";
import { SC_ADMIN_ACTION_TYPE } from "../../../Constants/action.constants";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import Toaster from "../../../../../pcdm/src/components/Toaster/toaster";
import Switch from "../../../../../pcdm/src/components/forms/Switch/switch";
import "../admin.scss";
import "./adminAutomationJobsControl.scss";

const AUTOMATION_INITIAL_STATE = {
  profileCreation: {
    ...FORM_CONTROL_DEFAULT,
  },
  sendEmail: {
    ...FORM_CONTROL_DEFAULT,
  },
};

function AdminAutomationJobsControl(props) {

  const { showNotification, automationStatus, toggleAutomationStatus, 
    getAutomationStatus, updateAutomationStatus } = props;

  const [formControls, setFormControls] = useState(AUTOMATION_INITIAL_STATE);

  useEffect(() => {
    if (automationStatus.data && automationStatus.data.length) {
      let profileData = automationStatus.data.filter((automation) =>
        automation.jobTitle === "ProfileCreation")[0];
      setFormControls({
        ...formControls,
        profileCreation: {
          ...formControls.profileCreation,
          value: profileData.active ? "On" : "Off",
          error: false,
          errorMsg: "",
        },
        sendEmail: {
          ...formControls.sendEmail,
          value: profileData.sendEmails ? "On" : "Off",
          error: false,
          errorMsg: "",
        }
      });
    }
  }, [automationStatus]);

  const onCallback = (status, requestType, responseData, emailStatus) => {
    if (status === SC_ADMIN_ACTION_TYPE.TOGGLE_AUTOMATION_STATUS_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: requestType === "profileSwitch" ? "Automation Job updated successfully" :
          emailStatus ? "Send Emails option is enabled successfully" :
            "Send Emails option is disabled successfully",
      });
    } else if (status === SC_ADMIN_ACTION_TYPE.TOGGLE_AUTOMATION_STATUS_ERROR) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_FORM_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
      getAutomationStatus();
    }
  };

  const onProfileCreationChange = async (value) => {
    let profileStatus = value === "On" ? 1 : 0;
    let sendMailStatus = formControls.sendEmail.value === "On" ? 1 : 0;
    setFormControls({
      ...formControls,
      profileCreation: {
        ...formControls.profileCreation,
        value: value,
      },
    });
    await updateAutomationStatus(profileStatus, sendMailStatus, "profileSwitch", onCallback)
  };

  const onSendEmailChange = async (value) => {
    let sendMailStatus = value === "On" ? 1 : 0;
    let profileStatus = formControls.profileCreation.value === "On" ? 1 : 0;
    setFormControls({
      ...formControls,
      sendEmail: {
        ...formControls.sendEmail,
        value: value,
      },
    });
    await updateAutomationStatus(profileStatus, sendMailStatus, "emailSwitch", onCallback)
  };

  return (
    <>
      <OverlayLoader
        loading={automationStatus.status === DATA_STATUS.LOADING ||
          toggleAutomationStatus.status === DATA_STATUS.LOADING}
      />
      <div className='admin-container sc-admin-attrition-container'>
        <div className="admin-automation_switch">
          <Switch
            name={"profileCreation"}
            label={"Profile Creation"}
            config={{
              options: [
                { id: 1, desc: "On" },
                { id: 2, desc: "Off" },
              ],
              id: "desc",
              value: "desc",
            }}
            formObj={formControls.profileCreation}
            className="profile-creation-slider"
            onChange={onProfileCreationChange}
          />
          <Switch
            name={"sendEmail"}
            label={"Send Emails"}
            config={{
              options: [
                { id: 1, desc: "On" },
                { id: 2, desc: "Off" },
              ],
              id: "desc",
              value: "desc",
            }}
            formObj={formControls.sendEmail}
            disable={!(formControls.profileCreation.value === "On")}
            className="profile-creation-slider"
            onChange={onSendEmailChange}
          />
        </div>
        <Toaster />
      </div>
    </>
  );
}

const mapStateToProps = (state) => ({
  automationStatus: state.SkillsCentralAdmin.automationStatus,
  toggleAutomationStatus: state.SkillsCentralAdmin.toggleAutomationStatus,
});

const mapDispatchToProps = (dispatch) => ({
  updateAutomationStatus: (profileStatus, sendMailStatus, changeType, callback) =>
    dispatch(toggleAutomationStatusThunk(profileStatus, sendMailStatus, changeType, callback)),
  getAutomationStatus: () => dispatch(getAutomationStatusThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminAutomationJobsControl);