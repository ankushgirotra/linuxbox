import React, { Component } from "react";
import { connect } from "react-redux";
import { addRoleThunk, deleteRoleThunk, editRoleThunk } from "../../../../store/admin.reducer";
import { validateAdminForm } from "../../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, ACTIONS } from "../../../../Constants/action.constants";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../../pcdm/src/components/FormModal/formModal";
import { ADMIN_DELETE_ROLE_POPUP_MSG } from "../../../../Constants/toolTip.messages";
import {
  DEFAULT_MSG_MODAL_CONFIG,
  MessageModal,
} from "../../../../../../pcdm/src/components/MessageModal/messageModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../../pcdm/src/components/forms/textField/textField";
import "../../admin.scss";

const ADMIN_ROLE_INITIAL_STATE = {
  messageModalConfig: { ...DEFAULT_MSG_MODAL_CONFIG },
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    roleName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    department: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    deleteButtonProp : false,
  },
};

class AdminRoleForm extends Component {
  constructor(props) {
    super(props);
    this.state = { departmentOptions: [], ...ADMIN_ROLE_INITIAL_STATE };
  }

  componentDidMount() {
    const { formMode, selectedRole, roles } = this.props;
    this.populateDepartmentOptions();
    if (formMode === SC_ADMIN_ACTIONS.EDIT_ROLE) {
      this.populateRoleForm(selectedRole);
    }
  }

  populateDepartmentOptions = () => {
    const departments = this.props.deptHeads && this.props.deptHeads.data && 
      this.props.deptHeads.data.map((obj) => obj.departmentName );
    const sortedDepartments = departments && departments.sort((a,b)=>a.localeCompare(b));
    this.setState({departmentOptions: sortedDepartments})
  }

  populateRoleForm = (role) => {
    const { formControls } = this.state;
    const {roles} =  this.props;
    let disableProp = false;
    for(let i=0; i<roles.data.length; i++)
    {
      if(role.roleName === roles.data[i].roleName){
        if(roles.data[i].roleUsed === true){
          disableProp = true;
          break;
        }
      }
    }
    this.setState({
      formControls: {
        ...formControls,
        roleName: {
          ...formControls.roleName,
          value: role.roleName,
        },
        department: {
          ...formControls.department,
          value: role.departmentName,
        },
        deleteButtonProp: disableProp
      },
    });
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    const selectedDept = this.props.deptHeads && this.props.deptHeads.data && 
      this.props.deptHeads.data.filter((obj)=>obj.departmentName.match(formControls.department.value));
    let payload = {
      roleName: formControls.roleName.value,
      departmentId: selectedDept[0].departmentId,
    };
    return payload;
  }

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { closeModal, addRole, selectedRole, formMode, editRole } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload();
      if (formMode === SC_ADMIN_ACTIONS.ADD_ROLE) {
        await addRole(payload, closeModal);
      } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ROLE) {
        let roleId = selectedRole && selectedRole.roleId ? selectedRole.roleId : "";
        await editRole(roleId, payload, closeModal);
      }
    }
  };

  onDeleteClick = () => {
    const { selectedRole } = this.props;
    this.setState({
      messageModalConfig: {
        ...DEFAULT_MSG_MODAL_CONFIG,
        title: "Delete",
        message: ADMIN_DELETE_ROLE_POPUP_MSG(selectedRole.roleName),
        visible: true,
        onClose: this.handleDelete,
      },
    });
  };

  handleDelete = async (button, data) => {
    const { selectedRole, closeModal } = this.props;
    const { messageModalConfig } = this.state;
    
    if (button === ACTIONS.YES) {
      await this.props.deleteRole(selectedRole.roleId, closeModal);
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    } else {
      this.setState({
        messageModalConfig: {
          ...messageModalConfig,
          visible: false,
        },
      });
    }
  };

  getHeader = () => {
    const { formMode } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.ADD_ROLE) {
      return "ADD ROLE";
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ROLE) {
      return "EDIT ROLE";
    }
  };

  getAdminRoleForm = () => {
    const { formControls, departmentOptions } = this.state;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="roleName"
              label={"Role Name"}
              type="text"
              formObj={formControls.roleName}
              isRequired={formControls.roleName.required}
              onChange={this.onInputChange}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="department"
              label={"Department"}
              formObj={formControls.department}
              isRequired={formControls.department.required}
              config={{
                options: [...departmentOptions],
                
              }}
              onChange={(e) =>
                this.onInputChange({
                    target: { name: e.name, value: e.value },
                })
            }
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formControls } = this.state;
    const { closeModal, formMode } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        {formMode === SC_ADMIN_ACTIONS.EDIT_ROLE ? (
          <CustomButton
            variant={BUTTON_VARIANTS.ERROR}
            onClick={this.onDeleteClick}
            disable={this.state.formControls.deleteButtonProp}
            size="md"
          >
            Delete
          </CustomButton>
        ):<CustomButton
          disable={false}
          loading={false}
          variant={BUTTON_VARIANTS.LIGHT}
          onClick={() => closeModal()}
          size="md"
          type={"button"}
        >
          Cancel
        </CustomButton>}
      </div>
    );
  }

  render() {
    const {
      formVisible,
      closeModal,
      addRoleStatus,
      editRoleStatus,
      deleteRoleStatus,
    } = this.props;
    const { messageModalConfig } = this.state;
    return (
      <>
        <FormModal
          className="sc-admin-dept_heads-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={() => this.getAdminRoleForm()}
          footer={() => this.getFooter()}        
          isLoading={
            addRoleStatus === DATA_STATUS.LOADING || editRoleStatus === DATA_STATUS.LOADING ||
            deleteRoleStatus.status === DATA_STATUS.LOADING 
          }
        />
      <MessageModal {...messageModalConfig} />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  addRoleStatus: state.SkillsCentralAdmin.addRoleStatus.status,
  editRoleStatus: state.SkillsCentralAdmin.editRoleStatus.status,
  deptHeads: state.SkillsCentralAdmin.deptHeads,
  deleteRoleStatus: state.SkillsCentralAdmin.deleteRoleStatus,
});

const mapDispatchToProps = (dispatch) => ({
  addRole: (addRoleFormData, callback) =>
    dispatch(addRoleThunk(addRoleFormData, callback)),
  editRole: (roleId, addRoleFormData, callback) =>
    dispatch(editRoleThunk(roleId, addRoleFormData, callback)),
  deleteRole: (roleId, callback) => 
    dispatch(deleteRoleThunk(roleId, callback))
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminRoleForm);
