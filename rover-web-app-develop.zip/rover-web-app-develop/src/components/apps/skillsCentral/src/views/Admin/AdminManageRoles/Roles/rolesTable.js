import React, { useMemo } from "react";
import { PlusCircle } from "react-feather";
import sortBy from "../../../../../../../../services/helper.service";
import { SC_ADMIN_ACTIONS } from "../../../../Constants/action.constants";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../../pcdm/src/components/DataGrid/dataGrid";
import "../adminManageRoles.scss";

export default function AdminRolesTable(props) {

  const { roles, deptHeads, onAddorEditAdminRole } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => roleHeader(),
      accessor: "roleName",
      Cell: ({ row: { original } }) => showRoleHead(original, "roleName"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Department",
      accessor: "departmentName",
      disableFilters: true,
      disableSortBy: true,
    },
  ]);

  const roleHeader = () => {
    return (
      <div className="add-role-head">
        <p>Role</p>
        <CustomButton
          onClick={(e) => {
            e.stopPropagation();
            onAddorEditAdminRole(SC_ADMIN_ACTIONS.ADD_ROLE, {})
          }}
          title={"Click to add role"}
          className="role-add-link"
        >
          <span className="mr-2">ADD</span>
          <PlusCircle size="15" strokeWidth={3} />
        </CustomButton>
      </div>
    );
  };

  const showRoleHead = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() => onAddorEditAdminRole(SC_ADMIN_ACTIONS.EDIT_ROLE, {...row})}
      >
        {row[key]}
      </LinkExtended>
    );
  };

  let rolesList = [];
  if (Array.isArray(roles.data) && roles.data.length) {
    rolesList = roles.data.map((obj) => {
      const deptRow = deptHeads.data.filter((ob) => ob.departmentId === obj.departmentId)
      const deptName = deptRow[0] ? deptRow[0].departmentName : ""
      return { ...obj, departmentName: deptName }
    })
  }
  const data = useMemo(() => [...sortBy(rolesList, "roleName")], [rolesList]);

  return (
    <DataGrid
      data={data}
      columns={columns}
      noRowText={"Click + icon to start adding role"}
    />
  );

}

