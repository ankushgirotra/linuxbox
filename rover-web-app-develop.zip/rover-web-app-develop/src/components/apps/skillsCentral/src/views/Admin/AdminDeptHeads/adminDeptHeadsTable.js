import React, { useMemo } from "react";
import { PlusCircle, Circle } from "react-feather";
import sortBy from "../../../../../../../services/helper.service";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { SC_ADMIN_ACTIONS } from "../../../Constants/action.constants";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../pcdm/src/components/DataGrid/dataGrid";
import "./adminDeptHeads.scss";

export default function AdminDeptHeadsTable(props) {

  const { deptHeads, onAddorEditAdminDeptHead, onClickViewManagers } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => deptHeadsHeader(),
      accessor: "departmentName",
      Cell: ({ row: { original } }) => showDeptHead(original, "departmentName"),
      disableFilters: true,
    },
    {
      Header: "Abbreviation",
      accessor: "abbreviation",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Dept Head Name",
      accessor: "departmentHead",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Dept Head ID",
      accessor: "departmentHeadId",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "RM's",
      Cell: ({ row: { original } }) => showDeptManagers(original, "actionRequired"),
      accessor: "actionRequired",
      disableFilters: true,
      disableSortBy: true,
    },
  ]);

  const deptHeadsHeader = () => {
    return (
      <div className="add-dept_heads-head">
        <p>Dept Name</p>
        <CustomButton
          onClick={(e) => {
            e.stopPropagation(); // --> to disable sort on click of this button
            onAddorEditAdminDeptHead(SC_ADMIN_ACTIONS.ADD_DEPT_HEAD, {});
          }}
          title={"Click to add department"}
          className="dept_heads-add-link"
        >
          <span className="mr-2">ADD</span>
          <PlusCircle size="15" strokeWidth={3} />
        </CustomButton>
      </div>
    );
  };

  const showDeptHead = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() =>
          onAddorEditAdminDeptHead(SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD, { ...row })
        }
      >
        {row.departmentName}
      </LinkExtended>
    );
  };

  const showDeptManagers = (row, key) => {
    return (
      (row && row.actionRequired) ? <>
        <div className="view-manager-cell">
          <LinkExtended
            className="td-product"
            onClick={() => {
              onClickViewManagers(row.departmentId)
             }}
          >
            View Managers
      </LinkExtended>
          <div className="no-of-managers-badge" >
            <Circle fill="#3b77fe" size={"1.7em"} stroke="#ffffff" />
            <h6 className="manager_count">{row.actionRequired ? row.actionRequired : 0}</h6>
          </div>
        </div>
      </> : <></>
    );
  };

  const data = useMemo(() => [...sortBy(deptHeads.data, "departmentName")], [deptHeads]);

  return (
    <>
      <OverlayLoader
        loading={deptHeads.status === DATA_STATUS.LOADING}
      />
      <div className="admin-dept_heads-table-container pcdm-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          noRowText={"Click + icon to start adding department"}
        />
      </div>
    </>
  );
}

