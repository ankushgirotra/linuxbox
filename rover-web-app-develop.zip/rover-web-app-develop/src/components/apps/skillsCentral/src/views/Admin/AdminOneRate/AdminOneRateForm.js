import React, { Component } from "react";
import { connect } from "react-redux";
import { addOneRateThunk, editOneRateThunk } from "../../../store/admin.reducer";
import { validateAdminForm } from "../../../Services/admin.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, ACTIONS } from "../../../Constants/action.constants";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../pcdm/src/components/forms/textField/textField";
import "../admin.scss";
import { stringToCurrency } from "../../../../../pcdm/src/services/form.service";


const ADMIN_ONE_RATE_INITIAL_STATE = {
    formControls: {
        edited: false,
        error: false,
        errorMessage: "",
        errorDetail: "",
        year: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
        oneRate: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
        blendedRate: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
    },
};

class AdminOneRateForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_ONE_RATE_INITIAL_STATE, yearOptions: [] };
  }

  componentDidMount() {
    const { formMode, selectedOneRate } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.EDIT_ONE_RATE) {
      this.populateFields(selectedOneRate);
    }
    this.populateYearDropdownOptions();
  }
  populateFields = (selectedOneRate) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        year: {
            ...formControls.year,
            value: selectedOneRate.year,
            // disabled: true,
        },
        oneRate: {
            ...formControls.oneRate,
            value: stringToCurrency(String(selectedOneRate.oneRate), "blur", 2),
        },
        blendedRate: {
            ...formControls.blendedRate,
            value: stringToCurrency(String(selectedOneRate.blendedRate), "blur", 2),
        },
      },
    });
  };

  populateYearDropdownOptions = () => {
    let currentYear = new Date().getFullYear();
    const { oneRate } = this.props;
    let yearsExsisting = oneRate.data.map((obj) => {
      return Number(obj.year);
    });
    let { yearOptions } = this.state;
    yearOptions.push(
      currentYear - 1,
      currentYear,
      currentYear + 1,
      currentYear + 2
    );
    const finalOptions = yearOptions.filter((val) => {
      return yearsExsisting.indexOf(val) === -1;
    });
    this.setState({ yearOptions: finalOptions });
  };
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  onRateChange = (event, on, field) => {
    const { formControls } = this.state;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [field]: {
          ...formControls[field],
          error: false,
          value: stringToCurrency(event.target.value, on, 2),
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    const { formMode, selectedOneRate } = this.props;
    if(formMode===SC_ADMIN_ACTIONS.ADD_ONE_RATE){
      let payload = {
        year: formControls.year.value,
        oneRate: formControls.oneRate.value.split("$")[1],
        blendedRate: formControls.blendedRate.value.split("$")[1],
      };
      return payload;
    }else if(formMode===SC_ADMIN_ACTIONS.EDIT_ONE_RATE){
      let payload = {
        newYear: formControls.year.value,
        year: selectedOneRate.year,
        oneRate: formControls.oneRate.value.split("$")[1],
        blendedRate: formControls.blendedRate.value.split("$")[1],
      };
      return payload;
    }
    
  };

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode, closeModal, addOneRate, editOneRate } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload(formMode);
      if (formMode === SC_ADMIN_ACTIONS.ADD_ONE_RATE) {
        await addOneRate(payload, closeModal);
      } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ONE_RATE) {
          await editOneRate(payload, closeModal);
      }
    }
  };

  getHeader = () => {
    const { formMode } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.ADD_ONE_RATE) {
      return "Add One-Rate";
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ONE_RATE) {
      return "Edit One-Rate";
    }
  };

  getAdminAttritionForm = () => {
    const { formControls, yearOptions } = this.state;
    const { formMode, selectedOneRate } = this.props;
    let editYearOptions = formMode === SC_ADMIN_ACTIONS.EDIT_ONE_RATE ? [selectedOneRate.year, ...yearOptions]:[]
    editYearOptions.sort();
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <CustomSelect
              name="year"
              label={"Year"}
              formObj={formControls.year}
              isRequired={formControls.year.required}
              config={{
                options: formMode === SC_ADMIN_ACTIONS.EDIT_ONE_RATE ? [...editYearOptions] : [...yearOptions],
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <TextField
              name="oneRate"
              label={"One-Rate"}
              formObj={formControls.oneRate}
              isRequired={formControls.oneRate.required}
              type="text"
              placeholder="$___"
              onBlur={(e) => this.onRateChange(e, "blur", "oneRate")}
              onChange={(e) => this.onRateChange(e, "", "oneRate")}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <TextField
              name="blendedRate"
              label={"Blended Rate"}
              formObj={formControls.blendedRate}
              isRequired={formControls.blendedRate.required}
              type="text"
              placeholder="$___"
              onBlur={(e) => this.onRateChange(e, "blur", "blendedRate")}
              onChange={(e) => this.onRateChange(e, "", "blendedRate")}
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formControls } = this.state;
    const { closeModal } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        <CustomButton
          disable={false}
          loading={false}
          variant={BUTTON_VARIANTS.LIGHT}
          onClick={() => closeModal()}
          size="md"
          type={"button"}
        >
          Cancel
        </CustomButton>
      </div>
    );
  };

  render() {
    const { formVisible, closeModal, addOneRateStatus, editOneRateStatus } = this.props;
    return (
      <>
        <FormModal
          className="sc-admin-attrition-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={this.getHeader()}
          content={() => this.getAdminAttritionForm()}
          footer={() => this.getFooter()}
          isLoading={addOneRateStatus.status === DATA_STATUS.LOADING || editOneRateStatus.status === DATA_STATUS.LOADING}
        />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
    addOneRateStatus: state.SkillsCentralAdmin.addOneRateStatus,
    editOneRateStatus: state.SkillsCentralAdmin.editOneRateStatus,
    oneRate: state.SkillsCentralAdmin.oneRate,    
});

const mapDispatchToProps = (dispatch) => ({
    addOneRate: (adminOneRateFormData, callback) =>
        dispatch(addOneRateThunk(adminOneRateFormData, callback)),
    editOneRate: (adminOneRateFormData, callback) =>
        dispatch(editOneRateThunk(adminOneRateFormData, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminOneRateForm);
