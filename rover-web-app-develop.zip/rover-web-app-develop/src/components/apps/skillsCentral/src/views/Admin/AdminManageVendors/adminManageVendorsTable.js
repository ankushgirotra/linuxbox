import React, { useMemo } from "react";
import { PlusCircle, Layers } from "react-feather";
import sortBy from "../../../../../../../services/helper.service";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { SC_ADMIN_ACTIONS } from "../../../Constants/action.constants";
import { OverlayLoader } from "../../../../../pcdm/src/components/DataHandler/dataHandler";
import LinkExtended from "../../../../../../shared/Link/linkExtended";
import CustomButton from "../../../../../pcdm/src/components/forms/Button/button";
import DataGrid from "../../../../../pcdm/src/components/DataGrid/dataGrid";
import "./adminManageVendor.scss";

export default function AdminManageVendorsTable(props) {

  const { vendors, onAddorEditAdminManageVendor } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => vendorHeader(),
      accessor: "vendorName",
      Cell: ({ row: { original } }) => showVendorHead(original, "vendorName" , "numNames"),
      disableFilters: true,
    },
    {
      Header: "Tier",
      accessor: "tier",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Active",
      accessor: "active",
      Cell: ({ row: { original } }) => showVendorActiveStatus(original, "active"),
      disableFilters: true,
    },
  ]);

  const showVendorActiveStatus = (row, key) => {
    let active = row && row[key];
    if (active) {
      return <span> &#10004;</span>;
    } else {
      return null;
    }
  };

  const vendorHeader = () => {
    return (
      <div className="add-manage_vendor-head">
        <p>Vendor</p>
      </div>
    );
  };

  const showVendorHead = (row, key, count) => {
    return (
      <div className="admin-vendor-row">
        <LinkExtended
          className="td-product"
          onClick={() => {
            onAddorEditAdminManageVendor(SC_ADMIN_ACTIONS.EDIT_VENDOR, { ...row })
          }
          }
        >
          {row[key]}
          {row[count] && row[count] > 1 ?
            <span className="vendor-icon" title={"This vendor has more than 1 name"}>
              <Layers size="12" stroke={"black"} strokeWidth={"2.5"} /> </span>
            : null}
        </LinkExtended>
      </div>
    );
  };

  const data = useMemo(() => [...sortBy(vendors.data, "vendorName")] , [vendors]);

  return (
    <>
      <OverlayLoader
        loading={vendors.status === DATA_STATUS.LOADING}
      />
      <div className="sc-admin-manage_vendor-table-container pcdm-scroll-vertical">
        <DataGrid
          data={data}
          columns={columns}
          noRowText={"Click + icon to start adding vendor"}
        />
      </div>
    </>
  );
}

