import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { getDeptHeadsThunk, getDeptManagersThunk } from "../../../store/admin.reducer";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS ,SC_ADMIN_ACTION_TYPE } from "../../../Constants/action.constants";
import { ACTIONS } from "../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../pcdm/src/constants/message.contants";
import Toaster from "../../../../../pcdm/src/components/Toaster/toaster";
import AdminDeptHeadsTable from "./adminDeptHeadsTable";
import AdminDeptHeadForm from "./adminDeptHeadForm";
import "./adminDeptHeads.scss";
import "../admin.scss";
import AdminDeptManagersTable from "./adminDeptManagersTable";
import AdminDeptManagerForm from "./adminDeptManagerForm";

function AdminDeptHeads(props) {

  const { showNotification, getDeptHeads, deptHeads, getDeptManagers, deptManagers } = props;

  const [showAdminDeptHeadForm, setShowAdminDeptHeadForm] = useState(false);

  const [adminAdminDeptHeadFormMode, setAdminDeptHeadFormMode] = useState("");

  const [selectedDeptHead, setSelectedDeptHead] = useState({});

  const [viewManagers, setViewManagers] = useState(false);

  const [showAdminDeptManagerForm, setShowAdminDeptManagerForm] = useState(false);

  const [selectedDeptManager, setSelectedDeptManager] = useState({});

  const onAddorEditAdminDeptHead = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_DEPT_HEAD) {
      setShowAdminDeptHeadForm(true);
      setAdminDeptHeadFormMode(SC_ADMIN_ACTIONS.ADD_DEPT_HEAD);
      setSelectedDeptHead({});
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD) {
      setShowAdminDeptHeadForm(true);
      setAdminDeptHeadFormMode(SC_ADMIN_ACTIONS.EDIT_DEPT_HEAD);
      setSelectedDeptHead({ ...data });
    }
  };

  const onEditAdminDeptManager = ( data) => {
      setShowAdminDeptManagerForm(true);
      setSelectedDeptManager({ ...data });
  };

  const onClickViewManagers = (deptId) => {
    setViewManagers(true);
    props.setViewManagersProps(true)
    getDeptManagers(deptId)
  };
 const goBackToDeptHeads =() =>{
   setViewManagers(false)
   props.setViewManagersProps(false)
 }
  const onModalClose = (status, responseData, keepModal = false) => {
    let isAddForm = adminAdminDeptHeadFormMode === SC_ADMIN_ACTIONS.ADD_DEPT_HEAD;
    let isDeleted = status === SC_ADMIN_ACTION_TYPE.DELETE_DEPT_HEAD_SUCCESS;
    if (
      status === SC_ADMIN_ACTION_TYPE.ADD_DEPT_HEAD_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_DEPT_HEAD_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_DEPT_HEAD_SUCCESS
    ) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: isAddForm ? "Department added successfully" : 
        ( isDeleted? "Department deleted successfully" : "Department updated successfully"),
      });
      getDeptHeads();
      setShowAdminDeptHeadForm(false);
      if (isAddForm) {
        getDeptManagers(responseData.departmentId);
        setViewManagers(true)
      }
    } else if (
      status === SC_ADMIN_ACTION_TYPE.ADD_DEPT_HEAD_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_DEPT_HEAD_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_DEPT_HEAD_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (!keepModal || showAdminDeptHeadForm) {
      setShowAdminDeptHeadForm(false);  //close the form on click of cancel or close icon
    }
  };

  const onManagerModalClose = (status, responseData, keepModal = false) => {
    if (
      status === SC_ADMIN_ACTION_TYPE.EDIT_DEPT_MANAGER_SUCCESS
    ) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Manager Updated successfully",
      });
      getDeptManagers(selectedDeptManager.departmentId);
      setShowAdminDeptManagerForm(false);
    } else if (
      status === SC_ADMIN_ACTION_TYPE.EDIT_DEPT_MANAGER_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (!keepModal || showAdminDeptManagerForm) {
      setShowAdminDeptManagerForm(false);  //close the form on click of cancel or close icon
    }
  };

  return (
    <>
     {viewManagers && typeof deptManagers.data !== 'string' ?<span className="rover-link" style={{marginLeft:"3rem"}} onClick={goBackToDeptHeads}>&lt;-- Go back</span>:""}
    <div className='admin-container sc-admin-dept_heads-container'>
      {viewManagers && typeof deptManagers.data !== 'string' ?<>
        <AdminDeptManagersTable
          deptManagers={deptManagers}
          onEditAdminDeptManager={onEditAdminDeptManager}
        />
      {showAdminDeptManagerForm ? (
        <AdminDeptManagerForm
          formVisible={showAdminDeptManagerForm}
          closeModal={(status, data, keepModal) => onManagerModalClose(status, data, keepModal)}
          selectedDeptManager={selectedDeptManager}
        />
      ) : null}</>:
      <>
      <AdminDeptHeadsTable
        onAddorEditAdminDeptHead={onAddorEditAdminDeptHead}
        deptHeads={deptHeads}
        onClickViewManagers={onClickViewManagers}
      />
      {showAdminDeptHeadForm ? (
        <AdminDeptHeadForm
          formVisible={showAdminDeptHeadForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          formMode={adminAdminDeptHeadFormMode}
          selectedDeptHead={selectedDeptHead}
        />
      ) : null}</>}
      <Toaster />
    </div>
    </>
  );
}

const mapStateToProps = (state) => ({
  deptHeads: state.SkillsCentralAdmin.deptHeads,
  deptManagers: state.SkillsCentralAdmin.deptManagers,
});

const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
  getDeptHeads: () => dispatch(getDeptHeadsThunk()),
  getDeptManagers: (deptId) => dispatch(getDeptManagersThunk(deptId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminDeptHeads);
