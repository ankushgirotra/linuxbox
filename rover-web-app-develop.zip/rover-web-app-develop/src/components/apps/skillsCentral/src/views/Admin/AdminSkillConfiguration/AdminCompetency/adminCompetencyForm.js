import React, { Component } from "react";
import { connect } from "react-redux";
import { addAdminCompetenciesThunk } from "../../../../store/admin.reducer";
import { editAdminCompetenciesThunk } from "../../../../store/admin.reducer";
import { handleAdminCompetencyAPIResponse, validateAdminForm } from "../../../../Services/admin.service";
import { getFormattedUserId } from "../../../../../../../../services/auth.services";
import sortBy from "../../../../../../../../services/helper.service";
import { FORM_CONTROL_DEFAULT } from "../../../../../../pcdm/src/constants/form.constants";
import { SC_ADMIN_ACTIONS, SKILL_TYPE } from "../../../../Constants/action.constants";
import { resourceTypeOptions as resourceTypeOptions } from "../../../../Constants/listOptions.constants";
import { DATA_STATUS } from "../../../../Constants/action.constants";
import { FormModal } from "../../../../../../pcdm/src/components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../../pcdm/src/components/forms/textField/textField";
import "../../admin.scss";
import "../adminSkillConfiguration.scss";
import "./adminCompetency.scss";

const ADMIN_COMPETENCY_FORM_INITIAL_STATE = {
  formControls: {
    edited: false,
    error: false,
    errorMessage: "",
    errorDetail: "",
    skillName: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    resourceType: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
    departmentId: {
      ...FORM_CONTROL_DEFAULT,
      required: true,
    },
  },
};

class AdminCompetencyForm extends Component {
  constructor(props) {
    super(props);
    this.state = { ...ADMIN_COMPETENCY_FORM_INITIAL_STATE };
  }

  
  componentDidMount() {
    const { formMode, selectedCompetency } = this.props;
    if (formMode === SC_ADMIN_ACTIONS.EDIT_COMP) {
      this.populateFileds(selectedCompetency);
    }
  }

  populateFileds = (selectedCompetency) => {
    const { formControls } = this.state;
    let departmentValue = this.getDeptFieldValue(selectedCompetency.department); 
    let rescType = selectedCompetency.resourceType === "Employee" ? 1: 2;
    let temp = selectedCompetency.resourceType;
    this.setState({
      formControls: {
        ...formControls,
        skillName: {
          ...formControls.skillName,
          value: selectedCompetency.skillName,
        },
        resourceType:{
          ...formControls.resourceType,
          value: rescType,
        },
        departmentId:{
          ...formControls.departmentId,
          value: departmentValue,
        },
      },
    });
  };

  getDeptFieldValue = (deptList) => {
    let deptListValue = deptList && deptList.length ? deptList.map((dept) => ({
      label: dept.abbreviation,
      value: dept.departmentId
    })) : [];
    return deptListValue;
  };

  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        edited: true,
        error: false,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
  };

  reqPayload = () => {
    const { formControls } = this.state;
    const { userParams } = this.props;
    let deptInfoList = formControls.departmentId.value
    let deptIdList = deptInfoList && deptInfoList.length ? deptInfoList.map((dept) => dept.value) : [];
    let empId = localStorage.getItem('emplyoee_id')
    let payload = {
      skillName: formControls.skillName.value,
      resourceTypeId: formControls.resourceType.value,
      resourceId: empId ? empId : getFormattedUserId(userParams),
      skillType: SKILL_TYPE.COMP,
      skillSubcategoryId: null,
      isSpecializedTechnology: false,
      isMainTechnology: false,
      departmentId: deptIdList,
    };
    return payload;
  };

  onSubmit = async (e) => {
    if (e) {
      e.preventDefault();
    }
    const { formControls } = this.state;
    const { formMode, closeModal, addAdminCompetency, editAdminCompetency,selectedCompetency } = this.props;
    let validation = validateAdminForm(formControls);
    if (validation.error) {
      this.setState({ formControls: { ...validation } });
    } else {
      let payload = this.reqPayload(formMode);
      console.log(formControls)
      if (formMode === SC_ADMIN_ACTIONS.ADD_COMP) {
        await addAdminCompetency(payload, closeModal);
      }else if (formMode === SC_ADMIN_ACTIONS.EDIT_COMP) {
        await editAdminCompetency(selectedCompetency.skillId, payload, closeModal);
      }
    }
  };

  getAdminCompetencyForm = () => {
    const { formControls } = this.state;
    const { deptHeads } = this.props;
    return (
      <form className="pcdm-form">
        <div className="pcdm-form__form-group">
          <div className="pcdm-form__form-group-field">
            <TextField
              name="skillName"
              label={"Competency"}
              type="text"
              formObj={formControls.skillName}
              isRequired={formControls.skillName.required}
              onChange={this.onInputChange}
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="resourceType"
              label={"Resource Type"}
              formObj={formControls.resourceType}
              isRequired={formControls.resourceType.required}
              config={{
                options: [...resourceTypeOptions],
                id: "id",
                value: "name",
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
          <div className={`pcdm-form__form-group-field`}>
            <CustomSelect
              name="departmentId"
              label={"Departments"}
              formObj={formControls.departmentId}
              isRequired={formControls.departmentId.required}
              isMulti={true}
              config={{
                options: deptHeads && deptHeads.length ? [...sortBy(deptHeads, "abbreviation")] : [],
                id: "departmentId",
                value: "abbreviation",
              }}
              onChange={(e) =>
                this.onInputChange({
                  target: { name: e.name, value: e.value },
                })
              }
            />
          </div>
        </div>
      </form>
    );
  };

  getFooter = () => {
    const { formControls } = this.state;
    const { closeModal } = this.props;
    return (
      <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
        <CustomButton
          variant={BUTTON_VARIANTS.PRIMARY}
          size="md"
          type={"submit"}
          disable={!formControls.edited}
          onClick={(e) => this.onSubmit(e)}
        >
          Save
        </CustomButton>
        <CustomButton
          disable={false}
          loading={false}
          variant={BUTTON_VARIANTS.LIGHT}
          onClick={() => closeModal()}
          size="md"
          type={"button"}
        >
          Cancel
        </CustomButton>
      </div>
    );
  }

  render() {
    const {
      formVisible,
      closeModal,
      addAdminCompetenciesStatus,
      editAdminCompetenciesStatus,
      header,
    } = this.props;
    return (
      <>
        <FormModal
          className="admin-competency-form"
          visible={formVisible}
          closeModal={() => closeModal()}
          header={header}
          content={() => this.getAdminCompetencyForm()}
          footer={() => this.getFooter()}
          isLoading={
            addAdminCompetenciesStatus.status === DATA_STATUS.LOADING || editAdminCompetenciesStatus.status === DATA_STATUS.LOADING
          }
        />
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  addAdminCompetenciesStatus: state.SkillsCentralAdmin.addAdminCompetenciesStatus,
  editAdminCompetenciesStatus: state.SkillsCentralAdmin.editAdminCompetenciesStatus,
  deptHeads: state.SkillsCentralAdmin.deptHeads.data,
  currentResource: state.SCUsersReducer.employeeDetails.data,
  userParams: state.AuthReducer.user,
});

const mapDispatchToProps = (dispatch) => ({
  addAdminCompetency: (payload, callback) =>
    dispatch(addAdminCompetenciesThunk(payload, callback)),
  editAdminCompetency: (skillId,payload, callback) =>
    dispatch(editAdminCompetenciesThunk(skillId,payload, callback))
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminCompetencyForm);
