import React, { useMemo } from "react";
import sortBy from "../../../../../../../../services/helper.service";
import DataGrid from "../../../../../../pcdm/src/components/DataGrid/dataGrid";
import LinkExtended from "../../../../../../../shared/Link/linkExtended";
import "../adminManageRoles.scss";
import { sampleJobTitleData } from "../../../../Constants/listOptions.constants";

export default function AdminJobTitleTable(props) {

  const { jobTitles, roles, deptHeads, onEditAdminJobTitle } = props;

  const columns = useMemo(() => [
    {
      Header: "Job Title ID",
      accessor: "jobTitleId",
      Cell: ({ row: { original } }) => showJobTitleHead(original, "jobTitleId"),
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Job Title",
      accessor: "jobTitle",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Role",
      accessor: "role",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Belt",
      accessor: "belt",
      disableFilters: true,
      disableSortBy: true,
    },
    {
      Header: "Department",
      accessor: "departmentName",
      disableFilters: true,
      disableSortBy: true,
    },
  ]);

  const showJobTitleHead = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() => 
          onEditAdminJobTitle({...row})
        }
      >
        {row[key]}
      </LinkExtended>
    );
  };

  let rolesList = [];
  if (Array.isArray(roles.data) && roles.data.length) {
    rolesList = roles.data.map((obj) => {
      const deptRow = deptHeads.data.filter((ob) => ob.departmentId === obj.departmentId)
      const deptName = deptRow[0] ? deptRow[0].departmentName : ""
      return { ...obj, departmentName: deptName }
    })
  }
  
  let jobTitlesList = [];
  if (Array.isArray(jobTitles.data) && jobTitles.data.length) {
    jobTitlesList = jobTitles.data.map((obj) => {
      const rolesRow = rolesList.filter((ob) => ob.roleId === obj.roleId)
      const deptName = rolesRow[0] ? rolesRow[0].departmentName : ""
      const role = rolesRow[0] ? rolesRow[0].roleName : ""
      return { ...obj, departmentName: deptName, role: role }
    })
  }
  
  const data = useMemo(() => [...sortBy(jobTitlesList, "jobTitleId")] , [jobTitlesList]);

  return <DataGrid data={data} columns={columns} noRowText={"No rows found"} />;

}

