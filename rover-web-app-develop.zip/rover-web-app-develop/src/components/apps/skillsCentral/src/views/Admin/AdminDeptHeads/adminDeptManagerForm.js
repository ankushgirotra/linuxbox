import React, { Component } from "react";
import { connect } from "react-redux";
import { validateAdminForm } from "../../../Services/admin.service";
import { editDepartmentManagerThunk } from "../../../store/admin.reducer";
import { FORM_CONTROL_DEFAULT } from "../../../../../pcdm/src/constants/form.constants";
import { DATA_STATUS } from "../../../../../pcdm/src/constants/service.constant";
import { FormModal } from "../../../../../pcdm/src/components/FormModal/formModal";
import CustomButton, { BUTTON_VARIANTS } from "../../../../../pcdm/src/components/forms/Button/button";
import CustomSelect from "../../../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
import TextField from "../../../../../pcdm/src/components/forms/textField/textField";
import "../admin.scss";
import "./adminDeptHeads.scss";

const ADMIN_MANAGER_INITIAL_STATE = {
    formControls: {
        edited: false,
        error: false,
        errorMessage: "",
        errorDetail: "",
        name: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
            readOnly: true,
        },
        actionMessage: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
            readOnly: true,
        },
        isActive: {
            ...FORM_CONTROL_DEFAULT,
            required: true,
        },
    },
};

class AdminDeptManagerForm extends Component {
    constructor(props) {
        super(props);
        this.state = { ...ADMIN_MANAGER_INITIAL_STATE };
    }

    componentDidMount() {
        const { selectedDeptManager } = this.props;
        this.populateFileds(selectedDeptManager);
    }

    populateFileds = (selectedDeptManager) => {
        const { formControls } = this.state;
        this.setState({
            formControls: {
                ...formControls,
                name: {
                    ...formControls.name,
                    value: selectedDeptManager.rmFullName,
                },
                actionMessage: {
                    ...formControls.actionMessage,
                    value: selectedDeptManager.actionMessage,
                },
                isActive: {
                    ...formControls.isActive,
                    value: selectedDeptManager.active ? 1 : 2,
                },
            },
        });
    };

    onInputChange = (event) => {
        const { formControls } = this.state;
        const name = event.target.name;
        const value = event.target.value;
        this.setState({
            formControls: {
                ...formControls,
                edited: true,
                error: false,
                [name]: {
                    ...formControls[name],
                    error: false,
                    value: value,
                },
            },
        });
    };

    onSubmit = async (e) => {
        if (e) {
            e.preventDefault();
        }
        const { formControls } = this.state;
        const { editDepartmentManager, closeModal, selectedDeptManager } = this.props;
        const isActive = formControls.isActive.value === 1 ? true: false;
        let validation = validateAdminForm(formControls);
        if (validation.error) {
            this.setState({ formControls: { ...validation } });
        } else {
            await editDepartmentManager(selectedDeptManager.departmentRmsId, isActive, closeModal);
        }
    };

    getHeader = () => {
        return "Edit Manager";
    };

    getAdminDeptManagerForm = () => {
        const { formControls } = this.state;
        return (
            <form className="pcdm-form">
                <div className="pcdm-form__form-group">
                    <div className="pcdm-form__form-group-field">
                        <TextField
                            name="name"
                            label={"Name"}
                            type="text"
                            formObj={formControls.name}
                            isRequired={formControls.name.required}
                            readOnly={formControls.name.readOnly}
                        />
                    </div>
                    <div className="pcdm-form__form-group-field">
                        <TextField
                            name="actionMessage"
                            label={"Action Message"}
                            type="text"
                            formObj={formControls.actionMessage}
                            isRequired={formControls.actionMessage.required}
                            readOnly={formControls.actionMessage.readOnly}
                        />
                    </div>
                    <div className={`pcdm-form__form-group-field`}>
                        <CustomSelect
                            name="isActive"
                            label={"isActive"}
                            formObj={formControls.isActive}
                            isRequired={formControls.isActive.required}
                            config={{
                                options: [
                                    { id: 1, value: "Yes" },
                                    { id: 2, value: "No" },
                                ],
                                id: "id",
                                value: "value",
                            }}
                            onChange={(e) =>
                                this.onInputChange({
                                    target: { name: e.name, value: e.value },
                                })
                            }
                        />
                    </div>
                </div>
            </form>
        );
    };

    getFooter = () => {
        const { formControls } = this.state;
        const { closeModal } = this.props;
        return (
            <div className={`pcdm-btn-wrapper pcdm-btn-wrapper--inline`}>
                <CustomButton
                    variant={BUTTON_VARIANTS.PRIMARY}
                    size="md"
                    type={"submit"}
                    disable={!formControls.edited}
                    onClick={(e) => this.onSubmit(e)}
                >
                    Save
                </CustomButton>
                <CustomButton
                    disable={false}
                    loading={false}
                    variant={BUTTON_VARIANTS.LIGHT}
                    onClick={() => closeModal()}
                    size="md"
                    type={"button"}
                >
                    Cancel
                </CustomButton>
            </div>
        );
    }

    render() {
        const {
            formVisible,
            closeModal,
            editDeptManagerStatus,
        } = this.props;
        return (
            <>
                <FormModal
                    className="sc-admin-dept_heads-form"
                    visible={formVisible}
                    closeModal={() => closeModal()}
                    header={this.getHeader()}
                    content={() => this.getAdminDeptManagerForm()}
                    footer={() => this.getFooter()}
                    isLoading={
                        editDeptManagerStatus.status === DATA_STATUS.LOADING
                    }
                />
            </>
        );
    }
}

const mapStateToProps = (state) => ({
    editDeptManagerStatus: state.SkillsCentralAdmin.editDeptManagerStatus,
});

const mapDispatchToProps = (dispatch) => ({
    editDepartmentManager: (deptRmId, isActive, callback) =>
        dispatch(editDepartmentManagerThunk(deptRmId, isActive, callback)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminDeptManagerForm);
