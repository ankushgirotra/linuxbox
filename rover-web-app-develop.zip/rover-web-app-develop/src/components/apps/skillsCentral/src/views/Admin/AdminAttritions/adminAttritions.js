import React, { useState } from "react";
import { connect } from "react-redux";
import { getAttritionOptionsThunk } from "../../../store/admin.reducer";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS, SC_ADMIN_ACTION_TYPE } from "../../../Constants/action.constants";
import { ACTIONS } from "../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../pcdm/src/constants/message.contants";
import Toaster from "../../../../../pcdm/src/components/Toaster/toaster";
import AdminAttritionTable from "./adminAttritionsTable";
import AdminAttritionForm from "./adminAttritionsForm";
import "./adminAttrition.scss";
import "../admin.scss";

function AdminAttrition(props) {

  const { showNotification, getAttritionOptions, attritionOptions } = props;

  const [showAdminAttritionForm, setShowAdminAttritionForm] = useState(false);

  const [adminAttritionFormMode, setAdminAttritionFormMode] = useState("");

  const [selectedAttritionOptions, setSelectedAttritionOptions] = useState({});

  const onAddorEditAdminAttrition = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_ATTRITION) {
      setShowAdminAttritionForm(true);
      setAdminAttritionFormMode(SC_ADMIN_ACTIONS.ADD_ATTRITION);
      setSelectedAttritionOptions({});
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_ATTRITION) {
      setShowAdminAttritionForm(true);
      setAdminAttritionFormMode(SC_ADMIN_ACTIONS.EDIT_ATTRITION);
      setSelectedAttritionOptions({ ...data });
    }
  };

  const onModalClose = (status, responseData, keepModal = false) => {
    let isAddForm = adminAttritionFormMode === SC_ADMIN_ACTIONS.ADD_ATTRITION;
    let isDeleted = status === SC_ADMIN_ACTION_TYPE.DELETE_ATTRITION_OPTION_SUCCESS;
    if (
      status === SC_ADMIN_ACTION_TYPE.ADD_ATTRITION_OPTION_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_ATTRITION_OPTION_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_ATTRITION_OPTION_SUCCESS
    ) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: isAddForm ? "Attrition added successfully" :
          (isDeleted ? "Attrition deleted successfully" : "Attrition updated successfully"),
      });
      getAttritionOptions();
      setShowAdminAttritionForm(false);
    } else if (
      status === SC_ADMIN_ACTION_TYPE.ADD_ATTRITION_OPTION_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_ATTRITION_OPTION_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_ATTRITION_OPTION_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (!keepModal || showAdminAttritionForm) {
      setShowAdminAttritionForm(false);
    }
  };
  

  return (
    <div className='admin-container sc-admin-attrition-container'>
      <AdminAttritionTable
        onAddorEditAdminAttrition={onAddorEditAdminAttrition}
        attritionOptions={attritionOptions}
      />
      {showAdminAttritionForm ? (
        <AdminAttritionForm
          formVisible={showAdminAttritionForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          formMode={adminAttritionFormMode}
          selectedAttritionOptions={selectedAttritionOptions}
        />
      ) : null}
      <Toaster />
    </div>
  );
}

const mapStateToProps = (state) => ({
  attritionOptions: state.SkillsCentralAdmin.attritionOptions,
});

const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
  getAttritionOptions: () => dispatch(getAttritionOptionsThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminAttrition);
