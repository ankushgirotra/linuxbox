import React, { useState } from "react";
import { connect } from "react-redux";
import { addNotification } from "../../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS, SC_ADMIN_ACTION_TYPE } from "../../../../Constants/action.constants";
import { getAdminCompetenciesThunk } from "../../../../store/admin.reducer";
import { ACTIONS } from "../../../../../../pcdm/src/constants/action.constants";
import AdminCompetencyTable from "./adminCompetencyTable";
import AdminCompetencyForm from "./adminCompetencyForm";
import "../../admin.scss";
import "../adminSkillConfiguration.scss";
import "./adminCompetency.scss";


function AdminCompetencyTab(props) {

  const {
    adminCompetencies,
    showNotification,
    getAdminCompetencies,
  } = props;

  const [skillCentralAdminFormMode, setSkillCentralAdminFormMode] = useState("");
  
  const [showAdminCompetencyForm, setShowAdminCompetencyForm] = useState(false);

  const [selectedCompetency, setSelectedCompetency] = useState({});

  const onAddorEditAdminCompetency = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_COMP) {
      setShowAdminCompetencyForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.ADD_COMP);
      setSelectedCompetency({});
    }else if (formMode === SC_ADMIN_ACTIONS.EDIT_COMP) {
      setShowAdminCompetencyForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.EDIT_COMP);
      setSelectedCompetency({ ...data });
    }
  };

  const getCompetencyHeader = () => {
    if (skillCentralAdminFormMode === SC_ADMIN_ACTIONS.ADD_COMP) {
      return "Add Competency";
    } else if (skillCentralAdminFormMode === SC_ADMIN_ACTIONS.EDIT_COMP) {
      return "Edit Competency";
    }
  };

  const onModalClose = (status, data) => {
    if (status === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_COMPETENCY_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Competency Added SuccessFully",
      });
      getAdminCompetencies();
      setShowAdminCompetencyForm(false);
    } else if (status === SC_ADMIN_ACTION_TYPE.ADD_ADMIN_COMPETENCY_ERROR) {
      let errResponse = data && data.response && data.response.data
        ? data.response.data : "Error in Adding Competency";
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (status === SC_ADMIN_ACTION_TYPE.EDIT_ADMIN_COMPETENCY_SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: "Competency Edited SuccessFully",
      });
      getAdminCompetencies();
      setShowAdminCompetencyForm(false);
    }
    else if (status === SC_ADMIN_ACTION_TYPE.EDIT_ADMIN_COMPETENCY_ERROR) {
      let errResponse = data && data.response && data.response.data
        ? data.response.data : "Error in Editing Competency";
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else {
      setShowAdminCompetencyForm(false);
    }
  };

  return (
    <div className="sc-admin-competency_tab-container">
      <AdminCompetencyTable
        onAddorEditAdminCompetency={onAddorEditAdminCompetency}
        adminCompetenciesList={adminCompetencies}
      />
      {showAdminCompetencyForm ? (
        <AdminCompetencyForm
          formVisible={showAdminCompetencyForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          header={getCompetencyHeader}
          formMode={skillCentralAdminFormMode}
          selectedCompetency={selectedCompetency}
        />
      ) : null}
    </div>
  );
}


const mapStateToProps = (state) => ({
  adminCompetencies: state.SkillsCentralAdmin.adminCompetencies,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminCompetencies: () => dispatch(getAdminCompetenciesThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminCompetencyTab);
