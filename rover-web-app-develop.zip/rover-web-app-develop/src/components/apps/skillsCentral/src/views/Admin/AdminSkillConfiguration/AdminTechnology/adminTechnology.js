import React, { useState } from "react";
import { connect } from "react-redux";
import { Edit } from "react-feather";
import { getSkillExpThunk, getAdminCategoryThunk } from "../../../../store/admin.reducer";
import { getTechnologiesThunk } from "../../../../store/users.reducer";
import { addNotification } from "../../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS } from "../../../../Constants/action.constants";
import { ACTIONS } from "../../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../../pcdm/src/constants/message.contants";
import { DATA_STATUS } from "../../../../../../pcdm/src/constants/service.constant";
import { OverlayLoader } from "../../../../../../pcdm/src/components/DataHandler/dataHandler";
import Property from "../../../../../../../shared/Property/property";
import AdminTechnologyForm from "./adminTechnologyForm";
import AdminTechnologyTable from "./adminTechnologyTable";
import AdminCategoryForm from "./adminCategoryForm";
import SkillExpirationForm from "./skillExpirationForm";
import "../../admin.scss";
import "../adminSkillConfiguration.scss";
import "./adminTechnology.scss";


function AdminTechnologyTab(props) {

  const {
    getSkillExp,
    getAdminTechnologies,
    getAdminCategories,
    showNotification,
    skillExpiration,
    technologies,
  } = props;

  const [skillCentralAdminFormMode, setSkillCentralAdminFormMode] = useState("");

  const [showSkillExpiryForm, setShowSkillExpiryForm] = useState(false);

  const [showAdminTechnologyForm, setShowAdminTechnologyForm] = useState(false);

  const [showAdminCategoryForm, setShowAdminCategoryForm] = useState(false);
  
  const [selectedTechnology, setSelectedTechnology] = useState({});

  const onModifySkillExpiration = () => {
    setShowSkillExpiryForm(true);
    setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.EDIT_SKILL_EXPIRATION);
  };

  const onAddorEditAdminTechnology = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_TECH) {
      setShowAdminTechnologyForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.ADD_TECH);
      setSelectedTechnology({});
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_TECH) {
      setShowAdminTechnologyForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.EDIT_TECH);
      setSelectedTechnology({ ...data });
    }
  };

  const onAddorEditAdminCategory = (formMode) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_CATEGORY) {
      setShowAdminCategoryForm(true);
      setSkillCentralAdminFormMode(SC_ADMIN_ACTIONS.ADD_CATEGORY);
    }
  };

  const onModalClose = (status, data) => {
    if (status === ACTIONS.SUCCESS) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: data.message,
      });
      if (showSkillExpiryForm) {
        getSkillExp();
        setShowSkillExpiryForm(false);
      } else if (showAdminCategoryForm) {
        getAdminCategories();
        setShowAdminCategoryForm(false);
      } else {
        getAdminTechnologies();
        setShowAdminTechnologyForm(false);
      }
    } else if (status === ACTIONS.ERROR) {
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: data && data.message ? data.message : ERROR_MSG.COMMON_ERR,
      });
    } else {
      setShowAdminTechnologyForm(false);
      setShowSkillExpiryForm(false);
      setShowAdminCategoryForm(false);
    }
  };

  const getTechnologyFormHeader = () => {
    if (skillCentralAdminFormMode === SC_ADMIN_ACTIONS.ADD_TECH) {
      return "Add Technology";
    } else if (skillCentralAdminFormMode === SC_ADMIN_ACTIONS.EDIT_TECH) {
      return "Edit Technology";
    }
  };

  return (
    <div className="sc-admin-technology_tab-container">
      <OverlayLoader loading={technologies.status === DATA_STATUS.LOADING} />
      <div className="sc-admin-actions">
        <Property
          className="skill-exp-prop"
          name="Skill Expiration"
          value={`${skillExpiration.data} Month${Number(skillExpiration.data) > 1 ? `s` : ``}`}
          onIconClick={onModifySkillExpiration}
          icon={<Edit size="12" strokeWidth={3} />}
        />
      </div>
      <AdminTechnologyTable
        onAddorEditAdminTechnology={onAddorEditAdminTechnology}
        onAddorEditAdminCategory={onAddorEditAdminCategory}
      />
      {showSkillExpiryForm ? (
        <SkillExpirationForm
          formVisible={showSkillExpiryForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          header={"Skill Expiration"}
          formMode={skillCentralAdminFormMode}
        />
      ) : null}
      {showAdminTechnologyForm ? (
        <AdminTechnologyForm
          formVisible={showAdminTechnologyForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          header={() => getTechnologyFormHeader()}
          formMode={skillCentralAdminFormMode}
          selectedTechnology={selectedTechnology}
        />
      ) : null}
      {showAdminCategoryForm ? (
        <AdminCategoryForm
          formVisible={showAdminCategoryForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          header={"Add Category"}
          formMode={skillCentralAdminFormMode}
        />
      ) : null}
    </div>
  );
}

const mapStateToProps = (state) => ({
  technologies: state.SCUsersReducer.technologies,
  skillExpiration: state.SkillsCentralAdmin.skillExpiration,
  categoryOptions: state.SkillsCentralAdmin.adminCategories,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminTechnologies: () => dispatch(getTechnologiesThunk()),
  showNotification: (notification) => dispatch(addNotification(notification)),
  getSkillExp: () => dispatch(getSkillExpThunk()),
  getAdminCategories: () => dispatch(getAdminCategoryThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminTechnologyTab);
