import React, { useState } from "react";
import { connect } from "react-redux";
import { getManageVendorsThunk } from "../../../store/admin.reducer";
import { addNotification } from "../../../../../pcdm/src/store/common.reducer";
import { SC_ADMIN_ACTIONS ,SC_ADMIN_ACTION_TYPE } from "../../../Constants/action.constants";
import { ACTIONS } from "../../../../../pcdm/src/constants/action.constants";
import { ERROR_MSG } from "../../../../../pcdm/src/constants/message.contants";
import Toaster from "../../../../../pcdm/src/components/Toaster/toaster";
import AdminManageVendorsTable from "./adminManageVendorsTable";
import AdminManageVendorForm from "./adminManageVendorsForm";
import "./adminManageVendor.scss";
import "../admin.scss";

function AdminManageVendors(props) {

  const { showNotification, getManageVendors, vendors } = props;

  const [showAdminManageVendorForm, setShowAdminManageVendorForm] = useState(false);

  const [adminAdminManageVendorFormMode, setAdminManageVendorFormMode] = useState("");

  const [selectedVendor, setSelectedVendor] = useState({}); 

  const onAddorEditAdminManageVendor = (formMode, data) => {
    if (formMode === SC_ADMIN_ACTIONS.ADD_VENDOR) {
      setShowAdminManageVendorForm(true);
      setAdminManageVendorFormMode(SC_ADMIN_ACTIONS.ADD_VENDOR);
      setSelectedVendor({});
    } else if (formMode === SC_ADMIN_ACTIONS.EDIT_VENDOR) {
      setShowAdminManageVendorForm(true);
      setAdminManageVendorFormMode(SC_ADMIN_ACTIONS.EDIT_VENDOR);
      setSelectedVendor({ ...data });
    }  
  };

  const onModalClose = (status, responseData, keepModal = false) => {
    let isAddForm = adminAdminManageVendorFormMode === SC_ADMIN_ACTIONS.ADD_VENDOR;
    let isDeleted = status === SC_ADMIN_ACTION_TYPE.DELETE_MANAGE_VENDOR_SUCCESS;

    if (
      status === SC_ADMIN_ACTION_TYPE.ADD_MANAGE_VENDOR_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_MANAGE_VENDOR_SUCCESS ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_MANAGE_VENDOR_SUCCESS
    ) {
      showNotification({
        title: "Success",
        variant: ACTIONS.SUCCESS,
        content: isAddForm ? "Vendor added successfully" :
        (isDeleted ? "Vendor deleted successfully" : "Vendor updated successfully")
      });
      getManageVendors();
      setShowAdminManageVendorForm(false);
    } else if (
      status === SC_ADMIN_ACTION_TYPE.ADD_MANAGE_VENDOR_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.EDIT_MANAGE_VENDOR_ERROR ||
      status === SC_ADMIN_ACTION_TYPE.DELETE_MANAGE_VENDOR_ERROR
    ) {
      let errResponse = responseData && responseData.data && responseData.data.length
        && responseData.data[0].message ? responseData.data[0].message : ERROR_MSG.COMMON_ERR;
      showNotification({
        title: "Error",
        variant: ACTIONS.ERROR,
        content: errResponse,
      });
    } else if (!keepModal || showAdminManageVendorForm) {
      setShowAdminManageVendorForm(false);  //close the form on click of cancel or close icon
    }
  };

  return (
    <div className='admin-container sc-admin-manage_vendor-container'>
      <AdminManageVendorsTable
        vendors={vendors}
        onAddorEditAdminManageVendor={onAddorEditAdminManageVendor}
      />
      {showAdminManageVendorForm ? (
        <AdminManageVendorForm
          formVisible={showAdminManageVendorForm}
          closeModal={(status, data, keepModal) => onModalClose(status, data, keepModal)}
          formMode={adminAdminManageVendorFormMode}
          selectedVendor={selectedVendor}
        />
      ) : null}
      <Toaster />
    </div>
  );
}

const mapStateToProps = (state) => ({
  vendors: state.SkillsCentralAdmin.vendors,
});

const mapDispatchToProps = (dispatch) => ({
  showNotification: (notification) => dispatch(addNotification(notification)),
  getManageVendors: () => dispatch(getManageVendorsThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(AdminManageVendors);
