export const methodologiesmock=[
    {
        "methodologyId":1,
        "methodologyName":"Scrum",
        "createdDate":"2018-03-30T04:01:42.000+0000"
    },
    {
        "methodologyId":2,
        "methodologyName":"Kanban",
        "createdDate":"2018-03-30T04:01:42.000+0000"
    }
]


export const resourceMethodologiesmock=[
    {
        "id":14,
        "resourceId":"420045",
        "resourceName":"Badhweliraja Pradeepreddy",
        "methodologyId":1,
        "methodologyName":"Scrum",
        "expertiseLevel":2,
        "active":true,
        "sourceName":"test test",
        "comments":"test",
        "createdDate":"2020-12-14T04:11:20.000+0000"
    }
]