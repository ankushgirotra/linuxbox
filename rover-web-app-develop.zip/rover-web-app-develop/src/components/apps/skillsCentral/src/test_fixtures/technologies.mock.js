export const technologiesmock=
[
    {
        "skillId": 1,
        "skillName": "Cobol",
        "skillCategory": "Cobol",
        "skillDescription": " ",
        "specializedSkills": false,
        "highLevelTechName": "MF Language",
        "mainTechnology": true,
        "created": "2018-03-29T22:31:42.000+0000",
        "createdBy": "Rajesh kumar Sankaran",
        "modified": "2018-05-16T15:26:23.000+0000",
        "modifiedBy": "Patsy Trickel",
        "profileName": "Mainframe",
        "profileNameProfileID": "6.00000000000000",
        "active": true,
        "itemType": "Item",
        "path": "teams/Rover/Lists/Skills"
    },
    {
        "skillId": 2,
        "skillName": "CICS",
        "skillCategory": "Cobol",
        "skillDescription": " ",
        "specializedSkills": false,
        "highLevelTechName": "MF Language",
        "mainTechnology": false,
        "created": "2018-03-29T22:31:42.000+0000",
        "createdBy": "Rajesh kumar Sankaran",
        "modified": "2018-03-29T22:31:42.000+0000",
        "modifiedBy": "Rajesh kumar Sankaran",
        "profileName": " ",
        "profileNameProfileID": " ",
        "active": true,
        "itemType": "Item",
        "path": "teams/Rover/Lists/Skills"
    },
    {
        "skillId": 3,
        "skillName": "JCL",
        "skillCategory": "Cobol",
        "skillDescription": " ",
        "specializedSkills": false,
        "highLevelTechName": "MF Language",
        "mainTechnology": false,
        "created": "2018-03-29T22:31:42.000+0000",
        "createdBy": "Rajesh kumar Sankaran",
        "modified": "2018-03-29T22:31:42.000+0000",
        "modifiedBy": "Rajesh kumar Sankaran",
        "profileName": " ",
        "profileNameProfileID": " ",
        "active": true,
        "itemType": "Item",
        "path": "teams/Rover/Lists/Skills"
    }
];



export const resourceTechnologymock=
[
    {
        "id": 1,
        "resourceId": "390560",
        "resourceName": "Anil kumar Kasturi",
        "technologyId": 1,
        "technologyName": "Cobol",
        "expertiseLevel": 1,
        "active": true,
        "activeTech": true,
        "sourceName": "Test Test",
        "comments": "test",
        "createdDate": "2020-12-09T10:24:12.000+0000",
        "history": []
    },
    {
        "id": 2,
        "resourceId": "390560",
        "resourceName": "Anil kumar Kasturi",
        "technologyId": 2,
        "technologyName": "CICS",
        "expertiseLevel": 1,
        "active": true,
        "activeTech": false,
        "sourceName": "test",
        "comments": "",
        "createdDate": "2020-12-09T10:24:29.000+0000",
        "history": []
    }
];



