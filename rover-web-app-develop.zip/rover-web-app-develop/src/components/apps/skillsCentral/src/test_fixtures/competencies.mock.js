export const competenciesMock=[
    {
        "competencyId":1,
        "competencyName":"Analytical Thinking & Problem Solving",
        "description":"Problem Structuring / FramingStrategic AnalysisOut-of-the-box ThinkingAnalytical Modeling",
        "forEmployee":true
    },
    {
        "competencyId":2,
        "competencyName":"Business Acumen",
        "description":"Industry KnowledgeOrganizational KnowledgeProduct and Service KnowledgeCore Business Capabilities",
        "forEmployee":true
    }, 
    {
        "competencyId":3,
        "competencyName":"Stakeholder and Relationship Mgmt",
        "description":"Relationship ManagementCustomer FocusBusiness CommunicationBusiness Imperatives and Technology Implications",
        "forEmployee":true
    }
]
