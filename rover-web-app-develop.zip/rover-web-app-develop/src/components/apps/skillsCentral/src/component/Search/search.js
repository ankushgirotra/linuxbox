import React, { Component } from "react";
import { Search } from "react-feather";
import './search.scss';


class SearchTextField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formControls: {
        searchText: { value: "", error: false, errorMsg: "" },
      },
    };
  }
  onInputChange = (event) => {
    const { formControls } = this.state;
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      formControls: {
        ...formControls,
        [name]: {
          ...formControls[name],
          error: false,
          value: value,
        },
      },
    });
    this.props.filterUpdate(value);
  };
  render() {
    const { formControls } = this.state;
    return (
      <div className="input_field-search_icon-wrapper">
        <input
          name="searchText"
          className={"pcdm-input"}
          type={"text"}
          placeholder="Search..."
          value={formControls.searchText.value}
          onChange={this.onInputChange}
          required={false}
        />
        <span className="input_field-search_icon">
          <Search size="20" strokeWidth={2} />
        </span>
      </div>
    );
  }
}
export default SearchTextField;
