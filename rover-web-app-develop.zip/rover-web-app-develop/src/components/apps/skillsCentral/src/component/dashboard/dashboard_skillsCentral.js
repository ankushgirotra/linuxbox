import React from 'react';

function DashboardSkillsCentral () {
  return (
    <section>
      <div>
        <div>
          <h1 className='title '>
              Skills Central
          </h1>
          <h2 className='subtitle'>
            Find the perfect resource
          </h2>
        </div>
      </div>
    </section>
  );
}

export default DashboardSkillsCentral;
