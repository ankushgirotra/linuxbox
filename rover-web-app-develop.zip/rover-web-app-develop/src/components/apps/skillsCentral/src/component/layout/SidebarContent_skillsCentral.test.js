import React from 'react';
import { configure, shallow } from 'enzyme/build';
import Adapter from 'enzyme-adapter-react-16/build';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import { SidebarSkillsCentral } from './SidebarContent_skillsCentral';
import localStorageMock from '../../../../../../__mocks__/localStorage';

// for enzyme to work
configure({ adapter: new Adapter() });

let component = null;

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
const store = mockStore();

const baseProps = {
  hideSidebar: jest.fn(),
  logout: jest.fn()
};

describe('SidebarContent component', () => {
  beforeEach(() => {
    console.error = jest.fn();
    component = shallow(<SidebarSkillsCentral {...baseProps} />);
  });

  describe('Have the Sidebar content generate', () => {
    it('should trigger logout after click the logout link', () => {
      localStorageMock.setItem('token', 'ValidToken');
      const click = component.find('[title="Log Out"]');
      const mockWindow = { location: { reload: null } };
      jest.fn({ window: mockWindow });
      click.simulate('click');
      expect(global.window.location.pathname).toBe('/');
    });
    it('should trigger hideSidebar after click the Dashboard', () => {
      const click = component.find('[title="Dashboard"]');
      click.simulate('click');
      expect(baseProps.hideSidebar).toHaveBeenCalled();
    });
  });
});
