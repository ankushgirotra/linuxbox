import React from "react";
import "./list.scss";
import { ChevronRight } from "react-feather";

export default function List({ listArray, id, displayKey, onClick, isActive, className = "", content = null }) {
  return (
    <div className={`sc-scroll-vertical ${className}`}>
      <ul className="skillcentral-list scroll-content">
        {listArray.map((item, index) => {
          let activeClassName = isActive(item) ? "skillcentral-list--item__active" : "";
          return (
            <li
              key={index}
              className={`skillcentral-list--item ${activeClassName}`}
              onClick={() => onClick(item)}
            >
              {content && typeof content === "function" ? content(item, displayKey, index) : <span>{item[displayKey]}</span>}
              {/* <ChevronRight className="list-direction" size={18} strokeWidth={3} /> */}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
