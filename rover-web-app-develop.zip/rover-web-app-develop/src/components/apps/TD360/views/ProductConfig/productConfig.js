import React, { useEffect } from "react";
import { 
  getTDProductDetailsThunk, 
  getProductContactDetailsThunk,
  getProductTeamDetailsThunk,
 } from "../../store/tdProducts.reducer";
import { connect } from "react-redux";
import { Button } from "react-bootstrap";
import { Edit3 } from "react-feather";
import { TD360_ROUTES } from "../../../../app/Route/constants/td360Routes.constants";
import { useHistory } from "react-router";
import ProductDetailsView from "./ProductDetailsView";
import BackMoveButton from "./backMoveButton";
import ProductTeamDetails from "./ProductTeamsDetails";
import "./productConfig.scss";
import ProductCommentsView from "./ProductCommentsView";
import ProductMaturityDetailsView from "./productMaturityDetailsView";

function ProductContact(props) {

  const { 
    getTDProductDetails, 
    ProductDetails, 
    getProductContactDetails, 
    ProductContactDetails,
    getProductTeamDetails,
    TeamDetails,
   } = props;

  useEffect(() => {
    let productId = localStorage.getItem("tdProductId");
    console.log(productId);
    getTDProductDetails(productId);
    getProductContactDetails(productId);
    getProductTeamDetails(productId);
  }, []);

  const history = useHistory();
  const onEditClick = () => {
    history.push({
      pathname: `${TD360_ROUTES.getEditRoute()}`,
    });
  };

  return (
    <div className="td360_product_dashboard">
      <div className="editdetails">
        <span className="pageName">
          {" "}
          Product Details Dashboard - {ProductDetails.data.productId}{" "}
        </span>
        <Button fliud={true}>
          <Edit3 size={10} strokeWidth={2} />
          <span onClick={onEditClick}>Edit Configuration</span>
        </Button>
      </div>
      <div className="productDetails">
        <label>Product ID - {ProductDetails.data.productId} |</label>
        <label>Product Name - {ProductDetails.data.productName} |</label>
        <label>Product Line Id - {ProductDetails.data.productLineId} </label>
      </div>
      
       <BackMoveButton/>
      {/* <div className="td360Container" id="td360"></div> */}
      <ProductDetailsView ProductContactDetails={ProductContactDetails.data} />
      <ProductTeamDetails TeamDetails={TeamDetails.data} />
      <ProductMaturityDetailsView/>
      <ProductCommentsView />
    </div>
  );
}
const mapStateToProps = (state, ownProps) => ({
  ProductDetails: state.TDProductsReducer.TDProductDetails,
  ProductContactDetails: state.TDProductsReducer.ProductContactDetails,
  TeamDetails: state.TDProductsReducer.ProductTeamDetails,
});

const mapDispatchToProps = (dispatch) => ({
  getTDProductDetails: (productId) =>  dispatch(getTDProductDetailsThunk(productId)),
  getProductContactDetails: (productId) => dispatch(getProductContactDetailsThunk(productId)),
  getProductTeamDetails: (productId) => dispatch(getProductTeamDetailsThunk(productId))
});

export default connect(mapStateToProps, mapDispatchToProps)(ProductContact);
