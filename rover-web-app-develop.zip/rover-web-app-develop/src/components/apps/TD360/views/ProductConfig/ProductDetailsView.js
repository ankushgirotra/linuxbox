import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import moment from "moment";
import "./ProductDetailsView.scss";

function ProductDetailsView(props) {

  const { ProductContactDetails } = props;

  const [ProductDetailsToggle, setProductDetailsToggle] = useState(false);

  const onArrowClick = () => {
    setProductDetailsToggle(!ProductDetailsToggle);
  };
  return (
    <div className="td_product_contact_readOnly">
      <Container>
        <div className="contact_section1">
          <Row className="rrc-request-comments-header" >
            <div className="rrc-request-comments-blueBar"></div>
            <Col className="rrc-request-comments-titleProps">
              <p
                style={{
                  color: "#3B77FE",
                  paddingRight: "5px",
                  fontSize: "16px",
                }}
              >
                Product Contact Details
              </p>
            </Col>
            <Col className="rrc-request-comments-collapsible">
              {ProductDetailsToggle ? (
                <span style={{ fontSize: "20px" }} onClick={onArrowClick}>
                  <i className="fas fa-caret-up"></i>
                </span>
              ) : (
                <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                  <i className="fas fa-caret-down"></i>
                </div>
              )}
            </Col>
          </Row>

          {!ProductDetailsToggle ? (
            <React.Fragment>
              <Row className="td_product_info-container">
                <Col className="td_product">
                  <p className="td_product_label">Product ID: </p>
                  <p className="td_product_value">{ProductContactDetails.productId}</p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Product Name: </p>
                  <p className="td_product_value">
                    {ProductContactDetails.productName}
                  </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Product Line ID: </p>
                  <p className="td_product_value">{ProductContactDetails.productLineId} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Product Line Name: </p>
                  <p className="td_product_value">
                    {ProductContactDetails.productLine}
                  </p>
                </Col>
              </Row>
              <Row className="td_product_info-container">
                <Col className="td_product">
                  <p className="td_product_label">TDU Applicability: </p>
                  <p className="td_product_value">
                    {ProductContactDetails.techDebtUpdateApplicability}
                  </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Code Repository: </p>
                  <p className="td_product_value">{ProductContactDetails.codeRepo} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">
                    DSL (Development Service Lead):{" "}
                  </p>
                  <p className="td_product_value">{ProductContactDetails.dslName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">
                    Engineering Service Manager:{" "}
                  </p>
                  <p className="td_product_value">{ProductContactDetails.emsName} </p>
                </Col>
              </Row>
              <Row className="td_product_info-container">
                <Col className="td_product">
                  <p className="td_product_label">Quality ESM: </p>
                  <p className="td_product_value">{ProductContactDetails.qaEsmName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Release Analyst: </p>
                  <p className="td_product_value">{ProductContactDetails.releaseAnalystName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Lead Engineer: </p>
                  <p className="td_product_value">{ProductContactDetails.leadEngName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">AMS/ARES Lead: </p>
                  <p className="td_product_value">{ProductContactDetails.amsLeadName} </p>
                </Col>
              </Row>
              <Row className="td_product_info-container">
                <Col className="td_product">
                  <p className="td_product_label">IT Product Manager: </p>
                  <p className="td_product_value">{ProductContactDetails.itpmName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">
                    Alternate Product Manager:{" "}
                  </p>
                  <p className="td_product_value">{ProductContactDetails.itAlternateITPMName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Application Architect: </p>
                  <p className="td_product_value">{ProductContactDetails.appArchitectName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Business Analyst: </p>
                  <p className="td_product_value">{ProductContactDetails.busAnalystName} </p>
                </Col>
              </Row>
              <Row className="td_product_info-container">
                <Col className="td_product">
                  <p className="td_product_label">System Analyst: </p>
                  <p className="td_product_value">{ProductContactDetails.systemAnalystName} </p>
                </Col>
              </Row>
              <Row className="td_product_info-container">
                <Col className="td_product">
                  <p className="td_product_label">Modified By </p>
                  <p className="td_product_value">{ProductContactDetails.modifiedByName} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Modified Date </p>
                  <p className="td_product_value">
                    {/* {ProductContactDetails.modifiedDate}  */}
                    {ProductContactDetails.modifiedDate?moment(ProductContactDetails.modifiedDate).format("MM/DD/YYYY"):"-"}
                  </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Created By </p>
                  <p className="td_product_value">{ProductContactDetails.createdBy} </p>
                </Col>
                <Col className="td_product">
                  <p className="td_product_label">Created Date </p>
                  <p className="td_product_value">
                    {/* {ProductContactDetails.createdDate}  */}
                    {ProductContactDetails.createdDate?moment(ProductContactDetails.createdDate).format("MM/DD/YYYY"):"-"}
                  </p>
                </Col>
              </Row>
            </React.Fragment>
          ) : null}
        </div>
      </Container>
    </div>
  );
}

export default ProductDetailsView;
