import React,{useState} from 'react'
import { Container, Row, Col } from "react-bootstrap";
import { Button } from "react-bootstrap";
import "./comments.scss";

function Comments(props){
    const [commentsToggle, setCommentsToggle] = useState(false);

    const onArrowClick = () => {
        setCommentsToggle(!commentsToggle);
    };
    return(
        <div className='td_add_comments'>
            <Container>
                <div className="addComments">
                    <Row className = "rrc-request-comments-header">
                    <div className= "rrc-request-comments-blueBar"></div>
                    <Col className= "rrc-request-comments-titleProps">
                        <p
                            style={{
                                color: "#3B77FE",
                                paddingRight: "5px",
                                fontSize: "16px",
                            }}
                        >
                            Comments
                        </p>
                    </Col>
                    <Col className="rrc-request-comments-collapsible">
                        {commentsToggle ? (
                            <span style={{ fontSize: "20px"}} onClick={onArrowClick}>
                                <i className="fas fa-caret-up"></i>
                            </span>
                    ) : (
                    <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                        <i className="fas fa-caret-down"></i>
                    </div>
                )}
                    </Col>
                    </Row>
                {!commentsToggle ? (
                    <React.Fragment>
                        <Row className = "td_add_comments">
                            <Col>
                                <textarea placeholder='Enter comment' className= "td_comments_textarea" ></textarea>
                            </Col>
                            <Col className= "td_comments_button">
                                <Button>
                                    <span>Add comments</span>
                                </Button>
                            </Col>
                        </Row>
                    </React.Fragment>
                ) : null}
                </div>
            </Container>
        </div>
    )
}
export default Comments;