import React,{Fragment, useState} from "react";
import { Row, Col } from "react-bootstrap";
import Avatar from "../../../../shared/components/Avatar/avatar";

const COMMENTS_INITIAL_STATE = {
  detailsCollapsed: true
}

function ProductCommentsView(props){
  const [requestCommentsState, setRequestCommentsState] = useState(COMMENTS_INITIAL_STATE);
  const productComments=[
    {initial: 'JM', commentorName: 'John Martin', comment: 'Working as expected', time:'30 March 2023 10:30 AM' },
    {initial: 'MA', commentorName: 'Michiel Arrington', comment: 'Evrything looks good', time: '30 March 2023 11:30 AM' },
    {initial: 'ML', commentorName: 'Mach Lakshmanan', comment: 'No issues', time: '30 March 2023 12:30 AM' },
  ];

  const onArrowClick = () => {
    setRequestCommentsState({
        ...requestCommentsState,
        detailsCollapsed: !requestCommentsState.detailsCollapsed
    })
}

    return(
        <Fragment>
          <div className="td_product_contact_readOnly">
           <div className="contact_section1">
           <Row className="rrc-request-comments-header" style={{ margin: "0px" }}>
             <div className="rrc-request-comments-blueBar"></div>
               <Col className="rrc-request-comments-titleProps">
                  <p style={{ color: "#3B77FE", paddingRight: "0px", fontSize: "16px" }} >Comments</p>
                </Col>
                <Col className="rrc-request-comments-collapsible">
                  {requestCommentsState.detailsCollapsed ?
                    <span style={{ fontSize: "20px" }} onClick={onArrowClick}>
                        <i className="fas fa-caret-down"></i>
                    </span> :
                    <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                        <i className="fas fa-caret-up"></i>
                    </div>
                  }
                </Col>       
            </Row>
            
           <Row className="rrc-request-comments-body" style={{ margin: "0px" }} >    
             {requestCommentsState.detailsCollapsed ?
             <>
              <Col sm={12} md={12} lg={12} xl={12} >
                  <div className="add-scroll">
                     {productComments.map(comment=>{return(            
                    <div>
                      <Row style={{ marginTop: "0px" }}>
                      <Col sm={1} md={1} lg={1} xl={1}>
                        <Avatar initial={comment.initial}></Avatar>
                      </Col>
                      <Col sm={11} md={11} lg={11} xl={11}  style={{ paddingLeft: "10px" }}>
                        <p className="commentor-info">
                           <p><span className="commentor-name">{comment.commentorName} | {comment.time}</span>  </p>
                           <span className="comment">{comment.comment}</span>
                        </p> 
                        </Col> 
                      </Row>
                      <hr className="hr" />
                    </div>
                    );
                  })}                      
                  </div>
              </Col>
              </> : ""
            }
           </Row>
           </div>
          </div> 
        </Fragment>
    )
}

export default ProductCommentsView;

