
import React from 'react';
import { useHistory } from 'react-router-dom';
import { ArrowLeft } from "react-feather";
import { Row } from "react-bootstrap";
import { TD360_ROUTES } from '../../../../app/Route/constants/td360Routes.constants';

const BackMoveButton = () => {

    const history = useHistory();


    const clickHandler = () => {
        history.push(TD360_ROUTES.getHomeRoute());
    };


    return (
        <React.Fragment>
            <Row style={{ padding: "0px 10px 10px 10px" }}>
                <span className={"go-back-arrow"} style={{marginLeft: "3em", marginTop: "2px" }}>
                    <p onClick={clickHandler} >
                        <ArrowLeft size={13} />Go Back 
                    </p>
                </span>
            </Row>
        </React.Fragment>
    );
};

export default BackMoveButton;