import React, { useEffect, useState } from "react";
import { Container, Row, Col } from "react-bootstrap";

function ProductTeamsDetails(props) {

  const { TeamDetails } = props;

  const [ProductDetailsToggle, setProductDetailsToggle] = useState(false);

  const onArrowClick = () => {
    setProductDetailsToggle(!ProductDetailsToggle);
  };
  return (
    <div className="td_product_contact_readOnly">
      <Container>
        <div className="contact_section1">
          <Row className="rrc-request-comments-header" >
            <div className="rrc-request-comments-blueBar"></div>
            <Col className="rrc-request-comments-titleProps">
              <p
                style={{
                  color: "#3B77FE",
                  paddingRight: "5px",
                  fontSize: "16px",
                }}
              >
                Product Teams Details
              </p>
            </Col>
            <Col className="rrc-request-comments-collapsible">
              {ProductDetailsToggle ? (
                <span style={{ fontSize: "20px" }} onClick={onArrowClick}>
                  <i className="fas fa-caret-up"></i>
                </span>
              ) : (
                <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                  <i className="fas fa-caret-down"></i>
                </div>
              )}
            </Col>
          </Row>
          {!ProductDetailsToggle ? (
            <React.Fragment>
              {TeamDetails.map((TeamDetails, index) => {
                return (
                  <React.Fragment>
                    <Row className="td_product_info-container" Key={index}>
                      <Col className="td_product">
                        <p className="td_product_label">Team  Name:</p>
                        <p className="td_product_value">{TeamDetails.productTeamName}</p>
                      </Col>
                      <Col className="td_product">
                        <p className="td_product_label">Vendor Name:</p>
                        <p className="td_product_value">{TeamDetails.vendorName}</p>
                      </Col>
                      <Col className="td_product">
                        <p className="td_product_label">Vendor Liason:</p>
                        <p className="td_product_value">{TeamDetails.vendorLiasonFullName}</p>
                      </Col>
                      <Col className="td_product">
                        <p className="td_product_label">Scrum Master:</p>
                        <p className="td_product_value">{TeamDetails.scrumMasterFullName}</p><br></br>
                      </Col>
                    </Row>
                    <Row className="td_product_info-container" key={index}>
                      <Col className="td_product">
                        <p className="td_product_label">Skills:</p>
                        <p className="td_product_value">{TeamDetails.skillName}</p>
                      </Col>
                      <Col className="td_product">
                        <p className="td_product_label">Jira Board Name:</p>
                        <p className="td_product_value">{TeamDetails.jiraBoardName}</p>
                      </Col>
                    </Row>
                    <hr className="hr" />
                  </React.Fragment>
                )
              })}


            </React.Fragment>
          ) : null}

        </div>
      </Container>
    </div>
  );

}
export default ProductTeamsDetails;
