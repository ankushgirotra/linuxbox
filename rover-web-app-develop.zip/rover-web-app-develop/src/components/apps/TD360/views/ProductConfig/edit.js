import React, { useEffect } from "react";
import { getTDProductDetailsThunk } from "../../store/tdProducts.reducer";
import { connect } from "react-redux";
import { Button } from "react-bootstrap";
import { Edit3 } from "react-feather";
import BackMoveButton from "./backButton";
import ProductTeamDetails from "./ProductTeamsDetails";
import ProductDetailsView from "./ProductDetailsView";
import "./edit.scss";
import Comments from "./comments";

function Edit(props) {
    const { 
        getTDProductDetails, 
        ProductDetails, 
       } = props;
    return (
        <div className="td360_product_dashboard">
      <div className="editdetails">
        <span className="pageName">
          {" "}
          Product Details Dashboard - {ProductDetails.data.productId}{" "}
        </span>
        <Button fliud={true}>
          <Edit3 size={10} strokeWidth={2} />
          <span onClick>Save Details</span>
        </Button>
      </div>
      <div className="productDetails">
      <label>Product ID - {ProductDetails.data.productId} |</label>
        <label>Product Name - {ProductDetails.data.productName} |</label>
        <label>Product Line Id - {ProductDetails.data.productLineId} </label>
      </div>
        <BackMoveButton/>
        <div>(<Comments/>)</div>
      </div>
    )
}
const mapStateToProps = (state, ownProps) => ({
    ProductDetails: state.TDProductsReducer.TDProductDetails
});
const mapDispatchToProps = (dispatch) => ({
    getTDProductDetails: (productId) =>  dispatch(getTDProductDetailsThunk(productId))
  });
 export default connect(mapStateToProps, mapDispatchToProps) (Edit);