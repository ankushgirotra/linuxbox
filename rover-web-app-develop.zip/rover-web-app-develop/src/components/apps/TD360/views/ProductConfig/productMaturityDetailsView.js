import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";


function ProductMaturityDetailsView()
{

    const [ProductMaturityDetailsToggle, setProductMaturityDetailsToggle] = useState(false);

    const onArrowClick = () => {
        setProductMaturityDetailsToggle(
            !ProductMaturityDetailsToggle)

    };

    return (
        <div className="td_product_contact_readOnly">
            <Container>
                <div className="contact_section1">
                    <Row className="rrc-request-comments-header" >
                        <div className="rrc-request-comments-blueBar"></div>
                        <Col className="rrc-request-comments-titleProps">
                            <p
                                style={{
                                    color: "#3B77FE",
                                    paddingRight: "5px",
                                    fontSize: "16px",
                                }}
                            >
                                Product Maturity Details
                            </p>
                        </Col>
                        <Col className="rrc-request-comments-collapsible">
                            {ProductMaturityDetailsToggle ? (
                                <span style={{ fontSize: "20px" }} onClick={onArrowClick}>
                                    <i className="fas fa-caret-up"></i>
                                </span>
                            ) : (
                                <div style={{ fontSize: "20px" }} onClick={onArrowClick}>
                                    <i className="fas fa-caret-down"></i>
                                </div>
                            )}
                        </Col>
                    </Row>

                    {!ProductMaturityDetailsToggle ? (
                        <div className="maturity_table">

                          <table>
                            <thead>
                                <tr>
                                    <th>Require</th>
                                    <th>Category</th>
                                    <th>Tool</th>
                                    <th>Current State</th>
                                    <th>Target State</th>
                                    <th>Plan</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>yes</td>
                                    <td>Version Control</td>
                                    <td>Tool 1</td>
                                    <td>CState1</td>
                                    <td>TState1</td>
                                    <td>Plan1</td>
                                    <td>Notes1</td>
                                </tr>
                                <tr>
                                    <td>no</td>
                                    <td>Branching Strategy</td>
                                    <td>Tool 2</td>
                                    <td>CState2</td>
                                    <td>TState2</td>
                                    <td>Plan2</td>
                                    <td>Notes2</td>
                                </tr>
                                <tr>
                                    <td>yes</td>
                                    <td>Static Code Analysis</td>
                                    <td>Tool 3</td>
                                    <td>CState3</td>
                                    <td>TState3</td>
                                    <td>Plan3</td>
                                    <td>Notes3</td>
                                </tr>
                                <tr>
                                    <td>yes</td>
                                    <td>Unit Test Code Coverage</td>
                                    <td>Tool 4</td>
                                    <td>CState4</td>
                                    <td>TState4</td>
                                    <td>Plan4</td>
                                    <td>Notes4</td>
                                </tr>
                                <tr>
                                    <td>no</td>
                                    <td>Vulnerability Scanning</td>
                                    <td>Tool 5</td>
                                    <td>CState5</td>
                                    <td>TState5</td>
                                    <td>Plan5</td>
                                    <td>Notes5</td>
                                </tr>
                                <tr>
                                    <td>no</td>
                                    <td>Artifact Version Control</td>
                                    <td>Tool 6</td>
                                    <td>CState6</td>
                                    <td>TState6</td>
                                    <td>Plan6</td>
                                    <td>Notes6</td>
                                </tr>
                                <tr>
                                    <td>no</td>
                                    <td>Infrastructure Provisioning</td>
                                    <td>Tool 7</td>
                                    <td>CState7</td>
                                    <td>TState7</td>
                                    <td>Plan7</td>
                                    <td>Notes7</td>
                                </tr>
                                <tr>
                                    <td>no</td>
                                    <td>Integration Testing</td>
                                    <td>Tool 8</td>
                                    <td>CState8</td>
                                    <td>TState8</td>
                                    <td>Plan8</td>
                                    <td>Notes8</td>
                                </tr>
                                <tr>
                                    <td>yes</td>
                                    <td>Performance Testing</td>
                                    <td>Tool 9</td>
                                    <td>CState9</td>
                                    <td>TState9</td>
                                    <td>Plan9</td>
                                    <td>Notes9</td>
                                </tr>
                                <tr>
                                    <td>yes</td>
                                    <td>Build/Deploy Automation</td>
                                    <td>Tool 10</td>
                                    <td>CState10</td>
                                    <td>TState10</td>
                                    <td>Plan10</td>
                                    <td>Notes10</td>
                                </tr>
                                <tr>
                                    <td>no</td>
                                    <td>Zero Downtime Release</td>
                                    <td>Tool 11</td>
                                    <td>CState11</td>
                                    <td>TState11</td>
                                    <td>Plan11</td>
                                    <td>Notes11</td>
                                </tr>
                            </tbody>


                          </table>

                            
                            
                        </div>
                    ) : null}
                </div>
            </Container>
        </div>
    );
}

export default ProductMaturityDetailsView;