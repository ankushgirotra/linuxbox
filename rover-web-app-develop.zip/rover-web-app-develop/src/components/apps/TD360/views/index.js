import React, { useEffect } from 'react';
import ProductDashboard from "./ProductDashboard/productDashboard";

function TD360Home(props){

    useEffect(()=>{
        document.title =  "Rover - Technical Delivery 360"
    },[])

    return (<ProductDashboard />)
}

export default TD360Home;