// import React,{useState} from 'react';
// //import "./score.scss";
// import Table  from "react-bootstrap/Table";

// function Score(props) {
//     return(
//        <div className="score">
//     <Table size="sm" variant="gray" striped bordered hover>
//     <tbody>
//     <span className="score">ScoreCard</span>
//     <tr>
//         <th>Assesment </th>
//         <th> Score </th>
//         <th>Maximum</th>  
//     </tr>
//     <tr>
//         <td>DevOps Score:</td>
//         <td> 2.0 </td>
//         <td>4.4</td>  
//     </tr>
//     <tr>
//         <td>Process Score:</td>
//         <td> 2.2 </td>
//         <td>3.0</td>  
//     </tr>
//     <tr>
//         <td>Quality Score:</td>
//         <td> 3.3 </td>
//         <td>4.0</td>  
//     </tr>
//     <tr>
//         <td>Reliability Score:</td>
//         <td> 2.3 </td>
//         <td>3.8</td>  
//     </tr>
//     <tr>
//         <td>Software Score:</td>
//         <td> 1.0 </td>
//         <td>2.3</td>  
//     </tr>
//     <tr>
//         <td>Average</td>
//         <td>4.275</td>
//         <td>2.7</td>
//     </tr>
//     </tbody>
// </Table>
// </div>
//     );
// }
// export default Score;