// import React, { useState, useEffect } from "react";
// import {Form } from "react-bootstrap";
// import Select from "react-select";
// import { Container, Row, Col } from "react-bootstrap";
// import Dropdown from 'react-bootstrap/Dropdown';
// import DropdownButton from 'react-bootstrap/DropdownButton';
// import Button from 'react-bootstrap/Button';
// import Table from 'react-bootstrap/Table';

// const Software = () => {
//   const [ans1, setAns1]=useState(0);
//   const [ans2, setAns2]=useState(0);
//   const [ans3, setAns3]=useState(0);
//   const [ans4, setAns4]=useState(0);
//   const [ans5, setAns5]=useState(0);
  
//   const [Avg, setAvg]=useState(0.0);
   
//   const setAnsUpdate=(data,updateData)=>{
//     let total='';
//     let value=0;
//     value=  parseInt(data);
//     if(updateData =='setAns1'){
//       setAns1(value);
//       total= value+ans2+ans3+ans4+ans5;
//       setAvg( total / 5);
//     } 
//     else if(updateData =='setAns2'){
//       setAns2(value);
//       total=ans1+value+ans3+ans4+ans5 ;
//       setAvg(total / 5);
//     }
//     else if(updateData =='setAns3'){
//       setAns3(value);
//       total= ans1+ans2+value+ans4+ans5;
//       setAvg(total / 5);
//     }
//     else if(updateData =='setAns4'){
//       setAns4(value);
//       total= ans1+ans2+ans3+value+ans5
//       setAvg(total / 5);
//     }
//     else if(updateData =='setAns5'){
//       setAns5(value);
//       total = ans1+ans2+ans3+ans4+value
//       setAvg(total / 5);
//     }   
//   }

    
    
//     return (
//         <div className="app" style={{marginLeft:'0px'}}>
//         <div className="td_product_contact_readOnly" >
//            <Row className="rrc-request-comments-header" >
//              <div className="rrc-request-comments-blueBar"></div>
//                <Col className="rrc-request-comments-titleProps">
//                   <p style={{ color: "#3B77FE", paddingRight: "0px", fontSize: "16px" }} >Software Engineering Assessment</p>
//                 </Col>
                       
//             </Row>
//             <Row className="rrc-request-comments-body" style = {{margin: "0px"}}>
//             <div>
//           <Table style = {{margin:"0px"}}striped bordered hover >
//       <thead>
//      <tr >
//           <th style={{width:'10px'}}>{1}</th>
//           <th style={{width:'20rem'}}>{'Requirements Understanding (developer perspective - WHY, WHAT)'}</th>
//           <th style={{width:'17rem'}}>
//             <select  style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns1')}
//              //value={ans1}
//              >
//   <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>           
//  <option 
//     value={0}
//     score={0}
//     >{'In sprint defects >2'}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'In sprint defects >0 & <=2'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'In sprint defects =0'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans1}</th>
//         </tr>  
//         <tr >


//           <th style={{width:'10px'}}>{2}</th>
//           <th style={{width:'20rem'}}>{'Integrations'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//              onChange={(e) => setAnsUpdate(e.target.value,'setAns2')}
//              //value={ans2}
//              >
//   <option 
//     value={0}
//     score={0}
//     >{''}
//   </option>    
//  <option 
//     value={0}
//     score={0}
//     >{'Integration points unknown'}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Integration need are defined but not completed'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Some integration information is available or stubs are available prior to start'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'The integration information is availabe prior to development start'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans2}</th>
//         </tr> 


//         <tr >


//           <th style={{width:'10px'}}>{3}</th>
//           <th style={{width:'20rem'}}>{'Developer product team onboarding'}</th>
//           <th style={{width:'17rem'}}>
//             <select  style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns3')}
           
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'No documentation, all through word of mouth, IDEs available or downloaded from internet or basic tools leveraged, no coding guidelines or checklist'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Some documentation for access, IDEs available through software self service, basic level of coding guidelines & checklist'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Self service onborading access, IDEs available through software self service,Coding guidelines and checklist'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans3}</th>
//         </tr>

//         <tr >


//           <th style={{width:'10px'}}>{4}</th>
//           <th style={{width:'20rem'}}>{'Reviews & Defect Management'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}  onChange={(e) => setAnsUpdate(e.target.value,'setAns4')}
//              //value={ans2}
//              >
//   <option 
//     value={0}
//     score={0}
//     >{''}
//   </option>         
//  <option 
//     value={0}
//     score={0}
//     >{'"RubberStamp" reviews'}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Reviews are adhoc and some actions associated with defects that are identified during reviews tracked until they are resolved'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Reviews are planned and actions associated with defects that are identified during reviews tracked until they are resolved'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans4}</th>
//         </tr>


//         <tr >


//           <th style={{width:'10px'}}>{5}</th>
//           <th style={{width:'20rem'}}>{'TDD adoption on new build'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}} onChange={(e) => setAnsUpdate(e.target.value,'setAns5')}
//              //value={ans2}
//              >
//   <option 
//     value={0}
//     score={0}
//     >{''}
//   </option>         
//  <option 
//     value={0}
//     score={0}
//     >{'No'}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Yes'}
//    </option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans5}</th>
//         </tr>

//         <tr >


//           <th style={{width:'10px'}}>{6}</th>
//           <th style={{width:'20rem'}}>{'Documentation and knowledge transfer'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}} onChange={(e) => setAnsUpdate(e.target.value,'setAns5')}
//              //value={ans2}
//              >
//     <option 
//     value={0}
//     score={0}
//     >{''}
//     </option> 
//     <option 
//     score={1}
//    value={1}
//    >{'No formal process and adhoc KT sessions'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Teamsite, sharepoint site leveraging word, excel, pdfs & accounted for within sprints'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Managed through standard tool - confluence, innersource & accounted for within sprints'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Documentation part of code & accounted for within user stories for sprint'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans5}</th>
//         </tr>

//         <tr >


//           <th style={{width:'10px'}}>{7}</th>
//           <th style={{width:'20rem'}}>{'Configuration Management - Integration with IDEs'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}} onChange={(e) => setAnsUpdate(e.target.value,'setAns5')}
//              //value={ans2}
//              >
//   <option 
//     value={0}
//     score={0}
//     >{''}
//   </option>       
//  <option 
//     value={0}
//     score={0}
//     >{'No'}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Yes'}
//    </option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans5}</th>
//         </tr>
//       </thead>
//       <tbody>
// <tr>
//     <th></th>
//     <th></th>
//     <th></th>
//     <th style={{width:'50px'}}>{Avg}</th>
// </tr>
       
       
//       </tbody>
//     </Table>
//     </div>
//     </Row>
//         </div>
//         </div>
      

//     );
// }
        
// export default Software;