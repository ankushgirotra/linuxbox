// // import React, { useState, useEffect } from "react";
// // import {Form } from "react-bootstrap";
// // import Select from "react-select";
// // import { Container, Row, Col } from "react-bootstrap";
// // import Dropdown from 'react-bootstrap/Dropdown';
// // import DropdownButton from 'react-bootstrap/DropdownButton';
// // import Button from 'react-bootstrap/Button';
// // import Table from 'react-bootstrap/Table';

// // const Reliability = () => {
// // const [ans1, setAns1]=useState(0);
// // const [ans2, setAns2]=useState(0);
// // const [ans3, setAns3]=useState(0);
// // const [ans4, setAns4]=useState(0);


// // const [Avg, setAvg]=useState(0.0);

// // const setAnsUpdate=(data,updateData)=>{
// //     debugger
// //     let total='';

// //     let value=0;
// //     value=  parseInt(data);
// // if(updateData =='setAns1'){
// // setAns1(value);
// // total= value+ans2+ans3+ans4;
// // setAvg( total / 4);
// // } 
// // else if(updateData =='setAns2'){
// //     setAns2(value);
// //     total=ans1+value+ans3+ans4;
// //     setAvg(total / 4);
// // }
// // else if(updateData =='setAns3'){
// //     setAns3(value);
// //     total= ans1+ans2+value+ans4;
// //     setAvg(total / 4);
// // }
// // else if(updateData =='setAns4'){
// //     setAns4(value);
// //     total= ans1+ans2+ans3+value
// //     setAvg(total / 4);
// // }
// // }
    
// //     return (

// //         <div className="app" style={{marginLeft:'72px'}}>
// //            <Table striped bordered hover >
// //       <thead>
// //      <tr >
// //           <th style={{width:'10px'}}>{1}</th>
// //           <th style={{width:'5rem'}}>{'Availability'}</th>
// //           <th style={{width:'35rem'}}>
// //             <select  style={{height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px',width:'51rem'}}
// //             onChange={(e) => setAnsUpdate(e.target.value,'setAns1')}
// //              //value={ans1}
// //              >
          
// //  <option 
// //     value={0}
// //     score={0}
// //     >{''}
// //     </option>
// //     <option 
// //     score={1}
// //    value={1}
// //    >{'React to an outage.No application health checks,no app/infrastructure monitoring or alerts.Manual restoration.'}
// //    </option>
// //    <option 
// //     score={2}
// //    value={2}
// //   >{'React to an outage.Manual application health checks,no application/infrastructure monitoring or alerting. Manual restoration.'}</option>
// //    <option 
// //     score={3}
// //    value={3}
// //    >{' Proactively prevent an outage with automated/manual app health check,monitoring or alerting.No infrastructure monitoring/alerting. Manual restoration.'}</option>
// //    <option 
// //     score={4}
// //    value={4}
// //    >{'Proactively prevent an outage with automated/manual app health check, monitoring or alerting.Infrastructure moniting and alerting in place.Manual restoration.'}</option>
// //   </select>
// //             </th>
// //           <th style={{width:'50px'}}>{ans1}</th>
// //         </tr>  
// //         <tr >


// //           <th style={{width:'10px'}}>{2}</th>
// //           <th style={{width:'10rem'}}>{'Performance'}</th>
// //           <th style={{width:'55rem'}}>
// //             <select style={{height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px',width:'51rem'}}
// //              onChange={(e) => setAnsUpdate(e.target.value,'setAns2')}
// //              //value={ans2}
// //              >
          
// //  <option 
// //     value={0}
// //     score={0}
// //     >{''}
// //     </option>
// //     <option 
// //     score={1}
// //    value={1}
// //    >{' React to the application performance issue based on user reporting.'}
// //    </option>
// //    <option 
// //     score={2}
// //    value={2}
// //   >{' Monitor and address performance issues based on application alerts and infrastructure monitoring..'}</option>
// //    <option 
// //     score={3}
// //    value={3}
// //    >{' Predict and prevent performance issues without any user impact.'}</option>
// //   </select>
// //             </th>
// //           <th style={{width:'50px'}}>{ans2}</th>
// //         </tr> 


// //         <tr >


// //           <th style={{width:'10px'}}>{3}</th>
// //           <th style={{width:'10rem'}}>{'Scalability'}</th>
// //           <th style={{width:'55rem'}}>
// //             <select  style={{height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px',width:'51rem'}}
// //             onChange={(e) => setAnsUpdate(e.target.value,'setAns3')}
           
// //              >
          
// //  <option 
// //     value={0}
// //     score={0}
// //     >{''}
// //     </option>
// //     <option 
// //     score={1}
// //    value={1}
// //    >{' No scaling ability.'}
// //    </option>
// //    <option 
// //     score={2}
// //    value={2}
// //   >{' Reactive with manual scaling process.'}</option>
// //    <option 
// //     score={3}
// //    value={3}
// //    >{'Proactive with manual scaling process.'}</option>
// //    <option 
// //     score={4}
// //    value={4}
// //    >{'Auto Scaling.'}</option>
// //   </select>
// //             </th>
// //           <th style={{width:'50px'}}>{ans3}</th>
// //         </tr>

// //         <tr >


// //           <th style={{width:'10px'}}>{4}</th>
// //           <th style={{width:'10rem'}}>{'Resiliency'}</th>
// //           <th style={{width:'55rem'}}>
// //             <select style={{height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px',width:'51rem'}}  onChange={(e) => setAnsUpdate(e.target.value,'setAns4')}
// //              //value={ans2}
// //              >
          
// //  <option 
// //     value={0}
// //     score={0}
// //     >{''}
// //     </option>
// //     <option 
// //     score={1}
// //    value={1}
// //    >{'Single point of failure.'}
// //    </option>
// //    <option 
// //     score={2}
// //    value={2}
// //   >{'Failover with manual restoration in place.'}</option>
// //    <option 
// //     score={3}
// //    value={3}
// //    >{'Automated restoration and failover capability.'}</option>
// //   </select>
// //             </th>
// //             <th style={{width:'50px'}}>{ans4}</th>
// //         </tr>
// //       </thead>
// //       <tbody>
// // <tr>
// //     <th></th>
// //     <th></th>
// //     <th></th>
// //     <th style={{width:'50px'}}>{Avg}</th>
// // </tr>
       
       
// //       </tbody>
// //     </Table>
// //         </div>
// //     );
// // }
        
// // export default Reliability;

// import React, { useState, useEffect } from "react";
// import {Form } from "react-bootstrap";
// import Select from "react-select";
// import { Container, Row, Col } from "react-bootstrap";
// import Dropdown from 'react-bootstrap/Dropdown';
// import DropdownButton from 'react-bootstrap/DropdownButton';
// import Button from 'react-bootstrap/Button';
// import Table from 'react-bootstrap/Table';
// const Reliability = () => {
// const [ans1, setAns1]=useState(0);
// const [ans2, setAns2]=useState(0);
// const [ans3, setAns3]=useState(0);
// const [ans4, setAns4]=useState(0);


// const [Avg, setAvg]=useState(0.0);
// // useEffect(() => {
// //    setAvg(ans1+ans2+ans3+ans4+ans5 % 5);
// //   },[ans5,ans4,ans3,ans2,ans1]);

// const setAnsUpdate=(data,updateData)=>{
//     debugger
//     let total='';

//     let value=0;
//     value=  parseInt(data);
// if(updateData =='setAns1'){
// setAns1(value);
// total= value+ans2+ans3+ans4;
// setAvg( total / 4);
// } 
// else if(updateData =='setAns2'){
//     setAns2(value);
//     total=ans1+value+ans3+ans4 ;
//     setAvg(total / 4);
// }
// else if(updateData =='setAns3'){
//     setAns3(value);
//     total= ans1+ans2+value+ans4;
//     setAvg(total / 4);
// }
// else if(updateData =='setAns4'){
//     setAns4(value);
//     total= ans1+ans2+ans3+value
//     setAvg(total / 4);
// }
// }
    
//     return (
//         <div className="app" style={{marginLeft:'0px'}}>
//            <div className="td_product_contact_readOnly" >
//            <Row className="rrc-request-comments-header" >
//              <div className="rrc-request-comments-blueBar"></div>
//                <Col className="rrc-request-comments-titleProps">
//                   <p style={{ color: "#3B77FE", paddingRight: "0px", fontSize: "16px" }} >Reliability Engineering </p>
//                 </Col>
                       
//             </Row>
//             <Row className="rrc-request-comments-body" style={{ margin: "0px" }} >
//             <div >
//            <Table style = {{margin:"0px"}} striped bordered hover >
//       <thead>
//      <tr >
//           <th style={{width:'10px'}}>{1}</th>
//           <th style={{width:'20rem'}}>{'Availability'}</th>
//           <th style={{width:'17rem'}}>
//             <select  style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns1')}
//              //value={ans1}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{' React to an outage. No application health checks, no app / infrastructure  monitoring or alerts. Manual restoration.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{' React to an outage. Manual application health checks, no application / infrastructure monitoring or alerting. Manual restoration.'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{' Proactively prevent an outage with automated / manual app health check, monitoring or alerting. No infrastructure monitoring / alerting. Manual restoration.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{' Proactively prevent an outage with automated / manual app health check, monitoring or alerting. Infrastructure moniting and alerting in place. Manual restoration.'}</option>
//    <option 
//     score={5}
//    value={5}
//    >{' Predict an outage and prevent it before disruption occurs.'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans1}</th>
//         </tr>  
//         <tr >


//           <th style={{width:'10px'}}>{2}</th>
//           <th style={{width:'20rem'}}>{'Performance'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//              onChange={(e) => setAnsUpdate(e.target.value,'setAns2')}
//              //value={ans2}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{' React to the application performance issue based on user reporting.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{' Monitor and address performance issues based on application alerts and infrastructure monitoring.'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{' Predict and prevent performance issues without any user impact.'}</option>

//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans2}</th>
//         </tr> 


//         <tr >


//           <th style={{width:'10px'}}>{3}</th>
//           <th style={{width:'20rem'}}>{'Scalability'}</th>
//           <th style={{width:'17rem'}}>
//             <select  style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns3')}
           
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{' No scaling ability..'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{' Reactive with manual scaling process.'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Proactive with manual scaling process.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Auto Scaling.'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans3}</th>
//         </tr>

//         <tr >


//           <th style={{width:'10px'}}>{4}</th>
//           <th style={{width:'20rem'}}>{'Resiliency'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}  onChange={(e) => setAnsUpdate(e.target.value,'setAns4')}
//              //value={ans2}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{' Single point of failure.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{' Failover with manual restoration in place.'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{' Automated restoration and failover capability.'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans4}</th>
//         </tr>


       
//       </thead>
//       <tbody>
// <tr>
//     <th></th>
//     <th></th>
//     <th></th>
//     <th style={{width:'50px'}}>{Avg}</th>
// </tr>
       
       
//       </tbody>
//     </Table>
//     </div>
//     </Row>
//            </div>
           
//         </div>
//     );
// }
        
// export default Reliability;