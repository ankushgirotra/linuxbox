// import React, { useState, useEffect } from "react";
// import {Form } from "react-bootstrap";
// import Select from "react-select";
// import { Container, Row, Col } from "react-bootstrap";
// import Dropdown from 'react-bootstrap/Dropdown';
// import DropdownButton from 'react-bootstrap/DropdownButton';
// import Button from 'react-bootstrap/Button';
// import Table from 'react-bootstrap/Table';
// const DevOpsAss = () => {
// const [ans1, setAns1]=useState(0);
// const [ans2, setAns2]=useState(0);
// const [ans3, setAns3]=useState(0);
// const [ans4, setAns4]=useState(0);
// const [ans5, setAns5]=useState(0);

// const [Avg, setAvg]=useState(0.0);
// // useEffect(() => {
// //    setAvg(ans1+ans2+ans3+ans4+ans5 % 5);
// //   },[ans5,ans4,ans3,ans2,ans1]);

// const setAnsUpdate=(data,updateData)=>{
//     debugger
//     let total='';

//     let value=0;
//     value=  parseInt(data);
// if(updateData =='setAns1'){
// setAns1(value);
// total= value+ans2+ans3+ans4+ans5;
// setAvg( total / 5);
// } 
// else if(updateData =='setAns2'){
//     setAns2(value);
//     total=ans1+value+ans3+ans4+ans5 ;
//     setAvg(total / 5);
// }
// else if(updateData =='setAns3'){
//     setAns3(value);
//     total= ans1+ans2+value+ans4+ans5;
//     setAvg(total / 5);
// }
// else if(updateData =='setAns4'){
//     setAns4(value);
//     total= ans1+ans2+ans3+value+ans5
//     setAvg(total / 5);
// }
// else if(updateData =='setAns5'){
//     setAns5(value);
//     total = ans1+ans2+ans3+ans4+value
//     setAvg(total / 5);
// }
// }
    
//     return (
//         <div className="app" style={{marginLeft:'0px'}}>
//            <div className="td_product_contact_readOnly" >
//            <Row className="rrc-request-comments-header" >
//              <div className="rrc-request-comments-blueBar"></div>
//                <Col className="rrc-request-comments-titleProps">
//                   <p style={{ color: "#3B77FE", paddingRight: "0px", fontSize: "16px" }} >DevOps Engineering Assessment</p>
//                 </Col>
                       
//             </Row>
//             <Row className="rrc-request-comments-body" style={{ margin: "0px" }} >
//             <div >
//            <Table style = {{margin:"0px"}} striped bordered hover >
//       <thead>
//      <tr >
//           <th style={{width:'10px'}}>{1}</th>
//           <th style={{width:'20rem'}}>{'Which best 1 describes your applications environment provisioning?'}</th>
//           <th style={{width:'17rem'}}>
//             <select  style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns1')}
//              //value={ans1}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Environments are manually created and configured every time.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Provisioning is repeatable and follows standards. Request process is manual and requires several teams to be involved..'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Provisioning is automated and on demand.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Provisioning is automated and  integrated into overall delivery pipeline. '}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans1}</th>
//         </tr>  
//         <tr >


//           <th style={{width:'10px'}}>{2}</th>
//           <th style={{width:'20rem'}}>{'Which best describes your applications release process? '}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//              onChange={(e) => setAnsUpdate(e.target.value,'setAns2')}
//              //value={ans2}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Changes are infrequent and scheduled and change orders are manually created months in advance. Change board approval is required.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Changes are frequent (once or twice monthly). Change orders are created manually and board approval is required. '}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Changes are automatically created as part of the overall delivery pipeline, but weeks or months in advance of the change date. Change order approval by a board is required.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Changes are automatically created as part of the overall delivery pipeline close to the change date. Change order approval by a board is required.'}</option>
//    <option 
//     score={5}
//    value={5}
//   >{'Changes are automatically created as part of the overall delivery pipeline. Change board approval is not required or approval is lightweight.  '}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans2}</th>
//         </tr> 


//         <tr >


//           <th style={{width:'10px'}}>{3}</th>
//           <th style={{width:'20rem'}}>{'Which best describes your applications quality or testing practices? '}</th>
//           <th style={{width:'17rem'}}>
//             <select  style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns3')}
           
//              >
          
//           <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Environments are manually created and configured every time.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Provisioning is repeatable and follows standards. Request process is manual and requires several teams to be involved..'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Provisioning is automated and on demand.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Provisioning is automated and  integrated into overall delivery pipeline. '}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans3}</th>
//         </tr>

//         <tr >


//           <th style={{width:'10px'}}>{4}</th>
//           <th style={{width:'20rem'}}>{'Which best describes your applications security practices??'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}  onChange={(e) => setAnsUpdate(e.target.value,'setAns4')}
//              //value={ans2}
//              >
          
//           <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Environments are manually created and configured every time.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Provisioning is repeatable and follows standards. Request process is manual and requires several teams to be involved..'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Provisioning is automated and on demand.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Provisioning is automated and  integrated into overall delivery pipeline. '}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans4}</th>
//         </tr>


//         <tr >


//           <th style={{width:'10px'}}>{5}</th>
//           <th style={{width:'20rem'}}>{'Which best describes how your application is deployed? ?'}</th>
//           <th style={{width:'17rem'}}>
//             <select style={{width:'17rem',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}} onChange={(e) => setAnsUpdate(e.target.value,'setAns5')}
//              //value={ans2}
//              >
          
//           <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Environments are manually created and configured every time.'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'Provisioning is repeatable and follows standards. Request process is manual and requires several teams to be involved..'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'Provisioning is automated and on demand.'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'Provisioning is automated and  integrated into overall delivery pipeline. '}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans5}</th>
//         </tr>
//       </thead>
//       <tbody>
// <tr>
//     <th></th>
//     <th></th>
//     <th></th>
//     <th style={{width:'50px'}}>{Avg}</th>
// </tr>
       
       
//       </tbody>
//     </Table>
//     </div>
//     </Row>
//            </div>
           
//         </div>
//     );
// }
        
// export default DevOpsAss;