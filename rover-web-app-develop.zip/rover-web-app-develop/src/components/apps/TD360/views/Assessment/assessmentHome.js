// // import React from 'react';
// // import ReactDOM from 'react-dom';
// // import SelectDropdown from "../../../pcdm/src/components/forms/select/select";
// // import CustomSelect from "../../../pcdm/src/components/forms/SelectDropdown/selectDropdown";
// // import Dropdown from 'react-bootstrap/Dropdown';
// // import DropdownButton from 'react-bootstrap/DropdownButton';
// // const AssessmentHome=()=>{return 

// // (<>
// // <DropdownButton id="dropdown-basic-button" title="Dropdown button">
// //       <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
// //       <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
// //       <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
// //     </DropdownButton>

// // </>)
// // };
// // export default AssessmentHome;

// import React, { useState, useEffect } from "react";
// import {Form } from "react-bootstrap";
// import Select from "react-select";
// import { Container, Row, Col } from "react-bootstrap";
// import Dropdown from 'react-bootstrap/Dropdown';
// import DropdownButton from 'react-bootstrap/DropdownButton';
// import Button from 'react-bootstrap/Button';
// import Devops from "./devOpsAssessment";
// import Reliability from "./reliabilityAssessment";
// import Software from "./softwareAssessment";
// import QualityEngineeringAssessment from "./qualityEngineeringAssessment"




// const App = () => {

//     const [validated, setValidated] = useState(false);
//     const [showForm1, setShowForm1] =useState(true);
//     const [showForm2, setShowForm2] =useState(true);
//     const [showForm3, setShowForm3] =useState(true);
//     const [showForm4, setShowForm4] =useState(true);
   

// const [selectValue, setSelectValue]=useState('Select');

//     const [data, setData] = useState([
//         {id:'1',Name:'one'},{id:'4',Name:'one'},
//         {id:'2',Name:'one'},{id:'5',Name:'one'},
//         {id:'3',Name:'one'},
//     ]);
    

//     const categories = data.map((item) => ({ value: item.id, label: item.Name }));

    

//     const FormRedirect=(e)=>{
//         //setSelectValue(e)
//         if(e=='DevOps'){
//             setShowForm1(false)
//             setShowForm2(true)
//             setShowForm3(true)
//             setShowForm4(true);
//             setSelectValue(e)
//         }else if(e=='Reliability'){
//             setShowForm1(true)
//             setShowForm2(false)
//             setShowForm3(true)
//             setShowForm4(true);
//             setSelectValue(e);
//         }else if(e=='Software'){
//             setShowForm1(true)
//             setShowForm2(true)
//             setShowForm3(false)
//             setShowForm4(true);
//             setSelectValue(e);
//         }else if(e=='Quality'){
//             setShowForm1(true)
//             setShowForm2(true)
//             setShowForm3(true)
//             setShowForm4(false);
//             setSelectValue(e);
//         }
//     }

//     // const twoCalls= e=>{
//     //     setSelectValue(e)
//     //     FormRedirect()
//     // }

//     return (   
//         <div >
//             <div className="app" style={{marginLeft:'50px'}} >
//           <Form noValidate validated={validated}>
                
                    
//                     <Form.Group  controlId="validationCustom02">
//                         <br></br>
//                         {/* <Form.Label for='assessmentName'>Assessments</Form.Label> */}
//                         <Row> 
//                         <label for='assessmentName'>
//                             <br></br>
//                             <h4>Select Assessment here: &nbsp;</h4>
//                         </label>
                     
//     <DropdownButton id="dropdown-basic-button" title={selectValue} onSelect={e=>{FormRedirect(e)}}   name='assessmentName'>
      
//       <Dropdown.Item eventKey="Reliability" value={"Reliability"}>Reliability Engineering</Dropdown.Item>
//       <Dropdown.Item eventKey="Software" value={"Software"}>Software Engineering</Dropdown.Item>
//       <Dropdown.Item eventKey="Quality" value={"Quality"}>Quality Engineering Assessment</Dropdown.Item>
//       <Dropdown.Item eventKey="DevOps" value={"DevOps"}> DevOps Engineering </Dropdown.Item>
//       {/* <Dropdown.Item eventKey="DevOps4" value={"DevOps4"}>Process Engineering Assessment</Dropdown.Item> */}
//     </DropdownButton>
//     </Row> 
                        
      
//                     </Form.Group>
//                     {/* <Button variant="light" style={{height:'44px',marginTop:'29px',marginLeft:'60px'}} onClick={()=>FormRedirect()}>Take Assessment</Button>  */}
               
//             </Form>
//             </div>
            
//            {!showForm1&&(
//            <>
//             <Devops />
//            </>)} 
//            {!showForm2&&(<>
//             <Reliability />
//            </>)}
//            {!showForm3&&(<>
//             <Software />
//            </>)}
//            {!showForm4&&(<>
//             <QualityEngineeringAssessment />
//            </>)}
//            <Row>
//             {(!showForm1||!showForm2||!showForm3||!showForm4)?
//               <>
//               <Row>
//               {/* <Button variant="light" style={{height:'44px',marginLeft:'38rem'}} onClick={()=>FormRedirect('DevOps')}>Next</Button> */}
//               <Button variant="light" style={{height:'44px',marginLeft:'45rem'}} >Submit</Button>
//               </Row>
//               </>
//               :''
//             }
           
//            </Row>
//                   </div>
//     );
// }
        
// export default App;