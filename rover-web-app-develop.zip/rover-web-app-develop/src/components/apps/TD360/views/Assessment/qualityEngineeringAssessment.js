// import React, { useState, useEffect, Fragment } from "react";
// import { Container, Row, Col } from "react-bootstrap";
// import Table from 'react-bootstrap/Table';

// // const ASSESSMENT_INITIAL_STATE = {
// //   detailsCollapsed: true
// // }

// const QualityEngineeringAssessment = () => {
// const [ans1, setAns1]=useState(0);
// const [ans2, setAns2]=useState(0);
// const [ans3, setAns3]=useState(0);
// const [ans4, setAns4]=useState(0);
// const [ans5, setAns5]=useState(0);
// const [ans6, setAns6]=useState(0);
// const [ans7, setAns7]=useState(0);
// const [ans8, setAns8]=useState(0);
// const [ans9, setAns9]=useState(0);
// const [ans10, setAns10]=useState(0);
// const [ans11, setAns11]=useState(0);
// const [ans12, setAns12]=useState(0);


// const [Total, setTotal]=useState(0.0);

// const setAnsUpdate=(data,updateData)=>{
//   debugger
//   let total='';

//   let value=0;
//   value=  parseInt(data);
// if(updateData =='setAns1'){
// setAns1(value);
// total= value+ans2+ans3+ans4+ans5+ans6+ans7+ans8+ans9+ans10+ans11+ans12 ;
// setTotal( total);
// } 
// else if(updateData =='setAns2'){
//   setAns2(value);
//   total=ans1+value+ans3+ans4+ans5+ans6+ans7+ans8+ans9+ans10+ans11+ans12 ;
//   setTotal( total);
// }
// else if(updateData =='setAns3'){
//   setAns3(value);
//   total= ans1+ans2+value+ans4+ans5+ans6+ans7+ans8+ans9+ans10+ans11+ans12 ;
//   setTotal( total);
// }
// else if(updateData =='setAns4'){
//   setAns4(value);
//   total= ans1+ans2+ans3+value+ans5+ans6+ans7+ans8+ans9+ans10+ans11+ans12 ;
//   setTotal( total);
// }
// else if(updateData =='setAns5'){
//   setAns5(value);
//   total = ans1+ans2+ans3+ans4+value+ans6+ans7+ans8+ans9+ans10+ans11+ans12 ;
//   setTotal( total);
// }
// else if(updateData =='setAns6'){
//   setAns6(value);
//   total= ans1+ans2+ans3+ans4+ans5+value+ans7+ans8+ans9+ans10+ans11+ans12 ;
//   setTotal( total);
//   } 
//   else if(updateData =='setAns7'){
//     setAns7(value);
//     total=ans1+ans2+ans3+ans4+ans5+ans6+value+ans8+ans9+ans10+ans11+ans12 ;
//     setTotal( total);
//   }
//   else if(updateData =='setAns8'){
//     setAns8(value);
//     total= ans1+ans2+ans3+ans4+ans5+ans6+ans7+value+ans9+ans10+ans11+ans12 ;
//     setTotal( total);
//   }
//   else if(updateData =='setAns9'){
//     setAns9(value);
//     total= ans1+ans2+ans3+ans4+ans5+ans6+ans7+ans8+value+ans10+ans11+ans12 ;
//     setTotal( total);
//   }
//   else if(updateData =='setAns10'){
//     setAns10(value);
//     total = ans1+ans2+ans3+ans4+ans5+ans6+ans7+ans8+ans9+value+ans11+ans12 ;
//     setTotal( total);
//   }
//   else if(updateData =='setAns11'){
//     setAns11(value);
//     total= ans1+ans2+ans3+ans4+ans5+ans6+ans7+ans8+ans9+ans10+value+ans12 ;
//     setTotal( total);
//     } 
//     else if(updateData =='setAns12'){
//       setAns12(value);
//       total=ans1+ans2+ans3+ans4+ans5+ans6+ans7+ans8+ans9+ans10+ans11+value ;
//      setTotal( total);
//     }
// }   
// // const [requestAssesmentsState, setRequestAssessmentsState] = useState(ASSESSMENT_INITIAL_STATE);
// // const onArrowClick = () => {
// //   setRequestAssessmentsState({
// //       ...requestAssesmentsState,
// //       detailsCollapsed: !requestAssesmentsState.detailsCollapsed
// //   }) 
// // }
//     return (
    
//        <div className="app" style={{marginLeft:'0px'}}>
//        <div className="td_product_contact_readOnly" >
//           <Row className="rrc-request-comments-header" >
//              <div className="rrc-request-comments-blueBar"></div>
//                <Col className="rrc-request-comments-titleProps">
//                   <p style={{ color: "#3B77FE", paddingRight: "0px", fontSize: "16px" }} >Quality Engineering Assessment- Unit Test</p>
//                 </Col>
                       
//             </Row>
//             <Row className="rrc-request-comments-body" style={{ margin: "0px" }} >
//             {true?
//             <>
//             <div >
//            <Table style = {{margin:"0px"}} striped bordered hover >
//       <thead>
//      <tr >
//           <th style={{width:'10px'}}>{1}</th>
//           <th style={{width:'20rem'}}>{'Is there a unit testbed?'}</th>
//           <th style={{width:'6rem'}}>
//             <select  style={{width:'70px', height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns1')}
//              //value={ans1}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Yes'}
//    </option>
//    <option 
//     score={0}
//    value={0}
//   >{'No'}</option>
  
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans1}</th>
//         </tr>  
//         <tr >


//           <th style={{width:'10px'}}>{2}</th>
//           <th style={{width:'20rem'}}>{'What is the code coverage %?'}</th>
//           <th style={{width:'6rem'}}>
//             <select style={{width:'70px',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//              onChange={(e) => setAnsUpdate(e.target.value,'setAns2')}
//              //value={ans2}
//              >
          
//  <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'0-19%'}
//    </option>
//    <option 
//     score={2}
//    value={2}
//   >{'20-39%.'}</option>
//    <option 
//     score={3}
//    value={3}
//    >{'40-59%'}</option>
//    <option 
//     score={4}
//    value={4}
//    >{'60-79%'}</option>
//    <option 
//     score={5}
//    value={5}
//    >{'80-100%'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans2}</th>
//         </tr> 


//         <tr >


//           <th style={{width:'10px'}}>{3}</th>
//           <th style={{width:'20rem'}}>{'Is unit testing CICD automated?'}</th>
//           <th style={{width:'6rem'}}>
//             <select  style={{width:'70px',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}
//             onChange={(e) => setAnsUpdate(e.target.value,'setAns3')}
           
//              >
          
//     <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Yes'}
//    </option>
//    <option 
//     score={0}
//    value={0}
//   >{'No'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans3}</th>
//         </tr>

//         <tr >


//           <th style={{width:'10px'}}>{4}</th>
//           <th style={{width:'20rem'}}>{'Is unit testing quality gated (coverage % and pass rate)?'}</th>
//           <th style={{width:'6rem'}}>
//             <select style={{width:'70px',height:'28px',border:"1px solid #999", color:'1c87c9', backgroundColor:'#eee', borderRadius:'5px'}}  onChange={(e) => setAnsUpdate(e.target.value,'setAns4')}
//              //value={ans2}
//              >
          
//    <option 
//     value={0}
//     score={0}
//     >{''}
//     </option>
//     <option 
//     score={1}
//    value={1}
//    >{'Yes'}
//    </option>
//    <option 
//     score={0}
//    value={0}
//   >{'No'}</option>
//   </select>
//             </th>
//           <th style={{width:'50px'}}>{ans4}</th>
//         </tr>


        
//       </thead>
//    <tbody>
// <tr>
//     <th></th>
//     <th></th>
//     <th></th>
//     <th style={{width:'50px'}}>{Total}</th>
// </tr>
       
       
//       </tbody>
//     </Table>
//         </div>
//             </>:""
//             }

//             </Row>
//        </div>
//        </div>
    
//     );
// }
        
// export default QualityEngineeringAssessment;