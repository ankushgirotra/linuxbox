import React, { useMemo } from "react";
import DataGrid, { SelectColumnFilter } from "../../../pcdm/src/components/DataGrid/dataGrid";
import { OverlayLoader } from "../../../pcdm/src/components/DataHandler/dataHandler";
import { DATA_STATUS } from "../../../pcdm/src/constants/service.constant";
import LinkExtended from "../../../../shared/Link/linkExtended";
import { TD360_ROUTES } from "../../../../app/Route/constants/td360Routes.constants";
import { useHistory } from "react-router";
import AdvancedDataGrid from "../../../../shared/AdvancedDataGrid/advancedDataGrid";

function ProductTable(props) {
  const {
    products
  } = props;

  const columns = useMemo(() => [
    {
      Header: (props) => "Product ID",
      accessor: "productId",
      Cell: ({ row: { original } }) => showProduct(original, "productId"),
      Filter: SelectColumnFilter,
      filter: "includes",
    },
    {
      Header: "Product Name",
      accessor: "productName",
      Filter: SelectColumnFilter,
      filter: "includes",
    },
    {
      Header: "Product Line",
      accessor: "productLineName",
      Filter: SelectColumnFilter,
      filter: "includes",
    },
    {
      Header: "ITPM",
      accessor: "productManager",
      disableFilters: true,
    },
    {
      Header: "ESM NAME",
      accessor: "esmName",
      disableFilters: true,
    },
    {
      Header: "Director",
      accessor: "directorName",
      disableFilters: true,
    },
  ]);

  const history = useHistory();
  const onProductIdClick = (row) => {
    history.push(TD360_ROUTES.getProdutConfigRoute(row.productId));
    localStorage.setItem('tdProductId',row.productId);
  }

  const showProduct = (row, key) => {
    return (
      <LinkExtended
        className="td-product"
        onClick={() =>
          onProductIdClick({ ...row })
        }
      >
        {row[key]}
      </LinkExtended>
    );
  };



  return (
    <div className="project-data-grid-container td360-product-table ">
      <OverlayLoader
        loading={
          products.status === DATA_STATUS.LOADING
        }
      />
      {/* <DataGrid
        data={products && products.data && products.data.length ? products.data : []}
        columns={columns}
        // toolTip={getToolTip}
        showUpdatedDataGrid={true}
        noRowText={"Click Add project button to start creating projects"}
      /> */}
      <AdvancedDataGrid
            // id={searchId}
            data={products && products.data && products.data.length ? products.data : []}
            columns={columns}
            reqColumn={"productId"}
            // onCellClick={onProfileClick}
            // currentPageOptions={currentPageOptions}
            showPagination={products && products.data && products.data.length > 10}
            noRowText={"No Results Found"}
          />
    </div>
  );
}

export default ProductTable;