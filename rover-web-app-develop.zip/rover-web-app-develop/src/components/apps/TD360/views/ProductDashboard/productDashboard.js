import React, { useEffect, useState } from "react";
import ProductTable from "./productTable";
import { getTDAllProductsThunk, getTDAllProductsBylanIdThunk } from "../../store/tdProducts.reducer";
import { connect } from "react-redux";
import "./productDashboard.scss";


function ProductDashboard(props) {

  const {
    getAllProducts,
    allProducts,
    allProductsByLanId,
    getTDAllProductsBylanId,
  } = props;

  const [checked, setChecked] = useState(false);
  const handleChange = () => {
    setChecked(!checked);
  }
  
  useEffect(()=>{
    getAllProducts()
    let username = localStorage.getItem("username")
    getTDAllProductsBylanId(username)
  },[])

  return (
    <div className="td360_product_dashboard">
        <span className="pageName"> Product Configuration Dashboard</span>
        <br/>
        <input type = "checkbox" checked = {checked} onChange = {handleChange} className="checkBox"/>
        <p className="checkBoxText">View My Data</p>
      <div className="td360Container" id="td360">
        <ProductTable  products={checked ? allProductsByLanId  : allProducts} />
      </div>
    </div>
  );
}

const mapStateToProps = (state, ownProps) => ({
  allProducts: state.TDProductsReducer.TDAllProducts,
  allProductsByLanId: state.TDProductsReducer.TDAllProductsBylanId,
});

const mapDispatchToProps = (dispatch) => ({
  getTDAllProductsBylanId: (lanId) => dispatch(getTDAllProductsBylanIdThunk(lanId)),
  getAllProducts: () => dispatch(getTDAllProductsThunk()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProductDashboard);
