
//Dashboard Tab
export const getAllProductsTDURL = () => {
    return `v1/td/getAllProducts`;
};

export const getAllProductsBylanIdTDURL = (productManagerLANID) => {
  return `v1/td/getAllProducts/${productManagerLANID}`;
}

export const getProductDetailsTDURL = (productId) => {
  return `v1/td/getProductDetails/${productId}`;
};

export const getProductContactDetailsURL = (productId) => {
  return `v1/td/getProductContacts/${productId}`;
}

export const getProductTeamDetailsURL = (productId) => {
  return `v1/td/getProductTeamDetails/${productId}`;
}
