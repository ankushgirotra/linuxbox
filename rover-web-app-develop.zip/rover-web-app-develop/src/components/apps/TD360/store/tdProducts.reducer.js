import { 
  getAllProductsTDURL, 
  getProductDetailsTDURL, 
  getAllProductsBylanIdTDURL,
  getProductContactDetailsURL, 
  getProductTeamDetailsURL,
} from "./endpoints";
import { DATA_STATUS } from "../../pcdm/src/constants/service.constant";
import roverTDURL from "../../../../apis/technicalDelivery_api";

// ACTION TYPES
export const TD_ALL_PRODUCTS_SUCCESS = "TD_ALL_PRODUCTS_SUCCESS";
export const TD_ALL_PRODUCTS_LOADING = "TD_ALL_PRODUCTS_LOADING";
export const TD_ALL_PRODUCTS_ERROR = "TD_ALL_PRODUCTS_ERROR";

export const TD_ALL_PRODUCTS_BY_LANID_SUCCESS = "TD_ALL_PRODUCTS_BY_LANID_SUCCESS";
export const TD_ALL_PRODUCTS_BY_LANID_LOADING = "TD_ALL_PRODUCTS_BY_LANID_LOADING";
export const TD_ALL_PRODUCTS_BY_LANID_ERROR = "TD_ALL_PRODUCTS_BY_LANID_ERROR";

export const TD_PRODUCTS_DETAILS_SUCCESS = "TD_PRODUCTS_DETAILS_SUCCESS";
export const TD_PRODUCTS_DETAILS_LOADING = "TD_PRODUCTS_DETAILS_LOADING";
export const TD_PRODUCTS_DETAILS_ERROR = "TD_PRODUCTS_DETAILS_ERROR";

export const PRODUCTS_CONTACT_DETAILS_SUCCESS = "PRODUCTS_CONTACT_DETAILS_SUCCESS";
export const PRODUCTS_CONTACT_DETAILS_LOADING = "PRODUCTS_CONTACT_DETAILS_LOADING";
export const PRODUCTS_CONTACT_DETAILS_ERROR = "PRODUCTS_CONTACT_DETAILS_ERROR";

export const PRODUCTS_TEAM_DETAILS_SUCCESS = "PRODUCTS_TEAM_DETAILS_SUCCESS";
export const PRODUCTS_TEAM_DETAILS_LOADING = "PRODUCTS_TEAM_ETAILS_LOADING";
export const PRODUCTS_TEAM_DETAILS_ERROR = "PRODUCTS_TEAM_DETAILS_ERROR";

// ACTION CREATORS
export const getTDAllProducts = (products) => ({
  type: TD_ALL_PRODUCTS_SUCCESS,
  products,
});
export const getTDAllProductsLoading = () => ({
  type: TD_ALL_PRODUCTS_LOADING,
});
export const getTDAllProductsError = (error) => ({
  type: TD_ALL_PRODUCTS_ERROR,
  error,
});
export const getTDProductDetails = (productsDetails) => ({
  type: TD_PRODUCTS_DETAILS_SUCCESS,
  productsDetails,
});
export const getTDProductDetailsLoading = () => ({
  type: TD_PRODUCTS_DETAILS_LOADING,
});
export const getTDProductDetailsError = (error) => ({
  type: TD_PRODUCTS_DETAILS_ERROR,
  error,
});

export const getTDAllProductsBylanId = (products) => ({
  type: TD_ALL_PRODUCTS_BY_LANID_SUCCESS,
  products,
});
export const getTDAllProductsBylanIdLoading = () => ({
  type: TD_ALL_PRODUCTS_BY_LANID_LOADING,
});
export const getTDAllProductsBylanIdError = (error) => ({
  type: TD_ALL_PRODUCTS_BY_LANID_ERROR,
  error,
});

export const getProductContactDetails = (productsDetails) => ({
  type: PRODUCTS_CONTACT_DETAILS_SUCCESS,
  productsDetails,
});
export const getProductContactDetailsLoading = () => ({
  type: PRODUCTS_CONTACT_DETAILS_LOADING,
});
export const getProductContactDetailsError = (error) => ({
  type: PRODUCTS_CONTACT_DETAILS_ERROR,
  error,
});

export const getProductTeamDetails = (teamDetails) => ({
  type: PRODUCTS_TEAM_DETAILS_SUCCESS,
  teamDetails,
});
export const getProductTeamDetailsLoading = () => ({
  type: PRODUCTS_TEAM_DETAILS_LOADING,
});
export const getProductTeamDetailsError = (error) => ({
  type: PRODUCTS_TEAM_DETAILS_ERROR,
  error,
});

//THUNK
export const getTDAllProductsThunk = () => async (dispatch) => {
  try {
    dispatch(getTDAllProductsLoading());
    const { data } = await roverTDURL.get(getAllProductsTDURL());
    dispatch(getTDAllProducts(data));
  } catch (error) {
    console.error(error);
    dispatch(getTDAllProductsError(error));
  }
};
export const getTDProductDetailsThunk = (productId) => async (dispatch) => {
  try {
    dispatch(getTDProductDetailsLoading());
    const { data } = await roverTDURL.get(getProductDetailsTDURL(productId));
    dispatch(getTDProductDetails(data));
  } catch (error) {
    console.error(error);
    dispatch(getTDProductDetailsError(error));
  }
};

export const getTDAllProductsBylanIdThunk = (lanId) => async (dispatch) => {
  try {
    dispatch(getTDAllProductsBylanIdLoading());
    const { data } = await roverTDURL.get(getAllProductsBylanIdTDURL(lanId));
    dispatch(getTDAllProductsBylanId(data));
  } catch (error) {
    console.error(error);
    dispatch(getTDAllProductsBylanIdError(error));
  }
};

export const getProductContactDetailsThunk = (productId) => async (dispatch) => {
  try {
    dispatch(getProductContactDetailsLoading());
    const { data } = await roverTDURL.get(getProductContactDetailsURL(productId));
    dispatch(getProductContactDetails(data));
  } catch (error) {
    console.error(error);
    dispatch(getProductContactDetailsError(error));
  }
};

export const getProductTeamDetailsThunk = (productId) => async (dispatch) => {
  try {
    dispatch(getProductTeamDetailsLoading());
    const { data } = await roverTDURL.get(getProductTeamDetailsURL(productId));
    dispatch(getProductTeamDetails(data));
  } catch (error) {
    console.error(error);
    dispatch(getProductTeamDetailsError(error));
  }
};

// INITIAL STATE
const initialState = {
  TDAllProducts: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  TDAllProductsBylanId: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  TDProductDetails: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  ProductContactDetails: { data: [], status: DATA_STATUS.INITIAL, response: {} },
  ProductTeamDetails: { data: [], status: DATA_STATUS.INITIAL, response: {} },
};

// REDUCERS
export const TDProductsReducer = (state = initialState, action) => {
  switch (action.type) {
    case TD_ALL_PRODUCTS_SUCCESS:
      return {
        ...state,
        TDAllProducts: {
          ...state.TDAllProducts,
          data: action.products,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case TD_ALL_PRODUCTS_LOADING:
      return {
        ...state,
        TDAllProducts: {
          ...state.TDAllProducts,
          status: DATA_STATUS.LOADING,
        },
      };
    case TD_ALL_PRODUCTS_ERROR:
      return {
        ...state,
        TDAllProducts: { ...initialState.TDAllProducts, response: action.error },
      };
    case TD_PRODUCTS_DETAILS_SUCCESS:
      return {
        ...state,
        TDProductDetails: {
          ...state.TDProductDetails,
          data: action.productsDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case TD_PRODUCTS_DETAILS_LOADING:
      return {
        ...state,
        TDProductDetails: {
          ...state.TDProductDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case TD_PRODUCTS_DETAILS_ERROR:
      return {
        ...state,
        TDProductDetails: { ...initialState.TDProductDetails, response: action.error },
      };
    case TD_ALL_PRODUCTS_BY_LANID_SUCCESS:
      return {
        ...state,
        TDAllProductsBylanId: {
          ...state.TDAllProductsBylanId,
          data: action.products,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case TD_ALL_PRODUCTS_BY_LANID_LOADING:
      return {
        ...state,
        TDAllProductsBylanId: {
          ...state.TDAllProductsBylanId,
          status: DATA_STATUS.LOADING,
        },
      };
    case TD_ALL_PRODUCTS_BY_LANID_ERROR:
      return {
        ...state,
        TDAllProductsBylanId: { ...initialState.TDAllProductsBylanId, response: action.error },
      };
    case PRODUCTS_CONTACT_DETAILS_SUCCESS:
      return {
        ...state,
        ProductContactDetails: {
          ...state.ProductContactDetails,
          data: action.productsDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case PRODUCTS_CONTACT_DETAILS_LOADING:
      return {
        ...state,
        ProductContactDetails: {
          ...state.ProductContactDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case PRODUCTS_CONTACT_DETAILS_ERROR:
      return {
        ...state,
        ProductContactDetails: { ...initialState.ProductContactDetails, response: action.error },
      };
    case PRODUCTS_TEAM_DETAILS_SUCCESS:
      return {
        ...state,
        ProductTeamDetails: {
          ...state.ProductTeamDetails,
          data: action.teamDetails,
          status: DATA_STATUS.SUCCESS,
        },
      };
    case PRODUCTS_TEAM_DETAILS_LOADING:
      return {
        ...state,
        ProductTeamDetails: {
          ...state.ProductTeamDetails,
          status: DATA_STATUS.LOADING,
        },
      };
    case PRODUCTS_TEAM_DETAILS_ERROR:
      return {
        ...state,
        ProductTeamDetails: { ...initialState.ProductTeamDetails, response: action.error },
      };
    default:
      return state;
  }
};

export default TDProductsReducer;

