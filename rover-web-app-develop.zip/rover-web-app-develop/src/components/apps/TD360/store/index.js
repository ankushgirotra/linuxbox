import TDProductsReducer from './tdProducts.reducer';

const TechnicalDeliveryReducer = {

    TDProductsReducer,

};

export { TechnicalDeliveryReducer };
