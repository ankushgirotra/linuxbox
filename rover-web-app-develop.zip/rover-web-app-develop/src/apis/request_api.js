import axios from 'axios';
import cookie from 'react-cookies';


const fetchClient = () => {
  // const DOMAIN = `https://rover-web-api-request-test.cfaa.azr.hcsctest.net`;
  const DOMAIN = cookie.load('ROVER_REQUEST_API');

  const payloadOptions = {
    baseURL: DOMAIN,
    headers: {
      'Content-Type': 'application/json'
    }
  };

  const instance = axios.create(payloadOptions);

  instance.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    config.headers.Authorization = token ? `Bearer ${token}` : "";
    return config;
  });
  return instance;
};

export default fetchClient();