import axios from 'axios';
import cookie from 'react-cookies';

const fetchClient = () => {
  const DOMAIN = cookie.load('ROVER_PCD_API')
 // const DOMAIN = `https://rover-web-api-pcd-test.cfaa.azr.hcsctest.net`;
  const payloadOptions = {
    baseURL: DOMAIN,
    headers: {
      'Content-Type': 'application/json'
    }
  };

  // Create instance
  const instance = axios.create(payloadOptions);

  instance.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    //config.headers.Authorization = token ? `${token}` : '';
    config.headers.Authorization = token ? `Bearer ${token}` : '';
    return config;
  });
  return instance;
};

export default fetchClient();