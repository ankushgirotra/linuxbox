import axios from "axios";
import cookie from "react-cookies";

const fetchClient = () => {
  const payloadOptions = async () => ({
    baseURL: await cookie.load("ROVER_WEB_API"),
    headers: {
      "Content-Type": "application/json",
    },
  });
  // Create instance
  const instance = axios.create(payloadOptions());

  instance.interceptors.request.use((config) => {
    const token = localStorage.getItem("token");
    config.headers.Authorization = token ? `Bearer ${token}` : "";
    return config;
  });
  return instance;
};

export default fetchClient();
