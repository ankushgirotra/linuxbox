
const axios = jest.genMockFromModule('axios');

axios.create = jest.fn(() => axios);
axios.get = jest.fn((url) => Promise.resolve({ data: {} }));
axios.post = jest.fn((url, params) => Promise.resolve({ data: {} }));
axios.put = jest.fn((url, params) => Promise.resolve({ data: {} }));
axios.delete = jest.fn((url, params) => Promise.resolve({ data: {} }));

export default axios;