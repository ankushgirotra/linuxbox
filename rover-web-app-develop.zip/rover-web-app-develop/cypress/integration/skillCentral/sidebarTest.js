describe('Upon visiting the Rover Skills Central', () => {
  it('the user clicked on "Rover Skills Central" at sidebar will navigate to Rover Skills Central Dashboard page', () => {
    cy.visit('/');
    cy.loginAs('admin', 'password');
    cy.visit('/');
    cy.wait(3000);
    cy.get('ul').contains('Apps').click();
    cy.get('ul').contains('Rover Skills Central').click();
    cy.wait(3000);
    cy.url().should('include', '/skillscentral');
  });
});
