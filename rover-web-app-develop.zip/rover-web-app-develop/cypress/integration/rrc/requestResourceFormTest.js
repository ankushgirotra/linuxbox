describe('Upon visiting the Rover RRC', () => {
  beforeEach(() => {
    cy.loginAs('admin', 'password');
    cy.saveLocalStorage();
    cy.visit('/configs');
    cy.visit('/');
    cy.restoreLocalStorage();
    cy.visit('/rrc');
    cy.wait(1000);
  });

  it('When user clicks on "Create Request" in the sidebar, the Create Request form renders as modal with correct initial fields', () => {
    cy.get('ul').contains('Request').click();
    cy.get('ul').contains('Create Request').click();
    cy.get('#contained-modal-title-vcenter').contains('Create Request');
    cy.contains('Template');
    cy.contains('Portfolio');
    cy.contains('Product');
    cy.contains('Application');
    cy.contains('Skills');
    cy.contains('Start Date');
    cy.contains('End Date');
    cy.contains('Allocation %');
    cy.contains('# of Resources Needed');
    cy.contains('Role');
    cy.contains('Resource Type');
    cy.contains('Title');
    cy.contains('Degree');
    cy.contains('Locations');
    cy.contains('Notes');
    cy.get('#saveDraft').contains('Save as Draft');
  });
  //
  it('The user is able to create a request draft by interacting with all fields in the UI', () => {
    cy.contains('Create Request').click();
    cy.get('#selectportfolio').click().contains('DevOps').click();
    cy.get('#selectproduct').click().contains('PRODUCT Application Services').click();
    cy.get('#selectapplication').click().contains('AppInsight').click();
    cy.contains('Product Code');
    cy.get('#PRD_Code').next().get('b').contains('PRD00000171');
    cy.get('#domainOwner').next().get('b').contains('Treacy, Carroll');
    cy.get('#selectskills').click().contains('JAVA').click();
    cy.get('input[type=date]').get('#startDate').type('2020-09-18');
    cy.get('input[type=date]').get('#endDate').type('2021-09-18');
    cy.get('#allocation').type('35');
    cy.get('#selectrole').click().contains('Developer').click();
    cy.get('#selecttitle').click().contains('Sr Developer').click();
    cy.get('#selectdegree').click().contains('Third Degree').click();
    cy.get('#selectresourceType').click().contains('Employee').click();
    cy.get('#CHICAGO').check();
    cy.contains('Notes').next().get('textarea').type('Toms New Draft Request.');
    cy.get('#saveDraft').click();
    cy.contains('Name of Draft');
    cy.get('#draftName').type('Toms New Draft');
    cy.get('#modalSaveButton').click();
    cy.contains('Create Request').click();
    cy.get('#selectportfolio').should('have.value', '');
    cy.get('#selectproduct').should('have.value', '');
    cy.get('#selectapplication').should('have.value', '');
    cy.get('#selectskills').should('have.value', '');
    cy.get('input[type=date]').should('have.value', '');
    cy.get('input[type=date]').should('have.value', '');
    cy.get('#allocation').should('have.value', '');
    cy.get('#selectrole').should('have.value', '');
    cy.get('#selecttitle').should('have.value', '');
    cy.get('#selectdegree').should('have.value', '');
    cy.get('#selectresourceType').should('have.value', '');
    cy.contains('Notes').next().get('textarea').should('have.value', '');
  });

  it('When user changes "Portfolio" selector, then "Product" and "Application" will reset', () => {
    cy.contains('Create Request').click();
    cy.get('#selectportfolio').click().contains('DevOps').click();
    cy.get('#selectproduct').click().contains('PRODUCT Application Services').click();
    cy.get('#selectapplication').click().contains('AppInsight').click();
    cy.get('#selectportfolio').click().contains('Digital Delivery').click();
    cy.contains('-------- Select Product --------');
    cy.contains('-------- Select Application --------');
  });

  it('When user changes "Product" selector, then "Application" resets and "Portfolio" remains the same', () => {
    cy.contains('Create Request').click();
    cy.get('#selectportfolio').click().contains('EMPCO').click();
    cy.get('#selectproduct').click().contains('PRODUCT Quality / RX').click();
    cy.get('#selectapplication').click().contains('Prime Therapeutics RX').click();
    cy.get('#selectproduct').click().contains('PRODUCT Care Coordination - GPD').click();
    cy.contains('-------- Select Application --------');
  });

  it('When user changes "Role" selector, then "Title" and "Degree" fields will reset', () => {
    cy.contains('Create Request').click();
    cy.get('#selectrole').click().contains('Developer').click();
    cy.get('#selecttitle').click().contains('Sr Developer').click();
    cy.get('#selectdegree').click().contains('Second Degree').click();
    cy.get('#selectrole').click().contains('Development Lead').click();
    cy.contains('-------- Select Title --------');
    cy.contains('-------- Select Degree --------');
  });

  it('When user changes "Title" selector, then "Degree" will reset and "Role" will remain the same', () => {
    cy.contains('Create Request').click();
    cy.get('#selectrole').click().contains('Developer').click();
    cy.get('#selecttitle').click().contains('Sr Developer').click();
    cy.get('#selectdegree').click().contains('Third Degree').click();
    cy.get('#selecttitle').click().contains('Technology Associate').click();
    cy.contains('-------- Select Degree --------');
  });
});
