// Run cypress open in terminal
// Click on rover-test in popup window to run e2e test specs

describe('Upon visiting the Rover Web App', () => {
  beforeEach(() => {
    cy.loginAs('admin', 'password');
    cy.saveLocalStorage();
  });
  beforeEach(() => {
    cy.visit('/configs');
    cy.visit('/');
    cy.restoreLocalStorage();
  });
  it('the user visits the request drafts page and selects the first draft in the row', () => {
    cy.visit('/rrc/requestdrafts');
    cy.wait(3000);
    cy.get('div').contains('Draft_1').click();
    cy.wait(3000);
    cy.matchImageSnapshot('Request Draft #1', { capture: 'fullPage', scale: true });
  });
  it('the user visits the request drafts page and selects the second draft in the row', () => {
    cy.visit('/rrc/requestdrafts');
    cy.wait(3000);
    cy.get('div').contains('Draft_2').click();
    cy.wait(3000);
    cy.matchImageSnapshot('Request Draft #2', { capture: 'fullPage', scale: true });
  });
});
