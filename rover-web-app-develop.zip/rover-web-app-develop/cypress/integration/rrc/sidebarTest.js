describe('Upon visiting the Rover RRC', () => {
  it('the user clicked on "Request Templates" at sidebar will navigate to request templates page', () => {
    cy.visit('/');
    cy.loginAs('admin', 'password');
    cy.visit('/rrc');
    cy.wait(3000);
    cy.get('ul').contains('Request').click();
    cy.get('ul').contains('Request Templates').click();
    cy.wait(3000);
    cy.url().should('include', '/rrc/requesttemplates');
  });
});
describe('The "Data Upload" Page', () => {
  it('is visible when the logged-in user is "admin"', () => {
    cy.visit('/');
    cy.loginAs('admin', 'password');
    cy.visit('/rrc');
    cy.wait(2000);
    cy.get('ul').contains('Data Upload').click();
    cy.url().should('include', '/admin/upload');
    cy.wait(2000);
    cy.matchImageSnapshot('Data Upload Page -- Authorized Uploader', { capture: 'fullPage', scale: true });
  });
  it('is not visible when the logged-in user is "user"', () => {
    cy.visit('/');
    cy.loginAs('user', 'password');
    cy.visit('/rrc');
    cy.wait(2000);
    cy.get('ul').should('not.contain', 'Data Upload');
    cy.visit('/rrc/admin/upload');
    cy.wait(2000);
    cy.matchImageSnapshot('Data Upload Page -- User Not Authorized Uploader', { capture: 'fullPage', scale: true });
  });
});
