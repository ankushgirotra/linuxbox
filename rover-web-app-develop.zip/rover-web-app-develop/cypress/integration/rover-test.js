// Run cypress open in terminal
// Click on rover-test in popup window to run e2e test specs

describe('Rover Web App', () => {
  beforeEach(() => {
    cy.saveLocalStorage();
  });
  beforeEach(() => {
    cy.visit('/configs');
    cy.visit('/');
    cy.restoreLocalStorage();
  });
  it('Log in page works', () => {
    cy.visit('/login');
    cy.get('#username').type('admin').should('have.value', 'admin');
    cy.get('#password').type('password').should('have.value', 'password');
    cy.get('#signIn').click();
  });
});
