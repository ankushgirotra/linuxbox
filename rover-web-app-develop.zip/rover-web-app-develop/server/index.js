const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const pino = require('express-pino-logger')();
const request = require('request');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(pino);
app.use(cookieParser());

let sanitizer = (str) => {
  let temp = document.createElement("div");
  temp.textContent = str;
  return temp.innerHTML;
}

app.get('/configs', (req, res) => {
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.cookie('AUTH_SERVICE', process.env.REACT_APP_AUTH_SERVICE, { httpOnly: false })
  res.cookie('ROVER_WEB_API', process.env.REACT_APP_ROVER_WEB_API, { httpOnly: false });
  res.send();
});

app.post('/login', (req, res) => {
  res.header('Access-Control-Allow-Origin', sanitizer(req.headers.origin));
  res.header('Access-Control-Allow-Credentials', true);
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  req.pipe(request(process.env.REACT_APP_AUTH_SERVICE + '/v1/unauth/login')).pipe(res);
});

app.post('/refresh_api/:refresh_token', (req, res) => {
  res.header('Access-Control-Allow-Origin', sanitizer(req.headers.origin));
  res.header('Access-Control-Allow-Credentials', true);
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  req.pipe(request(process.env.REACT_APP_AUTH_SERVICE + `/v1/unauth/refresh?grant_type=refresh_token&refresh_token:${req.params.refresh_token}`)).pipe(res);
});

app.listen(3001, () =>
  console.log('Express server is running on localhost:3001')
);
